#!/bin/sh
# Build a private release directory and archive from a clean commit.
#   tools/release.sh OUTDIR
# Writes OUTDIR/agent-loop-<commit>/ and OUTDIR/agent-loop-<commit>.tar.gz.
# Installs nothing, enables nothing, publishes nothing.
set -eu
out=$(cd "$1" && pwd)
top=$(git rev-parse --show-toplevel)
cd "$top"
if [ -n "$(git status --porcelain)" ]; then echo "release: working tree not clean" >&2; exit 1; fi
commit=$(git rev-parse HEAD)
short=$(git rev-parse --short=12 HEAD)
rel="$out/agent-loop-$short"
rm -rf "$rel"; mkdir -p "$rel/bin"
git archive --format=tar.gz --prefix="agent-loop-$short-src/" -o "$rel/agent-loop-$short-src.tar.gz" "$commit"
CGO_ENABLED=0 go build -trimpath -o "$rel/bin/agent-loop" ./cmd/agent-loop
cp README.md TRACKING.md "$rel/"
cp -r docs examples LICENSES "$rel/"
mkdir -p "$rel/provenance"
cp conformance/PROVENANCE.json conformance/host/adjudicated.json "$rel/provenance/"
python3 - "$rel" "$commit" <<'PY'
import hashlib, json, subprocess, sys, os
rel, commit = sys.argv[1], sys.argv[2]
b = os.path.join(rel, "bin", "agent-loop")
mods = subprocess.run(["go", "version", "-m", b], capture_output=True, text=True).stdout.replace(rel + "/", "")
json.dump({"commit": commit, "binary_sha256": hashlib.sha256(open(b, "rb").read()).hexdigest(),
           "build": "CGO_ENABLED=0 go build -trimpath ./cmd/agent-loop",
           "go_version_m": mods.splitlines(),
           "label": "SUPERVISED PREVIEW / NOT QUALIFIED FOR UNATTENDED USE"},
          open(os.path.join(rel, "BUILD.json"), "w"), indent=1)
PY
(cd "$rel" && find . -type f ! -name MANIFEST.sha256 | sort | xargs sha256sum > MANIFEST.sha256)
tar -C "$out" -czf "$rel.tar.gz" "agent-loop-$short"
echo "$rel.tar.gz"
