#!/usr/bin/env python3
"""Sort past lost completions into their cause, from the workers' own history.

    python backtest_wakes.py LEDGER.tsv HISTORY.jsonl [HISTORY.jsonl ...]

A lost completion is a ledger COMPLETED row whose note says the completion was
lost ("lost completion", "lost wake", "found in history not inbox", "no wake
sent"). For each one, the worker's history (every tool call with its command
and output) is searched between the dispatch row and the completion row for
wake attempts, and the case is:

  a  no wake attempt at all in that window (the worker never sent one)
  b  a wake attempt whose output is an error (it was sent and failed)
  c  a wake attempt whose output says started/queued (it arrived; the
     controller did not act on it)

Reads only; prints one line per loss and a total.
"""
import datetime
import json
import re
import sys

LOST = re.compile(r"lost (completion|wake)|found in history not inbox|no wake sent", re.I)


def ts(s):
    if len(s) == 17 and s.endswith("Z"):
        s = s[:16] + ":00Z"
    return datetime.datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(
        tzinfo=datetime.timezone.utc).timestamp()


def hms(t):
    return datetime.datetime.fromtimestamp(t, datetime.timezone.utc).strftime("%H:%M:%S")


def main():
    rows = [l.rstrip("\n").split("\t") for l in open(sys.argv[1], encoding="utf-8")]
    calls = []
    for path in sys.argv[2:]:
        seen = set()
        for line in open(path, encoding="utf-8", errors="replace"):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            title = r.get("title") or ""
            if r.get("role") not in ("tool", "assistant"):
                continue
            if r.get("role") == "assistant":
                calls.append((r.get("at", 0), "__assistant__", r.get("text") or "", None))
                continue
            if "wake" not in title and "socket" not in title:
                continue
            key = (r.get("id"), r.get("status"))
            if key in seen:
                continue
            seen.add(key)
            calls.append((r.get("at", 0), title, str(r.get("output") or ""), r.get("status")))
    calls.sort()
    dispatched = {}
    counts = {"a": 0, "b": 0, "c": 0}
    for f in rows:
        if len(f) < 7:
            continue
        if f[3] == "DISPATCHED":
            dispatched[f[2]] = ts(f[0])
            continue
        if f[3] != "COMPLETED" or not LOST.search(f[6]):
            continue
        start = dispatched.get(f[2])
        if start is None:
            continue
        end = ts(f[0]) + 60
        window = [c for c in calls if start - 60 <= c[0] <= end]
        # A wake attempt is a command that invokes a wake program for cairn;
        # a file that merely mentions cairn or a receipt quoting an old wake
        # reply is not one (both fooled the first version of this).
        tries = [c for c in window if c[1] != "__assistant__" and
                 re.search(r"wake\S*\s+['\"]?cairn\b|cairn-wake|wake-cairn", c[1])]
        said = [c for c in window if c[1] == "__assistant__"]
        if not tries:
            case = "a"
            stall = [c for c in said if "[stall]" in c[2]]
            if stall:
                why = "turn KILLED by the stall watchdog at %s: %s" % (hms(stall[-1][0]), stall[-1][2][:80])
                counts["a:stall"] = counts.get("a:stall", 0) + 1
            elif said:
                why = "turn ended without a wake; last words at %s: %s" % (
                    hms(said[-1][0]), re.sub(r"\s+", " ", said[-1][2])[-110:])
            else:
                why = "no wake and no reply in the worker's history"
        else:
            outs = " | ".join(re.sub(r"\s+", " ", c[2])[:120] for c in tries)
            if any(re.search(r"^wake: cairn -> (started|queued)|\bwake: cairn -> (started|queued)", c[2]) for c in tries):
                case, why = "c", outs
            else:
                case, why = "b", outs
        counts[case] += 1
        print("%s  %-24s done %s  tries=%d  %s" % (case, f[2], f[0][11:16], len(tries), why[:230]))
    print("\ntotal: %d lost  a=%d (never sent; %d of them: turn killed by the stall watchdog)  "
          "b=%d (sent, failed)  c=%d (arrived, not acted on)"
          % (counts["a"] + counts["b"] + counts["c"], counts["a"], counts.get("a:stall", 0),
             counts["b"], counts["c"]))


if __name__ == "__main__":
    main()
