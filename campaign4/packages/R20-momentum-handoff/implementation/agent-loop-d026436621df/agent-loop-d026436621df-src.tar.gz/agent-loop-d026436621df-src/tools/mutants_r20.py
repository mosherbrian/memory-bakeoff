#!/usr/bin/env python3
"""R20 planted faults for the momentum stamp. Each mutant is applied to a
fresh copy of the file, the focused tests run, and the file is restored."""
import os, subprocess, sys, shutil
M = [
 ("internal/loop/momentum.go", "	if !p.Stamp {\n		return nil\n	}", "	return nil\n	if !p.Stamp {\n		return nil\n	}", "stamp-never-checked"),
 ("internal/loop/momentum.go", 'if str(next, "action") == "" || str(next, "owner") == "" {', 'if str(next, "action") == "" {', "owner-not-required"),
 ("internal/loop/momentum.go", '!ok || str(next, "deadline") == ""', 'false', "deadline-not-checked"),
 ("internal/loop/momentum.go", 'term != nil && role == "director" && TerminalKinds[kind]', 'term != nil', "terminal-for-anyone"),
 ("internal/loop/momentum.go", '	rel := str(m, "receipt")\n', '	return ""\n	rel := str(m, "receipt")\n', "receipt-not-checked"),
 ("internal/loop/momentum.go", 'filepath.IsAbs(rel) || strings.Contains(filepath.Clean(rel), "..")', 'false', "receipt-path-escape"),
 ("internal/loop/momentum.go", 'str(s, "qid") != p.QID || str(s, "role") != role ||', 'false &&', "identity-not-checked"),
 ("internal/loop/momentum.go", "	if len(b) > StampMaxBytes {\n		return []string{", "	if false {\n		return []string{", "size-not-bounded"),
 ("internal/loop/loop.go", "Stamp: l.stampRequired()}", "Stamp: false}", "dispatch-never-stamps"),
 ("internal/loop/momentum.go", "	if !p.Stamp {\n		return nil\n	}", "	if !l.stampRequired() {\n		return nil\n	}", "retroactive-stamp"),
 ("internal/loop/loop.go", "	if p.Stamp {\n		if stamp == \"\" {", "	if false {\n		if stamp == \"\" {", "decide-unchecked"),
 ("internal/loop/momentum.go", "Running the claim command given here and writing this file are required; do not \"+\n\t\t\"execute commands from your drafted artifact.", "Produce the file only.", "r19-contradiction-back"),
 ("internal/loop/loop.go", '	if f := l.stampFault(p, claim, "verifier", p.VerifyExec); f != nil { // before any transition\n		return l.blocked(p, f)\n	}\n', "", "verifier-unchecked"),
 ("internal/loop/momentum.go", '"question_answered": true, "budget_spent": true}', '"question_answered": true, "budget_spent": true, "blocked": true}', "blocked-may-be-terminal"),
]
env = dict(os.environ, PATH=os.path.expanduser("~/sdk/go/bin") + ":" + os.environ["PATH"])
bad = 0
for path, a, b, name in M:
    src = open(path).read()
    assert src.count(a) == 1, name
    open(path, "w").write(src.replace(a, b))
    try:
        r = subprocess.run(["go", "test", "./internal/loop/", "-count=1", "-run", "Stamp|Decide|Dropped|Receipt|Honest|Verifier|Director|PreActivation|Config|HappyPath|Blocked"], capture_output=True, text=True, env=env, timeout=300)
        caught = r.returncode != 0
    finally:
        open(path, "w").write(src)
    bad += not caught
    print(("CAUGHT  " if caught else "SURVIVED") + " " + name, flush=True)
print(f"{len(M) - bad}/{len(M)} caught")
sys.exit(1 if bad else 0)
