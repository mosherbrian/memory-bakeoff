#!/bin/bash
# P13 private watcher test: (a) on ledgers WITHOUT resolution records the private
# watcher behaves exactly as the installed one (same output, same pages, same
# state); (b) recurrence -> decision (resolve) -> no page; recurrence -> no
# decision -> page; a record raised AFTER the resolution still pages; the
# installed escalations tool still lists pending with a resolution record present.
# Usage: watch_test.sh INSTALLED_WATCHER PRIVATE_WATCHER RESOLVER ESCALATIONS
set -u; IW=$1; PW=$2; RES=$3; ESC=$4; n=0; bad=0
chk() { n=$((n+1)); if [ "$2" = "$3" ]; then echo "ok   $1"; else bad=$((bad+1)); echo "FAIL $1: want [$2] got [$3]"; fi; }
now=$(date +%s)
mk() { # DIR JSONL-LINES
  rm -rf $1; mkdir -p $1/.local/share/agent-deck $1/.config/agent-deck
  printf '#!/bin/sh\necho "PAGE $*" >> %s/pages\ncat >> %s/pages\n' $1 $1 > $1/.config/agent-deck/ticket; chmod +x $1/.config/agent-deck/ticket
  printf '%s\n' "$2" > $1/.local/share/agent-deck/escalations.jsonl; }
run() { HOME=$1 ESCALATION_GRACE_MIN=${3:-45} python $2 > $1/out 2>&1; echo "rc=$?" >> $1/out; }
T=$(mktemp -d)
old=$((now-7200)); a=$((now-3600)); rec=$((now-1800))
CORPUS=(
 ""
 "{\"t\": $old, \"id\": \"E-1\", \"kind\": \"k\", \"key\": \"aaaaaaaaaaaa\", \"text\": \"one\"}"
 "{\"t\": $old, \"id\": \"E-1\", \"kind\": \"k\", \"key\": \"aaaaaaaaaaaa\", \"text\": \"one\"}
{\"t\": $a, \"ack\": \"E-1\", \"note\": \"x\"}
{\"t\": $rec, \"id\": \"E-2\", \"kind\": \"k\", \"key\": \"aaaaaaaaaaaa\", \"text\": \"one\"}"
 "{\"t\": $now, \"id\": \"E-3\", \"kind\": \"k\", \"key\": \"bbbbbbbbbbbb\", \"text\": \"fresh\"}"
 "{\"t\": $old, \"id\": \"E-1\", \"kind\": \"k\", \"key\": \"aaaaaaaaaaaa\", \"text\": \"one\"}
{\"t\": $a, \"ack\": \"E-1\", \"note\": \"x\"}"
)
for i in "${!CORPUS[@]}"; do
  mk $T/i$i "${CORPUS[$i]}"; mk $T/p$i "${CORPUS[$i]}"; run $T/i$i $IW; run $T/p$i $PW
  chk "non-P13 corpus $i: identical output" "$(cat $T/i$i/out)" "$(cat $T/p$i/out)"
  chk "non-P13 corpus $i: identical pages" "$(cat $T/i$i/pages 2>/dev/null | sed 's/raised [0-9]* min/raised N min/')" "$(cat $T/p$i/pages 2>/dev/null | sed 's/raised [0-9]* min/raised N min/')"
  chk "non-P13 corpus $i: identical state" "$(python -c "import json;print(json.load(open('$T/i$i/.local/share/agent-deck/escalation-watch.json'))['told'])" 2>/dev/null)" "$(python -c "import json;print(json.load(open('$T/p$i/.local/share/agent-deck/escalation-watch.json'))['told'])" 2>/dev/null)"
done
# recurrence -> decision (resolution) -> no page
mk $T/r "${CORPUS[2]}"; HOME=$T/r python $RES aaaaaaaaaaaa D-Q-Q-v1 "decided" >/dev/null
before=$(md5sum < $T/r/.local/share/agent-deck/escalations.jsonl)
run $T/r $PW 0; chk "recurrence then decision: no page" "" "$(cat $T/r/pages 2>/dev/null)"
chk "resolution appended, earlier records kept" "4 3" "$(wc -l < $T/r/.local/share/agent-deck/escalations.jsonl) $(head -3 $T/r/.local/share/agent-deck/escalations.jsonl | grep -c t)"
chk "installed escalations --pending works with a resolution record" "0" "$(HOME=$T/r python $ESC --pending >/dev/null 2>&1; echo $?)"
# recurrence -> no decision -> page
mk $T/u "${CORPUS[2]}"; run $T/u $PW 0; chk "recurrence unresolved: pages RECURRED (listed twice: stale and recurred, installed behaviour)" "2" "$(grep -c "RECURRED AFTER AN ACK" $T/u/pages 2>/dev/null)"
# a record AFTER the resolution is a new condition
mk $T/n "${CORPUS[2]}"; HOME=$T/n python $RES aaaaaaaaaaaa D-Q-Q-v1 "decided" >/dev/null; sleep 1
echo "{\"t\": $(( $(date +%s) + 1 )), \"id\": \"E-9\", \"kind\": \"k\", \"key\": \"aaaaaaaaaaaa\", \"text\": \"one\"}" >> $T/n/.local/share/agent-deck/escalations.jsonl
run $T/n $PW 0; chk "record after the resolution still pages" "1" "$(grep -c 'E-9' $T/n/pages 2>/dev/null)"
chk "an ack alone (no resolution) is not terminal: unresolved stale pages" "1" "$(mk $T/s "${CORPUS[1]}"; run $T/s $PW 0; grep -c 'E-1' $T/s/pages 2>/dev/null)"
chk "resolver refuses a malformed key" "1" "$(HOME=$T/r python $RES notakey D x >/dev/null 2>&1; echo $?)"
echo "TOTAL $n checks, $bad wrong"; [ $bad -eq 0 ]
