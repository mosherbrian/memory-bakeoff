#!/usr/bin/env python
"""Python conformance adapter: replay cases against a Python core.

    python replay_py.py SRC_DIR CASE.json [CASE.json ...]

Prints one JSON line per case: {"case", "steps", "ok", "first_diff"}.
Exit 0 only if every step of every case matched.

This is the reference adapter. Replaying the recording on the SAME source it
was recorded from must match 100%; anything less means the recording format
missed something, and no other implementation can be judged against it.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pyharness as H  # noqa: E402
from compare import first_diff  # noqa: E402


class AutoPaths(H.Paths):
    """Creates a fresh real directory the first time a case names one."""

    def __init__(self, root):
        super().__init__()
        self.root = root

    def real(self, p):
        head = p.partition("/")[0]
        if head not in self.name_to_real:
            self.add(tempfile.mkdtemp(dir=self.root), head)
        return super().real(p)


def run_case(case, mods):
    driver, tokens_box = mods["driver"], mods["tokens"]
    root = tempfile.mkdtemp(prefix="replay-")
    paths, objs, refs, closed = AutoPaths(root), {}, {}, set()
    tokens_box[0] = H.Tokens()

    def register(o, oid):
        objs[oid] = o
        refs[id(o)] = oid

    try:
        for i, st in enumerate(case["steps"]):
            args = H.deser(st.get("args", []), paths, objs)
            kwargs = H.deser(st.get("kwargs", {}), paths, objs)
            outcome = None
            try:
                if st["op"] == "new":
                    cls = getattr(mods["store"] if st["class"] == "Store" else driver, st["class"])
                    o = cls(*args, **kwargs)
                    register(o, st["id"])
                    if st["class"] == "Driver":
                        for a in ("store", "ingress", "world", "clock"):
                            if id(getattr(o, a)) not in refs:
                                register(getattr(o, a), "%s.%s" % (st["id"], a))
                    res = None
                elif st["op"] == "call":
                    o = objs[st["target"]]
                    res = getattr(o, st["method"])(*args, **kwargs)
                    if st["method"] == "close":
                        closed.add(st["target"])
                elif st["op"] == "func":
                    m, _, n = st["name"].partition(".")
                    res = getattr(mods[m], n)(*args, **kwargs)
                elif st["op"] == "setattr":
                    setattr(objs[st["target"]], st["attr"],
                            H.deser(st["value"], paths, objs))
                    res = None
                else:
                    raise ValueError("unknown op " + st["op"])
                outcome = {"return": H.ser(res, paths, refs)}
            except Exception as e:  # the case says what, if anything, raises
                if st["op"] == "call" and st["method"] == "close":
                    closed.add(st["target"])
                outcome = {"raise": H.ser_exc(e, paths, refs)}
            got = {"expect": outcome,
                   "state": H.dump_state(objs, closed, paths, refs)}
            want = {"expect": st["expect"], "state": st["state"]}
            d = first_diff(want, got)
            if d:
                return {"case": case["id"], "steps": len(case["steps"]),
                        "ok": False, "first_diff": "step %d (%s %s): %s" % (
                            i, st["op"], st.get("method") or st.get("name")
                            or st.get("class") or st.get("attr"), d)}
        return {"case": case["id"], "steps": len(case["steps"]), "ok": True}
    finally:
        for o in objs.values():
            if isinstance(o, (driver.Driver, mods["store"].Store)):
                try:
                    o.close()
                except Exception:
                    pass
        shutil.rmtree(root, ignore_errors=True)


def main():
    src = os.path.abspath(sys.argv[1])
    sys.path.insert(0, src)
    import driver
    import ingress
    import supervisor
    import status
    import validator
    import lifecycle
    import store
    tokens = [H.Tokens()]
    ingress.secrets = type("S", (), {"token_hex": staticmethod(
        lambda n=32: tokens[0].token_hex(n))})
    mods = {"driver": driver, "supervisor": supervisor, "status": status,
            "validator": validator, "lifecycle": lifecycle, "store": store,
            "tokens": tokens}
    bad = 0
    for p in sys.argv[2:]:
        with open(p) as fh:
            r = run_case(json.load(fh), mods)
        bad += not r["ok"]
        print(json.dumps(r, sort_keys=True))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
