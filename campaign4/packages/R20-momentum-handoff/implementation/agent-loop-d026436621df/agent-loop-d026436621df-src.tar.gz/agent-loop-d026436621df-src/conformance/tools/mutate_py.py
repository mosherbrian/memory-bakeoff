#!/usr/bin/env python
"""Proof that the suite can fail: plant one fault at a time in a copy of the
reference source and require the replay to catch it.

    python mutate_py.py SRC_DIR TESTS_DIR CASES_DIR

For each mutant this also runs the ORIGINAL pytest suite, so the report shows
what the recording catches that the hand-written asserts did not. A mutant
that survives both is a gap in the suite, reported by name; it is not an
error in this tool.
"""
from __future__ import annotations

import glob
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))

# (file, exact original text, replacement, what the fault means)
MUTANTS = [
    ("lifecycle.py", "        if now_i > dl_i:\n",
     "        if now_i >= dl_i:\n", "publish AT the deadline refused"),
    ("lifecycle.py", '        if st.get("disposition") is not None:\n            raise TransitionError("E_ALREADY_DECIDED",',
     '        if False:\n            raise TransitionError("E_ALREADY_DECIDED",',
     "R13 undone: a second decide replaces the first"),
    ("lifecycle.py", '    if event.get("actor", {}).get("seat") == producer:',
     '    if False:', "R13 undone: the producer may verify its own work"),
    ("lifecycle.py", '        st["producer_seat"] = event.get("actor", {}).get("seat")',
     '        st["producer_seat"] = "nobody"', "R13 undone: the producer is not recorded"),
    ("ingress.py", '        if "decide" in atomic and atomic.get("grant_ref") is not None:',
     '        if False:', "R13 undone: decide + grant_ref accepted"),
    ("store.py", '        for ev in (verdict_event, decide_event):\n            if ev["event_id"] in self.seen_events:\n                raise TransitionError("E_DUP_EVENT", ev["event_id"])',
     '        for ev in (verdict_event, decide_event):\n            pass',
     "R13 undone: no duplicate check before the pair's transaction"),
    ("lifecycle.py", "HARD_RECOVERY_MAX_S = 600", "HARD_RECOVERY_MAX_S = 601",
     "recovery ceiling off by one second"),
    ("lifecycle.py", 'if st["attempt"] >= budget["attempts"]:',
     'if st["attempt"] > budget["attempts"]:', "one extra attempt allowed"),
    ("lifecycle.py", 'if st.get("disposition") is not None:\n            raise TransitionError("E_BAD_TRANSITION", "already closed")',
     'pass', "decision task on a closed package allowed"),
    ("store.py", "        self.seen_events.add(eid)\n        for extra in extra_rows:",
     "        for extra in extra_rows:", "appended event not marked seen"),
    ("store.py", '"decided_by"] = "tern"', '"decided_by"] = "cairn"',
     "snapshot attributes decisions to the wrong seat"),
    ("store.py", 'self.set_ack(aid, "acknowledged" if body.get("acknowledged")',
     'self.set_ack(aid, "acknowledged" if True',
     "every start recorded as acknowledged"),
    ("ingress.py", "NESTED_DEADLINE_CAP_S = 86400", "NESTED_DEADLINE_CAP_S = 86401",
     "nested deadline cap off by one second"),
    ("ingress.py", "FUTURE_SKEW_TOLERANCE_S = 120", "FUTURE_SKEW_TOLERANCE_S = 121",
     "future skew tolerance off by one second"),
    ("ingress.py", 'for forged in ("recorded_at", "receipt", "_trusted", "phase_hint"):',
     'for forged in ("recorded_at", "receipt", "_trusted"):',
     "caller phase hints accepted"),
    ("ingress.py", 'if "hold" in keys and "decide" in keys:',
     'if False:', "mixed hold+decide not rejected up front"),
    ("ingress.py", 'TRUSTED_SEATS = ("tern", "corvid", "kiln", "cairn")',
     'TRUSTED_SEATS = ("tern", "corvid", "kiln", "cairn", "mallory")',
     "an unknown seat is trusted"),
    ("driver.py", "if now is None or dl is None or now < dl:\n            return (\"no-op-early\", True)\n        stop_key",
     "if now is None or dl is None or now <= dl:\n            return (\"no-op-early\", True)\n        stop_key",
     "deadline exactly due treated as early"),
    ("driver.py", "        self.mark_handled(effect)  # durable ack: reopen cannot repeat",
     "        pass", "handled effect not recorded durably"),
    ("driver.py", 'self.ext.wake("tern", wake_reason)',
     'self.ext.wake("cairn", wake_reason)', "deadline wake goes to the wrong seat"),
    ("validator.py", "if dl is not None and dl < tnow:",
     "if dl is not None and dl <= tnow:", "in-flight exactly at deadline called overdue"),
    ("validator.py", 'if revisit is not None and revisit <= tnow and tid not in triggers_fired:',
     'if revisit is not None and revisit < tnow and tid not in triggers_fired:',
     "trigger exactly due not fired"),
    ("validator.py", 'return _invalid("E_CYCLE", "successor cycle at %s" % pid)',
     'return None', "successor cycles accepted"),
    ("supervisor.py", 'return {"verdict": "ACTIVE", "detail": "deduplicated; trigger %s already owned" % tid}, True',
     'return verdict, False', "ACTION_DUE not deduplicated"),
    ("status.py", '"duty": "cairn",', '"duty": "tern",', "status names the wrong duty seat"),
]


def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


def main():
    src, tests, cases = (os.path.abspath(p) for p in sys.argv[1:4])
    files = sorted(f for f in glob.glob(os.path.join(cases, "**", "*.json"),
                                        recursive=True)
                   if os.path.basename(f) != "RECORDING.json")
    root = tempfile.mkdtemp(prefix="mutate-")
    rows, gaps = [], 0
    for fname, old, new, meaning in MUTANTS:
        pkg = os.path.join(root, "pkg")
        shutil.rmtree(pkg, ignore_errors=True)
        shutil.copytree(src, os.path.join(pkg, "src"))
        shutil.copytree(tests, os.path.join(pkg, "tests"))
        path = os.path.join(pkg, "src", fname)
        text = open(path).read()
        if text.count(old) != 1:
            rows.append((fname, meaning, "NOT APPLIED (text not unique)", ""))
            gaps += 1
            continue
        open(path, "w").write(text.replace(old, new))
        rep = run([sys.executable, os.path.join(HERE, "replay_py.py"),
                   os.path.join(pkg, "src")] + files)
        failed = sum('"ok": false' in l for l in rep.stdout.splitlines())
        # Tests that pin an absolute path to their source never run the
        # mutated copy, so their pass/fail says nothing about the fault.
        pinned = any(src in open(os.path.join(dp, f), errors="replace").read()
                     for dp, _, fs in os.walk(tests) for f in fs if f.endswith(".py"))
        pt = None if pinned else run([sys.executable, "-m", "pytest", "-q",
                                      "-p", "no:cacheprovider", "tests"], cwd=pkg)
        caught_suite = "caught (%d cases)" % failed if failed else "SURVIVED"
        caught_py = "n/a (tests pin their src)" if pt is None else \
            ("caught" if pt.returncode else "survived")
        gaps += not failed
        rows.append((fname, meaning, caught_suite, caught_py))
    shutil.rmtree(root, ignore_errors=True)
    w = max(len(r[1]) for r in rows)
    print("%-13s %-*s  %-22s %s" % ("file", w, "planted fault", "conformance",
                                    "original pytest"))
    for f, m, a, b in rows:
        print("%-13s %-*s  %-22s %s" % (f, w, m, a, b))
    print("\n%d of %d mutants caught by the conformance suite" % (
        len(rows) - gaps, len(rows)))
    return 1 if gaps else 0


if __name__ == "__main__":
    sys.exit(main())
