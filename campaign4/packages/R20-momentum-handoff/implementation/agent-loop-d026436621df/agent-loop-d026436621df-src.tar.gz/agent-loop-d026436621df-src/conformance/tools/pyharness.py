"""Shared pieces of the Python recorder and the Python replay adapter.

Both must serialise values and dump state in exactly the same way, or the
replay would disagree with the recording for reasons that have nothing to do
with the code under test. So they share this one module.

Nothing here knows what a lifecycle is. It turns Python values into JSON and
reads the observable state of a live Driver.
"""
from __future__ import annotations

import json
import os


class Tokens:
    """Deterministic stand-in for secrets.token_hex, reset per case.

    The core draws random hex for ingress epochs. A recording must be
    replayable, so every implementation replaces the random source with this
    counter in conformance mode: the n-th call returns n as zero-padded hex
    of 2*nbytes characters.
    """

    def __init__(self):
        self.n = 0

    def token_hex(self, nbytes=32):
        self.n += 1
        return "%0*x" % (2 * nbytes, self.n)


class Paths:
    """Maps real temporary directories to stable names T1, T2, ..."""

    def __init__(self):
        self.real_to_name = {}
        self.name_to_real = {}

    def add(self, real, name=None):
        name = name or "T%d" % (len(self.real_to_name) + 1)
        self.real_to_name[real] = name
        self.name_to_real[name] = real
        return name

    def norm(self, s):
        for real, name in self.real_to_name.items():
            if s == real:
                return {"__path__": name}
            if s.startswith(real + os.sep):
                return {"__path__": name + s[len(real):]}
        return s

    def real(self, p):
        head, _, rest = p.partition("/")
        base = self.name_to_real[head]
        return os.path.join(base, rest) if rest else base


def ser(v, paths, refs):
    """Python value -> JSON value. Object references become {"__ref__": id}."""
    if isinstance(v, bool) or v is None or isinstance(v, (int, float)):
        return v
    if isinstance(v, str):
        return paths.norm(v)
    if isinstance(v, dict):
        return {str(k) if not isinstance(k, tuple) else "|".join(map(str, k)):
                ser(x, paths, refs) for k, x in v.items()}
    if isinstance(v, tuple):
        return {"__tuple__": [ser(x, paths, refs) for x in v]}
    if isinstance(v, list):
        return [ser(x, paths, refs) for x in v]
    if isinstance(v, (set, frozenset)):
        return {"__set__": sorted((ser(x, paths, refs) for x in v),
                                  key=lambda x: json.dumps(x, sort_keys=True))}
    rid = refs.get(id(v))
    if rid is not None:
        return {"__ref__": rid}
    raise TypeError("cannot serialise %r" % type(v).__name__)


def deser(v, paths, objs):
    if isinstance(v, list):
        return [deser(x, paths, objs) for x in v]
    if isinstance(v, dict):
        if set(v) == {"__path__"}:
            return paths.real(v["__path__"])
        if set(v) == {"__ref__"}:
            return objs[v["__ref__"]]
        if set(v) == {"__tuple__"}:
            return tuple(deser(x, paths, objs) for x in v["__tuple__"])
        if set(v) == {"__set__"}:
            return set(deser(x, paths, objs) for x in v["__set__"])
        return {k: deser(x, paths, objs) for k, x in v.items()}
    return v


def ser_exc(e, paths, refs):
    out = {"class": type(e).__name__}
    for attr in ("code", "detail", "owner", "evidence"):
        if hasattr(e, attr):
            out[attr] = ser(getattr(e, attr), paths, refs)
    if "code" not in out:
        out["str"] = str(e)
    return out


def dump_store(st, paths, refs):
    """A Store opened on its own (a test reopening a ledger to check it)."""
    try:
        st.conn.execute("SELECT 1")
    except Exception:
        return "closed"
    events = [
        {"event_id": r[0], "question_id": r[1], "revision": r[2],
         "type": r[3], "actor_seat": r[4], "actor_role": r[5], "at": r[6],
         "body": json.loads(r[7])}
        for r in st.conn.execute(
            "SELECT event_id, question_id, revision, type, actor_seat,"
            " actor_role, at, body FROM events ORDER BY rowid")]
    return ser({
        "events": events,
        "meta": dict(st.conn.execute("SELECT key, value FROM meta").fetchall()),
        "revisions": {"%s|%s" % k: v for k, v in st.revisions.items()},
        "seen_events": sorted(st.seen_events),
        "acks": st.acks,
    }, paths, refs)


def dump_driver(d, paths, refs):
    """Observable state of one open Driver: durable tables first, then the
    in-memory adapters a test can see."""
    conn = d.store.conn
    try:
        conn.execute("SELECT 1")
    except Exception:  # the store was closed directly, not through the Driver
        return "closed"
    events = [
        {"event_id": r[0], "question_id": r[1], "revision": r[2],
         "type": r[3], "actor_seat": r[4], "actor_role": r[5], "at": r[6],
         "body": json.loads(r[7])}
        for r in conn.execute(
            "SELECT event_id, question_id, revision, type, actor_seat,"
            " actor_role, at, body FROM events ORDER BY rowid")]
    meta = dict(conn.execute("SELECT key, value FROM meta").fetchall())
    kv = dict(conn.execute("SELECT key, value FROM driver_kv").fetchall())
    ing = d.ingress
    return ser({
        "events": events,
        "meta": meta,
        "driver_kv": kv,
        "revisions": {"%s|%s" % k: v for k, v in d.store.revisions.items()},
        "seen_events": sorted(d.store.seen_events),
        "acks": d.store.acks,
        "grants": d.grants,
        "timer": {"armed": d.timer.armed, "fired": sorted(d.timer.fired),
                  "removed": sorted(d.timer.removed)},
        "ext": {"stops": [list(x) for x in d.ext.stops],
                "wakes": [list(x) for x in d.ext.wakes],
                "notifications": [list(x) for x in d.ext.notifications]},
        "launches": d.launch.launches,
        "executor_runs": d.executor.runs,
        "inspect_calls": d.inspect.calls,
        "crash_points": sorted(d.crash_points),
        "ingress": {"epoch": ing.epoch, "last": ing._last,
                    "ambiguous": ing._ambiguous},
    }, paths, refs)


def dump_state(objs, closed, paths, refs):
    """State of every live object a case has named, keyed by its id."""
    import driver as drv
    import store as stmod
    out = {}
    for oid in sorted(objs):
        o = objs[oid]
        if oid in closed:
            out[oid] = "closed"
        elif isinstance(o, drv.Driver):
            out[oid] = dump_driver(o, paths, refs)
        elif isinstance(o, drv.FakeExternalWorld):
            out[oid] = ser(o.state, paths, refs)
        elif isinstance(o, stmod.Store) and "." not in oid:
            out[oid] = dump_store(o, paths, refs)
        elif isinstance(o, drv.FakeClock):
            out[oid] = {"now": o.now, "mono": o.monotonic()}
    return out
