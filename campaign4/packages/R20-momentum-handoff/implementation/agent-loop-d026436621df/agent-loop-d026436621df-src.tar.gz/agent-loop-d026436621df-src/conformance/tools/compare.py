"""The one comparison rule every adapter's output is judged by.

JSON values are equal when they have the same shape and the same leaves.
Objects compare by key set, arrays by position, and numbers by value
(1000 and 1000.0 are equal: Python keeps a float where Go may print an int).
Nothing is masked. A field that should not be compared must not be recorded.
"""


def first_diff(want, got, path="$"):
    """None if equal, else a one-line description of the first difference."""
    if isinstance(want, bool) or isinstance(got, bool):
        if want is got or (type(want) is type(got) and want == got):
            return None
        return "%s: want %r, got %r" % (path, want, got)
    if isinstance(want, (int, float)) and isinstance(got, (int, float)):
        return None if float(want) == float(got) else \
            "%s: want %r, got %r" % (path, want, got)
    if isinstance(want, dict) and isinstance(got, dict):
        if set(want) != set(got):
            return "%s: keys missing %s, extra %s" % (
                path, sorted(set(want) - set(got)),
                sorted(set(got) - set(want)))
        for k in sorted(want):
            d = first_diff(want[k], got[k], "%s.%s" % (path, k))
            if d:
                return d
        return None
    if isinstance(want, list) and isinstance(got, list):
        if len(want) != len(got):
            return "%s: length %d, got %d" % (path, len(want), len(got))
        for i, (a, b) in enumerate(zip(want, got)):
            d = first_diff(a, b, "%s[%d]" % (path, i))
            if d:
                return d
        return None
    if type(want) is not type(got) or want != got:
        return "%s: want %r, got %r" % (path, want, got)
    return None
