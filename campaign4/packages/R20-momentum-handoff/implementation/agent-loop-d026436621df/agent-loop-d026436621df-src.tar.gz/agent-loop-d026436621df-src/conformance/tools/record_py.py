#!/usr/bin/env python
"""Record the Python reference tests as language-neutral conformance cases.

    python record_py.py SRC_DIR TESTS_DIR OUT_DIR

Runs every test function in TESTS_DIR against the Python core in SRC_DIR,
with the core's public entry points wrapped. Each call a TEST makes (not the
core's own internal calls) is written as one step: the operation, its
arguments, what it returned or raised, and the full observable state after
it. One test function becomes one case file.

Why record instead of rewriting by hand: a hand conversion can drop an
assertion or weaken one, and nobody would notice. A recording contains
everything the test did, and the state dump after each step checks more than
the test's own asserts did. Every recorded case must then replay cleanly on
the same Python source (replay_py.py) before any other implementation is
compared against it.
"""
from __future__ import annotations

import functools
import hashlib
import importlib
import json
import os
import shutil
import sys
import tempfile
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pyharness as H  # noqa: E402

# Tests that inspect Python source text or read the host clock. They check
# properties of the Python files, not behaviour, so they have no portable
# form. Each implementation carries its own equivalent (see README).
NOT_PORTABLE = {
    "test_no_live_effects_possible": "reads Python source text",
    "test_no_alternate_public_write_path": "reads Python source text",
    "test_host_clock_adapter_reads_utc": "reads the real host clock",
    "test_A3_injected_second_insert_failure_rolls_back":
        "replaces Store._insert with a failing function (monkeypatch)",
}

DRIVER_METHODS = (
    "close", "admit_authorize", "start_dispatch", "acknowledge",
    "publish_completion", "verify", "terminal_close", "on_deadline",
    "on_handoff_deadline", "cancel_deadline", "is_cancelled", "handled",
    "mark_handled", "reconcile_restart", "reconstruct_timers",
    "dedupe_trigger", "pin_grant", "ledger", "snapshot", "_submit")
STORE_METHODS = ("append", "record_terminal", "set_ack", "ledger_view",
                 "ledger_revision", "publish_snapshot", "close")
INGRESS_METHODS = ("append", "record_terminal", "reconcile_clock")
CLOCK_METHODS = ("advance", "advance_wall_only", "advance_mono_only",
                 "utc_now", "monotonic")
WORLD_METHODS = ("record", "delivery")
FUNCS = (("supervisor", "supervise"), ("supervisor", "dedupe_action_due"),
         ("supervisor", "load_snapshot"), ("status", "status_report"),
         ("validator", "validate"), ("lifecycle", "apply"),
         ("lifecycle", "new_revision"))
SKIP_ATTRS = {"tmp", "db", "worldpath"}  # test bookkeeping stuck onto a Driver, not state


class Recorder:
    def __init__(self):
        self.depth = 0
        self.reset()

    def reset(self):
        self.steps = []
        self.objs = {}
        self.refs = {}
        self.closed = set()
        self.paths = H.Paths()
        self.tokens = H.Tokens()
        self.counters = {}

    def new_id(self, prefix):
        self.counters[prefix] = self.counters.get(prefix, 0) + 1
        return "%s%d" % (prefix, self.counters[prefix])

    def register(self, obj, oid):
        self.objs[oid] = obj
        self.refs[id(obj)] = oid

    def s(self, v):
        return H.ser(v, self.paths, self.refs)

    def emit(self, step, outcome):
        step["expect"] = outcome
        self.depth += 1  # reading state must not record calls of its own
        try:
            step["state"] = H.dump_state(self.objs, self.closed, self.paths,
                                         self.refs)
        finally:
            self.depth -= 1
        self.steps.append(step)


R = Recorder()


def top_level(fn):
    """Run fn with depth raised; report whether this is a test's own call."""
    @functools.wraps(fn)
    def w(*a, **kw):
        outer = R.depth == 0
        R.depth += 1
        try:
            return fn(outer, *a, **kw)
        finally:
            R.depth -= 1
    return w


def wrap_method(cls, name):
    orig = getattr(cls, name)

    @top_level
    def w(outer, self, *a, **kw):
        if not outer:
            return orig(self, *a, **kw)
        step = {"op": "call", "target": R.refs.get(id(self)),
                "method": name, "args": R.s(list(a)), "kwargs": R.s(kw)}
        try:
            res = orig(self, *a, **kw)
        except BaseException as e:
            if name == "close":
                R.closed.add(R.refs.get(id(self)))
            R.emit(step, {"raise": H.ser_exc(e, R.paths, R.refs)})
            raise
        if name == "close":
            R.closed.add(R.refs.get(id(self)))
        R.emit(step, {"return": R.s(res)})
        return res
    setattr(cls, name, w)


def wrap_func(mod, name):
    orig = getattr(mod, name)

    @top_level
    def w(outer, *a, **kw):
        if not outer:
            return orig(*a, **kw)
        step = {"op": "func", "name": "%s.%s" % (mod.__name__, name),
                "args": R.s(list(a)), "kwargs": R.s(kw)}
        try:
            res = orig(*a, **kw)
        except BaseException as e:
            R.emit(step, {"raise": H.ser_exc(e, R.paths, R.refs)})
            raise
        R.emit(step, {"return": R.s(res)})
        return res
    setattr(mod, name, w)


def wrap_init(cls, prefix, after=None):
    orig = cls.__init__

    @top_level
    def w(outer, self, *a, **kw):
        if not outer:
            return orig(self, *a, **kw)
        args, kwargs = R.s(list(a)), R.s(kw)
        orig(self, *a, **kw)
        oid = R.new_id(prefix)
        R.register(self, oid)
        if after:
            after(self, oid)
        R.emit({"op": "new", "class": cls.__name__, "id": oid,
                "args": args, "kwargs": kwargs}, {"return": None})
    cls.__init__ = w


def wrap_setattr(cls):
    orig = cls.__setattr__

    def w(self, attr, value):
        oid = R.refs.get(id(self))
        if R.depth > 0 or oid is None or attr in SKIP_ATTRS:
            return orig(self, attr, value)
        step = {"op": "setattr", "target": oid, "attr": attr,
                "value": R.s(value)}
        R.depth += 1
        try:
            orig(self, attr, value)
        finally:
            R.depth -= 1
        R.emit(step, {"return": None})
    cls.__setattr__ = w


def install(src):
    sys.path.insert(0, src)
    import driver
    import ingress
    import store
    import supervisor
    import status
    import validator
    import lifecycle
    import types
    # Older packages import the core as src.<module>. Point that name at the
    # same (wrapped) modules so both spellings are recorded.
    pkg = types.ModuleType("src")
    pkg.__path__ = []
    sys.modules["src"] = pkg
    for m in ("driver", "ingress", "store", "supervisor", "status",
              "validator", "lifecycle"):
        sys.modules["src." + m] = sys.modules[m]
        setattr(pkg, m, sys.modules[m])

    def driver_children(d, oid):
        for attr in ("store", "ingress"):
            R.register(getattr(d, attr), "%s.%s" % (oid, attr))
        for attr in ("world", "clock"):
            if id(getattr(d, attr)) not in R.refs:
                R.register(getattr(d, attr), "%s.%s" % (oid, attr))

    wrap_init(driver.FakeClock, "c")
    wrap_init(driver.FakeExternalWorld, "w")
    wrap_init(driver.Driver, "d", after=driver_children)
    wrap_init(store.Store, "s")
    for n in DRIVER_METHODS:
        wrap_method(driver.Driver, n)
    for n in STORE_METHODS:
        wrap_method(store.Store, n)
    for n in INGRESS_METHODS:
        wrap_method(ingress.TrustedIngress, n)
    for n in CLOCK_METHODS:
        wrap_method(driver.FakeClock, n)
    for n in WORLD_METHODS:
        wrap_method(driver.FakeExternalWorld, n)
    wrap_setattr(driver.Driver)
    wrap_setattr(driver.FakeClock)
    for m, n in FUNCS:
        wrap_func(sys.modules[m], n)
    ingress.secrets = R.tokens_proxy = type(
        "S", (), {"token_hex": staticmethod(
            lambda n=32: R.tokens.token_hex(n))})


def _unit(cls, name):
    def run():
        t = cls(name)
        t.setUp()
        try:
            getattr(t, name)()
        finally:
            t.tearDown()
    return run


def main():
    src, tests_dir, out = (os.path.abspath(p) for p in sys.argv[1:4])
    only = set(sys.argv[4:])  # optional: restrict to these test files
    install(src)
    root = tempfile.mkdtemp(prefix="record-")
    real_mkdtemp = tempfile.mkdtemp

    def mkdtemp(*a, **kw):
        kw["dir"] = root
        p = real_mkdtemp(*a, **kw)
        R.paths.add(p)
        return p
    tempfile.mkdtemp = mkdtemp

    sys.path.insert(0, os.path.dirname(tests_dir))
    manifest = {"cases": [], "not_portable": [], "failed": []}
    for fn in sorted(os.listdir(tests_dir)):
        if not (fn.startswith("test_") and fn.endswith(".py")):
            continue
        if only and fn not in only:
            continue
        modname = fn[:-3]
        mod = importlib.import_module("%s.%s" % (
            os.path.basename(tests_dir), modname))
        tests = [(n, f) for n, f in vars(mod).items()
                 if n.startswith("test_") and callable(f)]
        import unittest
        for cname, cls in vars(mod).items():
            if isinstance(cls, type) and issubclass(cls, unittest.TestCase):
                for n in sorted(vars(cls)):
                    if n.startswith("test_"):
                        tests.append(("%s.%s" % (cname, n), _unit(cls, n)))
        for name, f in tests:
            cid = "%s::%s" % (modname, name)
            if name in NOT_PORTABLE:
                f()  # still run it: it must pass on the reference
                manifest["not_portable"].append(
                    {"case": cid, "why": NOT_PORTABLE[name]})
                continue
            R.reset()
            try:
                f()
            except BaseException:
                manifest["failed"].append(
                    {"case": cid, "error": traceback.format_exc()})
                continue
            case = {"id": cid, "source": "tests/%s" % fn, "test": name,
                    "steps": R.steps}
            path = os.path.join(out, modname, name + ".json")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as fh:
                json.dump(case, fh, indent=1, sort_keys=True)
                fh.write("\n")
            manifest["cases"].append(
                {"case": cid, "steps": len(R.steps),
                 "file": os.path.relpath(path, out)})
    shutil.rmtree(root, ignore_errors=True)
    with open(os.path.join(out, "RECORDING.json"), "w") as fh:
        json.dump(manifest, fh, indent=1, sort_keys=True)
        fh.write("\n")
    print("recorded %d cases, %d not portable, %d FAILED" % (
        len(manifest["cases"]), len(manifest["not_portable"]),
        len(manifest["failed"])))
    for f in manifest["failed"]:
        print(f["case"], f["error"][-400:], sep="\n")
    return 1 if manifest["failed"] else 0


if __name__ == "__main__":
    sys.exit(main())
