#!/usr/bin/env python
"""Record the Python host adapter's behaviour on scripted scenarios.

    python host_py.py SRC_DIR SCENARIOS.json OUT.json

SRC_DIR is the reference r3harness directory. Each scenario builds a fresh
Driver (FakeClock) + HostAdapter in a temp dir, runs its ops, and records
every op's result or error code, then the final driver_kv and every
transport/runner call. internal/host/parity_test.go runs the same
scenarios on the Go port and requires identical output. Temp paths are
written as $TMP; inode/dev numbers as 0.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile


def main():
    src, scen_path, out_path = sys.argv[1:4]
    sys.path.insert(0, os.path.abspath(src))
    import driver as D
    import host_adapter as H
    import turn_handoff as T
    import harness as HR

    def norm(v, tmp):
        s = json.dumps(v, sort_keys=True, default=_default)
        s = s.replace(tmp, "$TMP")
        s = re.sub(r'\\"(inode|dev)\\": \d+', r'\\"\1\\": 0', s)
        s = re.sub(r'"(inode|dev)": \d+', r'"\1": 0', s)
        return json.loads(s)

    def _default(o):
        if isinstance(o, (set, frozenset)):
            return sorted(o)
        raise TypeError(repr(o))

    results = []
    for sc in json.load(open(scen_path)):
        tmp = tempfile.mkdtemp(prefix="hostpy-")
        os.makedirs(os.path.join(tmp, "stream"))
        queue = list(sc.get("runner") or [])
        calls = []

        def runner(cmd, **kw):
            calls.append([str(c) for c in cmd])
            r = queue.pop(0) if queue else {"rc": 0}
            if r.get("raise") == "timeout":
                raise subprocess.TimeoutExpired(cmd, kw.get("timeout"))
            if r.get("raise") == "spawn":
                raise OSError("spawn failed")
            return subprocess.CompletedProcess(cmd, r.get("rc", 0), r.get("stdout", ""),
                                               r.get("stderr", ""))

        def sub(v):
            if isinstance(v, str):
                return v.replace("$TMP", tmp)
            if isinstance(v, list):
                return [sub(x) for x in v]
            if isinstance(v, dict):
                return {k: sub(x) for k, x in v.items()}
            return v

        db = os.path.join(tmp, "h.db")
        state = {"clock": D.FakeClock()}

        def build():
            drv = D.Driver(db, state["clock"])
            tcfg = sc.get("transport") or {"kind": "fake"}
            if tcfg["kind"] == "fake":
                tr = state.get("fake") or H.FakeWakeTransport()
                state["fake"] = tr
            else:
                tr = H.HostWakeTransport(tcfg.get("wake", "/bin/wake"), tcfg.get("allow", []),
                                         enabled=tcfg.get("enabled", True),
                                         kv_get=drv.kv.get, kv_put=drv._kv_put, runner=runner)
            mcfg = sc.get("timers") or {"kind": "fake"}
            if mcfg["kind"] == "host":
                tm = H.HostTimerService(drv.kv.get, drv._kv_put, enabled=mcfg.get("enabled", True),
                                        allowlist=tuple(mcfg.get("allow", [])), runner=runner,
                                        callback_argv=mcfg.get("callback", []))
            else:
                tm = H.FakeTimerService(drv.kv.get, drv._kv_put)
            return H.HostAdapter(drv, clock=drv.clock, transport=tr, timers=tm,
                                 live=sc.get("live", False))

        ad = build()
        watcher = T.TurnWatcher(os.path.join(tmp, "stream"))
        cursors, events = {}, []
        out = []
        for op in sc["ops"]:
            name, a = op["op"], sub(op.get("args") or {})
            drv = ad.driver
            try:
                if name == "clock_set":
                    state["clock"].now = a["now"]; r = None
                elif name == "clock_advance":
                    r = state["clock"].advance(a["s"])
                elif name in ("write", "append"):
                    p = os.path.join(tmp, a["path"])
                    os.makedirs(os.path.dirname(p), exist_ok=True)
                    with open(p, "w" if name == "write" else "a") as fh:
                        fh.write(a["text"])
                    r = None
                elif name == "replace_file":
                    p = os.path.join(tmp, a["path"])
                    with open(p + ".new", "w") as fh:
                        fh.write(a["text"])
                    os.replace(p + ".new", p); r = None
                elif name == "reopen":
                    drv.close(); ad = build(); r = None
                elif name == "kv_put":
                    drv._kv_put(a["k"], a["v"]); r = None
                elif name == "admit_authorize":
                    r = drv.admit_authorize(a["qid"])
                elif name == "start_dispatch":
                    r = drv.start_dispatch(a["qid"], a["action"], duration_s=a["duration_s"])
                elif name == "send":
                    r = ad.transport.send(a["seat"], a["text"], kind=a.get("kind", "wake"),
                                          action=a.get("action"), execution=a.get("execution"))
                elif name == "state":
                    r = ad.transport.state(a["mid"])
                elif name == "mark":
                    r = ad.transport.mark(a["mid"], a["state"])
                elif name == "timer_create":
                    r = ad.timers.create(a["id"], a["deadline"])
                elif name == "timer_cancel":
                    r = ad.timers.cancel(a["id"])
                elif name == "timer_fire":
                    r = ad.timers.fire(a["id"], a["now"], a["deadline"])
                elif name == "timer_create_host":
                    r = ad.timers.create_host(a["id"], a["deadline"], a["delay_s"], a.get("callback"))
                elif name == "timer_cancel_host":
                    r = ad.timers.cancel_host(a["id"])
                elif name == "timer_query_host":
                    r = ad.timers.query_host(a["id"])
                elif name == "capture":
                    r = ad.capture(a["package"], a["attempt"], a["action"], a["event"],
                                   a["execution"], a["outcome"], a.get("occurred_at"),
                                   a.get("provenance"))
                elif name == "receipt":
                    r = ad.receipt(a["package"], a["attempt"], a["action"], a["event"], a["execution"])
                elif name == "trail":
                    r = ad.trail(a["action"])
                elif name == "bound_artifacts":
                    r = sorted(ad.bound_artifacts(a["action"]))
                elif name == "bind_route":
                    r = ad.bind_route(a["action"], a["seat"])
                elif name == "route_for":
                    r = ad.route_for(a["action"])
                elif name == "bind_turn":
                    r = ad.bind_turn(a["stream_key"], a["item"], a["execution"], a["action"], a["step"])
                elif name == "turn_binding":
                    r = ad.turn_binding(a["stream_key"], a["item"])
                elif name == "outbox_send":
                    r = ad.outbox_send(a["target"], a["payload"], execution=a.get("execution"))
                elif name == "outbox_ack":
                    r = ad.outbox_ack(a["oid"])
                elif name == "drain":
                    r = sorted(ad.drain_outbox_settled(a.get("qid", "P6F")))  # order not meaningful
                elif name == "reconcile_outbox":
                    r = ad.reconcile_outbox()
                elif name == "register_execution":
                    r = ad.register_execution(a["action"], a["execution"], a["auth"], a["deadline"])
                elif name == "current_execution":
                    r = ad.current_execution(a["action"])
                elif name == "apply_result":
                    r = ad.apply_execution_result(a["action"], a["execution"], a["result"])
                elif name == "resume_execution":
                    r = ad.resume_execution(a["action"], a["attempt"], a["old"], a["new"],
                                            a["auth"], a["deadline"], a["phase"])
                elif name == "replace_action":
                    r = ad.replace_action(a["old"], a["new"], a["execution"], a["auth"],
                                          a["deadline"], a["attempt_changed"])
                elif name == "drive_next":
                    r = ad.drive_next(a["action"], a["verify_action"], a["deadline"], a["hashes"],
                                      qid=a.get("qid"))
                elif name == "arm_from_ledger":
                    r = ad.arm_from_ledger(a["id"], a["deadline"], a.get("now"))
                elif name == "arm_current":
                    r = ad.arm_current(a["id"], a["qid"])
                elif name == "reconcile_send":
                    r = ad.reconcile_send(a["mid"], a["action"])
                elif name == "escalate":
                    r = ad.escalate_unavailable(a["action"], a["owner"], a["next"], a["deadline"])
                elif name == "confirm_ack":
                    r = ad.confirm_escalation_ack(a["action"])
                elif name == "poll":
                    for k in a.get("notify", []):
                        watcher.notify(k)
                    evs, cursors, notes, labels = watcher.poll(
                        a["keys"], cursors,
                        lambda t: drv._kv_put("sidecar-seen:" + t, "1"),
                        lambda t: drv.kv.get("sidecar-seen:" + t) == "1")
                    events = evs
                    r = [evs, cursors, notes, labels]
                elif name == "write_claim":
                    r = T.write_claim(a["dir"], a["execution"], a["claim"])
                elif name == "validate_claim":
                    r = T.validate_claim(a["claim"], a["launch"])
                elif name == "recompute":
                    r = T.recompute_artifacts(a["claim"], a["base"])
                elif name == "run_handoff":
                    turn = events[a["event"]] if "event" in a else a["turn"]
                    r = T.run_handoff(ad, a["qid"], turn, a["claims"], a["launch"],
                                      a.get("verify_spec"))
                elif name == "timer_callback":
                    r = HR.timer_callback(db, a["timer"], qid=a.get("qid"),
                                          action_id=a.get("action"), execution=a.get("execution"))
                else:
                    raise SystemExit("unknown op " + name)
                out.append({"op": name, "result": norm(r, tmp)})
            except SystemExit:
                raise
            except Exception as e:  # noqa: BLE001
                code = getattr(e, "code", None)
                if code is None and isinstance(e, ValueError):
                    code = str(e).split(":")[0]
                out.append({"op": name, "error": code or type(e).__name__})
        final = {"kv": dict(sorted(ad.driver.kv.items())),
                 "runner_calls": calls,
                 "transport_calls": [list(c) for c in ad.transport.calls],
                 "escalations": ad.escalations}
        results.append({"name": sc["name"], "ops": out, "final": norm(final, tmp)})
        ad.driver.close()
    with open(out_path, "w") as fh:
        json.dump(results, fh, indent=1, sort_keys=True)
        fh.write("\n")
    print("recorded %d scenarios, %d ops" % (len(results), sum(len(r["ops"]) for r in results)))


if __name__ == "__main__":
    main()
