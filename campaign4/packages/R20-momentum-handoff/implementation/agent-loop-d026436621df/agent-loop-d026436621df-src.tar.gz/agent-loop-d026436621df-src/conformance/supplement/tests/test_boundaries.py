"""Supplementary boundary cases, written for the conformance suite.

The package tests never probe exact boundaries: a planted off-by-one in the
publish deadline, the recovery ceiling, the attempt count, the nested
deadline cap, validator deadlines and trigger times, successor cycles and
start acknowledgement all survived BOTH the original pytest suite and its
recording (mutate_py.py, 2026-09-22). These tests close those gaps.

They assert nothing themselves. They drive the reference implementation
through each boundary on both sides, and the recorder writes down whatever
the reference did. A port must then do the same. So these cases state the
reference's behaviour at the boundary; they do not claim it is right.
"""
import os
import random
import tempfile

from driver import Driver, FakeClock, FakeExternalWorld
import lifecycle as L
import validator as V
from lifecycle import TransitionError
from ingress import IngressError

T0 = "2026-09-21T12:00:00Z"
DL = "2026-09-21T13:00:00Z"
BUDGET = {"attempts": 1, "repairs": 1, "verifier_s": 1800,
          "passes": {"verify": {"max_s": 1800},
                     "controller_recovery": {"max_s": 600}}}
ACT = {"reader": {"seat": "corvid", "role": "reader"},
       "director": {"seat": "tern", "role": "director"},
       "duty": {"seat": "cairn", "role": "duty"},
       "worker": {"seat": "kiln", "role": "worker"},
       "verifier": {"seat": "corvid", "role": "verifier"}}


def _t(sec):
    """UTC instant sec seconds after 12:00:00Z."""
    import datetime
    t = datetime.datetime(2026, 9, 21, 12) + datetime.timedelta(seconds=sec)
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def _ev(n, typ, who, **kw):
    e = {"event_id": "b%d" % n, "type": typ, "actor": dict(ACT[who])}
    e.update(kw)
    return e


def _apply(st, ev, now, budget=BUDGET):
    try:
        return L.apply(st, ev, now, budget)[0]
    except TransitionError:
        return st


def _running(n0=0, deadline=DL, budget=BUDGET):
    st = L.new_revision("QB")
    st = _apply(st, _ev(n0 + 1, "admit", "reader"), T0, budget)
    st = _apply(st, _ev(n0 + 2, "authorize", "director"), T0, budget)
    st = _apply(st, _ev(n0 + 3, "start", "duty", deadline=deadline,
                        action_id="a1"), T0, budget)
    return st


def _checking(n0=0):
    st = _running(n0)
    return _apply(st, _ev(n0 + 4, "publish", "worker",
                          artifact_hashes={"h": "x"},
                          handoff_deadline=_t(7200)), T0)


def test_publish_at_deadline_edges():
    st = _running()
    for n, now in enumerate((_t(3599), _t(3600), _t(3601))):
        _apply(st, _ev(10 + n, "publish", "worker",
                       artifact_hashes={"h": "x"},
                       handoff_deadline=_t(7200)), now)


def test_attempt_budget_edges():
    for attempts in (0, 1, 2):
        b = dict(BUDGET, attempts=attempts)
        st = L.new_revision("QA")
        st = _apply(st, _ev(1, "admit", "reader"), T0, b)
        st = _apply(st, _ev(2, "authorize", "director"), T0, b)
        _apply(st, _ev(3, "start", "duty", deadline=DL, action_id="a1"),
               T0, b)


def test_recovery_ceiling_edges():
    st = _apply(_running(), _ev(20, "interrupt", "duty", reason="x"), T0)
    for n, (el, cap) in enumerate(((0, 600), (600, 600), (601, 600),
                                   (599, 599), (0, 601), (10, 0),
                                   (-1, 600))):
        _apply(st, _ev(30 + n, "recover", "duty", elapsed_s=el,
                       pass_budget_s=cap), T0)


def test_verifier_spend_edges():
    st = _checking()
    for n, (el, cap) in enumerate(((1800, 1800), (1801, 1800), (0, 1801),
                                   (60, None), (1800, None), (1801, None))):
        kw = {"elapsed_s": el}
        if cap is not None:
            kw["pass_budget_s"] = cap
        _apply(st, _ev(40 + n, "verify_pass", "verifier", **kw), T0)


def test_decision_task_and_decide_after_close():
    st = _checking()
    st = _apply(st, _ev(50, "verify_pass", "verifier", elapsed_s=1), T0)
    disp = {"kind": "question_answered", "decision_ref": "d1",
            "reason": "r"}
    closed = _apply(st, _ev(51, "decide", "director", disposition=disp), T0)
    _apply(closed, _ev(52, "decision_task", "duty", deadline=_t(100)), T0)
    _apply(closed, _ev(53, "decide", "director",
                       disposition=dict(disp, decision_ref="d2")), T0)


def test_lifecycle_random_walks():
    """Seeded walks through every event type, role and boundary time."""
    rng = random.Random(20260922)
    types = sorted(L.PERMITTED)
    roles = sorted(ACT)
    times = [_t(s) for s in (0, 3599, 3600, 3601, 7200)]
    for walk in range(40):
        st = L.new_revision("QW%d" % walk)
        for step in range(12):
            typ = rng.choice(types)
            allowed = L.PERMITTED[typ]
            who = rng.choice(allowed) if rng.random() < 0.85 \
                else rng.choice(roles)
            kw = {}
            if typ == "start":
                kw = {"deadline": rng.choice(times[1:] + [None]),
                      "action_id": "a%d" % step}
            elif typ == "publish":
                kw = {"artifact_hashes": rng.choice([{"h": "x"}, {}])}
                if rng.random() < 0.5:
                    kw["verify"] = {"action_id": "v%d" % step,
                                    "owner": "corvid",
                                    "deadline": rng.choice(times)}
                else:
                    kw["handoff_deadline"] = rng.choice(times + [None])
                    kw["handoff_owner"] = rng.choice(
                        ["duty", "director", "worker"])
            elif typ in ("verify_pass", "verify_fail"):
                kw = {"elapsed_s": rng.choice([0, 1800, 1801]),
                      "eligible_repair": rng.random() < 0.5}
            elif typ == "recover":
                kw = {"elapsed_s": rng.choice([0, 600, 601]),
                      "pass_budget_s": rng.choice([600, 601])}
            elif typ == "resolve" and rng.random() < 0.5:
                kw = {"new_allocation": rng.choice([
                    {"grant_s": 600, "granted_by": "tern"},
                    {"grant_s": 1801, "granted_by": "tern"},
                    {"grant_s": 600, "granted_by": "kiln"}, "free"])}
            elif typ == "interrupt":
                kw = {"remaining_verifier_s": rng.choice([None, 0, 60])}
            elif typ == "decision_task":
                kw = {"deadline": rng.choice(times)}
            elif typ == "decide":
                kw = {"disposition": rng.choice([
                    {"kind": "question_answered", "decision_ref": "d",
                     "reason": "r"},
                    {"kind": "budget_spent", "decision_ref": "d"},
                    {"kind": "nonsense", "decision_ref": "d", "reason": "r"}])}
            ev = _ev(1000 * walk + step, typ, who, **kw)
            st = _apply(st, ev, rng.choice(times))


# -- validator --------------------------------------------------------------
def _flight(pid, phase, aid, owner, dl, receipt):
    return {"package_id": pid, "phase": phase, "action_id": aid,
            "owner": owner, "deadline": dl, "dispatch_receipt": receipt}


def _validate(snap, ledger, now, fired=None):
    V.validate(snap, ledger, now, fired)


def test_validator_deadline_edges():
    led = {"revision": 3, "packages": {"P-r1": {
        "phase": "RUNNING", "flight": {"action_id": "a1", "owner": "kiln",
                                       "deadline": DL},
        "receipt": "acknowledged"}}}
    snap = {"schema_version": 1, "ledger_revision": 3, "terminal": {},
            "in_flight": [_flight("P-r1", "RUNNING", "a1", "kiln", DL,
                                  "acknowledged")]}
    for now in (_t(3599), _t(3600), _t(3601), "2026-09-21T13:00:00+00:00",
                "2026-09-21T14:00:00+01:00", "2026-09-21T13:00:00",
                "not-a-time"):
        _validate(snap, led, now)


def test_validator_trigger_edges():
    disp = {"kind": "blocked", "decision_ref": "d", "reason": "r",
            "blocker": {"id": "b", "owner": "cairn", "resumption": "x",
                        "wake_trigger": {"revisit_at": DL}}}
    led = {"revision": 1, "packages": {"P-r1": {
        "phase": "TERMINATED", "disposition": disp}}}
    snap = {"schema_version": 1, "ledger_revision": 1, "in_flight": [],
            "terminal": {"P-r1": {"state": "TERMINATED", "disposition": disp,
                                  "decided_by": "tern", "decision_ref": "d",
                                  "reason": "r"}}}
    for now in (_t(3599), _t(3600), _t(3601)):
        _validate(snap, led, now)
        _validate(snap, led, now, ["revisit:" + DL])


def test_validator_successor_chains():
    def term(pid, succ):
        d = {"kind": "successor_opened", "decision_ref": "d", "reason": "r",
             "successor_id": succ}
        return d, {"state": "COMPLETE", "disposition": d,
                   "decided_by": "tern", "decision_ref": "d", "reason": "r"}
    for shape in ("cycle2", "cycle1", "chain-rest", "dangling", "live"):
        pk, terms, fl = {}, {}, []
        if shape == "cycle2":
            for a, b in (("A-r1", "B-r1"), ("B-r1", "A-r1")):
                d, e = term(a, b)
                pk[a] = {"phase": "COMPLETE", "disposition": d}
                terms[a] = e
        elif shape == "cycle1":
            d, e = term("A-r1", "A-r1")
            pk["A-r1"] = {"phase": "COMPLETE", "disposition": d}
            terms["A-r1"] = e
        elif shape == "chain-rest":
            d, e = term("A-r1", "B-r1")
            pk["A-r1"] = {"phase": "COMPLETE", "disposition": d}
            terms["A-r1"] = e
            rest = {"kind": "question_answered", "decision_ref": "d",
                    "reason": "r", "evidence_refs": ["x"]}
            pk["B-r1"] = {"phase": "COMPLETE", "disposition": rest}
            terms["B-r1"] = {"state": "COMPLETE", "disposition": rest,
                             "decided_by": "tern", "decision_ref": "d",
                             "reason": "r"}
        elif shape == "dangling":
            d, e = term("A-r1", "Z-r1")
            pk["A-r1"] = {"phase": "COMPLETE", "disposition": d}
            terms["A-r1"] = e
        else:
            d, e = term("A-r1", "B-r1")
            pk["A-r1"] = {"phase": "COMPLETE", "disposition": d}
            terms["A-r1"] = e
            pk["B-r1"] = {"phase": "RUNNING", "receipt": "acknowledged",
                          "flight": {"action_id": "b1", "owner": "kiln",
                                     "deadline": DL}}
            fl.append(_flight("B-r1", "RUNNING", "b1", "kiln", DL,
                              "acknowledged"))
        _validate({"schema_version": 1, "ledger_revision": 1,
                   "terminal": terms, "in_flight": fl},
                  {"revision": 1, "packages": pk}, T0)


def test_validator_random_perturbations():
    """Seeded single-field damage to a consistent snapshot/ledger pair."""
    rng = random.Random(922)
    fields = ("action_id", "owner", "deadline", "dispatch_receipt", "phase",
              "package_id")
    for n in range(60):
        led = {"revision": 2, "packages": {"P-r1": {
            "phase": "CHECKING", "receipt": "intended",
            "flight": {"action_id": "v1", "owner": "corvid",
                       "deadline": DL}}}}
        item = _flight("P-r1", "CHECKING", "v1", "corvid", DL, "intended")
        f = rng.choice(fields)
        item[f] = rng.choice([None, "", "x", DL, _t(3601), "acknowledged",
                              "RUNNING", 7])
        snap = {"schema_version": rng.choice([1, 1, 1, 2]),
                "ledger_revision": rng.choice([2, 2, 2, 3]),
                "terminal": {}, "in_flight": [item]}
        _validate(snap, led, rng.choice([T0, _t(3600), _t(3601)]))


# -- driver-level edges -----------------------------------------------------
def _driver():
    tmp = tempfile.mkdtemp(prefix="bnd-")
    return Driver(os.path.join(tmp, "ledger.db"), FakeClock(),
                  FakeExternalWorld(os.path.join(tmp, "world.json")))


def test_nested_deadline_cap_edges():
    for n, sec in enumerate((86400, 86401)):
        d = _driver()
        d.admit_authorize("QN")
        d.start_dispatch("QN", "a-w%d" % n, duration_s=3600)
        d.acknowledge("a-w%d" % n)
        try:
            d.publish_completion("QN", "a-w%d" % n, {"h": "x"},
                                 verify={"action_id": "v%d" % n,
                                         "owner": "corvid",
                                         "deadline": _t(sec)})
        except IngressError:
            pass
        d.close()


def test_start_ack_recording():
    d = _driver()
    d.admit_authorize("QS")
    ev = {"event_id": "s-start", "question_id": "QS", "revision": 1,
          "type": "start", "action_id": "s1", "acknowledged": False,
          "duration_s": 600}
    d._submit(ev, "duty")
    d.close()


def test_duration_and_skew_edges():
    d = _driver()
    d.admit_authorize("QD")
    for n, dur in enumerate((7200, 7201, 0, -1)):
        try:
            d.start_dispatch("QD", "a-d%d" % n, duration_s=dur)
        except IngressError:
            pass
    for n, sec in enumerate((120, 121, -5)):
        ev = {"event_id": "sk%d" % n, "question_id": "QD", "revision": 1,
              "type": "interrupt", "reason": "x",
              "occurred_at": _t(sec)}
        try:
            d._submit(ev, "duty")
        except (IngressError, TransitionError):
            pass
    d.close()
