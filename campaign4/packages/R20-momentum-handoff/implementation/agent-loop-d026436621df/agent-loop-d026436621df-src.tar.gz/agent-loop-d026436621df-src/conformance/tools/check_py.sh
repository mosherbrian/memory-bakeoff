#!/usr/bin/env bash
# Record the reference tests, then replay the recording on the same source.
# Usage: check_py.sh SRC_DIR TESTS_DIR OUT_DIR
set -eu
here=$(cd "$(dirname "$0")" && pwd)
python "$here/record_py.py" "$1" "$2" "$3"
find "$3" -name '*.json' ! -name RECORDING.json | sort | xargs python "$here/replay_py.py" "$1" \
  | python -c '
import json, sys
rs = [json.loads(l) for l in sys.stdin]
print("replay: %d/%d cases ok, %d steps" % (
    sum(r["ok"] for r in rs), len(rs), sum(r["steps"] for r in rs)))
for r in rs:
    if not r["ok"]:
        print("  FAIL", r["case"], r["first_diff"][:300])
sys.exit(0 if all(r["ok"] for r in rs) else 1)'
