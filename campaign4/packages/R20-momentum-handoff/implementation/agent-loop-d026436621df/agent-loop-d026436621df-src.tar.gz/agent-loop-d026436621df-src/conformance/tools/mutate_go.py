#!/usr/bin/env python
"""Proof that the suite can fail against the Go port: plant the Go
equivalent of each mutate_py.py fault, one at a time, and require
`go test ./internal/conform/` to fail.

    python mutate_go.py REPO_ROOT [--jobs N] [--only REGEX] [--logdir DIR]

Works on a copy of the repository; the original is never edited.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile

C = "internal/core/"
MUTANTS = [
    (C + "lifecycle.go", "if nowI.After(dlI) {", "if !nowI.Before(dlI) {",
     "publish AT the deadline refused"),
    (C + "lifecycle.go", 'if st.Get("disposition") != nil {\n\t\t\treturn fail("E_ALREADY_DECIDED"',
     'if false {\n\t\t\treturn fail("E_ALREADY_DECIDED"', "R13 undone: a second decide replaces the first"),
    (C + "lifecycle.go", 'if py.Eq(actorOf(event).Get("seat"), producer) {', "if false {",
     "R13 undone: the producer may verify its own work"),
    (C + "lifecycle.go", 'st.Set("producer_seat", actorOf(event).Get("seat"))',
     'st.Set("producer_seat", "nobody")', "R13 undone: the producer is not recorded"),
    (C + "ingress.go", 'if a.Has("decide") && a.Get("grant_ref") != nil {', "if false {",
     "R13 undone: decide + grant_ref accepted"),
    (C + "store.go", 'if id, _ := ev.Get("event_id").(string); s.SeenEvents[id] {', "if false {",
     "R13 undone: no duplicate check before the pair's transaction"),
    (C + "lifecycle.go", "const HardRecoveryMaxS = 600", "const HardRecoveryMaxS = 601",
     "recovery ceiling off by one second"),
    (C + "lifecycle.go", "if att >= lim {", "if att > lim {", "one extra attempt allowed"),
    (C + "lifecycle.go", 'return fail("E_BAD_TRANSITION", "already closed")',
     '_ = 0', "decision task on a closed package allowed"),
    (C + "store.go", "\ts.SeenEvents[eids] = true\n\ts.Revs.Set", "\ts.Revs.Set",
     "appended event not marked seen"),
    (C + "store.go", 'entry.Set("decided_by", "tern")', 'entry.Set("decided_by", "cairn")',
     "snapshot attributes decisions to the wrong seat"),
    (C + "store.go", 'if py.Truthy(body.Get("acknowledged")) {',
     'if true {', "every start recorded as acknowledged"),
    (C + "ingress.go", "NestedDeadlineCapS     = 86400", "NestedDeadlineCapS     = 86401",
     "nested deadline cap off by one second"),
    (C + "ingress.go", "FutureSkewToleranceS   = 120", "FutureSkewToleranceS   = 121",
     "future skew tolerance off by one second"),
    (C + "ingress.go", '"_trusted", "phase_hint"}', '"_trusted"}',
     "caller phase hints accepted"),
    (C + "ingress.go", 'if a.Has("hold") && a.Has("decide") {', 'if false {',
     "mixed hold+decide not rejected up front"),
    (C + "ingress.go", '"kiln", "cairn"}', '"kiln", "cairn", "mallory"}',
     "an unknown seat is trusted"),
    (C + "driver.go", "if !ok1 || !ok2 || now.Before(dl) {\n\t\treturn py.T(\"no-op-early\", true), nil\n\t}\n\tstopKey",
     "if !ok1 || !ok2 || !now.After(dl) {\n\t\treturn py.T(\"no-op-early\", true), nil\n\t}\n\tstopKey",
     "deadline exactly due treated as early"),
    (C + "driver.go", "\tif err := d.MarkHandled(effect); err != nil {\n\t\treturn nil, err\n\t}\n\tif recovered {",
     "\tif recovered {", "handled effect not recorded durably"),
    (C + "driver.go", 'd.Ext.Wake("tern", wakeReason)', 'd.Ext.Wake("cairn", wakeReason)',
     "deadline wake goes to the wrong seat"),
    (C + "validator.go", "if dl.Before(tnow) {", "if !dl.After(tnow) {",
     "in-flight exactly at deadline called overdue"),
    (C + "validator.go", "if ok && !revisit.After(tnow) && !fired.Has(tid) {",
     "if ok && revisit.Before(tnow) && !fired.Has(tid) {", "trigger exactly due not fired"),
    (C + "validator.go", 'return invalid("E_CYCLE", "successor cycle at "+pid)',
     'return nil', "successor cycles accepted"),
    (C + "supervisor.go", "if seen.Has(tid) {", "if false {", "ACTION_DUE not deduplicated"),
    (C + "status.go", '"duty", "cairn",', '"duty", "tern",', "status names the wrong duty seat"),
]

# Host building blocks, checked by internal/host/parity_test.go against the
# Python recording in conformance/host.
H = "internal/host/"
HOST_MUTANTS = [
    (H + "host.go", 'state = "queued"', 'state = "sent"', "queued wake reported as sent"),
    (H + "host.go", "if !ok1 || !ok2 || n.Before(dl) {", "if !ok1 || !ok2 || !n.After(dl) {",
     "timer due exactly at its deadline treated as early"),
    (H + "host.go", 'fmt.Sprintf("--on-active=%ds", int64(delayS))',
     'fmt.Sprintf("--on-active=%ds", int64(delayS+1))', "timer delay off by one second"),
    (H + "host.go", 'if r, ok := t.KV.Get("timer-rearm:" + canon); ok && r == py.ISO(at) {',
     'if r, ok := t.KV.Get("timer-rearm:" + canon); ok && r == py.ISO(at) && false {', "a replayed early callback arms a second timer"),
    (H + "host.go", "	cmd.WaitDelay = 500 * time.Millisecond", "", "a grandchild holding the pipes defeats the I/O timeout"),
    # P12: explicit-UTC calendar deadlines and exact /cancel receipts
    (H + "host.go", 'at.Format("2006-01-02 15:04:05") + " UTC"', 'at.Format("2006-01-02 15:04:05")',
     "calendar deadline without an explicit zone"),
    (H + "host.go", "at = at.UTC().Add(time.Second - 1).Truncate(time.Second)", "at = at.UTC().Truncate(time.Second)",
     "calendar deadline rounded down (fires before the deadline)"),
    (H + "host.go", '"--timer-property=AccuracySec=1s",', "",
     "deadline timer at systemd's default 1 min accuracy"),
    (H + "host.go", 'strings.CutPrefix(last, "wake: "+seat+" -> ")', 'strings.CutPrefix(last, "wake: ")',
     "a /cancel receipt for another session accepted"),
    (H + "host.go", 'case kind == "stop" && proc.RC == 1:', 'case proc.RC == 1:',
     "nothing-running accepted outside a /cancel"),
    (H + "adapter.go", 'case "sent", "queued", "delivered":', 'case "sent", "queued", "delivered", "ambiguous":',
     "ambiguous delivery settles the outbox"),
    (H + "adapter.go", "if s > FutureSkewToleranceS {", "if s > FutureSkewToleranceS+1 {",
     "skew tolerance off by one second"),
    (H + "adapter.go", "if dl.Sub(n) <= 0 {", "if dl.Sub(n) < 0 {", "timer armed with zero time left"),
    (H + "adapter.go", 'results.Set(oid, "held-ambiguous")', 'results.Set(oid, "held-awaiting-receipt")',
     "ambiguous outbox reported as awaiting a receipt"),
    (H + "adapter.go", 'if strings.HasPrefix(ce, "SUPERSEDED->") {', "if false {",
     "a superseded action's timer still fires"),
    (H + "adapter.go", 'if !py.Eq(receipt.Get("seat"), seat) {', 'if !py.Eq(receipt.Get("seat"), seat) && false {',
     "a receipt from the wrong seat settles"),
    (H + "adapter.go", "if !seen {\n\t\treturn false\n\t}", "if !seen && false {\n\t\treturn false\n\t}",
     "settles without proof the execution ran"),
    (H + "handoff.go", 'if claim.Has(f) {\n\t\t\treturn claimErr("E_FORGED_ROUTE',
     'if false && claim.Has(f) {\n\t\t\treturn claimErr("E_FORGED_ROUTE', "a claim may carry routing fields"),
    (H + "handoff.go", 'if kv(doneKey) != "" {', "if false {", "a completed handoff runs again"),
    (H + "handoff.go", "if fp != nil && !py.Eq(fp, recorded) {", "if false {", "a replaced stream file is accepted"),
    (H + "handoff.go", "if seenHas(token) {", "if false {", "stream lines emitted twice"),
    (H + "handoff.go", "if actual.Has(n) && !py.Eq(actual.Get(n), whashes.Get(n)) {", "if actual.Has(n) {",
     "any failed claim counts as an authenticated rejection"),
    (H + "handoff.go", 'if len(allowed) == 0 {\n\t\treturn nil, fault("E_FORGED_DISPOSITION"',
     'if len(allowed) == -1 {\n\t\treturn nil, fault("E_FORGED_DISPOSITION"', "verifier closes with no disposition"),
    (H + "handoff.go", 'for _, f := range []string{"kind", "decision_ref", "reason"} {',
     'for _, f := range []string{"kind"} {', "a disposition without a decision ref"),
    (H + "handoff.go", "\t\tif want == nil || py.Eq(have, want) {", "\t\tif true {",
     "a conflicting disposition is accepted as done"),
    (H + "handoff.go", 'return nil, fault("E_CLOSE_UNRESOLVED", "no authorized disposition was declared',
     'return rest()\n\t\treturn nil, fault("E_CLOSE_UNRESOLVED", "no authorized disposition was declared',
     "an intent alone reports terminal-rest (ruling finding 2)"),
    (H + "handoff.go", 'return nil, fault("E_CLOSE_UNRESOLVED", "verdict and disposition not committed: "+err.Error())',
     'return rest()', "a refused commit still writes done"),
    (H + "handoff.go", "\tif !known {", "\tif false {", "an unknown disposition kind reaches the commit"),
]

# The loop product, checked by internal/loop/loop_test.go (no Python
# reference exists for it).
LP = "internal/loop/"
LOOP_MUTANTS = [
    # P12-lock-budget-1: every hold is budgeted
    (LP + "timeout.go", "				if rem < MinIO {", "				if false {", "an I/O is started with too little of the hold budget left"),
    (LP + "timeout.go", "				if timeout > rem {", "				if false {", "an I/O timeout is not capped to the hold budget"),
    (LP + "timeout.go", "func (l *Loop) OutOfBudget() bool { return budgetShort(l.Cfg) }", "func (l *Loop) OutOfBudget() bool { return false }",
     "a run pass never yields at the lock budget"),
    (LP + "due.go", "		if budgetShort(cfg) {", "		if false {", "due markers are processed past the hold budget"),
    (LP + "due.go", "			return written[names[i]] < written[names[j]]", "			return written[names[i]] > written[names[j]]", "due markers newest first"),
    (LP + "due.go", "ok && now.Sub(at) > SaturationAge {", "ok && false {", "a saturated due backlog is not reported"),
    # P12-bounded-deadline-1: due markers are hints checked against the ledger
    (LP + "due.go", 'var dueName = regexp.MustCompile(`^[A-Za-z0-9._-]{1,200}$`)', 'var dueName = regexp.MustCompile(`^.*$`)',
     "an unsafe (path-traversing) due marker identity is accepted"),
    (LP + "due.go", ' || n != h.Action+".json" {', " {", "a due marker whose name does not match its action is acted on"),
    (LP + "due.go", '	case "E_UNKNOWN_PACKAGE", "E_ACTION_MISMATCH", "E_EXECUTION_MISMATCH", "E_SUPERSEDED_ACTION", "E_NO_EXECUTION_AUTHORITY", "E_NO_IDENTITY":\n		return true',
     '	case "E_UNKNOWN_PACKAGE":\n		return true', "a forged due marker (wrong action/execution) is kept instead of rejected"),
    # P12-stopped-ownership-1: the outside check escalates while run is stopped; fresh locked view
    (LP + "liveness.go", "if _, serr := os.Stat(c.Cfg.DB); serr == nil {", "if _, serr := os.Stat(c.Cfg.DB); serr == nil && false {",
     "the outside check never escalates a timeout while run is stopped"),
    # P12-closure-1: never-acked escalation and early-callback re-arm
    (LP + "timeout.go", "if !ok || now.Sub(at) < NoAckAfter {", "if !ok || now.Sub(at) < 2*NoAckAfter {", "no-ack duty escalation late"),
    (LP + "timeout.go", 'if !strings.HasPrefix(t.NoAckDuty, "sent") {', 'if t.NoAckDuty == "" {', "a failed no-ack send is never retried"),
    (LP + "timeout.go", ' || strings.HasPrefix(t.NoAckDuty, "failed")) {', ") {", "director not told when duty is unreachable"),
    (LP + "timeout.go", 'if p.Step != "timed-out" || t == nil || t.Ack != nil {', 'if p.Step != "timed-out" || t == nil {',
     "an acknowledged timeout is still escalated"),
    (LP + "timeout.go", '	if cur != action || rec == nil || py.S(rec.Get("phase")) != "RUNNING" {', '	if cur == "" || rec == nil || py.S(rec.Get("phase")) != "RUNNING" {',
     "an early callback re-arms a stale or settled action"),
    # P12: timeout settlement and acknowledgement
    (LP + "notice.go", 'case st == "sent" || st == "queued", kind == "stop" && (st == "cancelled" || st == "idle"):', 'case st == "sent" || st == "queued", kind == "stop" && st == "cancelled":',
     "an idle worker's /cancel aborts the timeout (P11 L2/L6)"),
    (LP + "timeout.go", 'if rec == nil || py.S(rec.Get("phase")) != "BLOCKED" {', 'if rec == nil {',
     "a timeout settled without a core interrupt"),
    (LP + "timeout.go", "		if inForce {", "		if false {", "a conflicting ack replaces one in force"),
    (LP + "timeout.go", 'if rec == nil || py.S(rec.Get("phase")) != "BLOCKED" ||\n\t\tpy.S(py.AsDict(rec.GetOr("flight", py.NewDict())).Get("action_id")) != action {',
     'if rec == nil || py.S(rec.Get("phase")) != "BLOCKED" {', "a timeout recorded for an action that is not the core's current one"),
    (LP + "timeout.go", 'if rec == nil || py.S(rec.Get("phase")) != "BLOCKED" ||\n\t\tpy.S(py.AsDict', 'if rec == nil || false ||\n\t\tpy.S(py.AsDict',
     "a step recorded as timed out without a core interrupt"),
    (LP + "timeout.go", "LOCK_EX|syscall.LOCK_NB)\n			if err == nil {", "LOCK_EX|syscall.LOCK_NB)\n			if true {",
     "the ledger lock does not exclude a second writer"),
    (LP + "timeout.go", "	if _, err := l.authority(p, role); err != nil {\n\t\treturn nil, err", "	if _, err := l.authority(p, role); false && err != nil {\n\t\treturn nil, err",
     "an ack from a changed principal accepted"),
    (LP + "timeout.go", "	if within <= 0 || within > MaxAckWithin {", "	if within < 0 {", "an unbounded or zero ack deadline accepted"),
    # P12-fair-handoff-1: "an expired ack escalated on every pass" (t.AckExpiredAt -> _ = t) is now EQUIVALENT:
    # the ack-expiry notice's incident key (ackexpiry|qid|id|deadline) also stops the repeat. Removed, recorded.
    (LP + "loop.go", "ok && it.Before(at.Add(-2*time.Second)) {", "ok && it.Before(at.Add(-2*time.Second)) && false {",
     "a turn from before the dispatch moves the package"),
    (LP + "loop.go", "\tif err := l.arm(qid, p.WorkAction, p.WorkExec, deadline); err != nil {",
     "\tif err := l.arm(qid, p.WorkAction, p.WorkExec, deadline); err != nil && false {",
     "work is sent with no deadline timer"),
    (LP + "loop.go", 'if py.Eq(outcome, "completed") && p.OnPass != nil {', "if p.OnPass != nil {",
     "a verifier FAIL closes on the PASS disposition"),
    (LP + "loop.go", 'return l.sendIncident("stop|"+action, id, "/cancel", "stop", action)', "_ = id\n\t\treturn nil",
     "a due deadline does not cancel the turn"),
    (LP + "loop.go", "\tif _, err := os.Stat(host.ClaimPathFor(l.Cfg.ClaimsDir, exec)); err != nil {",
     "\tif _, err := os.Stat(host.ClaimPathFor(l.Cfg.ClaimsDir, exec)); err != nil && false {",
     "a turn end with no claim moves the package"),
    (LP + "loop.go", 'ev := py.D("event_id", qid+"-decide-"+ref,', 'ev := py.D("event_id", qid+"-decide",',
     "a second, different decision is swallowed"),
    (LP + "loop.go", "if r.Worker == r.Verifier || r.Worker == l.Cfg.Director || r.Verifier == l.Cfg.Director {",
     "if false {", "the worker may verify its own work"),
    # P12-fair-handoff-1: D2 arrival-order grant, D1 accepted-only stamp, D3 one labelled repeat
    (LP + "queue.go", "isHead, exists = n == head, true", "isHead, exists = n == head || true, true", "any queued writer may take the lock (no hand-off)"),
    (LP + "queue.go", "if n >= QueueCap[class] {", "if false {", "admission is not capped"),
    (LP + "queue.go", "if v, err := strconv.ParseUint(x, 10, 64); err == nil && v > seq {", "if v, err := strconv.ParseUint(x, 10, 64); err == nil && false && v > seq {", "a lost counter reuses a live entry's name"),
    (LP + "queue.go", "case syscall.Kill(qe.PID, 0) == syscall.ESRCH, procStart(qe.PID) != qe.Start,", "case false, false,", "a dead or reused-pid waiter wedges the queue"),
    (LP + "queue.go", "serr == nil && time.Since(fi.ModTime()) > QueueStale:", "serr == nil && time.Since(fi.ModTime()) > 1000*QueueStale:", "a stuck waiter wedges the queue"),
    (LP + "queue.go", "json.Unmarshal(b, &qe) != nil || qe.PID <= 0 {", "false && json.Unmarshal(b, &qe) != nil || false {", "a malformed entry is not kept aside"),
    (LP + "timeout.go", "		if ent != \"\" {\n			q.remove(ent)", "		if false {\n			q.remove(ent)", "a holder or a waiter that gives up keeps its queue entry"),
    (LP + "due.go", "accepted := err == nil && (p.RC == host.WakeRCSent || p.RC == host.WakeRCQueued)", "accepted := err == nil", "a refused SATURATED report is stamped as told (D1)"),
    (LP + "notice.go", 'if kind == "stop" || r.Repeats >= 1 {', "if r.Repeats >= 1 {", "a cancel is repeated after an unknown outcome"),
    (LP + "notice.go", 'if kind == "stop" || r.Repeats >= 1 {', 'if kind == "stop" {', "every crash buys another repeat"),
    (LP + "notice.go", "		return nil // this incident's notice was accepted by the transport already", "		_ = 0", "an accepted notice is sent again"),
    (LP + "notice.go", "if r.Failures >= MaxFailedSends {", "if false {", "refused sends are retried without bound"),
    (LP + "notice.go", '		text = "REPEAT (" + kv + "): an earlier send of this notice may or may not have arrived. " + text', "		_ = kv", "the repeat is not labelled"),
    (LP + "due.go", 'case decision == "interrupted-effect-failed" && err != nil && strings.Contains(err.Error(), "E_DELIVERY_UNRESOLVED"):', "case false:", "an unresolved notice keeps its marker retried forever"),
    (LP + "timeout.go", '	if st == "idle" || st == "cancelled" {\n		// The cancel was confirmed', '	if false {\n		// The cancel was confirmed', "a confirmed cancel is reported as not confirmed"),
    # P12-ack-capacity-1: reserved ack/check grant order, durable ack requests, earliest detection
    (LP + "queue.go", "if prio(string(last)) && other != \"\" {", "if false && prio(string(last)) && other != \"\" {", "two priority grants in a row starve waiting writers"),
    (LP + "queue.go", 'if a := oldest(func(c string) bool { return c == "ack" }); a != "" {', "if a := \"\"; a != \"\" {", "an ack is not granted before other writers"),
    (LP + "queue.go", '	case "timeout-ack", "decision-ack":\n		return "ack"', '	case "decision-ack":\n		return "ack"\n	case "timeout-ack":\n		return "due"', "timeout-ack shares the callbacks' places"),
    (LP + "ack.go", "if json.Unmarshal(b, &old) == nil && old.Next == r.Next {", "if json.Unmarshal(b, &old) == nil {", "a conflicting request replaces nothing and reads as a replay"),
    (LP + "ack.go", "if n := len(pendingAcks(cfg)); n >= MaxPendingAcks {", "if n := len(pendingAcks(cfg)); false && n >= MaxPendingAcks {", "the request store is unbounded"),
    (LP + "ack.go", "			case !ok || !now.Before(dl):", "			case false && (!ok || !now.Before(dl)):", "an expired request is committed"),
    (LP + "ack.go", "ok && at.Sub(det) > AckBound {", "ok && false && at.Sub(det) > AckBound {", "a late commit is not recorded or escalated"),
    (LP + "ack.go", "if ok2 && (!ok1 || d.Before(at)) {", "if false && ok2 && (!ok1 || d.Before(at)) {", "detection moves to the later settlement time"),
    (LP + "due.go", "	acks := processAcks(cfg) // pending acknowledgements first", "	acks := []string(nil) // pending acknowledgements first", "pending ack requests are never drained"),
    (LP + "ack.go", 'if f, ok := host.IsFault(err); ok && f.Code == "E_BUDGET_EXHAUSTED" {', "if f, ok := host.IsFault(err); false && ok && f == nil {", "a spent hold budget rejects an ack request"),
    # P12-checker-ownership-1: incomplete checks fail and are owned without the ledger lock
    (LP + "liveness.go", "			if err == nil {\n				err = fmt.Errorf(\"check incomplete: %v\", eerr)\n			}", "			_ = 0", "an incomplete check reports success"),
    (LP + "liveness.go", "			if perr := RecordPendingCheck(c.Cfg, c.Now, eerr.Error()); perr != nil {", "			if perr := error(nil); perr != nil {", "an incomplete check leaves no pending marker"),
    (LP + "liveness.go", "	if err == nil {\n		did = append(did, ReconcileCheck(c.Cfg, c.Now)...)", "	if false {\n		did = append(did, ReconcileCheck(c.Cfg, c.Now)...)", "a completed check never clears the incident"),
    (LP + "checkerfail.go", "	case p.RC == host.WakeRCSent || p.RC == host.WakeRCQueued:", "	case true:", "a refused wake counts as told"),
    (LP + "checkerfail.go", "(!strings.HasPrefix(in.Duty, \"sent\") || now.Sub(dutySent) >= CheckerDirectorAfter) {", "(!strings.HasPrefix(in.Duty, \"sent\") || now.Sub(dutySent) >= 1000*CheckerDirectorAfter) {", "a lasting checker failure never reaches the director"),
    (LP + "checkerfail.go", "		if !strings.HasPrefix(in.Duty, \"sent\") {\n			in.Duty = checkerSend", "		if true {\n			in.Duty = checkerSend", "duty is re-told on every failure (no dedup)"),
    # P13: director decision ownership
    (LP + "decision.go", "		if err := l.save(p); err != nil {\n			return err\n		}\n	}\n	return l.armDecision(p)", "		if err := l.save(p); err != nil {\n			return err\n		}\n	}\n	return nil", "no decision deadline timer is armed"),
    (LP + "decision.go", "	if p.Decision == nil {\n		p.Decision = &DecisionDue{", "	if true {\n		p.Decision = &DecisionDue{", "a reopen moves the decision deadline"),
    (LP + "decision.go", "if st := p.Decision.Rungs[k]; strings.HasPrefix(st, \"sent\") || strings.HasPrefix(st, \"unresolved\") || now.Before(", "if st := p.Decision.Rungs[k]; st == \"-\" || now.Before(", "a rung fires again on every check"),
    (LP + "decision.go", "		ids := ledgerIDs(r, text, now.Add(-5*time.Second), false)\n		if len(ids) == 0 {", "		ids := ledgerIDs(r, text, now.Add(-5*time.Second), false)\n		if len(ids) < 0 {", "rc 0 without a durable ledger record counts as delivered"),
    (LP + "decision.go", "	if st := p.Decision.Reraised; strings.HasPrefix(st, \"sent\") || strings.HasPrefix(st, \"unresolved\") {\n		return nil", "	if st := p.Decision.Reraised; st == \"-\" {\n		return nil", "the re-raise repeats on every check"),
    (LP + "decision.go", "		if a.By == by && a.Next == next && a.Cap == dig {\n			return a, nil // replay\n		}\n		return nil, fmt.Errorf(", "		if a.By == by && a.Cap == dig {\n			return a, nil // replay\n		}\n		return nil, fmt.Errorf(", "a second acknowledgement is not refused cleanly"),
    (LP + "decision.go", "	if within <= 0 || within > MaxDecisionAckWithin {", "	if within <= 0 {", "an unbounded decision acknowledgement is accepted"),
    (LP + "decision.go", "		ok = ok || r == by", "		ok = ok || r == by || by != \"\"", "any principal may acknowledge a decision"),
    (LP + "loop.go", "	if p = l.Pkg(qid); p.Decision != nil && p.Decision.Resolved == \"\" {", "	if p = l.Pkg(qid); false {", "a decision does not resolve its incident (late pages)"),
    (LP + "decision.go", "			at, ok := py.Instant(p.StepAt)\n			if !ok {\n				at = now\n			}", "			at, ok := py.Instant(p.StepAt)\n			if !ok || true {\n				at = now\n			}", "a migrated decision deadline starts from now"),
    (LP + "decision.go", "	if p.Decision.Attempts[k] >= MaxRungAttempts {", "	if p.Decision.Attempts[k] >= MaxRungAttempts+100 {", "a failing rung is retried without bound"),
    (LP + "decision.go", "	p.Decision.Attempts[k]++\n", "", "attempts are not counted"),
    (LP + "decision.go", "			if st[0] == \"failed\" && now.Before(at.Add(RungRetryAfter)) {", "			if false {", "a failed rung is retried at once"),
    (LP + "decision.go", "len(ledgerIDs(r, text, at.Add(-5*time.Second), false)) > 0 {", "len(ledgerIDs(r, text, at.Add(-5*time.Second), false)) > 99 {", "an uncertain attempt with a durable receipt is sent again"),
    (LP + "decision.go", "		err := l.sendSeat(\"decision|\"+p.Decision.Incident+\"|\"+k+\"|unresolved\", l.Cfg.Director,", "		err := error(nil)\n		_ = l.Cfg.Director\n		_ = fmt.Sprintf(", "an unresolved rung is not owned by the director"),
    (LP + "decision.go", "	if !have || secret == \"\" || subtle.ConstantTimeCompare([]byte(dig), []byte(c.Digest)) != 1 {", "	if secret == \"\" && !have && subtle.ConstantTimeCompare([]byte(dig), []byte(c.Digest)) != 1 {", "an acknowledgement without its capability is accepted"),
    (LP + "decision.go", "	if exp, ok := py.Instant(c.Exp); !ok || now.After(exp) {", "	if exp, ok := py.Instant(c.Exp); !ok && now.After(exp) {", "an expired capability is accepted"),
    (LP + "decision.go", "	if len(r.Exec) > 0 && len(l.Cfg.DecisionResponders) > 0 {\n		err = l.issueCaps(p, now)", "	if len(r.Exec) > 0 && len(l.Cfg.DecisionResponders) > 0 && p.Decision.Caps == nil {\n		err = l.issueCaps(p, now)", "the capability is not rotated on a re-raise"),
    (LP + "decision.go", "		if err := os.WriteFile(tmp, []byte(sec+\"\\n\"), 0o600); err != nil {", "		if err := os.WriteFile(tmp, []byte(sec+\"\\n\"), 0o644); err != nil {", "the capability file is readable by others"),
    (LP + "decision.go", "	case \"required\":\n		l := c.DecisionLadder\n		if len(l) != 3", "	case \"required\":\n		l := c.DecisionLadder\n		if len(l) < 0", "a campaign without its full policy is accepted"),
    (LP + "decision.go", "		case len(r.Exec) > 0 && !filepath.IsAbs(r.Exec[0]):", "		case false:", "a relative adapter command is accepted"),
    (LP + "loop.go", "	missing = append(missing, c.validateDecision()...)\n", "", "the decision policy is never validated"),
    (LP + "loop.go", "	done = append(done, l.decisionLadder()...) // P13", "	_ = 0 // P13", "run's pass never walks the decision ladder"),
    # P9 read-only view (internal/expose, checked by its own tests)
    ("internal/expose/expose.go", "\t\t\t\tcase age < -5*time.Second:", "\t\t\t\tcase false:", "a future pass time reads as fresh"),
    ("internal/expose/expose.go", "\t\treturn \"UNKNOWN: \" + r.Source + \" unreadable\"", "\t\treturn \"OK\"", "a missing source reads OK"),
    ("internal/expose/expose.go", "\tif h != r.SHA256 {", "\tif h != r.SHA256 && false {", "a changed source reads OK"),
    ("internal/expose/expose.go", "\t\t\t\tif ev := o.check(*it.ResolvedBy); ev == \"OK\" {", "\t\t\t\tif ev := o.check(*it.ResolvedBy); ev != \"\" {",
     "an unverified resolution removes a pending judgment"),
    ("internal/expose/expose.go", "\t\t\tif r, _ := body[\"reason\"].(string); r == \"deadline-expired\" {", "\t\t\tif true {",
     "any interrupt counts as a timeout"),
    ("internal/expose/expose.go", "\t\t\tif seen[it.ID] {", "\t\t\tif false {", "a duplicate inventory id is not a conflict"),
    ("internal/expose/expose.go", "\t\tcase age > StaleAfter:", "\t\tcase age > 100*StaleAfter:", "a stale pass reads as fresh"),
    ("internal/expose/expose.go", "\t\tcase \"decision\":\n\t\t\tpk.Owner, pk.NextAction = owner(p, \"director\"), decide\n\t\t\tv.Pending = append(",
     "\t\tcase \"decision\":\n\t\t\tpk.Owner, pk.NextAction = owner(p, \"director\"), decide\n\t\t\t_ = append(", "a verdict waiting for the director is not pending"),
    ("internal/expose/expose.go", 'db, err := sql.Open("sqlite", "file:"+filepath.Join(snap, "ledger.db")+"?mode=ro")',
     'db, err := sql.Open("sqlite", "file:"+o.DB+"?mode=ro")', "the view opens the live ledger (creates -wal/-shm)"),
    ("internal/expose/expose.go", "\t\tif len(p.Principals) == 0 && p.Step != \"closed\" {", "\t\tif false {",
     "a package the loop cannot continue is offered a decide command"),
    # P10: the three P8 liveness blockers
    (LP + "liveness.go", "if ahead := at.Sub(now); ahead > FutureTolerance {", "if ahead := at.Sub(now); ahead > 100*FutureTolerance {",
     "a future pass time reads as fresh"),
    (LP + "liveness.go", "\tif p.Invocation != u.InvocationID {", "\tif false && p.Invocation != u.InvocationID {",
     "a pass from a previous run vouches for the current one"),
    (LP + "liveness.go", "\tif p.PID != u.MainPID {", "\tif false && p.PID != u.MainPID {", "a pass from another process of this invocation counts"),
    (LP + "liveness.go", "\tif u.InvocationID == \"\" {", "\tif false {", "an unreadable unit incarnation is green"),
    (LP + "liveness.go", "\t\tif since := now.Sub(u.StartedAt); since <= StartupGrace {", "\t\tif since := now.Sub(u.StartedAt); since <= 100*StartupGrace {",
     "startup grace never ends"),
    (LP + "liveness.go", "\tcloseable := !v.Alarm && v.State != \"starting\"", "\tcloseable := !v.Alarm",
     "starting closes an incident as recovered"),
    (LP + "liveness.go", "\tif inc := st.Open; closeable && inc != nil && inc.Damage != nil && inc.Ack == nil {", "\tif inc := st.Open; false && inc != nil {",
     "a state-damage incident closes without an acknowledgement"),
    (LP + "liveness.go", "\tq, qerr := quarantine(path, b, now)", "\tq, qerr := \"\", error(nil)",
     "damaged state is replaced without a preserved copy"),
    (LP + "liveness.go", "\tif damage != nil {\n\t\tv = Verdict{", "\tif false {\n\t\tv = Verdict{",
     "damaged state raises no alarm"),
    (LP + "liveness.go", "\t\tif w.Status != \"sent\" && w.Status != \"queued\" {", "\t\tif false {",
     "an unreachable duty seat does not reach the director"),
    (LP + "liveness.go", "\tsave := func() error { return saveState(statePath, st) }", "\tsave := func() error { saveState(statePath, st); return nil }",
     "a state that could not be saved passes silently"),
    # P8 repair-1, part A: runtime principal -> core authority
    (LP + "authority.go", "if current != rec.Seat || l.Cfg.Seats[rec.Seat] != rec.Session {",
     "if false {", "a rebound principal keeps its authority"),
    (LP + "authority.go", 'if !ok || rec.Seat == "" || rec.Session == "" {', "if false {",
     "a package with no recorded principal is served"),
    (LP + "loop.go", "\tdirector, err := l.authority(p, \"director\")\n\tif err != nil {\n\t\treturn err\n\t}",
     "\tdirector := py.D(\"seat\", l.Cfg.Director, \"role\", \"director\")\n\tvar err error\n\t_ = err",
     "decide passes the configured director name to the core (live-1)"),
    (LP + "loop.go", "\tif err := l.authorities(p, role); err != nil {\n\t\treturn l.blocked(p, err)\n\t}",
     "\tif err := l.authorities(p, role); err != nil && false {\n\t\treturn l.blocked(p, err)\n\t}", "the handoff skips the authority check"),
    (LP + "loop.go", "\terr = l.authorities(p, \"duty\")\n", "\terr = nil\n", "the timer callback skips the duty check"),
    # part B: supervisor liveness
    (LP + "liveness.go", "if age := now.Sub(at); age > StaleAfter {", "if age := now.Sub(at); age > 2*StaleAfter {",
     "a stale pass is treated as fresh"),
    (LP + "liveness.go", 'return alarm("unknown", "unit state unreadable: "+uerr.Error())',
     'return quiet("ok", "unit state unreadable: "+uerr.Error())', "unknown unit state reported green"),
    (LP + "liveness.go", "\t\tif !ok || c.Now.After(dl) {", "\t\tif false && (!ok || c.Now.After(dl)) {",
     "an expired acknowledgement suppresses the fault"),
    (LP + "liveness.go", "if c.Now.Sub(opened) >= CheckEvery-5*time.Second {", "if false && c.Now.Sub(opened) >= 0 {",
     "no acknowledgement never reaches the director"),
    (LP + "liveness.go", 'case "inactive", "failed":\n\t\t\treturn quiet("stopped"', 'case "inactive", "failed", "active":\n\t\t\treturn quiet("stopped"',
     "a stop that is not honoured stays quiet"),
    (LP + "liveness.go", "if p.ErrorStreak >= ErrorStreakAlarm {", "if false {", "failing passes stay green"),
    (LP + "liveness.go", 'return alarm("down", "run is not running and no stop was requested")',
     'return quiet("stopped", "run is not running and no stop was requested")', "an unplanned stop is quiet"),
    (LP + "loop.go", "\t\tif pr, ok := p.Principals[", "\t\tif pr, ok := p.Principals[\"none\"+", "the watch follows a rebound session"),
    (LP + "loop.go", "\t\tif t != n {", "\t\tif false && t != n {", "a session registered under another seat name is accepted"),
    (LP + "loop.go", "func (l *Loop) finishWorker(p *Pkg, end, launch *py.Dict) (string, error) {\n\tif why := l.inputsChanged(p); why != \"\" {",
     "func (l *Loop) finishWorker(p *Pkg, end, launch *py.Dict) (string, error) {\n\tif why := l.inputsChanged(p); why != \"\" && false {",
     "a changed input still dispatches the verifier"),
    (LP + "loop.go", "func (l *Loop) release(p *Pkg) error {\n\tif why := l.inputsChanged(p); why != \"\" {",
     "func (l *Loop) release(p *Pkg) error {\n\tif why := l.inputsChanged(p); why != \"\" && false {",
     "a held package is released on a changed input"),
    (LP + "loop.go", 'case st == "pending":\n\t\t\treturn "", nil', 'case st == "pending" && false:\n\t\t\treturn "", nil',
     "a pending decision releases its dependents"),
    (LP + "loop.go", 'var EligibleKinds = map[string]bool{"question_answered": true, "successor_opened": true}',
     'var EligibleKinds = map[string]bool{"question_answered": true, "successor_opened": true, "budget_spent": true}',
     "a budget_spent decision releases dependents"),
]


def run_one(goexe, work, fname, old, new, env=None, timeout=None):
    """Apply one mutant in WORK, run its tests, restore the file.
    Returns (verdict, gap, go test output)."""
    pkg = "./" + os.path.dirname(fname) + "/" if fname.startswith((H, LP, "internal/expose/")) else "./internal/conform/"
    path = os.path.join(work, fname)
    text = open(path).read()
    if text.count(old) != 1:
        return "NOT APPLIED (text not unique)", True, ""
    open(path, "w").write(text.replace(old, new))
    try:
        r = subprocess.run([goexe, "test", "-count=1", pkg],
                           cwd=work, capture_output=True, text=True, env=env, timeout=timeout)
    finally:
        open(path, "w").write(text)
    out = r.stdout + r.stderr
    n = r.stdout.count("--- FAIL: TestCases/") + r.stdout.count("--- FAIL: TestParity/")
    if pkg != "./internal/conform/":
        n = r.stdout.count("--- FAIL: Test")
    if r.returncode == 0:
        return "SURVIVED", True, out
    if n == 0:
        return "BUILD FAILED (mutant invalid)", True, out
    return "caught (%d cases)" % n, False, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("repo")
    ap.add_argument("--jobs", type=int, default=1, choices=range(1, 5))
    ap.add_argument("--only", help="run only mutants whose description matches this regex")
    ap.add_argument("--logdir", help="write one log file per mutant here")
    ap.add_argument("--timeout", type=int, default=1800, help="per-mutant go test timeout in seconds (--jobs > 1)")
    a = ap.parse_args()
    repo = os.path.abspath(a.repo)
    goexe = shutil.which("go") or os.path.expanduser("~/sdk/go/bin/go")
    todo = [(i, m) for i, m in enumerate(MUTANTS + HOST_MUTANTS + LOOP_MUTANTS, 1)
            if not a.only or re.search(a.only, m[3])]
    if a.logdir:
        os.makedirs(a.logdir, exist_ok=True)
    root = tempfile.mkdtemp(prefix="mutate-go-")
    results = {}

    def log(i, m, verdict, out):
        if a.logdir:
            with open(os.path.join(a.logdir, "%03d.log" % i), "w") as f:
                f.write("index: %d\nfile: %s\ndescription: %s\nverdict: %s\n\n%s"
                        % (i, m[0], m[3], verdict, "\n".join(out.splitlines()[-60:]) + "\n"))

    try:
        if a.jobs == 1:
            for i, (fname, old, new, meaning) in todo:
                work = os.path.join(root, "repo")
                shutil.rmtree(work, ignore_errors=True)
                shutil.copytree(repo, work, ignore=shutil.ignore_patterns(".git"))
                results[i] = run_one(goexe, work, fname, old, new)
                log(i, (fname, old, new, meaning), results[i][0], results[i][2])
        else:
            # N isolated copies; REPO itself is never written.
            free = queue.Queue()
            for k in range(a.jobs):
                d = os.path.join(root, "w%d" % k)
                shutil.copytree(repo, d, ignore=shutil.ignore_patterns(".git"))
                free.put(d)
            env = dict(os.environ)
            env["GOFLAGS"] = (env.get("GOFLAGS", "") + " -p=4").strip()

            def job(i, m):
                work = free.get()
                try:
                    try:
                        res = run_one(goexe, work, m[0], m[1], m[2], env=env, timeout=a.timeout)
                    except subprocess.TimeoutExpired as e:
                        out = e.stdout if isinstance(e.stdout, str) else (e.stdout or b"").decode(errors="replace")
                        res = ("TIMED OUT after %ds" % a.timeout, True, out)
                    except Exception as e:  # a worker crash is a gap, never dropped
                        res = ("WORKER ERROR (%s: %s)" % (type(e).__name__, e), True, "")
                        shutil.rmtree(work, ignore_errors=True)
                        shutil.copytree(repo, work, ignore=shutil.ignore_patterns(".git"))
                    log(i, m, res[0], res[2])
                    return res
                finally:
                    free.put(work)

            with concurrent.futures.ThreadPoolExecutor(a.jobs) as ex:
                futs = {i: ex.submit(job, i, m) for i, m in todo}
                for i, f in futs.items():
                    try:
                        results[i] = f.result()
                    except Exception as e:
                        results[i] = ("WORKER ERROR (%s: %s)" % (type(e).__name__, e), True, "")
    finally:
        shutil.rmtree(root, ignore_errors=True)
    rows = [(m[0], m[3], results[i][0]) for i, m in todo]
    gaps = sum(1 for i, _ in todo if results[i][1])
    w = max(len(r[1]) for r in rows) if rows else 0
    for f, m, s in rows:
        print("%-28s %-*s  %s" % (f, w, m, s), flush=True)
    print("\n%d of %d Go mutants caught" % (len(rows) - gaps, len(rows)), flush=True)
    return 1 if gaps else 0


if __name__ == "__main__":
    sys.exit(main())
