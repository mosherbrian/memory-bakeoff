// Command agent-loop is the single-binary home of the campaign-4 loop core.
//
// The loop (dispatch, run, status, claim, decide, stop, timer-callback) is
// in internal/loop; `agent-loop` with no arguments prints the commands.
package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"agent-loop/internal/conform"
	"agent-loop/internal/shadow"
)

// ReferencePin is the accepted Python source this build was checked against.
const ReferencePin = "memory-bake-off campaign4/packages/P6-r13-core-record-integrity @ c4ef8b98d22483fc1b38a710eb06a547bea82259 (core: candidate/src/r3harness)"

func main() {
	if len(os.Args) < 2 {
		usage()
	}
	switch os.Args[1] {
	case "version":
		fmt.Println(ReferencePin)
	case "conformance":
		os.Exit(runConformance(os.Args[2:]))
	case "shadow":
		os.Exit(runShadow(os.Args[2:]))
	case "coax":
		os.Exit(runCoax(os.Args[2:]))
	case "dispatch":
		os.Exit(runDispatch(os.Args[2:]))
	case "run":
		os.Exit(runRun(os.Args[2:]))
	case "status":
		os.Exit(runStatus(os.Args[2:]))
	case "claim":
		os.Exit(runClaim(os.Args[2:]))
	case "decide":
		os.Exit(runDecide(os.Args[2:]))
	case "stop":
		os.Exit(runStop(os.Args[2:]))
	case "check":
		os.Exit(runCheck(os.Args[2:]))
	case "start":
		os.Exit(runStart(os.Args[2:]))
	case "expose":
		os.Exit(runExpose(os.Args[2:]))
	case "liveness":
		os.Exit(runLiveness(os.Args[2:]))
	case "decision-check":
		os.Exit(runDecisionCheck(os.Args[2:]))
	case "decision-ack":
		os.Exit(runDecisionAck(os.Args[2:]))
	case "checker-failed":
		os.Exit(runCheckerFailed(os.Args[2:]))
	case "liveness-ack":
		os.Exit(runLivenessAck(os.Args[2:]))
	case "timeout-ack":
		os.Exit(runTimeoutAck(os.Args[2:]))
	case "timer-callback":
		os.Exit(runTimerCallback(os.Args[2:]))
	default:
		usage()
	}
}

func usage() {
	fmt.Fprintln(os.Stderr, `usage: agent-loop COMMAND [flags]   (every loop command takes --config FILE or $AGENT_LOOP_CONFIG)

The loop:
  dispatch   --qid Q --worker SEAT --verifier SEAT --task TEXT|@FILE --verify-task TEXT|@FILE
             [--duration 40m] [--verify-window 20m] [--on-pass KIND:REF:REASON]
             [--input PATH ...] [--after QID ...]
  run        [--once] [--every 30s]      watch turn ends and move packages on
  status     [--json]                    every package, its step, and who it waits on
  expose     [--inventory FILE] [--json] the read-only view: pending decisions, packages, overhead, known limits
  claim      --qid Q --step worker|verify --outcome completed|failed --artifact NAME=PATH ...
  decide     --qid Q --kind KIND --ref REF --reason TEXT
  stop                                   stop the loop; it stays stopped until start (deadline timers still fire)
  start                                  clear a stop and start the configured unit
  liveness                               the outside check (its own timer): incidents to duty, then director
  checker-failed --unit NAME             the check service's OnFailure handler (no ledger lock)
  liveness-ack --incident ID --by SEAT --next TEXT [--within 15m]
  check                                  confirm seat sessions against the registry, and paths
  timer-callback --qid Q --action A --execution E   (run by the deadline timers)

Checks and tools:
  conformance [CASE.json | DIR ...]      replay recorded cases on the Go core
  shadow [--json] LEDGER.tsv             replay a live ledger through the core, observe only
  coax [--live]                          coax the controller when a turn ended with no result
  version`)
	os.Exit(2)
}

func runConformance(paths []string) int {
	if len(paths) == 0 {
		paths = []string{"conformance/cases"}
	}
	var files []string
	for _, p := range paths {
		filepath.WalkDir(p, func(f string, d os.DirEntry, err error) error {
			if err == nil && !d.IsDir() && strings.HasSuffix(f, ".json") && d.Name() != "RECORDING.json" {
				files = append(files, f)
			}
			return nil
		})
	}
	bad, steps := 0, 0
	enc := json.NewEncoder(os.Stdout)
	for _, f := range files {
		r := conform.RunFile(f)
		steps += r.Steps
		if !r.OK {
			bad++
			enc.Encode(r)
		}
	}
	fmt.Fprintf(os.Stderr, "conformance: %d/%d cases ok, %d steps\n", len(files)-bad, len(files), steps)
	if bad > 0 || len(files) == 0 {
		return 1
	}
	return 0
}

func runShadow(args []string) int {
	asJSON := len(args) == 2 && args[0] == "--json"
	if asJSON {
		args = args[1:]
	}
	if len(args) != 1 {
		usage()
	}
	rows, gaps, err := shadow.ReadLedger(args[0])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	dir, err := os.MkdirTemp("", "shadow-")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer os.RemoveAll(dir)
	pkgRoot := filepath.Join(filepath.Dir(args[0]), "packages")
	rep, err := shadow.Run(rows, dir, pkgRoot, time.Now().UTC())
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	rep.Gaps = append(rep.Gaps, gaps...)
	if asJSON {
		json.NewEncoder(os.Stdout).Encode(rep)
		return 0
	}
	shadow.Print(os.Stdout, rep)
	return 0
}
