package main

import (
	"context"
	"path/filepath"

	"agent-loop/internal/expose"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"net"
	"os"
	"os/exec"
	"os/signal"
	"sort"
	"strings"
	"syscall"
	"text/tabwriter"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/loop"
	"agent-loop/internal/py"
)

type multi []string

func (m *multi) String() string     { return strings.Join(*m, ",") }
func (m *multi) Set(v string) error { *m = append(*m, v); return nil }

func loopFlags(name string) (*flag.FlagSet, *string) {
	fs := flag.NewFlagSet(name, flag.ExitOnError)
	cfg := fs.String("config", os.Getenv("AGENT_LOOP_CONFIG"), "project config (or $AGENT_LOOP_CONFIG)")
	return fs, cfg
}

func openLoop(path string) (*loop.Loop, error) {
	if path == "" {
		return nil, errors.New("--config is required")
	}
	cfg, err := loop.LoadConfig(path)
	if err != nil {
		return nil, err
	}
	return loop.Open(cfg, nil)
}

// openLocked opens the ledger after taking the ledger lock (bounded AdmittedWait);
// done() closes the ledger, then releases the lock.
func openLocked(path string) (*loop.Loop, func(), error) {
	if path == "" {
		return nil, nil, errors.New("--config is required")
	}
	cfg, err := loop.LoadConfig(path)
	if err != nil {
		return nil, nil, err
	}
	// Due deadlines before ordinary work. If they spend this hold's budget,
	// release and queue again (at the back) rather than start the work with
	// too little budget left for its own I/O.
	var k *loop.LedgerLock
	for tries := 0; ; tries++ {
		if k, err = loop.LockLedger(cfg, loop.AdmittedWait()); err != nil {
			return nil, nil, err
		}
		loop.ProcessDue(cfg)
		if !loop.BudgetShort(cfg) || tries >= 3 {
			break
		}
		k.Unlock()
	}
	l, err := loop.Open(cfg, nil)
	if err != nil {
		k.Unlock()
		return nil, nil, err
	}
	return l, func() { l.Close(); loop.ProcessDue(cfg); k.Unlock() }, nil
}

func fail(err error) int {
	if f, ok := host.IsFault(err); ok {
		fmt.Fprintf(os.Stderr, "agent-loop: %s: %s\n", f.Code, f.Detail)
		return 3
	}
	fmt.Fprintln(os.Stderr, "agent-loop:", err)
	return 1
}

func readText(v string) (string, error) {
	if strings.HasPrefix(v, "@") {
		b, err := os.ReadFile(v[1:])
		return string(b), err
	}
	return v, nil
}

func runDispatch(args []string) int {
	fs, cfg := loopFlags("dispatch")
	qid := fs.String("qid", "", "package id")
	worker := fs.String("worker", "", "worker seat")
	verifier := fs.String("verifier", "", "verifier seat")
	task := fs.String("task", "", "worker task text, or @FILE")
	vtask := fs.String("verify-task", "", "verifier task text, or @FILE")
	dur := fs.Duration("duration", 40*time.Minute, "worker time")
	vwin := fs.Duration("verify-window", 20*time.Minute, "verifier time")
	onPass := fs.String("on-pass", "", "KIND:REF:REASON closes the package on a verifier PASS without a separate decision")
	var inputs, after multi
	fs.Var(&inputs, "input", "a file the work depends on (relative to artifacts_dir); a change blocks the next dispatch; repeat")
	fs.Var(&after, "after", "a package that must close with question_answered or successor_opened first; repeat")
	fs.Parse(args)
	if *qid == "" || *worker == "" || *verifier == "" || *task == "" || *vtask == "" {
		fmt.Fprintln(os.Stderr, "dispatch needs --qid --worker --verifier --task --verify-task")
		return 2
	}
	wt, err := readText(*task)
	if err != nil {
		return fail(err)
	}
	vt, err := readText(*vtask)
	if err != nil {
		return fail(err)
	}
	var op *loop.OnPass
	if *onPass != "" {
		parts := strings.SplitN(*onPass, ":", 3)
		if len(parts) != 3 {
			fmt.Fprintln(os.Stderr, "--on-pass is KIND:REF:REASON")
			return 2
		}
		op = &loop.OnPass{Kind: parts[0], DecisionRef: parts[1], Reason: parts[2]}
	}
	l, done, err := openLocked(*cfg)
	if err != nil {
		return fail(err)
	}
	defer done()
	p, err := l.Dispatch(loop.Request{QID: *qid, Worker: *worker, Verifier: *verifier, WorkerTask: wt, VerifyTask: vt,
		DurationS: int64(dur.Seconds()), VerifyS: int64(vwin.Seconds()), OnPass: op, Inputs: inputs, After: after})
	if err != nil {
		return fail(err)
	}
	if p.Step == "held" {
		fmt.Printf("%s registered, held until %s close\n", p.QID, strings.Join(p.After, ", "))
		return 0
	}
	fmt.Printf("%s: %s (%s); verifier %s\n", p.QID, p.Step, p.WorkExec, p.Verifier)
	return 0
}

func runClaim(args []string) int {
	fs, cfg := loopFlags("claim")
	qid := fs.String("qid", "", "package id")
	step := fs.String("step", "", "worker or verify")
	outcome := fs.String("outcome", "", "completed or failed")
	var arts multi
	fs.Var(&arts, "artifact", "NAME=PATH (relative to artifacts_dir); repeat")
	fs.Parse(args)
	m := map[string]string{}
	for _, a := range arts {
		n, p, ok := strings.Cut(a, "=")
		if !ok {
			fmt.Fprintln(os.Stderr, "--artifact is NAME=PATH")
			return 2
		}
		m[n] = p
	}
	l, done, err := openLocked(*cfg)
	if err != nil {
		return fail(err)
	}
	defer done()
	path, err := l.Claim(*qid, *step, *outcome, m)
	if err != nil {
		return fail(err)
	}
	fmt.Println("claim filed:", path)
	return 0
}

func runDecide(args []string) int {
	fs, cfg := loopFlags("decide")
	qid := fs.String("qid", "", "package id")
	kind := fs.String("kind", "", "successor_opened | question_answered | budget_spent | blocked")
	ref := fs.String("ref", "", "decision reference")
	reason := fs.String("reason", "", "reason")
	stamp := fs.String("stamp", "", "momentum stamp file (relative to artifacts_dir); required for stamped packages")
	fs.Parse(args)
	l, done, err := openLocked(*cfg)
	if err != nil {
		return fail(err)
	}
	defer done()
	if err := l.DecideStamped(*qid, *kind, *ref, *reason, *stamp); err != nil {
		return fail(err)
	}
	fmt.Println(*qid, "closed:", *kind)
	return 0
}

func runStatus(args []string) int {
	fs, cfg := loopFlags("status")
	asJSON := fs.Bool("json", false, "machine-readable")
	fs.Parse(args)
	l, err := openLoop(*cfg)
	if err != nil {
		return fail(err)
	}
	defer l.Close()
	rows := l.Status()
	if *asJSON {
		json.NewEncoder(os.Stdout).Encode(map[string]any{"packages": rows, "outbox_pending": l.PendingOutbox()})
		return 0
	}
	w := tabwriter.NewWriter(os.Stdout, 0, 2, 2, ' ', 0)
	fmt.Fprintln(w, "PACKAGE\tSTEP\tWAITING ON\tSINCE\tDEADLINE\tVERDICT\tLAST")
	for _, r := range rows {
		fmt.Fprintf(w, "%v\t%v\t%v\t%v\t%v\t%v\t%v\n", r["qid"], r["step"], r["waiting_on"], r["since"], r["deadline"], r["verdict"], r["last"])
	}
	w.Flush()
	if n := l.PendingOutbox(); n > 0 {
		fmt.Printf("\n%d dispatch(es) still open in the outbox: each settles once its target's turn is seen and the ledger moves past it\n", n)
	}
	return 0
}

func runStop(args []string) int {
	fs, cfgPath := loopFlags("stop")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	if err := os.WriteFile(cfg.StopMarker(), []byte(time.Now().UTC().Format(time.RFC3339)+"\n"), 0o644); err != nil {
		return fail(err)
	}
	fmt.Println("stop requested: run exits at its next pass and stays stopped until `agent-loop start`.")
	fmt.Println("Stop is not cancellation: armed per-action deadline timers still fire and enforce their bounds.")
	return 0
}

// runStart clears an intentional stop and starts the unit.
func runStart(args []string) int {
	fs, cfgPath := loopFlags("start")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	if err := os.Remove(cfg.StopMarker()); err != nil && !os.IsNotExist(err) {
		return fail(err)
	}
	if cfg.Unit == "" {
		fmt.Println("stop marker cleared (no unit configured; start `agent-loop run` yourself)")
		return 0
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	out, err := exec.CommandContext(ctx, cfg.Systemctl, "--user", "start", cfg.Unit).CombinedOutput()
	if err != nil {
		return fail(fmt.Errorf("systemctl start %s: %v %s", cfg.Unit, err, out))
	}
	fmt.Println("stop marker cleared; started", cfg.Unit)
	return 0
}

// sdNotify tells systemd about readiness and liveness (Type=notify,
// WatchdogSec). It is called from run's own loop, after a pass completes.
func sdNotify(state string) {
	addr := os.Getenv("NOTIFY_SOCKET")
	if addr == "" {
		return
	}
	if addr[0] == '@' {
		addr = "\x00" + addr[1:]
	}
	c, err := net.Dial("unixgram", addr)
	if err != nil {
		return
	}
	defer c.Close()
	c.Write([]byte(state))
}

// runRun is the long-running loop: it wakes on every change in the
// stream directory (inotify) and at least every 30 seconds, and reopens
// the ledger each pass so dispatch/claim/decide from other processes are
// seen. After each completed pass it records the pass and pings the
// systemd watchdog. It exits 64 on an intentional stop and refuses to
// start while the stop marker exists.
func runRun(args []string) int {
	fs, cfgPath := loopFlags("run")
	once := fs.Bool("once", false, "one pass, then exit")
	every := fs.Duration("every", 30*time.Second, "longest wait between passes")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	stopped := func() bool { _, err := os.Stat(cfg.StopMarker()); return err == nil }
	if stopped() {
		fmt.Fprintln(os.Stderr, "agent-loop: stopped by agent-loop stop; run `agent-loop start` to resume")
		return loop.ExitStopped
	}
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGTERM, syscall.SIGINT)
	var n *host.DirNotifier
	if !*once {
		if n, err = host.NewDirNotifier(cfg.StreamDir); err != nil {
			fmt.Fprintln(os.Stderr, "agent-loop: no inotify, polling every", *every, ":", err)
		} else {
			defer n.Close()
		}
	}
	watcher, cursors := host.NewTurnWatcher(cfg.StreamDir), py.NewDict()
	var pass int64
	for {
		// The whole pass holds the ledger lock (bounded AdmittedWait).
		k, err := loop.LockLedger(cfg, loop.AdmittedWait())
		if err != nil {
			// Busy for a whole minute: other writers hold the ledger in turn
			// (each hold is budgeted and settles due deadlines first). Report
			// it in the heartbeat's absence and try again; do not exit.
			fmt.Fprintln(os.Stderr, "agent-loop: pass skipped:", err)
			if stopped() {
				return loop.ExitStopped
			}
			continue
		}
		for _, m := range loop.ProcessDue(cfg) { // due deadlines before ordinary work
			fmt.Println(time.Now().UTC().Format(time.RFC3339), m)
		}
		l, err := loop.Open(cfg, nil)
		if err != nil {
			return fail(err)
		}
		l.SetWatcher(watcher, cursors)
		if pass == 0 {
			if res, err := l.Adapter.ReconcileOutbox(); err != nil {
				fmt.Fprintln(os.Stderr, "agent-loop: outbox reconcile:", err)
			} else if res.Len() > 0 {
				fmt.Println(time.Now().UTC().Format(time.RFC3339), "outbox:", py.Dumps(res))
			}
		}
		pass++
		msgs, tickErr := l.Tick()
		yielded := l.Yielded
		cursors = l.Cursors()
		if err := l.RecordPass(pass, len(msgs), tickErr); err != nil {
			fmt.Fprintln(os.Stderr, "agent-loop: pass record:", err)
		}
		l.Close()
		for _, m := range loop.ProcessDue(cfg) { // and before the lock is released
			fmt.Println(time.Now().UTC().Format(time.RFC3339), m)
		}
		k.Unlock()
		for _, m := range msgs {
			fmt.Println(time.Now().UTC().Format(time.RFC3339), m)
		}
		if tickErr != nil {
			fmt.Fprintln(os.Stderr, "agent-loop:", tickErr)
		}
		if pass == 1 {
			sdNotify("READY=1")
		}
		sdNotify("WATCHDOG=1")
		if *once {
			return 0
		}
		if stopped() {
			fmt.Println("stop requested; exiting", loop.ExitStopped)
			return loop.ExitStopped
		}
		if yielded {
			continue // the pass stopped at the lock budget: continue at once
		}
		// The wait between passes ends at a turn event, the pass interval or
		// SIGTERM/SIGINT, whichever is first: a stop must not wait out the
		// interval (P11: TimeoutStopSec 20 s < every 30 s -> SIGABRT).
		waited := make(chan struct{})
		go func() {
			defer close(waited)
			if n != nil {
				n.Wait(*every)
			} else {
				time.Sleep(*every)
			}
		}()
		// An intentional stop (the marker) is seen within a second, not at
		// the end of the interval.
		tick := time.NewTicker(time.Second)
	wait:
		for {
			select {
			case <-sig:
				return 0
			case <-waited:
				break wait
			case <-tick.C:
				if stopped() {
					fmt.Println("stop requested; exiting", loop.ExitStopped)
					return loop.ExitStopped
				}
			}
		}
		tick.Stop()
	}
}

// runLiveness is the outside check (its own systemd timer, every 45 s).
func runLiveness(args []string) int {
	fs, cfgPath := loopFlags("liveness")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	if cfg.Unit == "" {
		return fail(errors.New("liveness needs \"unit\" in the config"))
	}
	v, did, err := (&loop.Checker{Cfg: cfg, Now: time.Now().UTC()}).Check()
	b, _ := json.Marshal(map[string]any{"verdict": v, "actions": did})
	fmt.Println(string(b))
	if err != nil {
		// The alarm (if any) was already sent; the failure to persist or read
		// state is itself reported and fails the unit, never passed as green.
		return fail(err)
	}
	return 0
}

func runLivenessAck(args []string) int {
	fs, cfgPath := loopFlags("liveness-ack")
	id := fs.String("incident", "", "incident id")
	by := fs.String("by", "", "your seat: the duty seat or the director")
	next := fs.String("next", "", "the next action you will take")
	within := fs.Duration("within", 15*time.Minute, "response deadline from now (max 1h)")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	if err := loop.AckIncident(cfg, *id, *by, *next, *within, time.Now().UTC()); err != nil {
		return fail(err)
	}
	fmt.Printf("acknowledged %s by %s; respond by %s. This is not recovery: the incident closes only when the loop is seen running again.\n",
		*id, *by, time.Now().UTC().Add(*within).Format(time.RFC3339))
	return 0
}

func runTimerCallback(args []string) int {
	fs, cfgPath := loopFlags("timer-callback")
	qid := fs.String("qid", "", "package id")
	action := fs.String("action", "", "action id")
	execution := fs.String("execution", "", "execution id")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	started := time.Now()
	k, err := loop.LockLedger(cfg, loop.DueWait)
	if err != nil {
		// Busy: leave a durable due marker (detection evidence), then keep
		// trying; every holder settles due markers first, and so do we.
		path, werr := loop.WriteDue(cfg, *qid, *action, *execution, time.Now().UTC())
		if werr != nil {
			return fail(fmt.Errorf("ledger busy (%v) and no due marker: %v", err, werr))
		}
		fmt.Println(py.Dumps(py.D("decision", "deferred", "due_marker", path, "reason", err.Error())))
		if k, err = loop.LockLedger(cfg, loop.DueWindow-time.Since(started)); err != nil {
			fmt.Println("still busy after", loop.DueWindow, "- the marker stays for the next holder:", err)
			return 0
		}
		defer k.Unlock()
		for _, m := range loop.ProcessDue(cfg) {
			fmt.Println(m)
		}
		return 0
	}
	defer k.Unlock()
	for _, m := range loop.ProcessDue(cfg) {
		fmt.Println(m)
	}
	d, note, err := loop.RunDeadline(cfg, *qid, *action, *execution, "")
	fmt.Println(py.Dumps(py.D("decision", d, "note", note)))
	for _, m := range loop.ProcessDue(cfg) {
		fmt.Println(m)
	}
	if err != nil {
		return fail(err)
	}
	return 0
}

// runTimeoutAck records that the director or duty owns a step timeout.
func runTimeoutAck(args []string) int {
	fs, cfgPath := loopFlags("timeout-ack")
	qid := fs.String("qid", "", "package id")
	action := fs.String("action", "", "the timed-out action")
	by := fs.String("by", "", "your seat: the director or duty")
	next := fs.String("next", "", "the next action you will take")
	within := fs.Duration("within", 15*time.Minute, "response deadline from now (max 1h)")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	if *within <= 0 || *within > loop.MaxAckWithin {
		return fail(fmt.Errorf("--within must be between 1s and %s", loop.MaxAckWithin))
	}
	// P12-ack-capacity-1: the request is durable BEFORE the lock is tried; any
	// ledger holder commits it (revalidated on a fresh ledger). Pending is not
	// an acknowledgement.
	now := time.Now().UTC()
	r, err := loop.SubmitAck(cfg, loop.AckRequest{QID: *qid, Action: *action, By: *by, Next: *next,
		Deadline: py.ISO(now.Add(*within)), Submitted: py.ISO(now), PID: os.Getpid()})
	if err != nil {
		return fail(err)
	}
	wait := loop.AckWorstCase
	if d, ok := py.Instant(loop.ReadDetection(cfg.DB, *qid)); ok {
		slack := d.Add(loop.AckBound).Sub(now)
		if slack >= loop.AckWorstCase {
			fmt.Printf("request recorded %s, %s after detection %s: while this command waits, it commits by detection + %s.\n",
				r.Submitted, now.Sub(d).Round(time.Second), py.ISO(d), loop.AckBound)
			wait = slack
		} else {
			fmt.Printf("request recorded %s, %s after detection %s: NO TIMELY PROMISE (the latest feasible submission was detection + %s); it is still committed, late commits are escalated.\n",
				r.Submitted, now.Sub(d).Round(time.Second), py.ISO(d), loop.AckBound-loop.AckWorstCase)
		}
	}
	if k, err := loop.LockLedger(cfg, wait); err == nil {
		loop.ProcessDue(cfg) // pending acknowledgements first, then due work
		k.Unlock()
	} else {
		fmt.Fprintln(os.Stderr, "agent-loop: lock not taken:", err)
	}
	res := loop.AckResult(cfg, r)
	if res == nil {
		fmt.Printf("PENDING: request %s/%s by %s is durable and NOT an acknowledgement yet; the next ledger holder (run, a callback, a dispatch, or the outside liveness check every 30 s) commits it.\n", *qid, *action, *by)
		return 3
	}
	if res.Outcome != "committed" {
		return fail(fmt.Errorf("acknowledgement rejected: %s", res.Reason))
	}
	late := ""
	if res.Late {
		late = " LATE: committed after the 60 s bound; the director was told."
	}
	fmt.Printf("timeout T-%s of %s acknowledged by %s at %s (detection %s); respond by %s: %s. This does not resume or close the package.%s\n",
		*action, *qid, res.By, res.CommittedAt, res.Detection, res.Deadline, res.Next, late)
	return 0
}

// runCheck confirms a config before use: every seat's session id is in the
// registry under that seat's name, and the paths the loop needs exist.
func runCheck(args []string) int {
	fs, cfgPath := loopFlags("check")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	bad := 0
	if fi, err := os.Stat(cfg.Wake); err != nil || fi.Mode()&0o111 == 0 {
		fmt.Println("FAIL wake script not executable:", cfg.Wake)
		bad++
	}
	if fi, err := os.Stat(cfg.StreamDir); err != nil || !fi.IsDir() {
		fmt.Println("FAIL stream_dir missing:", cfg.StreamDir)
		bad++
	}
	var names []string
	for n := range cfg.Seats {
		names = append(names, n)
	}
	sort.Strings(names)
	if err := cfg.VerifySeats(names...); err != nil {
		fmt.Println("FAIL", err)
		bad++
	} else {
		for _, n := range names {
			fmt.Printf("ok   %s = %s (registry, profile %s)\n", n, cfg.Seats[n], cfg.Profile)
		}
	}
	if bad > 0 {
		return 3
	}
	fmt.Println("config ok")
	return 0
}

// runExpose renders the read-only status view (Expose). It opens the
// ledger read-only and writes nothing.
func runExpose(args []string) int {
	fs, cfgPath := loopFlags("expose")
	inv := fs.String("inventory", "", "declared pointers to campaign records the ledger does not hold (optional)")
	base := fs.String("base", "", "directory inventory sources resolve against (default: the inventory's directory)")
	asJSON := fs.Bool("json", false, "machine-readable")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	b := *base
	if b == "" && *inv != "" {
		b = filepath.Dir(*inv)
	}
	v, err := expose.Build(expose.Options{Project: cfg.Project, DB: cfg.DB, Inventory: *inv, BaseDir: b,
		ClaimsDir: cfg.ClaimsDir, Bin: cfg.Bin, Config: cfg.Path, Director: cfg.Director, Now: time.Now().UTC()})
	if err != nil {
		return fail(err)
	}
	if *asJSON {
		e := json.NewEncoder(os.Stdout)
		e.SetIndent("", " ")
		e.Encode(v)
		return 0
	}
	fmt.Print(expose.Text(v))
	return 0
}

// runCheckerFailed is the outside check's OnFailure handler. It needs neither
// the ledger lock nor a healthy run or checker.
func runCheckerFailed(args []string) int {
	fs, cfgPath := loopFlags("checker-failed")
	unit := fs.String("unit", "", "the failed check unit")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	result := "result unknown"
	sc := cfg.Systemctl
	if sc == "" {
		sc = "systemctl"
	}
	if p, err := host.ExecRunner([]string{sc, "--user", "show", *unit, "-p", "Result,ExecMainCode,ExecMainStatus", "--value"}, nil, 2*time.Second); err == nil {
		result = strings.Join(strings.Fields(p.Stdout), " ")
	}
	in, err := loop.CheckerFailed(cfg, *unit, result, time.Now().UTC())
	b, _ := json.Marshal(in)
	fmt.Println(string(b))
	if err != nil {
		return fail(err)
	}
	return 0
}

// runDecisionCheck is the decision deadline timer's callback: it walks the
// decision ladder (and the other owned escalations) under the ledger lock.
func runDecisionCheck(args []string) int {
	fs, cfgPath := loopFlags("decision-check")
	fs.Parse(args)
	cfg, err := loop.LoadConfig(*cfgPath)
	if err != nil {
		return fail(err)
	}
	msgs, err := loop.EscalateTimeouts(cfg, nil)
	for _, m := range msgs {
		fmt.Println(m)
	}
	if err != nil {
		return fail(err)
	}
	return 0
}

// runDecisionAck records a responder's single bounded acknowledgement of an
// overdue decision. It is not a decision.
func runDecisionAck(args []string) int {
	fs, cfgPath := loopFlags("decision-ack")
	qid := fs.String("qid", "", "package id")
	by := fs.String("by", "", "a configured decision responder")
	next := fs.String("next", "", "the next action you will take")
	within := fs.Duration("within", 15*time.Minute, "response deadline from now (max 15m)")
	capFile := fs.String("cap-file", "", "the incident's acknowledgement capability file named in the notice")
	fs.Parse(args)
	sec, err := os.ReadFile(*capFile)
	if *capFile == "" || err != nil {
		return fail(fmt.Errorf("--cap-file: the capability file named in the notice is required (%v)", err))
	}
	l, done, err := openLocked(*cfgPath)
	if err != nil {
		return fail(err)
	}
	defer done()
	a, err := l.DecisionAck(*qid, *by, string(sec), *next, *within)
	if err != nil {
		return fail(err)
	}
	fmt.Printf("decision of %s acknowledged by %s at %s; respond by %s: %s. This is not a decision.\n", *qid, a.By, a.At, a.Deadline, a.Next)
	return 0
}
