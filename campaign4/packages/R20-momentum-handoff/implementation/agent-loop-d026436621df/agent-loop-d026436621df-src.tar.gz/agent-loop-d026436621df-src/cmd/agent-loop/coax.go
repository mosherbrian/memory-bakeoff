package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"agent-loop/internal/coax"
	"agent-loop/internal/shadow"
)

// runCoax: find dispatched work whose worker's turn ended with no result
// recorded, and tell the controller - once per ended turn. Dry by default:
// it writes what it WOULD send to --log. --live sends it with wake.
func runCoax(args []string) int {
	home, _ := os.UserHomeDir()
	fs := flag.NewFlagSet("coax", flag.ExitOnError)
	ledger := fs.String("ledger", filepath.Join(home, "memory-bake-off/campaign4/control-events.tsv"), "campaign ledger")
	streams := fs.String("streams", filepath.Join(home, ".config/agent-deck/acp-stream"), "acp-stream directory")
	state := fs.String("state", filepath.Join(home, ".local/share/agent-deck/coax-state.json"), "coaxes already made")
	logPath := fs.String("log", filepath.Join(home, ".local/share/agent-deck/coax.log"), "record of every coax, dry or live")
	profile := fs.String("profile", "campaign4", "agent-deck profile the seats live in")
	to := fs.String("to", "cairn", "seat that receives the coax")
	wakeLog := fs.String("wakelog", filepath.Join(home, ".local/share/agent-deck/wake-send.log"), "wake send log, to classify each loss")
	grace := fs.Duration("grace", 2*time.Minute, "time the controller gets to record a result itself")
	live := fs.Bool("live", false, "send with wake; without it, only record what would be sent")
	wakeCmd := fs.String("wake", filepath.Join(home, ".config/agent-deck/wake"), "command that delivers the coax")
	notify := fs.String("notify", "", "also send a copy of each coax (or, dry, what WOULD be sent) to this command, e.g. notify-claude, so a person sees each stall")
	fs.Parse(args)

	rows, _, err := shadow.ReadLedger(*ledger)
	if err != nil {
		fmt.Fprintln(os.Stderr, "coax:", err)
		return 1
	}
	seats, err := sessions(*profile)
	if err != nil {
		fmt.Fprintln(os.Stderr, "coax: cannot read the seats:", err)
		return 1
	}
	done := map[string]string{}
	if data, err := os.ReadFile(*state); err == nil {
		json.Unmarshal(data, &done)
	}
	now := time.Now().UTC()
	mode := "DRY"
	if *live {
		mode = "LIVE"
	}
	sent := 0
	for _, n := range coax.Find(rows, seats, *streams, filepath.Join(filepath.Dir(*ledger), "packages"), *wakeLog, *to, now, *grace) {
		if done[n.Key] != "" {
			continue
		}
		msg := n.Message(now)
		result := "would send"
		if *live {
			cmd := exec.Command(*wakeCmd, *to, msg)
			cmd.Env = append(os.Environ(), "AGENTDECK_PROFILE="+*profile)
			out, err := cmd.CombinedOutput()
			result = strings.TrimSpace(string(out))
			if err != nil && cmd.ProcessState.ExitCode() != 3 { // 3 = queued, delivered
				fmt.Fprintf(os.Stderr, "coax: wake failed: %v %s\n", err, out)
				continue // not recorded as done, so the next run tries again
			}
		}
		// The copy for a person goes AFTER the wake, so it never reports a
		// wake that did not happen. A failed copy does not undo the wake.
		if *notify != "" {
			head := "[coax DRY RUN - nothing was sent to " + *to + "] Would wake " + *to + ": "
			if *live {
				head = "[coax] Woke " + *to + " (" + result + "): "
			}
			cmd := exec.Command(*notify, "coax")
			cmd.Stdin = strings.NewReader(head + msg + "\n\nCompare with openwork: journalctl --user -u openwork -n 20")
			if out, err := cmd.CombinedOutput(); err != nil {
				fmt.Fprintf(os.Stderr, "coax: notify failed: %v %s\n", err, out)
				if !*live {
					continue // dry: the copy is the whole point, so try again next run
				}
			}
		}
		done[n.Key] = now.Format(time.RFC3339)
		sent++
		line, _ := json.Marshal(map[string]string{"at": now.Format(time.RFC3339), "mode": mode,
			"seat": n.Seat, "qid": n.QID, "to": *to, "case": n.Case, "result": result, "message": msg})
		appendLine(*logPath, string(line))
		fmt.Printf("coax %s: %s %s -> %s\n", mode, n.Seat, n.QID, result)
	}
	for k, v := range done { // forget coaxes older than two days
		if t, err := time.Parse(time.RFC3339, v); err == nil && now.Sub(t) > 48*time.Hour {
			delete(done, k)
		}
	}
	data, _ := json.MarshalIndent(done, "", " ")
	os.MkdirAll(filepath.Dir(*state), 0o755)
	tmp := *state + ".tmp"
	if err := os.WriteFile(tmp, data, 0o644); err == nil {
		os.Rename(tmp, *state)
	}
	fmt.Printf("coax: %d new\n", sent)
	return 0
}

// sessions maps seat title to session id in one agent-deck profile.
func sessions(profile string) (map[string]string, error) {
	cmd := exec.Command("agent-deck", "list", "--json")
	cmd.Env = append(os.Environ(), "AGENTDECK_PROFILE="+profile)
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	var xs []struct{ ID, Title string }
	if err := json.Unmarshal(out, &xs); err != nil {
		var wrapped struct{ Sessions []struct{ ID, Title string } }
		if err2 := json.Unmarshal(out, &wrapped); err2 != nil {
			return nil, err
		}
		xs = wrapped.Sessions
	}
	m := map[string]string{}
	for _, x := range xs {
		m[x.Title] = x.ID
	}
	return m, nil
}

func appendLine(path, line string) {
	os.MkdirAll(filepath.Dir(path), 0o755)
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		fmt.Fprintln(os.Stderr, "coax: log:", err)
		return
	}
	defer f.Close()
	fmt.Fprintln(f, line)
}
