// Package host is the port of the accepted Python host adapter
// (r3harness/host_adapter.py, turn_handoff.py, notify.py and the timer
// callback guard in harness.py; reference pin in PROVENANCE.json).
//
// It is the machinery around the core: sending through the wake script
// with durable receipts, a safe outbox, systemd one-shot timers, declared
// execution identity, the turn-end watcher, route-free completion claims
// and the verified handoff. Every OS boundary (subprocess, clock, files)
// is injectable so the same scenarios run against Python and Go
// (conformance/host).
package host

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// Fault is Python's OwnedFault: a named failure with an owner.
type Fault struct{ Code, Detail, Owner string }

func (f *Fault) Error() string { return f.Code + ": " + f.Detail }

func fault(code, detail string) *Fault { return &Fault{code, detail, "cairn"} }

// IsFault reports whether err is a Fault, and returns it.
func IsFault(err error) (*Fault, bool) {
	var f *Fault
	ok := errors.As(err, &f)
	return f, ok
}

// Proc is what a finished subprocess returned.
type Proc struct {
	RC             int
	Stdout, Stderr string
}

// ErrTimeout is subprocess.TimeoutExpired; any other Runner error is a
// failure to spawn.
var ErrTimeout = errors.New("timeout")

// ErrBudget: the subprocess was NOT started because the current ledger-lock
// hold has too little time left (the loop's budgeted Runner returns it).
var ErrBudget = errors.New("lock budget exhausted")

// Runner runs argv with extra environment and a timeout.
type Runner func(argv []string, env []string, timeout time.Duration) (Proc, error)

// ExecRunner is the production Runner.
func ExecRunner(argv []string, env []string, timeout time.Duration) (Proc, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	cmd.Env = append(os.Environ(), env...)
	// A child that outlives the killed process (e.g. a script's sleep) can
	// hold the output pipes open; without WaitDelay, Wait would block until
	// it exits and the timeout would not bound the call (P12-lock-budget-1).
	cmd.WaitDelay = 500 * time.Millisecond
	var out, errb strings.Builder
	cmd.Stdout, cmd.Stderr = &out, &errb
	err := cmd.Run()
	if ctx.Err() == context.DeadlineExceeded {
		return Proc{}, ErrTimeout
	}
	var ee *exec.ExitError
	if err != nil && !errors.As(err, &ee) {
		return Proc{}, err
	}
	return Proc{RC: cmd.ProcessState.ExitCode(), Stdout: out.String(), Stderr: errb.String()}, nil
}

// KV is the driver's durable key-value table.
type KV interface {
	Get(k string) (string, bool)
	Put(k, v string) error
}

type driverKV struct{ d *core.Driver }

func (k driverKV) Get(key string) (string, bool) { v, ok := k.d.KV[key]; return v, ok }
func (k driverKV) Put(key, v string) error       { return k.d.KVPut(key, v) }

// DriverKV exposes a driver's table as a KV.
func DriverKV(d *core.Driver) KV { return driverKV{d} }

func loadDict(raw string) *py.Dict {
	v, err := py.Loads([]byte(raw))
	if err != nil {
		return nil
	}
	return py.AsDict(v)
}

func orNil(s string, ok bool) any {
	if !ok {
		return nil
	}
	return s
}

// ---------------------------------------------------------------------------
// transports

// Wake exit codes of the wake script: 0 started, 3 queued, else failure.
const (
	WakeRCSent   = 0
	WakeRCQueued = 3
)

// Transport sends a message to a seat and reports its delivery state.
type Transport interface {
	Send(seat, text, kind string, action, execution any) (string, error)
	State(mid string) string
}

// FakeTransport records sends; its states are set by Mark. Only
// "delivered" is a transport receipt, and never a worker completion.
type FakeTransport struct {
	Calls [][3]string
	inbox map[string]*py.Dict
	n     int
}

func NewFakeTransport() *FakeTransport { return &FakeTransport{inbox: map[string]*py.Dict{}} }

func (t *FakeTransport) Send(seat, text, kind string, action, execution any) (string, error) {
	t.n++
	mid := fmt.Sprintf("msg-%d", t.n)
	t.Calls = append(t.Calls, [3]string{seat, text, kind})
	t.inbox[mid] = py.D("seat", seat, "kind", kind, "state", "queued", "action", action, "execution", execution)
	return mid, nil
}

func (t *FakeTransport) Mark(mid, state string) string {
	t.inbox[mid].Set("state", state)
	return state
}

func (t *FakeTransport) State(mid string) string {
	if m, ok := t.inbox[mid]; ok {
		return py.S(m.Get("state"))
	}
	return "unknown"
}

// WakeTransport sends through the wake script. Live sends fail closed
// unless enabled with a seat allowlist. Every send leaves a durable
// receipt whose identity never repeats, even across fresh instances.
type WakeTransport struct {
	WakePath  string
	Allowlist []string
	Enabled   bool
	Timeout   time.Duration
	Profile   string // AGENTDECK_PROFILE for the wake script
	KV        KV
	Run       Runner
	Calls     [][3]string
}

func (t *WakeTransport) allowed(seat string) bool {
	for _, s := range t.Allowlist {
		if s == seat {
			return true
		}
	}
	return false
}

func (t *WakeTransport) Send(seat, text, kind string, action, execution any) (string, error) {
	if !t.Enabled || !t.allowed(seat) {
		return "", fault("E_DISABLED", "live send outside enabled fixture allowlist")
	}
	t.Calls = append(t.Calls, [3]string{seat, text, kind})
	run := t.Run
	if run == nil {
		run = ExecRunner
	}
	timeout := t.Timeout
	if timeout == 0 {
		timeout = 30 * time.Second
	}
	profile := t.Profile
	if profile == "" {
		profile = "campaign4"
	}
	proc, err := run([]string{t.WakePath, seat, text}, []string{"AGENTDECK_PROFILE=" + profile}, timeout)
	if errors.Is(err, ErrBudget) {
		return "", fault("E_BUDGET_EXHAUSTED", "wake to "+seat+" not started: the ledger-lock hold's budget is spent")
	}
	if errors.Is(err, ErrTimeout) {
		return t.record(seat, kind, action, execution, "ambiguous", "timeout", "")
	}
	if err != nil {
		return t.record(seat, kind, action, execution, "ambiguous", "spawn-failed", "")
	}
	lines := splitLines(strings.TrimSpace(proc.Stdout))
	last := ""
	if len(lines) > 0 {
		last = lines[len(lines)-1]
	}
	state := "failed"
	switch {
	case proc.RC == WakeRCSent && strings.HasPrefix(last, "wake:"):
		state = "sent"
	case proc.RC == WakeRCQueued && strings.HasPrefix(last, "wake:"):
		state = "queued"
	case proc.RC == WakeRCSent || proc.RC == WakeRCQueued:
		state = "ambiguous" // right code, malformed receipt
	case kind == "stop" && proc.RC == 1:
		// The worker answered a /cancel (wake exits 1 for anything but
		// started/queued). Only its exact receipt for this session counts:
		// "wake: <seat> -> cancelled..." or "wake: <seat> -> nothing running...".
		switch reply, ok := strings.CutPrefix(last, "wake: "+seat+" -> "); {
		case ok && strings.HasPrefix(reply, "cancelled"):
			state = "cancelled"
		case ok && strings.HasPrefix(reply, "nothing running"):
			state = "idle" // the turn had already ended: nothing to cancel
		}
	}
	return t.record(seat, kind, action, execution, state, int64(proc.RC), last)
}

func (t *WakeTransport) record(seat, kind string, action, execution any, state string, rc any, receipt string) (string, error) {
	n := int64(1)
	if raw, ok := t.KV.Get("msg-counter"); ok {
		if c, err := strconv.ParseInt(strings.TrimSpace(raw), 10, 64); err == nil {
			n = c + 1
		}
	}
	a := "na"
	if s, ok := action.(string); ok && s != "" {
		a = s
	}
	mid := fmt.Sprintf("msg-%s-%d", a, n)
	if _, ok := t.KV.Get("msg:" + mid); ok {
		return "", fault("E_MSG_COLLISION", "refusing to overwrite receipt "+mid)
	}
	if err := t.KV.Put("msg-counter", strconv.FormatInt(n, 10)); err != nil {
		return "", err
	}
	return mid, t.KV.Put("msg:"+mid, py.Dumps(py.D("seat", seat, "kind", kind, "state", state,
		"rc", rc, "receipt", receipt, "action", action, "execution", execution)))
}

func (t *WakeTransport) State(mid string) string {
	raw, ok := t.KV.Get("msg:" + mid)
	if !ok {
		return "unknown"
	}
	d := loadDict(raw)
	if d == nil {
		return "unknown"
	}
	return py.S(d.GetOr("state", "unknown"))
}

// splitLines is Python's str.splitlines.
func splitLines(s string) []string {
	var out []string
	start := 0
	rs := []rune(s)
	for i := 0; i < len(rs); i++ {
		switch rs[i] {
		case '\n', '\v', '\f', 0x1c, 0x1d, 0x1e, 0x85, 0x2028, 0x2029:
			out = append(out, string(rs[start:i]))
			start = i + 1
		case '\r':
			out = append(out, string(rs[start:i]))
			if i+1 < len(rs) && rs[i+1] == '\n' {
				i++
			}
			start = i + 1
		}
	}
	if start < len(rs) {
		out = append(out, string(rs[start:]))
	}
	return out
}

// ---------------------------------------------------------------------------
// timers

// CanonicalTimerID removes exactly one trailing ".timer".
func CanonicalTimerID(id string) string { return strings.TrimSuffix(id, ".timer") }

// CanonicalUnit is the base name plus exactly one ".timer".
func CanonicalUnit(id string) string { return CanonicalTimerID(id) + ".timer" }

// Timers are one-shot relative timers with durable handled effects.
type Timers struct {
	KV        KV
	timers    map[string]*py.Dict
	cancelled map[string]bool
	// Host fields: systemd timers through Run, only when Enabled and
	// the timer is on the allowlist.
	Host        bool
	Enabled     bool
	Allowlist   []string
	Run         Runner
	CallbackArg []string
	SystemdRun  string
	Systemctl   string
	RunnerCalls [][]string
}

func NewTimers(kv KV) *Timers {
	return &Timers{KV: kv, timers: map[string]*py.Dict{}, cancelled: map[string]bool{},
		SystemdRun: "systemd-run", Systemctl: "systemctl"}
}

func (t *Timers) handled(id string) bool {
	v, _ := t.KV.Get("timer-handled:" + id)
	return v == "handled"
}

func (t *Timers) isCancelled(id string) bool {
	v, _ := t.KV.Get("timer-cancelled:" + id)
	return t.cancelled[id] || v == "cancelled"
}

func (t *Timers) Create(id string, deadline any) (py.Tuple, error) {
	if t.isCancelled(id) || t.handled(id) {
		return py.T("rejected-cancelled", true), nil
	}
	t.timers[id] = py.D("deadline", deadline, "state", "armed")
	return py.T("armed", false), nil
}

func (t *Timers) Cancel(id string) (py.Tuple, error) {
	delete(t.timers, id)
	t.cancelled[id] = true
	return py.T("cancelled", true), t.KV.Put("timer-cancelled:"+id, "cancelled")
}

func (t *Timers) Fire(id string, now, ledgerDeadline any) (py.Tuple, error) {
	if t.handled(id) {
		return py.T("already-handled", true), nil
	}
	tm, armed := t.timers[id]
	if t.isCancelled(id) || !armed {
		return py.T("no-op-not-armed", true), nil
	}
	n, ok1 := py.Instant(now)
	dl, ok2 := py.Instant(ledgerDeadline)
	if !ok1 || !ok2 || n.Before(dl) {
		return py.T("no-op-early", true), nil
	}
	if !py.Eq(tm.Get("deadline"), ledgerDeadline) {
		return py.T("no-op-stale", true), nil
	}
	tm.Set("state", "fired")
	return py.T("fired", false), t.KV.Put("timer-handled:"+id, "handled")
}

func (t *Timers) run(kind string, argv []string) (Proc, error) {
	t.RunnerCalls = append(t.RunnerCalls, append([]string{kind}, argv...))
	run := t.Run
	if run == nil {
		run = ExecRunner
	}
	return run(argv, nil, 30*time.Second)
}

func (t *Timers) guard(id string) error {
	canon := CanonicalTimerID(id)
	for _, a := range t.Allowlist {
		if t.Enabled && (id == a || canon == a || id == CanonicalTimerID(a) || canon == CanonicalTimerID(a) ||
			id == CanonicalUnit(a) || canon == CanonicalUnit(a)) {
			return nil
		}
	}
	return fault("E_DISABLED", "live timer outside enabled fixture allowlist")
}

// CommandFor is the systemd-run argv for a one-shot timer.
func (t *Timers) CommandFor(id string, delayS float64, cb []string) []string {
	if cb == nil {
		cb = t.CallbackArg
	}
	return append([]string{t.SystemdRun, "--user", "--unit=" + CanonicalUnit(id),
		fmt.Sprintf("--on-active=%ds", int64(delayS))}, cb...)
}

// CommandAt is the systemd-run argv for a one-shot timer at an absolute
// instant: an explicit-UTC calendar time (rounded up to the second), with
// AccuracySec=1s. P12 measured that `systemctl --user daemon-reload`
// restarts an --on-active timer's countdown (each reload postponed it by
// the time since the last), and that systemd's default 1 min accuracy
// fires up to a minute late; a known deadline is bounded at 30 s.
func (t *Timers) CommandAt(id string, at time.Time, cb []string) []string {
	if cb == nil {
		cb = t.CallbackArg
	}
	at = at.UTC().Add(time.Second - 1).Truncate(time.Second)
	return append([]string{t.SystemdRun, "--user", "--unit=" + CanonicalUnit(id), "--timer-property=AccuracySec=1s",
		"--on-calendar=" + at.Format("2006-01-02 15:04:05") + " UTC"}, cb...)
}

// CreateHost creates a real one-shot timer. The same identity with the
// same grant deadline is reused, never recreated; any other conflict is
// refused rather than hijacked or extended.
func (t *Timers) CreateHost(id string, deadline any, delayS float64, cb []string) (py.Tuple, error) {
	canon := CanonicalTimerID(id)
	if err := t.guard(canon); err != nil {
		return nil, err
	}
	if raw, ok := t.KV.Get("timer-arm:" + canon); ok {
		ex := loadDict(raw)
		if ex == nil {
			ex = py.NewDict()
		}
		if py.Eq(ex.Get("deadline"), deadline) && py.Eq(ex.Get("unit"), CanonicalUnit(canon)) {
			t.timers[canon] = py.D("deadline", deadline, "state", "armed-host")
			return py.T("armed-host-reused", true), nil
		}
		return nil, fault("E_TIMER_CONFLICT", "conflicting timer identity/deadline; refusing to hijack or extend")
	}
	argv := t.CommandFor(canon, delayS, cb)
	if at, ok := py.Instant(deadline); ok {
		argv = t.CommandAt(canon, at, cb)
	}
	proc, err := t.run("create", argv)
	if err != nil {
		return nil, err
	}
	if proc.RC != 0 {
		return nil, fault("E_TIMER_CREATE", "host timer refused: "+firstRunes(proc.Stderr, 200))
	}
	used := cb
	if len(used) == 0 {
		used = t.CallbackArg
	}
	stored := []any{}
	if len(used) > 0 {
		for _, a := range argv[len(argv)-len(used):] {
			stored = append(stored, a)
		}
	}
	if err := t.KV.Put("timer-arm:"+canon, py.Dumps(py.D("deadline", deadline,
		"unit", CanonicalUnit(canon), "callback", stored))); err != nil {
		return nil, err
	}
	t.timers[canon] = py.D("deadline", deadline, "state", "armed-host")
	return py.T("armed-host", false), nil
}

// RearmHost re-arms a deadline whose callback ran before it (the host clock
// stepped back between the firing and the callback's read): the SAME unit, at
// the ORIGINAL ledger instant, never a new duration. If that unit is already
// waiting for the same instant (a replay or reopen), it is reused: one due
// timer. The spent unit is stopped and reset first.
func (t *Timers) RearmHost(id string, at time.Time, cb []string) (py.Tuple, error) {
	canon := CanonicalTimerID(id)
	if err := t.guard(canon); err != nil {
		return nil, err
	}
	raw, _ := t.KV.Get("timer-arm:" + canon)
	if ex := loadDict(raw); ex != nil {
		if dl, ok := py.Instant(ex.Get("deadline")); !ok || !dl.Equal(at) {
			return nil, fault("E_TIMER_CONFLICT", "re-arm instant is not the armed deadline; refusing to move a deadline")
		}
	}
	if st, err := t.QueryHost(canon); err == nil && py.S(st.Get("ActiveState")) == "active" && py.S(st.Get("SubState")) == "waiting" {
		if r, ok := t.KV.Get("timer-rearm:" + canon); ok && r == py.ISO(at) {
			return py.T("rearmed-reused", true), nil
		}
	}
	for _, verb := range []string{"stop", "reset-failed"} {
		if _, err := t.run("rearm", []string{t.Systemctl, "--user", verb, CanonicalUnit(canon)}); err != nil {
			return nil, err
		}
	}
	proc, err := t.run("create", t.CommandAt(canon, at, cb))
	if err != nil {
		return nil, err
	}
	if proc.RC != 0 {
		return nil, fault("E_TIMER_CREATE", "re-arm refused: "+firstRunes(proc.Stderr, 200))
	}
	return py.T("rearmed", false), t.KV.Put("timer-rearm:"+canon, py.ISO(at))
}

// CancelHost stops the unit by the same identity, then cancels durably.
func (t *Timers) CancelHost(id string) (py.Tuple, error) {
	canon := CanonicalTimerID(id)
	if err := t.guard(canon); err != nil {
		return nil, err
	}
	for _, verb := range []string{"stop", "reset-failed"} {
		if _, err := t.run("cancel", []string{t.Systemctl, "--user", verb, CanonicalUnit(canon)}); err != nil {
			return nil, err
		}
	}
	return t.Cancel(id)
}

// QueryHost reads the unit's ActiveState/SubState.
func (t *Timers) QueryHost(id string) (*py.Dict, error) {
	canon := CanonicalTimerID(id)
	if err := t.guard(canon); err != nil {
		return nil, err
	}
	proc, err := t.run("query", []string{t.Systemctl, "--user", "show", CanonicalUnit(canon),
		"--property=ActiveState,SubState"})
	if err != nil {
		return nil, err
	}
	if proc.RC != 0 {
		msg := firstRunes(proc.Stderr, 200)
		if msg == "" {
			msg = "no status"
		}
		return nil, fault("E_TIMER_QUERY", "host timer query failed: "+msg)
	}
	props := py.NewDict()
	for _, line := range splitLines(proc.Stdout) {
		if k, v, ok := strings.Cut(line, "="); ok {
			props.Set(strings.TrimSpace(k), strings.TrimSpace(v))
		}
	}
	return props, nil
}

func firstRunes(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		r = r[:n]
	}
	return string(r)
}
