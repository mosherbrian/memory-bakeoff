// Package conform runs the recorded conformance cases against the Go core.
//
// A case is a list of steps recorded from the Python reference: construct an
// object, call a method or function, or set an attribute. After each step it
// holds what the call returned or raised and the full observable state. This
// package replays the steps on the Go objects, reads the Go state in the
// same shape, and reports the first difference. The case format is described
// in conformance/README.md.
package conform

import (
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

type runner struct {
	root    string
	names   map[string]string // T1 -> real dir
	objs    map[string]any
	order   []string
	closed  map[string]bool
	counter int
}

// Result is one case's outcome, the same fields replay_py.py prints.
type Result struct {
	Case      string `json:"case"`
	Steps     int    `json:"steps"`
	OK        bool   `json:"ok"`
	FirstDiff string `json:"first_diff,omitempty"`
}

// RunFile replays one case file.
func RunFile(path string) Result {
	data, err := os.ReadFile(path)
	if err != nil {
		return Result{Case: path, FirstDiff: err.Error()}
	}
	v, err := py.Loads(data)
	if err != nil {
		return Result{Case: path, FirstDiff: err.Error()}
	}
	return Run(py.AsDict(v))
}

// Run replays one parsed case.
func Run(c *py.Dict) Result {
	root, err := os.MkdirTemp("", "conform-")
	if err != nil {
		return Result{Case: py.S(c.Get("id")), FirstDiff: err.Error()}
	}
	r := &runner{root: root, names: map[string]string{}, objs: map[string]any{}, closed: map[string]bool{}}
	defer func() {
		for _, o := range r.objs {
			switch x := o.(type) {
			case *core.Driver:
				x.Close()
			case *core.Store:
				x.Close()
			}
		}
		os.RemoveAll(root)
	}()
	orig := core.TokenHex
	core.TokenHex = func(n int) string { r.counter++; return fmt.Sprintf("%0*x", 2*n, r.counter) }
	defer func() { core.TokenHex = orig }()

	steps := asList(c.Get("steps"))
	res := Result{Case: py.S(c.Get("id")), Steps: len(steps), OK: true}
	for i, s := range steps {
		st := py.AsDict(s)
		outcome := r.step(st)
		got := py.D("expect", outcome, "state", r.dump())
		want := py.D("expect", st.Get("expect"), "state", st.Get("state"))
		if d := FirstDiff(want, got, "$"); d != "" {
			label := st.Get("method")
			for _, k := range []string{"name", "class", "attr"} {
				if label == nil {
					label = st.Get(k)
				}
			}
			res.OK = false
			res.FirstDiff = fmt.Sprintf("step %d (%s %s): %s", i, py.S(st.Get("op")), py.S(label), d)
			return res
		}
	}
	return res
}

func asList(v any) []any {
	switch x := v.(type) {
	case []any:
		return x
	case py.Tuple:
		return x
	}
	return nil
}

func (r *runner) register(id string, o any) {
	if _, ok := r.objs[id]; !ok {
		r.order = append(r.order, id)
	}
	r.objs[id] = o
}

func (r *runner) idOf(o any) (string, bool) {
	for id, x := range r.objs {
		if x == o {
			return id, true
		}
	}
	return "", false
}

func (r *runner) real(p string) string {
	head, rest, _ := strings.Cut(p, "/")
	dir, ok := r.names[head]
	if !ok {
		dir, _ = os.MkdirTemp(r.root, "t")
		r.names[head] = dir
	}
	if rest == "" {
		return dir
	}
	return filepath.Join(dir, rest)
}

// deser turns recorded JSON back into live values.
func (r *runner) deser(v any) any {
	switch x := v.(type) {
	case []any:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = r.deser(e)
		}
		return out
	case *py.Dict:
		if x.Len() == 1 {
			k := x.Keys()[0]
			switch k {
			case "__path__":
				return r.real(x.Get(k).(string))
			case "__ref__":
				return r.objs[x.Get(k).(string)]
			case "__tuple__":
				return py.Tuple(r.deser(x.Get(k)).([]any))
			case "__set__":
				s := py.NewSet()
				for _, e := range asList(x.Get(k)) {
					s.Add(r.deser(e))
				}
				return s
			}
		}
		out := py.NewDict()
		for _, k := range x.Keys() {
			out.Set(k, r.deser(x.Get(k)))
		}
		return out
	}
	return v
}

// ser turns live values into the recorded JSON shape.
func (r *runner) ser(v any) any {
	switch x := v.(type) {
	case string:
		for name, dir := range r.names {
			if x == dir {
				return py.D("__path__", name)
			}
			if strings.HasPrefix(x, dir+string(os.PathSeparator)) {
				return py.D("__path__", name+x[len(dir):])
			}
		}
		return x
	case *py.Dict:
		if x == nil {
			return nil
		}
		out := py.NewDict()
		for _, k := range x.Keys() {
			out.Set(k, r.ser(x.Get(k)))
		}
		return out
	case []any:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = r.ser(e)
		}
		return out
	case py.Tuple:
		return py.D("__tuple__", r.ser([]any(x)))
	case *py.Set:
		items := x.Items()
		out := make([]any, len(items))
		for i, e := range items {
			out[i] = r.ser(e)
		}
		return py.D("__set__", out)
	case nil, bool, int64, float64:
		return x
	case int:
		return int64(x)
	}
	if id, ok := r.idOf(v); ok {
		return py.D("__ref__", id)
	}
	return fmt.Sprintf("<unserialisable %T>", v)
}

func serErr(err error) *py.Dict {
	switch e := err.(type) {
	case *core.TransitionError:
		return py.D("class", "TransitionError", "code", e.Code, "detail", e.Detail)
	case *core.IngressError:
		if e.Quarantined {
			return py.D("class", "Quarantined", "code", e.Code, "detail", e.Detail,
				"owner", e.Owner, "evidence", e.Evidence)
		}
		return py.D("class", "IngressError", "code", e.Code, "detail", e.Detail, "owner", e.Owner)
	case *core.SimulatedCrash:
		return py.D("class", "SimulatedCrash", "str", e.Point)
	case *core.PyError:
		return py.D("class", e.Class, "str", e.Msg)
	}
	return py.D("class", "GoError", "str", err.Error())
}

func (r *runner) step(st *py.Dict) (outcome *py.Dict) {
	defer func() {
		if p := recover(); p != nil {
			outcome = py.D("raise", py.D("class", "GoPanic", "str", fmt.Sprint(p)))
		}
	}()
	args := asList(r.deser(st.GetOr("args", []any{})))
	kw := py.AsDict(r.deser(st.GetOr("kwargs", py.NewDict())))
	if kw == nil {
		kw = py.NewDict()
	}
	var res any
	var err error
	switch st.Get("op") {
	case "new":
		res, err = r.construct(st.Get("class").(string), st.Get("id").(string), args, kw)
	case "call":
		target := st.Get("target").(string)
		method := st.Get("method").(string)
		res, err = r.call(r.objs[target], method, args, kw)
		if method == "close" {
			r.closed[target] = true
		}
	case "func":
		res, err = callFunc(st.Get("name").(string), args, kw)
	case "setattr":
		err = r.setattr(r.objs[st.Get("target").(string)], st.Get("attr").(string), r.deser(st.Get("value")))
	default:
		err = fmt.Errorf("unknown op %v", st.Get("op"))
	}
	if err != nil {
		return py.D("raise", serErr(err))
	}
	return py.D("return", r.ser(res))
}

// dump reads every named object's observable state, keyed by its id.
func (r *runner) dump() *py.Dict {
	ids := append([]string(nil), r.order...)
	sort.Strings(ids)
	out := py.NewDict()
	for _, id := range ids {
		o := r.objs[id]
		if r.closed[id] {
			out.Set(id, "closed")
			continue
		}
		switch x := o.(type) {
		case *core.Driver:
			if x.Store.DB.Ping() != nil { // the store was closed directly, not through the Driver
				out.Set(id, "closed")
				continue
			}
			out.Set(id, r.ser(dumpDriver(x)))
		case *core.Store:
			if strings.Contains(id, ".") {
				continue // a Driver's own store is inside the Driver's dump
			}
			if x.DB.Ping() != nil {
				out.Set(id, "closed")
				continue
			}
			out.Set(id, r.ser(dumpStore(x)))
		case *core.FakeWorld:
			out.Set(id, r.ser(x.State))
		case *core.FakeClock:
			out.Set(id, py.D("now", x.Now(), "mono", x.Mono))
		}
	}
	return out
}

func dumpDriverTables(db *sql.DB) *py.Dict {
	var events []any
	rows, err := db.Query("SELECT event_id, question_id, revision, type, actor_seat," +
		" actor_role, at, body FROM events ORDER BY rowid")
	if err == nil {
		for rows.Next() {
			var eid, q, typ, at, body string
			var rev int64
			var seat, role any
			rows.Scan(&eid, &q, &rev, &typ, &seat, &role, &at, &body)
			b, _ := py.Loads([]byte(body))
			events = append(events, py.D("event_id", eid, "question_id", q, "revision", rev,
				"type", typ, "actor_seat", str(seat), "actor_role", str(role), "at", at, "body", b))
		}
		rows.Close()
	}
	if events == nil {
		events = []any{}
	}
	return py.D("events", events, "meta", kvTable(db, "SELECT key, value FROM meta"))
}

func kvTable(db *sql.DB, q string) *py.Dict {
	out := py.NewDict()
	rows, err := db.Query(q)
	if err != nil {
		return out
	}
	defer rows.Close()
	for rows.Next() {
		var k, v string
		rows.Scan(&k, &v)
		out.Set(k, v)
	}
	return out
}

func dumpDriver(d *core.Driver) *py.Dict {
	t := dumpDriverTables(d.Store.DB)
	revs := py.NewDict()
	for _, k := range d.Store.Revs.Keys() {
		revs.Set(py.S(k.Q)+"|"+py.S(k.Rev), d.Store.Revs.Get(k))
	}
	pairs := func(xs []any) []any {
		out := make([]any, len(xs))
		copy(out, xs)
		return out
	}
	return py.D(
		"events", t.Get("events"),
		"meta", t.Get("meta"),
		"driver_kv", kvTable(d.Store.DB, "SELECT key, value FROM driver_kv"),
		"revisions", revs,
		"seen_events", core.SortedKeys(d.Store.SeenEvents),
		"acks", d.Store.Acks,
		"grants", d.Grants,
		"timer", py.D("armed", d.Timer.Armed, "fired", core.SortedKeys(d.Timer.Fired),
			"removed", core.SortedKeys(d.Timer.Removed)),
		"ext", py.D("stops", pairs(nz(d.Ext.Stops)), "wakes", pairs(nz(d.Ext.Wakes)),
			"notifications", pairs(nz(d.Ext.Notifications))),
		"launches", nz(d.Launch.Launches),
		"executor_runs", nz(d.Executor.Runs),
		"inspect_calls", nz(d.Inspect.Calls),
		"crash_points", core.SortedKeys(d.CrashPoints),
		"ingress", py.D("epoch", d.Ingress.Epoch, "last", d.Ingress.Last,
			"ambiguous", d.Ingress.Ambiguous),
	)
}

func dumpStore(s *core.Store) *py.Dict {
	d := dumpDriverTables(s.DB)
	revs := py.NewDict()
	for _, k := range s.Revs.Keys() {
		revs.Set(py.S(k.Q)+"|"+py.S(k.Rev), s.Revs.Get(k))
	}
	return py.D("events", d.Get("events"), "meta", d.Get("meta"), "revisions", revs,
		"seen_events", core.SortedKeys(s.SeenEvents), "acks", s.Acks)
}

func nz(xs []any) []any {
	if xs == nil {
		return []any{}
	}
	return xs
}

func str(v any) any {
	switch x := v.(type) {
	case []byte:
		return string(x)
	}
	return v
}
