package loop

import (
	"agent-loop/internal/core"
	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// Principal is the runtime seat and session bound to one core role for
// one package. The frozen core knows only its cast (core.Actor); the loop
// records which real principal each cast actor stands for, so the ledger's
// cast actor and the real producer stay linked (P8 live-1: the configured
// director name reached core ingress and was refused E_UNTRUSTED_ACTOR).
type Principal struct {
	Seat    string `json:"seat"`
	Session string `json:"session"`
}

// bindPrincipals records the registry-confirmed principals at dispatch.
func (l *Loop) bindPrincipals(p *Pkg) {
	p.Principals = map[string]Principal{
		"worker":   {p.Worker, l.Cfg.Seats[p.Worker]},
		"verifier": {p.Verifier, l.Cfg.Seats[p.Verifier]},
		"director": {l.Cfg.Director, l.Cfg.Seats[l.Cfg.Director]},
		"duty":     {l.Cfg.Duty, l.Cfg.Seats[l.Cfg.Duty]},
	}
}

// authority returns the core cast actor for role, only if the package has
// a recorded principal for it and the current configuration still binds
// that seat to the same session (and, for director and duty, still names
// that seat). A missing record is never backfilled from today's config.
func (l *Loop) authority(p *Pkg, role string) (*py.Dict, error) {
	rec, ok := p.Principals[role]
	if !ok || rec.Seat == "" || rec.Session == "" {
		return nil, &host.Fault{Code: "E_AUTHORITY_MISSING", Detail: p.QID + " has no recorded " + role + " principal", Owner: "cairn"}
	}
	current := rec.Seat
	switch role {
	case "director":
		current = l.Cfg.Director
	case "duty":
		current = l.Cfg.Duty
	}
	if current != rec.Seat || l.Cfg.Seats[rec.Seat] != rec.Session {
		return nil, &host.Fault{Code: "E_AUTHORITY_CHANGED", Detail: p.QID + ": " + role + " was " + rec.Seat + " (" + rec.Session +
			"), config now binds " + current + " (" + l.Cfg.Seats[current] + ")", Owner: "cairn"}
	}
	a, ok := core.Actor[role]
	if !ok {
		return nil, &host.Fault{Code: "E_AUTHORITY_MISSING", Detail: "the core has no " + role + " role", Owner: "cairn"}
	}
	return a.Copy(), nil
}

// authorities checks several roles before one core step.
func (l *Loop) authorities(p *Pkg, roles ...string) error {
	for _, r := range roles {
		if _, err := l.authority(p, r); err != nil {
			return err
		}
	}
	return nil
}
