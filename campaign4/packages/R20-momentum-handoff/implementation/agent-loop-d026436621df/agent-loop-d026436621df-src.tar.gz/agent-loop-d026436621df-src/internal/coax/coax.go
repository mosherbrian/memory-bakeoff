// Package coax finds dispatched work whose worker has stopped and whose
// result never reached the ledger, and says so to the controller.
//
// It replaces openwork's proxies with facts:
//
//   - a turn ENDED: every seat's acp-stream file holds one turn; it opens with
//     a start row whose item id is the start time in milliseconds, and closes
//     with an end row. The file's mtime is then the end time. openwork asked
//     agent-deck whether the seat looked idle, a status known to lag.
//   - the dispatch has NO RESULT ROW since it was sent. openwork looked for
//     recent files in the package folder and missed output written elsewhere.
//   - the receipt's claim_path, named in the message so the controller can go
//     straight to the evidence.
//
// Rule: the latest dispatch to a seat, a turn of that seat that started at or
// after the dispatch and has ended, `grace` or more ago, and no result row for
// that dispatch since it was sent. Then coax, once per ended turn.
//
// A turn that has not ended is never a stall here: a long silent turn is work.
// (The seat's own stall watchdog ends a turn that truly hangs, and that end
// then counts.) Deadlines stay with the controller's own timers.
package coax

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"agent-loop/internal/shadow"
)

// ResultVerbs are the rows that answer a dispatch. A verb outside this list
// does NOT count as an answer, so an unknown new verb can cause at most one
// extra coax for that turn - never the repeated storm a closed list caused in
// openwork, because each ended turn is coaxed once.
var ResultVerbs = map[string]bool{
	"COMPLETED": true, "COMPLETE": true, "INCOMPLETE": true, "PARTIAL": true,
	"PASS": true, "FAIL": true, "ACCEPTED": true, "BLOCKED": true,
	"CANCELLED": true, "RETIRED": true, "EXHAUSTED": true, "SUPERSEDED": true,
	"WITHDRAWN": true, "FROZEN": true, "RESOLVED": true, "INFRA_FAILURE": true,
	"PREPARED": true,
}

// Turn is what a seat's stream file says about its latest turn.
type Turn struct {
	Start, End time.Time
	Ended      bool
	LastText   string // the tail of what the seat wrote, for the controller
}

// ReadTurn reads one acp-stream file.
func ReadTurn(path string) (Turn, error) {
	var t Turn
	data, err := os.ReadFile(path)
	if err != nil {
		return t, err
	}
	fi, err := os.Stat(path)
	if err != nil {
		return t, err
	}
	var text strings.Builder
	for _, line := range strings.Split(string(data), "\n") {
		if strings.TrimSpace(line) == "" {
			continue
		}
		var r struct{ T, Item, X string }
		if json.Unmarshal([]byte(line), &r) != nil {
			continue
		}
		switch r.T {
		case "start":
			if ms, err := strconv.ParseInt(strings.TrimPrefix(r.Item, "i"), 10, 64); err == nil {
				t.Start = time.UnixMilli(ms).UTC()
			}
			t.Ended = false
			text.Reset()
		case "d":
			text.WriteString(r.X)
		case "end":
			t.Ended = true
			t.End = fi.ModTime().UTC()
		}
	}
	s := strings.TrimSpace(text.String())
	if len(s) > 400 {
		s = "..." + s[len(s)-400:]
	}
	t.LastText = s
	return t, nil
}

// Nudge is one coax the controller should get.
type Nudge struct {
	Key, Seat, QID, Pkg string
	Dispatched, Ended   time.Time
	Started             time.Time
	ClaimPath           string
	ClaimExists         bool
	Text                string
	Case, Why           string // which of the three ways the completion was lost
}

// The three ways a completion is lost, found in the backtest of 18 losses
// on 2026-09-21/22 (tools/backtest_wakes.py): 17 were a, 1 was b, none c.
const (
	CaseNeverSent = "a" // the worker sent no wake (forgot, or its turn was killed first)
	CaseFailed    = "b" // the worker's wake was sent and failed
	CaseIgnored   = "c" // the wake arrived; the controller did not act on it
)

// classify joins the nudge with the wake send log. Log lines are tab
// separated: time, profile, ref, sid, status, bytes, sender, excerpt.
func classify(n *Nudge, wakeLog, to, toID string) {
	n.Case, n.Why = CaseNeverSent, "no wake to "+to+" mentioning "+n.QID+" is in the send log"
	switch {
	case strings.Contains(n.Text, "[stall]"):
		n.Why = "the worker's turn was killed by the stall watchdog before it could send a wake"
	case n.Text == "":
		// 2026-09-22 23:49Z: kiln's turn hit the worker's 1800s turn limit
		// while waiting on a full gate; the stream held no text at all.
		n.Why = fmt.Sprintf("the worker's turn ended after %s with no text: it was cut off "+
			"(turn limit or a dead engine) before it could send a wake", n.Ended.Sub(n.Started).Round(time.Second))
	}
	data, err := os.ReadFile(wakeLog)
	if err != nil {
		n.Why += " (send log unreadable: " + err.Error() + ")"
		return
	}
	for _, line := range strings.Split(string(data), "\n") {
		f := strings.Split(line, "\t")
		if len(f) < 5 || !(f[2] == to || (toID != "" && (f[2] == toID || f[3] == toID))) {
			continue
		}
		t, err := time.Parse(time.RFC3339, f[0])
		if err != nil || t.Before(n.Dispatched.Add(-time.Minute)) {
			continue
		}
		// Monitors (openwork, coax itself) also wake the controller and name
		// the qid; their wakes are not the worker's completion. The first live
		// coax (2026-09-22 23:51Z) said "Case c" because of openwork's
		// "OPEN DISPATCH, IDLE WORKER" nudge at 23:22.
		if len(f) >= 8 && isMonitor(f[7]) {
			continue
		}
		about := len(f) >= 8 && strings.Contains(f[7], n.QID)
		failed := strings.HasPrefix(f[4], "FAILED")
		// A failure with no excerpt still counts inside the worker's turn:
		// failures before the excerpt column existed have none.
		inTurn := !t.Before(n.Dispatched) && !t.After(n.Ended.Add(time.Minute))
		switch {
		case failed && (about || (len(f) < 8 && inTurn)):
			n.Case, n.Why = CaseFailed, "a wake to "+to+" failed at "+t.Format("15:04:05Z")+": "+strings.TrimPrefix(f[4], "FAILED: ")
		case !failed && about:
			n.Case, n.Why = CaseIgnored, "a wake to "+to+" about "+n.QID+" was delivered at "+t.Format("15:04:05Z")+" ("+f[4]+"), but no result row followed"
			return
		}
	}
}

// monitorPrefixes start the wakes that monitors send, never workers.
var monitorPrefixes = []string{"OPEN DISPATCH", "Case ", "[coax]"}

func isMonitor(excerpt string) bool {
	for _, p := range monitorPrefixes {
		if strings.HasPrefix(excerpt, p) {
			return true
		}
	}
	return false
}

// Message is the text sent to the controller.
func (n Nudge) Message(now time.Time) string {
	claim := "no receipt names a claim_path for it"
	if n.ClaimPath != "" {
		state := "MISSING"
		if n.ClaimExists {
			state = "present"
		}
		claim = fmt.Sprintf("claim file %s is %s", n.ClaimPath, state)
	}
	msg := ""
	if n.Case != "" {
		msg = "Case " + n.Case + ": " + n.Why + ". "
	}
	msg += fmt.Sprintf("%s's turn for %s (%s) ended at %s, %d min ago, and no result row for %s "+
		"has been recorded since it was dispatched at %s. The completion may be lost; %s. "+
		"Check the evidence, then record what happened.",
		n.Seat, n.QID, n.Pkg, n.Ended.Format("15:04:05Z"), int(now.Sub(n.Ended).Minutes()),
		n.QID, n.Dispatched.Format("15:04Z"), claim)
	if n.Text != "" {
		msg += fmt.Sprintf(" %s's last words: %q", n.Seat, n.Text)
	}
	return msg
}

func instant(s string) (time.Time, bool) {
	if len(s) == 17 && strings.HasSuffix(s, "Z") {
		s = s[:16] + ":00Z"
	}
	t, err := time.Parse(time.RFC3339, s)
	return t.UTC(), err == nil
}

// Find returns the coaxes due now. seats maps a seat name to its session id.
func Find(rows []shadow.Row, seats map[string]string, streamDir, pkgRoot, wakeLog, to string,
	now time.Time, grace time.Duration) []Nudge {
	latest := map[string]shadow.Row{}
	for _, r := range rows {
		if r.Verb == "DISPATCHED" {
			latest[r.Seat] = r
		}
	}
	var names []string
	for s := range latest {
		names = append(names, s)
	}
	sort.Strings(names)
	var out []Nudge
	for _, seat := range names {
		// The controller's own steps (P6r15-failed-prepare-1, 2026-09-23) are
		// not handoffs: waking it about its own turn tells it nothing.
		if seat == to {
			continue
		}
		d := latest[seat]
		id, ok := seats[seat]
		if !ok {
			continue
		}
		td, ok := instant(d.At)
		if !ok {
			continue
		}
		turn, err := ReadTurn(filepath.Join(streamDir, id+".jsonl"))
		// The dispatch row's time is rounded down to the minute; the turn it
		// started begins at or after it.
		if err != nil || !turn.Ended || turn.Start.Before(td.Add(-time.Minute)) ||
			now.Sub(turn.End) < grace {
			continue
		}
		answered := false
		for _, r := range rows {
			if r.QID != d.QID || !ResultVerbs[r.Verb] {
				continue
			}
			if t, ok := instant(r.At); ok && !t.Before(td) {
				answered = true
			}
		}
		if answered {
			continue
		}
		n := Nudge{Key: d.QID + "@" + turn.Start.Format(time.RFC3339Nano), Seat: seat,
			QID: d.QID, Pkg: d.Pkg, Dispatched: td, Started: turn.Start, Ended: turn.End, Text: turn.LastText}
		n.ClaimPath = claimPath(filepath.Join(pkgRoot, d.Pkg), d.QID)
		if n.ClaimPath != "" {
			_, err := os.Stat(n.ClaimPath)
			n.ClaimExists = err == nil
		}
		if wakeLog != "" {
			classify(&n, wakeLog, to, seats[to])
		}
		out = append(out, n)
	}
	return out
}

// claimPath finds the claim_path a receipt in the package names for qid.
func claimPath(dir, qid string) string {
	files, _ := filepath.Glob(filepath.Join(dir, "*.json"))
	sort.Strings(files)
	for _, f := range files {
		data, err := os.ReadFile(f)
		if err != nil || !strings.Contains(string(data), qid) {
			continue
		}
		var rec map[string]any
		if json.Unmarshal(data, &rec) != nil {
			continue
		}
		if rec["action_id"] == qid {
			if p, ok := rec["claim_path"].(string); ok {
				return p
			}
		}
	}
	return ""
}
