package loop

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
)

// P10: the three P8 liveness blockers, each reproduced as a case that
// failed on c124d82 (evidence/baseline-c124d82.txt) and must now hold.

func TestFutureTimeIsNeverFresh(t *testing.T) {
	u := Unit{Active: "active", InvocationID: inv, MainPID: 7, StartedAt: t0.Add(-time.Hour)}
	for _, c := range []struct {
		ahead time.Duration
		state string
		alarm bool
	}{
		{0, "rest", false},
		{FutureTolerance, "rest", false},                 // the boundary is still accepted
		{FutureTolerance + time.Second, "unknown", true}, // one second past it is not
		{10 * time.Minute, "unknown", true},              // a clock stepped back ten minutes
	} {
		p := pass(-c.ahead, 0, 0)
		v := Assess(u, nil, p, nil, false, time.Time{}, t0)
		if v.State != c.state || v.Alarm != c.alarm {
			t.Errorf("pass %s ahead: %s alarm=%v (%s)", c.ahead, v.State, v.Alarm, v.Why)
		}
	}
}

func TestOnlyTheCurrentIncarnationCounts(t *testing.T) {
	fresh := func(invocation string, pid int) *Pass {
		p := pass(time.Second, 1, 0)
		p.Invocation, p.PID = invocation, pid
		return p
	}
	started := func(ago time.Duration) Unit {
		return Unit{Active: "active", InvocationID: inv, MainPID: 7, StartedAt: t0.Add(-ago)}
	}
	for _, c := range []struct {
		name  string
		u     Unit
		p     *Pass
		state string
		alarm bool
	}{
		{"current run", started(time.Hour), fresh(inv, 7), "ok", false},
		{"previous run, fresh pass", started(time.Hour), fresh("aaaa", 7), "hung", true},
		{"PID reused by a new run", started(time.Hour), fresh("aaaa", 7), "hung", true},
		{"previous run, restart 20 s ago", started(20 * time.Second), fresh("aaaa", 3), "starting", false},
		{"previous run, grace just over", started(StartupGrace + time.Second), fresh("aaaa", 3), "hung", true},
		{"pass with no identity", started(time.Hour), fresh("", 7), "hung", true},
		{"this invocation, another pid", started(time.Hour), fresh(inv, 999), "unknown", true},
		{"unit identity unreadable", Unit{Active: "active", MainPID: 7, StartedAt: t0.Add(-time.Hour)}, fresh(inv, 7), "unknown", true},
		{"start time unreadable", Unit{Active: "active", InvocationID: inv, MainPID: 7}, fresh("aaaa", 7), "unknown", true},
	} {
		v := Assess(c.u, nil, c.p, nil, false, time.Time{}, t0)
		if v.State != c.state || v.Alarm != c.alarm {
			t.Errorf("%s: %s alarm=%v (%s)", c.name, v.State, v.Alarm, v.Why)
		}
	}
}

// The unit restarts before its first pass while an incident is open:
// "starting" keeps the incident open (never recovered), and only a pass
// from the new run closes it.
func TestStartingNeverRecovers(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 1)
	r.check(t0.Add(101 * time.Second)) // hung: incident opened
	r.unit = strings.Replace(r.unit, "InvocationID="+inv, "InvocationID=bbbb", 1)
	r.unit = replaceStart(r.unit, t0.Add(110*time.Second))
	v, _ := r.check(t0.Add(120 * time.Second))
	st, _ := loadState(r.cfg.stateFile())
	if v.State != "starting" || st.Open == nil || len(st.History) != 0 {
		t.Fatalf("starting closed the incident: %v %+v", v, st)
	}
	t.Setenv("INVOCATION_ID", "bbbb")
	r.pass(t0.Add(130*time.Second), 1)
	r.check(t0.Add(140 * time.Second))
	st, _ = loadState(r.cfg.stateFile())
	if st.Open != nil || len(st.History) != 1 || st.History[0].Outcome != "recovered" {
		t.Fatalf("a pass from the new run did not recover: %+v", st)
	}
}

func replaceStart(unit string, at time.Time) string {
	var out []string
	for _, l := range strings.Split(unit, "\n") {
		if strings.HasPrefix(l, "ExecMainStartTimestamp=") {
			l = "ExecMainStartTimestamp=@" + itoa64(at.Unix())
		}
		out = append(out, l)
	}
	return strings.Join(out, "\n")
}

func itoa64(n int64) string { return strconv.FormatInt(n, 10) }

func quarantined(t *testing.T, r *liveRig) []string {
	m, _ := filepath.Glob(r.cfg.stateFile() + ".damaged-*")
	return m
}

func TestDamagedStateAlarmsAndKeepsTheBytes(t *testing.T) {
	for _, c := range []struct {
		name, bytes, kind, prior string
	}{
		{"malformed", "{not json", "malformed", ""},
		{"truncated with an open incident and ack", `{"open": {"id": "L20260923T100000Z", "state": "hung", "opened_at": "2026-09-23T10:00:00Z", "ack": {"by": "tern", "next_action": "restart", "response_deadline": "2026-09-23T10:15`, "malformed", "L20260923T100000Z"},
		{"partially populated", `{"open": {"state": "hung"}}`, "invalid", ""},
	} {
		t.Run(c.name, func(t *testing.T) {
			r := newLiveRig(t)
			r.pass(t0, 0)
			os.WriteFile(r.cfg.stateFile(), []byte(c.bytes), 0o644)
			v, did, err := (&Checker{Cfg: r.cfg, Now: t0.Add(10 * time.Second)}).Check()
			if err != nil || v.State != "unknown" || !v.Alarm || len(r.wakes) != 1 || !strings.Contains(r.wakes[0], "INCIDENT") {
				t.Fatalf("no owned alarm: %v %v %v %v", v, did, err, r.wakes)
			}
			q := quarantined(t, r)
			if len(q) != 1 {
				t.Fatalf("quarantine files: %v", q)
			}
			if b, _ := os.ReadFile(q[0]); string(b) != c.bytes {
				t.Fatal("the preserved copy differs from the original")
			}
			st, _ := loadState(r.cfg.stateFile())
			d := st.Open.Damage
			if d == nil || d.Kind != c.kind || d.Quarantine != q[0] || d.PriorIncident != c.prior || d.Bytes != len(c.bytes) {
				t.Fatalf("damage record: %+v", d)
			}
			if c.prior != "" && (!strings.Contains(d.PriorAck, "restart") || !strings.Contains(st.Open.Why, c.prior)) {
				t.Errorf("continuity lost: %+v / %s", d, st.Open.Why)
			}
			// Repeated checks: one alarm, one copy; no ack by the next window -> director.
			r.check(t0.Add(20 * time.Second))
			if len(r.wakes) != 1 || len(quarantined(t, r)) != 1 {
				t.Fatalf("repeated: %v %v", r.wakes, quarantined(t, r))
			}
			r.check(t0.Add(56 * time.Second))
			if len(r.wakes) != 2 || !strings.Contains(r.wakes[1], "ESCALATION") {
				t.Fatalf("no director escalation: %v", r.wakes)
			}
			// The loop is healthy, but a damage incident closes only after an ack.
			r.pass(t0.Add(60*time.Second), 0)
			r.check(t0.Add(65 * time.Second))
			if st, _ := loadState(r.cfg.stateFile()); st.Open == nil {
				t.Fatal("a damage incident closed without an acknowledgement")
			}
			if err := AckIncident(r.cfg, st.Open.ID, "tern", "inspected the damaged state", 10*time.Minute, t0.Add(66*time.Second)); err != nil {
				t.Fatal(err)
			}
			r.check(t0.Add(70 * time.Second))
			if st, _ := loadState(r.cfg.stateFile()); st.Open != nil || st.History[0].Outcome != "recovered" {
				t.Fatalf("not closed after ack and fresh pass: %+v", st)
			}
		})
	}
}

func TestUnreadableStateIsLeftUntouched(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 0)
	orig := []byte(`{"open": {"id": "L1", "opened_at": "2026-09-23T05:00:00Z"}}`)
	os.WriteFile(r.cfg.stateFile(), orig, 0o644)
	os.Chmod(r.cfg.stateFile(), 0)
	defer os.Chmod(r.cfg.stateFile(), 0o644)
	v, _, err := (&Checker{Cfg: r.cfg, Now: t0.Add(10 * time.Second)}).Check()
	if err != nil || v.State != "unknown" || len(r.wakes) != 1 {
		t.Fatalf("unreadable: %v %v %v", v, err, r.wakes)
	}
	r.check(t0.Add(20 * time.Second))
	if len(r.wakes) != 1 {
		t.Fatalf("re-alarmed every check: %v", r.wakes)
	}
	os.Chmod(r.cfg.stateFile(), 0o644)
	if b, _ := os.ReadFile(r.cfg.stateFile()); string(b) != string(orig) {
		t.Fatal("the unreadable original was changed")
	}
	if _, err := os.Stat(r.cfg.stateFile() + ".alt.json"); err != nil {
		t.Fatal("no working copy was kept")
	}
}

// Nowhere to preserve the damaged bytes: the original stays, the alarm is
// still sent, and the check reports its own failure instead of passing.
func TestNoPlaceToPreserveFailsLoudly(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 0)
	dir := filepath.Dir(r.cfg.stateFile())
	os.WriteFile(r.cfg.stateFile(), []byte("{bad"), 0o644)
	os.Chmod(dir, 0o555)
	defer os.Chmod(dir, 0o755)
	v, _, err := (&Checker{Cfg: r.cfg, Now: t0.Add(10 * time.Second)}).Check()
	os.Chmod(dir, 0o755)
	if err == nil || !v.Alarm || len(r.wakes) != 1 {
		t.Fatalf("silent: %v %v %v", v, err, r.wakes)
	}
	// P12-checker-ownership-1: the unwritable directory also stops the ledger part
	// ("check incomplete"); the state failure itself must still be the reported error.
	if strings.HasPrefix(err.Error(), "check incomplete") {
		t.Fatalf("the state failure was not reported, only the ledger part: %v", err)
	}
	if b, _ := os.ReadFile(r.cfg.stateFile()); string(b) != "{bad" {
		t.Fatal("the only copy was overwritten")
	}
}

// Duty unreachable: the director hears at once, not a check later.
func TestUnreachableDutyReachesTheDirector(t *testing.T) {
	r := newLiveRig(t)
	run := r.cfg.Run
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		if filepath.Base(argv[0]) == "wake" && argv[1] == r.cfg.Seats[r.cfg.Duty] && argv[1] != r.cfg.Seats[r.cfg.Director] {
			return host.Proc{RC: 1}, nil
		}
		return run(argv, env, timeout)
	}
	r.pass(t0, 0)
	r.cfg.Duty = "kiln" // a distinct duty seat for this case
	r.check(t0.Add(101 * time.Second))
	st, _ := loadState(r.cfg.stateFile())
	if len(st.Open.Director) != 1 || !st.Open.Escalated {
		t.Fatalf("director not woken when duty failed: %+v", st.Open)
	}
}
