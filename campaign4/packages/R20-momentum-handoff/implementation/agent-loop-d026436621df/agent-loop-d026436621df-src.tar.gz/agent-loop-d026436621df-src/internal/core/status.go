package core

import "agent-loop/internal/py"

// StatusReport: package, owner/action/deadline, receipt, evidence and next
// permitted action. Simulated observations are labeled SIMULATED.
func StatusReport(packageID any, ledgerPackages, snapshot, verdict *py.Dict) *py.Dict {
	pid, _ := packageID.(string)
	rec := py.AsDict(ledgerPackages.GetOr(pid, py.NewDict()))
	fl := py.AsDict(rec.Get("flight"))
	ho := py.AsDict(rec.Get("handoff"))
	var inflight []*py.Dict
	for _, it := range asList(snapshot.GetOr("in_flight", []any{})) {
		if i, ok := it.(*py.Dict); ok && py.Eq(i.Get("package_id"), packageID) {
			inflight = append(inflight, i)
		}
	}
	evidence := rec.Get("verdict")
	if !py.Truthy(evidence) {
		if len(inflight) > 0 {
			evidence = inflight[0].Get("phase")
		} else {
			evidence = rec.Get("phase")
		}
	}
	return py.D(
		"package", packageID, "simulated", true,
		"owner", or(fl.Get("owner"), ho.Get("owner")),
		"action", fl.Get("action_id"),
		"deadline", or(fl.Get("deadline"), ho.Get("deadline")),
		"receipt", rec.Get("receipt"),
		"evidence", evidence,
		"phase", rec.Get("phase"),
		"next_permitted_action", nextAction(rec, verdict),
		"supervision", verdict,
		"duty", "cairn",
		"escalation", "tern",
	)
}

func or(a, b any) any {
	if py.Truthy(a) {
		return a
	}
	return b
}

func nextAction(rec, verdict *py.Dict) any {
	phase := rec.Get("phase")
	switch {
	case py.Eq(verdict.Get("verdict"), "ACTION_DUE"):
		return "owner-reconcile " + py.S(py.AsDict(verdict.Get("action")).Get("owner"))
	case py.Eq(verdict.Get("verdict"), "INVALID"):
		return "owner-reconcile " + py.S(py.AsDict(verdict.Get("action")).GetOr("owner", "cairn"))
	}
	table := map[string]string{"REGISTERED": "duty start", "RUNNING": "worker publish",
		"CHECKING": "verifier verify", "BLOCKED": "duty resolve/defer/terminate",
		"COMPLETE": "director decide (terminal pause proposal: fake output only)"}
	if s, ok := phase.(string); ok {
		if v, ok := table[s]; ok {
			return v
		}
	}
	return "none"
}
