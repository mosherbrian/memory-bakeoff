package loop

// Supervisor liveness (Tern, OVERNIGHT-EXPOSE-LIVENESS-RULING and P8
// repair-1). `run` records a pass after each completed Tick, from the same
// goroutine; there is no heartbeat thread that could hide a stuck Tick. A
// separate process, `agent-loop liveness`, run by its own systemd timer,
// reads that pass, the stop marker and the unit's state, and owns
// incidents: duty is woken once with an exact acknowledgement command; no
// acknowledgement by the next check, or an acknowledgement whose response
// deadline passes without recovery, wakes the director. A queued or sent
// wake is never an acknowledgement, and an acknowledgement never means
// recovered: only a fresh pass on an active unit closes an incident as
// recovered.
//
// Stop is not cancellation: per-action deadline timers are systemd units
// of their own and keep enforcing granted bounds while `run` is stopped.

import (
	"agent-loop/internal/core"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

const (
	// StaleAfter: no completed pass for this long is a suspected dead or hung
	// loop. With a 45 s check this detects within 145 s (+ <=5 s of calls),
	// inside the 180 s suspicion bound.
	StaleAfter = 100 * time.Second
	// CheckEvery is the outside check's timer interval (the unit file's).
	CheckEvery = 45 * time.Second
	// ExitStopped is run's exit status for an intentional stop; the unit
	// neither restarts nor fails on it.
	ExitStopped = 64
	// ErrorStreakAlarm: this many failed passes in a row is an alarm even
	// though passes complete.
	ErrorStreakAlarm = 3
	// DirectorRepeat bounds repeats of an unresolved incident.
	DirectorRepeat = 15 * time.Minute
	// MaxAckWithin bounds an acknowledgement's response deadline.
	MaxAckWithin = time.Hour
	// FutureTolerance: a pass time later than now by more than this is not
	// evidence of anything (clock step back, or a writer with another
	// clock). The checker and run read the same host clock; 5 s covers the
	// gap between the write and the read plus timestamp truncation.
	FutureTolerance = 5 * time.Second
	// StartupGrace: after the unit starts, run gets this long to complete
	// its first pass before the absence of a pass from the current run is
	// an alarm. During it the state is "starting": quiet, never recovered.
	StartupGrace = 60 * time.Second
)

// StopMarker is the file `agent-loop stop` writes.
func (c *Config) StopMarker() string { return c.DB + ".stop" }

func (c *Config) stateFile() string { return c.DB + ".liveness.json" }

// Pass is what run records after each completed Tick.
type Pass struct {
	At          string `json:"at"`
	PID         int    `json:"pid"`
	Invocation  string `json:"invocation,omitempty"` // systemd INVOCATION_ID of the run that wrote it
	N           int64  `json:"pass"`
	Advanced    int    `json:"advanced"`
	Open        int    `json:"open_packages"`
	LastError   string `json:"last_error,omitempty"`
	ErrorStreak int    `json:"error_streak"`
	Yielded     bool   `json:"yielded,omitempty"` // the pass stopped at the lock budget; work remains
}

// RecordPass writes the pass record (run's goroutine, after Tick).
func (l *Loop) RecordPass(n int64, advanced int, tickErr error) error {
	prev := Pass{}
	json.Unmarshal([]byte(l.D.KV["loop-pass"]), &prev)
	p := Pass{At: py.ISO(l.now()), PID: os.Getpid(), Invocation: os.Getenv("INVOCATION_ID"), N: n, Advanced: advanced, Yielded: l.Yielded}
	for _, x := range l.Pkgs() {
		switch x.Step {
		case "held", "worker", "verify":
			p.Open++
		}
	}
	if tickErr != nil {
		p.LastError, p.ErrorStreak = tickErr.Error(), prev.ErrorStreak+1
	}
	b, _ := json.Marshal(p)
	return l.D.KVPut("loop-pass", string(b))
}

// ReadPass reads the pass record read-only (the check never writes the ledger).
func ReadPass(dbPath string) (*Pass, error) {
	if _, err := os.Stat(dbPath); err != nil {
		return nil, err
	}
	db, err := sql.Open("sqlite", "file:"+dbPath+"?mode=ro&_pragma=busy_timeout(1000)")
	if err != nil {
		return nil, err
	}
	defer db.Close()
	var raw string
	err = db.QueryRow("SELECT value FROM driver_kv WHERE key='loop-pass'").Scan(&raw)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	p := &Pass{}
	if err := json.Unmarshal([]byte(raw), p); err != nil {
		return nil, err
	}
	return p, nil
}

// Unit is the part of `systemctl show` the check reads.
type Unit struct {
	Active, Sub, Result string
	NRestarts           int
	InvocationID        string    // this start of the unit; unique per start
	MainPID             int       // the run process
	StartedAt           time.Time // ExecMainStartTimestamp
}

// QueryUnit reads the run unit's state, bounded to 2 s.
func QueryUnit(run host.Runner, systemctl, unit string) (Unit, error) {
	if run == nil {
		run = host.ExecRunner
	}
	proc, err := run([]string{systemctl, "--user", "show", unit, "--timestamp=unix", "-p",
		"ActiveState,SubState,Result,NRestarts,InvocationID,MainPID,ExecMainStartTimestamp"}, nil, 2*time.Second)
	if err != nil {
		return Unit{}, err
	}
	if proc.RC != 0 {
		return Unit{}, fmt.Errorf("systemctl show %s: rc %d %s", unit, proc.RC, strings.TrimSpace(proc.Stderr))
	}
	u := Unit{}
	for _, line := range strings.Split(proc.Stdout, "\n") {
		k, v, _ := strings.Cut(strings.TrimSpace(line), "=")
		switch k {
		case "ActiveState":
			u.Active = v
		case "SubState":
			u.Sub = v
		case "Result":
			u.Result = v
		case "NRestarts":
			u.NRestarts, _ = strconv.Atoi(v)
		case "InvocationID":
			u.InvocationID = v
		case "MainPID":
			u.MainPID, _ = strconv.Atoi(v)
		case "ExecMainStartTimestamp":
			if sec, err := strconv.ParseInt(strings.TrimPrefix(v, "@"), 10, 64); err == nil && sec > 0 {
				u.StartedAt = time.Unix(sec, 0).UTC()
			}
		}
	}
	if u.Active == "" {
		return u, fmt.Errorf("systemctl show %s: no ActiveState", unit)
	}
	return u, nil
}

// Verdict is the check's judgement.
type Verdict struct {
	State string `json:"state"` // ok rest stopped stopping | stop-pending crashed down restart-loop hung erroring unknown
	Alarm bool   `json:"alarm"`
	Why   string `json:"why"`
}

// Assess is the pure decision. Unknown is never green.
func Assess(u Unit, uerr error, p *Pass, perr error, marker bool, markerAt, now time.Time) Verdict {
	alarm := func(s, why string) Verdict { return Verdict{s, true, why} }
	quiet := func(s, why string) Verdict { return Verdict{s, false, why} }
	if uerr != nil {
		return alarm("unknown", "unit state unreadable: "+uerr.Error())
	}
	if marker {
		switch u.Active {
		case "inactive", "failed":
			return quiet("stopped", "stopped by agent-loop stop")
		}
		if now.Sub(markerAt) > StaleAfter {
			return alarm("stop-pending", fmt.Sprintf("stop requested %s ago, unit still %s", now.Sub(markerAt).Round(time.Second), u.Active))
		}
		return quiet("stopping", "stop requested, run finishing its pass")
	}
	switch u.Active {
	case "failed":
		if u.Result == "start-limit-hit" {
			return alarm("restart-loop", fmt.Sprintf("start limit hit after %d restarts", u.NRestarts))
		}
		return alarm("crashed", "unit failed: "+u.Result)
	case "inactive":
		return alarm("down", "run is not running and no stop was requested")
	}
	if perr != nil {
		return alarm("unknown", "ledger unreadable: "+perr.Error())
	}
	if p == nil {
		return alarm("hung", "unit "+u.Active+" but no completed pass is recorded")
	}
	at, ok := py.Instant(p.At)
	if !ok {
		return alarm("unknown", "pass time unreadable: "+p.At)
	}
	// A pass time in the future proves nothing (P8 blocker 2).
	if ahead := at.Sub(now); ahead > FutureTolerance {
		return alarm("unknown", fmt.Sprintf("pass time %s is %s in the future (clock stepped back?)", p.At, ahead.Round(time.Second)))
	}
	// Only a pass written by the unit's current start counts (P8 blocker 3):
	// same invocation and the unit's main process. A pass from an earlier
	// run, a reused PID or a pass with no identity cannot vouch for this one.
	if u.InvocationID == "" {
		return alarm("unknown", "the unit's current incarnation is unreadable (no InvocationID)")
	}
	if p.Invocation != u.InvocationID {
		from := "a previous run (invocation " + p.Invocation + ")"
		if p.Invocation == "" {
			from = "a writer with no incarnation identity"
		}
		if u.StartedAt.IsZero() {
			return alarm("unknown", "last pass is from "+from+" and the unit's start time is unreadable")
		}
		if since := now.Sub(u.StartedAt); since <= StartupGrace {
			return quiet("starting", fmt.Sprintf("run started %s ago and has not completed a pass yet; last pass is from %s (not recovered)",
				since.Round(time.Second), from))
		}
		return alarm("hung", fmt.Sprintf("no completed pass from the current run (invocation %s, started %s); last pass is from %s",
			u.InvocationID, py.ISO(u.StartedAt), from))
	}
	if p.PID != u.MainPID {
		return alarm("unknown", fmt.Sprintf("pass from this invocation but pid %d, while the unit's main pid is %d", p.PID, u.MainPID))
	}
	if age := now.Sub(at); age > StaleAfter {
		if u.Active == "active" {
			return alarm("hung", fmt.Sprintf("no completed pass for %s (unit active, pid %d)", age.Round(time.Second), p.PID))
		}
		return alarm("crashed", fmt.Sprintf("no completed pass for %s (unit %s/%s, %d restarts)", age.Round(time.Second), u.Active, u.Sub, u.NRestarts))
	}
	if p.ErrorStreak >= ErrorStreakAlarm {
		return alarm("erroring", fmt.Sprintf("%d failed passes in a row: %s", p.ErrorStreak, p.LastError))
	}
	if p.Open == 0 {
		return quiet("rest", "no open packages; passes continue")
	}
	return quiet("ok", fmt.Sprintf("pass %d %s ago", p.N, now.Sub(at).Round(time.Second)))
}

// Wake is one liveness send and what the transport said.
type Wake struct {
	At     string `json:"at"`
	To     string `json:"to"`
	Status string `json:"status"` // sent / queued / failed / ambiguous: never an acknowledgement
}

// Ack binds an owner, a next action and an absolute response deadline.
type Ack struct {
	By         string `json:"by"`
	NextAction string `json:"next_action"`
	Deadline   string `json:"response_deadline"`
	At         string `json:"at"`
}

// Incident is one liveness fault from detection to close.
type Incident struct {
	ID        string  `json:"id"`
	State     string  `json:"state"`
	Why       string  `json:"why"`
	OpenedAt  string  `json:"opened_at"`
	Duty      *Wake   `json:"duty_wake,omitempty"`
	Director  []Wake  `json:"director_wakes,omitempty"`
	Ack       *Ack    `json:"ack,omitempty"`
	ClosedAt  string  `json:"closed_at,omitempty"`
	Outcome   string  `json:"outcome,omitempty"` // recovered | stopped-intentionally
	Evidence  Verdict `json:"closing_evidence,omitempty"`
	Escalated bool    `json:"escalated"`
	Damage    *Damage `json:"state_damage,omitempty"` // the incident state file was damaged when this opened
}

// Damage is what the check preserved about a damaged or unreadable state file.
type Damage struct {
	At            string `json:"at"`
	Kind          string `json:"kind"` // malformed | invalid | unreadable
	Detail        string `json:"detail"`
	Original      string `json:"original"`
	Quarantine    string `json:"quarantine,omitempty"` // verified byte copy of the original
	SHA256        string `json:"sha256,omitempty"`
	Bytes         int    `json:"bytes"`
	PriorIncident string `json:"prior_incident,omitempty"` // id recovered from the damaged bytes, if any
	PriorAck      string `json:"prior_ack,omitempty"`      // raw ack fragment recovered, if any
}

// LiveState is the check's own file; it is not the ledger.
type LiveState struct {
	Open    *Incident         `json:"open,omitempty"`
	History []Incident        `json:"history,omitempty"`
	Msgs    map[string]string `json:"wake_receipts,omitempty"`
	Last    *Verdict          `json:"last_verdict,omitempty"`
	LastAt  string            `json:"last_check_at,omitempty"`
}

func loadState(path string) (*LiveState, error) {
	s := &LiveState{}
	b, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		return s, nil
	}
	if err != nil {
		return nil, err
	}
	return s, json.Unmarshal(b, s)
}

var (
	priorIDRe  = regexp.MustCompile(`"open"\s*:\s*\{[^{}]*?"id"\s*:\s*"([^"]+)"`)
	priorAckRe = regexp.MustCompile(`"ack"\s*:\s*(\{[^}]*\}?)`)
)

// valid reports whether a parsed state is usable as-is.
func (s *LiveState) valid() error {
	if s.Open != nil && (s.Open.ID == "" || s.Open.OpenedAt == "") {
		return fmt.Errorf("open incident without id or opened_at")
	}
	return nil
}

// resolveState loads the check's state without ever losing the only copy
// of a damaged file (P8 blocker 1). It returns the state, the path to save
// it to, and what was preserved when the file was damaged or unreadable.
//   - malformed/truncated/invalid: the original bytes are copied to a new
//     <file>.damaged-<time>.json (never overwriting), the copy is verified,
//     and only then does a fresh state replace the original;
//   - unreadable: the original is left untouched and the check works from
//     <file>.alt.json until the original is readable again;
//   - if the copy cannot be made, the original is left untouched as well.
func resolveState(path string, now time.Time) (*LiveState, string, *Damage) {
	b, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		return &LiveState{}, path, nil
	}
	alt := path + ".alt.json"
	if err != nil {
		// While the original stays unreadable the verdict stays UNKNOWN; the
		// open incident in the working copy keeps notification to once.
		d := &Damage{At: py.ISO(now), Kind: "unreadable", Detail: err.Error(), Original: path}
		st, _, altDamage := resolveState(alt, now)
		if altDamage != nil {
			d.Detail += "; working copy also damaged: " + altDamage.Detail
		}
		return st, alt, d
	}
	st := &LiveState{}
	perr := json.Unmarshal(b, st)
	if perr == nil {
		perr = st.valid()
	}
	if perr == nil {
		return st, path, nil
	}
	h := sha256.Sum256(b)
	d := &Damage{At: py.ISO(now), Kind: "malformed", Detail: perr.Error(), Original: path,
		SHA256: hex.EncodeToString(h[:]), Bytes: len(b)}
	if st.valid() != nil {
		d.Kind = "invalid"
	}
	if m := priorIDRe.FindSubmatch(b); m != nil {
		d.PriorIncident = string(m[1])
	}
	if m := priorAckRe.FindSubmatch(b); m != nil {
		d.PriorAck = string(m[1])
	}
	q, qerr := quarantine(path, b, now)
	if qerr != nil {
		d.Detail += "; could not preserve a copy (" + qerr.Error() + "), original left in place"
		fresh, _, _ := resolveState(alt, now)
		return fresh, alt, d
	}
	d.Quarantine = q
	return &LiveState{}, path, d
}

func quarantine(path string, b []byte, now time.Time) (string, error) {
	base := path + ".damaged-" + now.UTC().Format("20060102T150405Z")
	for i := 0; i < 100; i++ {
		q := base + ".json"
		if i > 0 {
			q = fmt.Sprintf("%s-%d.json", base, i)
		}
		f, err := os.OpenFile(q, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
		if os.IsExist(err) {
			continue
		}
		if err != nil {
			return "", err
		}
		_, werr := f.Write(b)
		cerr := f.Close()
		if werr != nil || cerr != nil {
			return "", fmt.Errorf("write %s: %v %v", q, werr, cerr)
		}
		back, err := os.ReadFile(q)
		if err != nil || string(back) != string(b) {
			return "", fmt.Errorf("verify %s failed", q)
		}
		return q, nil
	}
	return "", fmt.Errorf("no free quarantine name for %s", base)
}

func saveState(path string, s *LiveState) error {
	if len(s.History) > 50 {
		s.History = s.History[len(s.History)-50:]
	}
	b, _ := json.MarshalIndent(s, "", " ")
	if err := os.WriteFile(path+".tmp", b, 0o644); err != nil {
		return err
	}
	return os.Rename(path+".tmp", path)
}

type mapKV map[string]string

func (m mapKV) Get(k string) (string, bool) { v, ok := m[k]; return v, ok }
func (m mapKV) Put(k, v string) error       { m[k] = v; return nil }

// Checker runs one outside check. Now and Run are injectable.
type Checker struct {
	Cfg *Config
	Now time.Time
}

func (c *Checker) wake(st *LiveState, seat, text string) Wake {
	if st.Msgs == nil {
		st.Msgs = map[string]string{}
	}
	tr := &host.WakeTransport{WakePath: c.Cfg.Wake, Allowlist: []string{c.Cfg.Seats[seat]}, Enabled: true,
		Profile: c.Cfg.Profile, KV: mapKV(st.Msgs), Run: c.Cfg.Run, Timeout: 2500 * time.Millisecond}
	w := Wake{At: py.ISO(c.Now), To: seat}
	mid, err := tr.Send(c.Cfg.Seats[seat], text, "liveness", "liveness", nil)
	if err != nil {
		w.Status = "failed: " + err.Error()
		return w
	}
	w.Status = tr.State(mid)
	return w
}

func (c *Checker) ackCommand(id string) string {
	return fmt.Sprintf("%s liveness-ack --config %s --incident %s --by %s --next \"WHAT YOU WILL DO\" --within 15m",
		c.Cfg.Bin, c.Cfg.Path, id, c.Cfg.Duty)
}

// Check assesses and acts. It returns the verdict and what it did.
func (c *Checker) Check() (Verdict, []string, error) {
	v, did, err := c.check()
	// Outstanding step timeouts are escalated here too, so an intentional
	// stop (quiet for the loop itself) never leaves one waiting on nobody.
	// This is reported separately and opens no liveness incident.
	if _, serr := os.Stat(c.Cfg.DB); serr == nil {
		msgs, eerr := EscalateTimeouts(c.Cfg, core.NewFakeClock(py.ISO(c.Now)))
		for _, m := range msgs {
			did = append(did, "timeout: "+m)
		}
		if eerr != nil {
			// P12-checker-ownership-1: the ledger part did not run. Record it
			// durably (no ledger lock) and fail the check: never a completed one.
			did = append(did, "timeout escalation failed: "+eerr.Error())
			if perr := RecordPendingCheck(c.Cfg, c.Now, eerr.Error()); perr != nil {
				did = append(did, "pending check NOT recorded: "+perr.Error())
			}
			if err == nil {
				err = fmt.Errorf("check incomplete: %v", eerr)
			}
			return v, did, err
		}
	}
	if err == nil {
		did = append(did, ReconcileCheck(c.Cfg, c.Now)...)
	}
	return v, did, err
}

func (c *Checker) check() (Verdict, []string, error) {
	cfg := c.Cfg
	st, statePath, damage := resolveState(cfg.stateFile(), c.Now)
	var markerAt time.Time
	fi, mErr := os.Stat(cfg.StopMarker())
	marker := mErr == nil
	if marker {
		markerAt = fi.ModTime()
	}
	u, uerr := QueryUnit(cfg.Run, cfg.Systemctl, cfg.Unit)
	p, perr := ReadPass(cfg.DB)
	v := Assess(u, uerr, p, perr, marker, markerAt, c.Now)
	if damage != nil {
		v = Verdict{"unknown", true, fmt.Sprintf("incident state %s (%s); loop itself: %s: %s", damage.Kind, damage.Detail, v.State, v.Why)}
	}
	st.Last, st.LastAt = &v, py.ISO(c.Now)
	var did []string
	save := func() error { return saveState(statePath, st) }
	// An incident closes only on fresh evidence: ok, rest or an intentional
	// stop. "starting" is quiet but proves nothing; a state-damage incident
	// also needs its owner's acknowledgement before it can close.
	closeable := !v.Alarm && v.State != "starting"
	if inc := st.Open; closeable && inc != nil && inc.Damage != nil && inc.Ack == nil {
		closeable = false
	}
	if !v.Alarm && !closeable && st.Open == nil {
		return v, did, save()
	}
	if closeable {
		if inc := st.Open; inc != nil {
			inc.ClosedAt, inc.Evidence = py.ISO(c.Now), v
			inc.Outcome = "recovered"
			if v.State == "stopped" || v.State == "stopping" {
				inc.Outcome = "stopped-intentionally"
			}
			st.History = append(st.History, *inc)
			st.Open = nil
			did = append(did, "closed "+inc.ID+": "+inc.Outcome)
		}
		return v, did, save()
	}
	inc := st.Open
	if inc == nil {
		inc = &Incident{ID: "L" + c.Now.UTC().Format("20060102T150405Z"), State: v.State, Why: v.Why, OpenedAt: py.ISO(c.Now), Damage: damage}
		if damage != nil && damage.PriorIncident != "" {
			inc.Why += "; the damaged state held open incident " + damage.PriorIncident
		}
		st.Open = inc
		w := c.wake(st, cfg.Duty, fmt.Sprintf("[agent-loop liveness] INCIDENT %s on %s: %s: %s. You own it (duty). Acknowledge within %s with: %s",
			inc.ID, cfg.Project, v.State, inc.Why, CheckEvery, c.ackCommand(inc.ID)))
		inc.Duty = &w
		did = append(did, "opened "+inc.ID+", duty woken: "+w.Status)
		if w.Status != "sent" && w.Status != "queued" {
			// Duty unreachable: the director hears now, not a check later.
			dw := c.wake(st, cfg.Director, fmt.Sprintf("[agent-loop liveness] ESCALATION %s on %s: %s: %s; duty unreachable (%s). Acknowledge with: %s",
				inc.ID, cfg.Project, v.State, inc.Why, w.Status, strings.Replace(c.ackCommand(inc.ID), "--by "+cfg.Duty, "--by "+cfg.Director, 1)))
			inc.Director, inc.Escalated = append(inc.Director, dw), true
			did = append(did, "duty unreachable, director woken: "+dw.Status)
		}
		return v, did, save()
	}
	if v.Alarm {
		inc.State, inc.Why = v.State, v.Why
	}
	if inc.Duty == nil { // a partially recorded incident: send what was never sent
		w := c.wake(st, cfg.Duty, fmt.Sprintf("[agent-loop liveness] INCIDENT %s on %s: %s: %s. You own it (duty). Acknowledge within %s with: %s",
			inc.ID, cfg.Project, inc.State, inc.Why, CheckEvery, c.ackCommand(inc.ID)))
		inc.Duty = &w
		did = append(did, "duty woken for "+inc.ID+": "+w.Status)
		return v, did, save()
	}
	escalate, reason := false, ""
	switch {
	case inc.Ack != nil:
		dl, ok := py.Instant(inc.Ack.Deadline)
		if !ok || c.Now.After(dl) {
			escalate, reason = true, fmt.Sprintf("acknowledged by %s (%s) but not recovered by %s", inc.Ack.By, inc.Ack.NextAction, inc.Ack.Deadline)
		}
	default:
		opened, _ := py.Instant(inc.Duty.At)
		if c.Now.Sub(opened) >= CheckEvery-5*time.Second {
			escalate, reason = true, "duty did not acknowledge (wake "+inc.Duty.Status+")"
		}
	}
	if escalate {
		last := time.Time{}
		if n := len(inc.Director); n > 0 {
			last, _ = py.Instant(inc.Director[n-1].At)
		}
		if len(inc.Director) == 0 || c.Now.Sub(last) >= DirectorRepeat {
			w := c.wake(st, cfg.Director, fmt.Sprintf("[agent-loop liveness] ESCALATION %s on %s: %s: %s; %s. Acknowledge with: %s",
				inc.ID, cfg.Project, v.State, v.Why, reason, strings.Replace(c.ackCommand(inc.ID), "--by "+cfg.Duty, "--by "+cfg.Director, 1)))
			inc.Director = append(inc.Director, w)
			inc.Escalated = true
			did = append(did, "director woken for "+inc.ID+": "+w.Status)
		}
	}
	return v, did, save()
}

// AckIncident records an owner's acknowledgement. It never closes the
// incident; only a recovered check does.
func AckIncident(cfg *Config, id, by, next string, within time.Duration, now time.Time) error {
	if by != cfg.Duty && by != cfg.Director {
		return fmt.Errorf("%s is neither the duty seat (%s) nor the director (%s)", by, cfg.Duty, cfg.Director)
	}
	if strings.TrimSpace(next) == "" {
		return fmt.Errorf("--next must name the next action")
	}
	if within <= 0 || within > MaxAckWithin {
		return fmt.Errorf("--within must be between 1s and %s", MaxAckWithin)
	}
	st, path, damage := resolveState(cfg.stateFile(), now)
	if damage != nil && damage.Kind != "unreadable" {
		return fmt.Errorf("the incident state was damaged (%s); run the liveness check first, which preserves it", damage.Detail)
	}
	if st.Open == nil || st.Open.ID != id {
		return fmt.Errorf("no open incident %s", id)
	}
	st.Open.Ack = &Ack{By: by, NextAction: next, Deadline: py.ISO(now.Add(within)), At: py.ISO(now)}
	return saveState(path, st)
}
