package loop

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// rig is one project in a temp dir with a scripted wake script and
// systemd-run: every call is recorded, and a call's exit code can be
// scripted by the first argument.
type rig struct {
	t     *testing.T
	cfg   *Config
	clock *core.FakeClock
	calls [][]string
	fail  map[string]bool // argv[0] base names that fail
	// registry is what `agent-deck list --json` prints.
	registry string
}

func newRig(t *testing.T) *rig {
	dir := t.TempDir()
	r := &rig{t: t, clock: core.NewFakeClock(nil), fail: map[string]bool{},
		registry: `[{"id": "K", "title": "kiln"}, {"id": "C", "title": "corvid - reviewer"}, {"id": "T", "title": "tern"}]`}
	r.cfg = &Config{Project: "test", Wake: "/x/wake", DB: filepath.Join(dir, "loop.db"),
		StreamDir: filepath.Join(dir, "stream"), ClaimsDir: filepath.Join(dir, "claims"),
		ArtifactsDir: filepath.Join(dir, "art"), Director: "tern", Duty: "tern",
		Seats: map[string]string{"kiln": "K", "corvid": "C", "tern": "T"}, Bin: "/x/agent-loop",
		AgentDeck:  "agent-deck",
		SystemdRun: "systemd-run", Systemctl: "systemctl", MaxVerifyS: 7200, DecisionS: 86400,
		Path: filepath.Join(dir, "loop.json")}
	for _, d := range []string{r.cfg.StreamDir, r.cfg.ArtifactsDir} {
		os.MkdirAll(d, 0o755)
	}
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		r.calls = append(r.calls, argv)
		if r.fail[filepath.Base(argv[0])] {
			return host.Proc{RC: 1, Stderr: "refused"}, nil
		}
		if argv[0] == "agent-deck" {
			return host.Proc{RC: 0, Stdout: r.registry}, nil
		}
		if filepath.Base(argv[0]) == "wake" {
			return host.Proc{RC: 0, Stdout: "wake: " + argv[1] + " -> started\n"}, nil
		}
		return host.Proc{RC: 0}, nil
	}
	return r
}

func (r *rig) open() *Loop {
	l, err := Open(r.cfg, r.clock)
	if err != nil {
		r.t.Fatal(err)
	}
	return l
}

// wakes returns "seat: text-prefix" for every wake sent.
func (r *rig) wakes() []string {
	var out []string
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" {
			text := c[2]
			if len(text) > 40 {
				text = text[:40]
			}
			out = append(out, map[string]string{"K": "kiln", "C": "corvid", "T": "tern"}[c[1]]+": "+text)
		}
	}
	return out
}

func (r *rig) timers() int {
	n := 0
	for _, c := range r.calls {
		if c[0] == "systemd-run" {
			n++
		}
	}
	return n
}

// turnEnd appends a finished turn to a seat's stream, started now.
func (r *rig) turnEnd(key string) {
	now, _ := py.Instant(r.clock.Now())
	item := fmt.Sprintf("i%d", now.UnixMilli())
	f, _ := os.OpenFile(filepath.Join(r.cfg.StreamDir, key+".jsonl"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	fmt.Fprintf(f, "{\"t\": \"start\", \"item\": %q}\n{\"t\": \"end\", \"item\": %q}\n", item, item)
	f.Close()
}

func (r *rig) artifact(name, text string) {
	os.WriteFile(filepath.Join(r.cfg.ArtifactsDir, name), []byte(text), 0o644)
}

func (r *rig) tick(l *Loop) []string {
	msgs, err := l.Tick()
	if err != nil {
		r.t.Fatal(err)
	}
	return msgs
}

func must(t *testing.T, err error) {
	t.Helper()
	if err != nil {
		t.Fatal(err)
	}
}

func step(l *Loop, qid string) string { return l.Pkg(qid).Step }

func TestHappyPathToDecision(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "P1", Worker: "kiln", Verifier: "corvid", WorkerTask: "build the thing", VerifyTask: "review the thing", DurationS: 2400, VerifyS: 1200, OnPass: nil})
	must(t, err)
	if r.timers() != 1 || len(r.wakes()) != 1 || !strings.HasPrefix(r.wakes()[0], "kiln: ") {
		t.Fatalf("dispatch should arm one timer and wake kiln once: %v", r.calls)
	}
	if last := r.calls[len(r.calls)-1]; last[1] != "K" || !strings.Contains(last[2], "claim --config") {
		t.Fatalf("the worker's task must go to kiln's session and carry the claim command: %v", last)
	}
	// The worker's turn ends before its claim exists: nothing moves.
	r.clock.Advance(300)
	r.turnEnd("K")
	if msgs := r.tick(l); len(msgs) != 0 || step(l, "P1") != "worker" {
		t.Fatalf("moved without a claim: %v", msgs)
	}
	r.artifact("out.txt", "result")
	_, err = l.Claim("P1", "worker", "completed", map[string]string{"out": "out.txt"})
	must(t, err)
	if msgs := r.tick(l); len(msgs) != 1 || step(l, "P1") != "verify" {
		t.Fatalf("worker claim did not dispatch the verifier: %v", msgs)
	}
	if w := r.wakes(); len(w) != 2 || !strings.HasPrefix(w[1], "corvid: ") || r.timers() != 2 {
		t.Fatalf("verifier not woken once with its own timer: %v", w)
	}
	r.clock.Advance(600)
	r.artifact("review.md", "looks right")
	_, err = l.Claim("P1", "verify", "completed", map[string]string{"review": "review.md"})
	must(t, err)
	r.turnEnd("C")
	msgs := r.tick(l)
	if step(l, "P1") != "decision" || l.Pkg("P1").Verdict != "PASS" {
		t.Fatalf("verifier PASS not recorded for decision: %v %+v", msgs, l.Pkg("P1"))
	}
	if w := r.wakes(); !strings.HasPrefix(w[len(w)-1], "tern: ") {
		t.Fatalf("director not asked to decide: %v", w)
	}
	must(t, l.Decide("P1", "question_answered", "tern-1", "done"))
	if step(l, "P1") != "closed" {
		t.Fatal("decide did not close the package")
	}
	if ph := py.S(l.D.Store.Revs.Get(core.RevKey{Q: "P1", Rev: int64(1)}).Get("phase")); ph != "COMPLETE" {
		t.Fatalf("ledger phase %s", ph)
	}
	if err := l.Decide("P1", "question_answered", "tern-2", "again"); err == nil {
		t.Fatal("a second decision was accepted")
	}
}

func TestOnPassClosesWithoutADecision(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "P2", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200, OnPass: &OnPass{Kind: "question_answered", DecisionRef: "tern-pre", Reason: "pre-authorized"}})
	must(t, err)
	r.clock.Advance(60)
	r.artifact("o", "x")
	l.Claim("P2", "worker", "completed", map[string]string{"o": "o"})
	r.turnEnd("K")
	r.tick(l)
	r.clock.Advance(60)
	r.artifact("r", "ok")
	l.Claim("P2", "verify", "completed", map[string]string{"r": "r"})
	r.turnEnd("C")
	r.tick(l)
	if p := l.Pkg("P2"); p.Step != "closed" || p.Verdict != "PASS" {
		t.Fatalf("pre-authorized PASS did not close: %+v", p)
	}
}

func TestVerifierFailWaitsForTheDirector(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "P3", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200, OnPass: &OnPass{Kind: "question_answered", DecisionRef: "x", Reason: "y"}})
	must(t, err)
	r.clock.Advance(60)
	r.artifact("o", "x")
	l.Claim("P3", "worker", "completed", map[string]string{"o": "o"})
	r.turnEnd("K")
	r.tick(l)
	r.clock.Advance(60)
	r.artifact("r", "wrong")
	l.Claim("P3", "verify", "failed", map[string]string{"r": "r"})
	r.turnEnd("C")
	r.tick(l)
	if p := l.Pkg("P3"); p.Step != "decision" || p.Verdict != "FAIL" {
		t.Fatalf("a FAIL must not close on the pre-authorized PASS disposition: %+v", p)
	}
}

func TestTamperedArtifactIsOwnedRecovery(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "P4", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200, OnPass: nil})
	must(t, err)
	r.clock.Advance(60)
	r.artifact("o", "x")
	l.Claim("P4", "worker", "completed", map[string]string{"o": "o"})
	r.artifact("o", "changed after the claim")
	r.turnEnd("K")
	r.tick(l)
	if p := l.Pkg("P4"); p.Step != "recovery" || !strings.Contains(p.Notes[len(p.Notes)-1], "E_ARTIFACT_MISMATCH") {
		t.Fatalf("tampered artifact not caught: %+v", p)
	}
	if w := r.wakes(); !strings.HasPrefix(w[len(w)-1], "tern: escalation:P4-w1") {
		t.Fatalf("director not told: %v", w)
	}
}

func TestOldTurnEndsAreIgnored(t *testing.T) {
	r := newRig(t)
	r.turnEnd("K") // a turn from before the dispatch
	r.artifact("o", "x")
	l := r.open()
	defer l.Close()
	r.clock.Advance(60)
	_, err := l.Dispatch(Request{QID: "P5", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200, OnPass: nil})
	must(t, err)
	l.Claim("P5", "worker", "completed", map[string]string{"o": "o"})
	if msgs := r.tick(l); len(msgs) != 0 || step(l, "P5") != "worker" {
		t.Fatalf("an old turn end moved the package: %v", msgs)
	}
}

func TestNoTimerNoDispatch(t *testing.T) {
	r := newRig(t)
	r.fail["systemd-run"] = true
	l := r.open()
	defer l.Close()
	if _, err := l.Dispatch(Request{QID: "P6", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200, OnPass: nil}); err == nil {
		t.Fatal("dispatch succeeded without a deadline timer")
	}
	if len(r.wakes()) != 0 || step(l, "P6") != "blocked" {
		t.Fatalf("the worker was sent work with no deadline timer: %v", r.wakes())
	}
}

func TestDispatchRefusals(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	for name, err := range map[string]error{
		"same seat": func() error {
			_, e := l.Dispatch(Request{QID: "A", Worker: "kiln", Verifier: "kiln", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 60, OnPass: nil})
			return e
		}(),
		"unknown seat": func() error {
			_, e := l.Dispatch(Request{QID: "B", Worker: "kiln", Verifier: "mallory", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 60, OnPass: nil})
			return e
		}(),
		"window too big": func() error {
			_, e := l.Dispatch(Request{QID: "C", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 7201, OnPass: nil})
			return e
		}(),
	} {
		if err == nil {
			t.Errorf("%s: accepted", name)
		}
	}
	_, err := l.Dispatch(Request{QID: "D", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 600, VerifyS: 600, OnPass: nil})
	must(t, err)
	if _, err := l.Dispatch(Request{QID: "D", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 600, VerifyS: 600, OnPass: nil}); err == nil {
		t.Error("the same package was dispatched twice")
	}
}

func TestRestartDoesNotResend(t *testing.T) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(Request{QID: "P7", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200, OnPass: nil})
	must(t, err)
	l.Close()
	l = r.open()
	defer l.Close()
	res, err := l.Adapter.ReconcileOutbox()
	must(t, err)
	r.tick(l)
	if len(r.wakes()) != 1 {
		t.Fatalf("restart resent the dispatch: %v (%s)", r.wakes(), py.Dumps(res))
	}
}

func TestDeadlineCancelsTheTurnAndTellsTheDirector(t *testing.T) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(Request{QID: "P8", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 600, OnPass: nil})
	must(t, err)
	l.Close()
	// The callback runs on the host clock, long after this fake 60 s grant.
	out, err := TimerCallback(r.cfg, "P8", "P8-w1", "ex-P8-w1")
	must(t, err)
	if d := py.S(out.Get("decision")); d != "interrupted" {
		t.Fatalf("deadline decision %s", d)
	}
	w := r.wakes()
	if len(w) != 3 || w[1] != "kiln: /cancel" || !strings.HasPrefix(w[2], "tern: [agent-loop] deadline-expired:P8") {
		t.Fatalf("deadline effects: %v", w)
	}
	out, err = TimerCallback(r.cfg, "P8", "P8-w1", "ex-P8-w1")
	must(t, err)
	if len(r.wakes()) != 3 {
		t.Fatalf("a repeated callback repeated its effects: %v", r.wakes())
	}
	if _, err := TimerCallback(r.cfg, "P8", "P8-w1", "ex-forged"); err == nil {
		t.Fatal("a callback with the wrong execution was obeyed")
	}
}

func TestSeatBindingIsCheckedBeforeDispatch(t *testing.T) {
	r := newRig(t)
	req := Request{QID: "S", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 600, VerifyS: 600}
	// corvid's configured session is really cairn (the example-config bug).
	r.registry = `[{"id": "K", "title": "kiln"}, {"id": "C", "title": "cairn"}, {"id": "T", "title": "tern"}]`
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(req)
	if f, ok := host.IsFault(err); !ok || f.Code != "E_SEAT_BINDING" || !strings.Contains(f.Detail, "is cairn, not corvid") {
		t.Fatalf("got %v", err)
	}
	r.registry = `[{"id": "K", "title": "kiln"}, {"id": "T", "title": "tern"}]`
	if _, err := l.Dispatch(req); err == nil {
		t.Fatal("a session missing from the registry was accepted")
	}
	r.cfg.Seats["corvid"] = "K"
	if _, err := l.Dispatch(req); err == nil {
		t.Fatal("two seats on one session were accepted")
	}
	if len(r.wakes()) != 0 || r.timers() != 0 {
		t.Fatalf("something was sent on a bad binding: %v", r.calls)
	}
}

func TestChangedInputBlocksTheVerifierDispatch(t *testing.T) {
	r := newRig(t)
	r.artifact("spec.md", "v1")
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "I1", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v",
		DurationS: 2400, VerifyS: 1200, Inputs: []string{"spec.md"}})
	must(t, err)
	r.clock.Advance(60)
	r.artifact("o", "x")
	l.Claim("I1", "worker", "completed", map[string]string{"o": "o"})
	r.artifact("spec.md", "v2")
	r.turnEnd("K")
	r.tick(l)
	p := l.Pkg("I1")
	if p.Step != "blocked" || !strings.Contains(p.Notes[len(p.Notes)-1], "E_INPUT_CHANGED: spec.md") {
		t.Fatalf("changed input not blocked: %+v", p)
	}
	for _, w := range r.wakes() {
		if strings.HasPrefix(w, "corvid") {
			t.Fatalf("verifier dispatched on changed input: %v", r.wakes())
		}
	}
	if _, err := l.Dispatch(Request{QID: "I2", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v",
		DurationS: 60, VerifyS: 60, Inputs: []string{"absent.md"}}); err == nil || l.Pkg("I2") != nil {
		t.Fatal("a missing input was registered")
	}
}

func TestHeldPackageWithChangedInputIsNotSent(t *testing.T) {
	r := newRig(t)
	r.artifact("spec.md", "v1")
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "A", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200})
	must(t, err)
	_, err = l.Dispatch(Request{QID: "B", Worker: "kiln", Verifier: "corvid", WorkerTask: "task B", VerifyTask: "v",
		DurationS: 2400, VerifyS: 1200, Inputs: []string{"spec.md"}, After: []string{"A"}})
	must(t, err)
	r.artifact("spec.md", "v2")
	r.closeAs(l, "A", "question_answered")
	r.tick(l)
	if p := l.Pkg("B"); p.Step != "blocked" {
		t.Fatalf("B released on a changed input: %+v", p)
	}
	for _, c := range r.calls {
		if len(c) > 2 && strings.Contains(c[2], "task B") {
			t.Fatal("B's task was sent")
		}
	}
}

// closeAs walks a package through to the director's decision of kind.
func (r *rig) closeAs(l *Loop, qid, kind string) {
	r.clock.Advance(60)
	r.artifact("o-"+qid, "x")
	l.Claim(qid, "worker", "completed", map[string]string{"o": "o-" + qid})
	r.turnEnd("K")
	r.tick(l)
	r.clock.Advance(60)
	r.artifact("r-"+qid, "ok")
	l.Claim(qid, "verify", "completed", map[string]string{"r": "r-" + qid})
	r.turnEnd("C")
	r.tick(l)
	must(r.t, l.Decide(qid, kind, "ref-"+qid, "test"))
}

func TestPendingDecisionHoldsDependents(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	req := func(q string, after ...string) Request {
		return Request{QID: q, Worker: "kiln", Verifier: "corvid", WorkerTask: "task " + q, VerifyTask: "v",
			DurationS: 2400, VerifyS: 1200, After: after}
	}
	_, err := l.Dispatch(req("A"))
	must(t, err)
	p, err := l.Dispatch(req("B", "A"))
	must(t, err)
	if p.Step != "held" || len(r.wakes()) != 1 {
		t.Fatalf("B was not held behind A: %+v %v", p, r.wakes())
	}
	for name, rq := range map[string]Request{"self": req("C", "C"), "unknown": req("D", "nope")} {
		if _, err := l.Dispatch(rq); err == nil {
			t.Errorf("%s dependency accepted", name)
		}
	}
	r.tick(l)
	if step(l, "B") != "held" {
		t.Fatal("B released while A is undecided")
	}
	if st := l.Status(); st[1]["waiting_on"] != "A" {
		t.Fatalf("status does not show what B waits on: %v", st[1])
	}
	r.closeAs(l, "A", "question_answered")
	msgs := r.tick(l)
	if step(l, "B") != "worker" || !strings.HasPrefix(r.wakes()[len(r.wakes())-1], "kiln: ") {
		t.Fatalf("B not released after A's eligible decision: %v %v", msgs, r.wakes())
	}
	_, err = l.Dispatch(req("E"))
	must(t, err)
	_, err = l.Dispatch(req("F", "E"))
	must(t, err)
	r.closeAs(l, "E", "budget_spent")
	r.tick(l)
	if p := l.Pkg("F"); p.Step != "blocked" || !strings.Contains(p.Notes[len(p.Notes)-1], "E_DEPENDENCY_UNMET") {
		t.Fatalf("an ineligible decision released F: %+v", p)
	}
}
