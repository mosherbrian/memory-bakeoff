package loop

import (
	"encoding/json"
	"strings"
	"testing"

	"agent-loop/internal/core"
	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// fixtureRig is the P8 live-1 shape: no role uses a core cast name.
func fixtureRig(t *testing.T) *rig {
	r := newRig(t)
	r.cfg.Seats = map[string]string{"p6-fixture-p8-worker-1": "K", "p6-fixture-p8-verifier-1": "C", "p6-fixture-p8-director-1": "T"}
	r.cfg.Director, r.cfg.Duty = "p6-fixture-p8-director-1", "p6-fixture-p8-director-1"
	r.registry = `[{"id": "K", "title": "p6-fixture-p8-worker-1"}, {"id": "C", "title": "p6-fixture-p8-verifier-1"}, {"id": "T", "title": "p6-fixture-p8-director-1"}]`
	return r
}

func fixtureReq(q string) Request {
	return Request{QID: q, Worker: "p6-fixture-p8-worker-1", Verifier: "p6-fixture-p8-verifier-1",
		WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200}
}

// walk runs a package to its verdict, reopening the ledger between steps.
func (r *rig) walk(l *Loop, qid string, reopen bool) *Loop {
	next := func() {
		if reopen {
			l.Close()
			l = r.open()
		}
	}
	next()
	r.clock.Advance(60)
	r.artifact("o-"+qid, "x")
	if _, err := l.Claim(qid, "worker", "completed", map[string]string{"o": "o-" + qid}); err != nil {
		r.t.Fatal(err)
	}
	r.turnEnd("K")
	next()
	r.tick(l)
	next()
	r.clock.Advance(60)
	r.artifact("r-"+qid, "ok")
	if _, err := l.Claim(qid, "verify", "completed", map[string]string{"r": "r-" + qid}); err != nil {
		r.t.Fatal(err)
	}
	r.turnEnd("C")
	next()
	r.tick(l)
	next()
	return l
}

// The exact live-1 failure: the fixture director's decide was refused
// E_UNTRUSTED_ACTOR because the loop passed its name to the core.
func TestLive1DecideWithFixturePrincipals(t *testing.T) {
	for _, reopen := range []bool{false, true} {
		r := fixtureRig(t)
		l := r.open()
		if _, err := l.Dispatch(fixtureReq("P8-positive-1")); err != nil {
			t.Fatal(err)
		}
		l = r.walk(l, "P8-positive-1", reopen)
		if step(l, "P8-positive-1") != "decision" {
			t.Fatalf("reopen=%v: %+v", reopen, l.Pkg("P8-positive-1"))
		}
		if err := l.Decide("P8-positive-1", "question_answered", "P8-live1-signed", "real fixture hash verified"); err != nil {
			t.Fatalf("reopen=%v: decide: %v", reopen, err)
		}
		if step(l, "P8-positive-1") != "closed" {
			t.Fatalf("reopen=%v: not closed", reopen)
		}
		// The ledger holds the core cast; the record holds the real principals.
		rows, _ := l.D.Store.DB.Query("SELECT type, actor_seat FROM events")
		actors := map[string]string{}
		for rows.Next() {
			var typ, seat string
			rows.Scan(&typ, &seat)
			actors[typ] = seat
		}
		rows.Close()
		if actors["publish"] != "kiln" || actors["verify_pass"] != "corvid" || actors["decide"] != "tern" {
			t.Fatalf("ledger actors: %v", actors)
		}
		pr := l.Pkg("P8-positive-1").Principals
		if pr["worker"].Seat != "p6-fixture-p8-worker-1" || pr["director"].Session != "T" {
			t.Fatalf("principals: %+v", pr)
		}
		l.Close()
	}
}

func TestOnPassWithFixturePrincipals(t *testing.T) {
	r := fixtureRig(t)
	l := r.open()
	req := fixtureReq("A")
	req.OnPass = &OnPass{Kind: "question_answered", DecisionRef: "pre", Reason: "pre-authorized"}
	if _, err := l.Dispatch(req); err != nil {
		t.Fatal(err)
	}
	l = r.walk(l, "A", true)
	defer l.Close()
	if p := l.Pkg("A"); p.Step != "closed" {
		t.Fatalf("on-pass close: %+v", p)
	}
}

func code(err error) string {
	if f, ok := host.IsFault(err); ok {
		return f.Code
	}
	return ""
}

func TestRebindingIsRefusedBeforeAnyEffect(t *testing.T) {
	r := fixtureRig(t)
	l := r.open()
	defer l.Close()
	if _, err := l.Dispatch(fixtureReq("B")); err != nil {
		t.Fatal(err)
	}
	l.Close()
	l = r.walk(r.open(), "B", false)
	events := len(l.D.Store.SeenEvents)
	// The director seat is rebound to another session after dispatch.
	r.cfg.Seats["p6-fixture-p8-director-1"] = "X"
	if err := l.Decide("B", "question_answered", "r", "x"); code(err) != "E_AUTHORITY_CHANGED" {
		t.Fatalf("decide on a rebound director: %v", err)
	}
	// A different seat named director.
	r.cfg.Seats["p6-fixture-p8-director-1"] = "T"
	r.cfg.Seats["other"] = "T2"
	r.cfg.Director = "other"
	if err := l.Decide("B", "question_answered", "r", "x"); code(err) != "E_AUTHORITY_CHANGED" {
		t.Fatalf("decide by a renamed director: %v", err)
	}
	if len(l.D.Store.SeenEvents) != events || step(l, "B") != "decision" {
		t.Fatal("a refused decide changed the ledger")
	}
}

func TestWorkerRebindingBlocksTheHandoff(t *testing.T) {
	r := fixtureRig(t)
	l := r.open()
	defer l.Close()
	if _, err := l.Dispatch(fixtureReq("C")); err != nil {
		t.Fatal(err)
	}
	r.clock.Advance(60)
	r.artifact("o", "x")
	l.Claim("C", "worker", "completed", map[string]string{"o": "o"})
	r.turnEnd("K")
	r.cfg.Seats["p6-fixture-p8-worker-1"] = "K2"
	r.tick(l)
	p := l.Pkg("C")
	if p.Step != "blocked" || !strings.Contains(p.Notes[len(p.Notes)-1], "E_AUTHORITY_CHANGED") {
		t.Fatalf("handoff ran on a rebound worker: %+v", p)
	}
	for _, w := range r.wakes() {
		if strings.Contains(w, "P8") || strings.HasPrefix(w, ": {") {
			continue
		}
	}
}

func TestMissingPrincipalIsNeverBackfilled(t *testing.T) {
	r := fixtureRig(t)
	l := r.open()
	defer l.Close()
	if _, err := l.Dispatch(fixtureReq("D")); err != nil {
		t.Fatal(err)
	}
	l = r.walk(l, "D", false)
	// A record from before principals existed (the 4a00d67 shape).
	p := l.Pkg("D")
	p.Principals = nil
	b, _ := json.Marshal(p)
	l.D.KVPut("loop-pkg:D", string(b))
	if err := l.Decide("D", "question_answered", "r", "x"); code(err) != "E_AUTHORITY_MISSING" {
		t.Fatalf("decide without a recorded director: %v", err)
	}
	if l.Pkg("D").Principals != nil {
		t.Fatal("principals were backfilled from the current config")
	}
}

func TestDutySeatCannotBeWorkerOrVerifier(t *testing.T) {
	r := fixtureRig(t)
	r.cfg.Duty = "p6-fixture-p8-worker-1"
	l := r.open()
	defer l.Close()
	if _, err := l.Dispatch(fixtureReq("E")); err == nil {
		t.Fatal("duty = worker accepted")
	}
}

func TestTimerCallbackChecksDuty(t *testing.T) {
	r := fixtureRig(t)
	l := r.open()
	if _, err := l.Dispatch(Request{QID: "F", Worker: "p6-fixture-p8-worker-1", Verifier: "p6-fixture-p8-verifier-1",
		WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 600}); err != nil {
		t.Fatal(err)
	}
	l.Close()
	r.cfg.Seats["p6-fixture-p8-director-1"] = "T9" // duty rebound
	if _, err := TimerCallback(r.cfg, "F", "F-w1", "ex-F-w1"); code(err) != "E_AUTHORITY_CHANGED" {
		t.Fatalf("timer callback on a rebound duty seat: %v", err)
	}
	r.cfg.Seats["p6-fixture-p8-director-1"] = "T"
	out, err := TimerCallback(r.cfg, "F", "F-w1", "ex-F-w1")
	if err != nil || py.S(out.Get("decision")) != "interrupted" {
		t.Fatalf("timer callback: %v %v", out, err)
	}
	_ = core.Actor
}
