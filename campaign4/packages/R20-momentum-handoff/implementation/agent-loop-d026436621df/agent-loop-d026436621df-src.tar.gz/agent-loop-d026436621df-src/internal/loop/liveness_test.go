package loop

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

var t0 = time.Date(2026, 9, 23, 6, 0, 0, 0, time.UTC)

const inv = "0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f"

func pass(age time.Duration, open, streak int) *Pass {
	return &Pass{At: py.ISO(t0.Add(-age)), PID: 7, Invocation: inv, N: 3, Open: open, ErrorStreak: streak, LastError: "boom"}
}

func TestAssessTable(t *testing.T) {
	active := Unit{Active: "active", Sub: "running", InvocationID: inv, MainPID: 7, StartedAt: t0.Add(-time.Hour)}
	for _, c := range []struct {
		name      string
		u         Unit
		uerr      error
		p         *Pass
		perr      error
		marker    bool
		markerAge time.Duration
		state     string
		alarm     bool
	}{
		{"running", active, nil, pass(10*time.Second, 1, 0), nil, false, 0, "ok", false},
		{"legitimate rest", active, nil, pass(10*time.Second, 0, 0), nil, false, 0, "rest", false},
		{"intentional stop", Unit{Active: "inactive", Sub: "dead"}, nil, pass(time.Hour, 0, 0), nil, true, time.Hour, "stopped", false},
		{"stop in progress", active, nil, pass(10*time.Second, 1, 0), nil, true, 20 * time.Second, "stopping", false},
		{"stop not honoured", active, nil, pass(10*time.Second, 1, 0), nil, true, 101 * time.Second, "stop-pending", true},
		{"crashed, restart failed", Unit{Active: "failed", Result: "exit-code"}, nil, pass(time.Minute, 1, 0), nil, false, 0, "crashed", true},
		{"restart loop", Unit{Active: "failed", Result: "start-limit-hit", NRestarts: 5}, nil, pass(time.Minute, 1, 0), nil, false, 0, "restart-loop", true},
		{"unplanned stop", Unit{Active: "inactive", Sub: "dead"}, nil, pass(10*time.Second, 1, 0), nil, false, 0, "down", true},
		{"hung", active, nil, pass(101*time.Second, 1, 0), nil, false, 0, "hung", true},
		{"stale while restarting", Unit{Active: "activating", Sub: "auto-restart", InvocationID: inv, MainPID: 7, StartedAt: t0.Add(-time.Hour)}, nil, pass(101*time.Second, 1, 0), nil, false, 0, "crashed", true},
		{"restarted and servicing", Unit{Active: "activating", Sub: "start", InvocationID: inv, MainPID: 7, StartedAt: t0.Add(-time.Minute)}, nil, pass(5*time.Second, 1, 0), nil, false, 0, "ok", false},
		{"idle but fresh", active, nil, pass(99*time.Second, 0, 0), nil, false, 0, "rest", false},
		{"passes failing", active, nil, pass(10*time.Second, 1, 3), nil, false, 0, "erroring", true},
		{"no pass ever", active, nil, nil, nil, false, 0, "hung", true},
		{"unit unreadable", Unit{}, errors.New("timeout"), pass(10*time.Second, 1, 0), nil, false, 0, "unknown", true},
		{"ledger unreadable", active, nil, nil, errors.New("locked"), false, 0, "unknown", true},
		{"bad pass time", active, nil, &Pass{At: "garbage", Open: 1}, nil, false, 0, "unknown", true},
	} {
		v := Assess(c.u, c.uerr, c.p, c.perr, c.marker, t0.Add(-c.markerAge), t0)
		if v.State != c.state || v.Alarm != c.alarm {
			t.Errorf("%s: got %s alarm=%v (%s), want %s alarm=%v", c.name, v.State, v.Alarm, v.Why, c.state, c.alarm)
		}
	}
}

// liveRig scripts systemctl show and the wake script for the checker.
type liveRig struct {
	*rig
	unit  string // systemctl show output
	wakes []string
}

func newLiveRig(t *testing.T) *liveRig {
	t.Setenv("INVOCATION_ID", inv)
	r := &liveRig{rig: newRig(t), unit: fmt.Sprintf("ActiveState=active\nSubState=running\nResult=success\nNRestarts=0\nInvocationID=%s\nMainPID=%d\nExecMainStartTimestamp=@%d\n",
		inv, os.Getpid(), t0.Add(-time.Hour).Unix())}
	r.cfg.Unit = "agent-loop@test.service"
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		switch {
		case argv[0] == "systemctl":
			return host.Proc{RC: 0, Stdout: r.unit}, nil
		case filepath.Base(argv[0]) == "wake":
			if strings.HasPrefix(argv[2], "[agent-loop liveness]") { // not the packages' own dispatches
				r.wakes = append(r.wakes, argv[1]+": "+argv[2])
			}
			return host.Proc{RC: 3, Stdout: "wake: " + argv[1] + " -> queued behind the running turn"}, nil
		case argv[0] == "agent-deck":
			return host.Proc{RC: 0, Stdout: r.registry}, nil
		}
		return host.Proc{RC: 0}, nil
	}
	return r
}

func (r *liveRig) pass(at time.Time, open int) {
	l := r.open()
	defer l.Close()
	r.clock.SetNow(py.ISO(at))
	if open > 0 {
		if _, err := l.Dispatch(Request{QID: "Q" + at.Format("150405"), Worker: "kiln", Verifier: "corvid",
			WorkerTask: "w", VerifyTask: "v", DurationS: 3600, VerifyS: 600}); err != nil {
			r.t.Fatal(err)
		}
	}
	if err := l.RecordPass(1, 0, nil); err != nil {
		r.t.Fatal(err)
	}
}

func (r *liveRig) check(at time.Time) (Verdict, []string) {
	v, did, err := (&Checker{Cfg: r.cfg, Now: at}).Check()
	if err != nil {
		r.t.Fatal(err)
	}
	return v, did
}

func TestIncidentFlow(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 1)
	if v, did := r.check(t0.Add(30 * time.Second)); v.Alarm || len(did) != 0 || len(r.wakes) != 0 {
		t.Fatalf("fresh pass alarmed: %v %v %v", v, did, r.wakes)
	}
	// run hangs: no pass for 101 s.
	v, _ := r.check(t0.Add(101 * time.Second))
	if v.State != "hung" || len(r.wakes) != 1 || !strings.HasPrefix(r.wakes[0], "T: [agent-loop liveness] INCIDENT") ||
		!strings.Contains(r.wakes[0], "liveness-ack --config") {
		t.Fatalf("duty not woken once with the ack command: %v %v", v, r.wakes)
	}
	st, _ := loadState(r.cfg.stateFile())
	if st.Open.Duty.Status != "queued" || st.Open.Ack != nil {
		t.Fatalf("a queued wake was treated as more than a send: %+v", st.Open)
	}
	// Same check window: no repeat to duty.
	r.check(t0.Add(120 * time.Second))
	if len(r.wakes) != 1 {
		t.Fatalf("duty woken twice: %v", r.wakes)
	}
	// Next check, no ack: director.
	r.check(t0.Add(146 * time.Second))
	if len(r.wakes) != 2 || !strings.Contains(r.wakes[1], "ESCALATION") || !strings.Contains(r.wakes[1], "did not acknowledge") {
		t.Fatalf("director not woken after no ack: %v", r.wakes)
	}
	// Not again within 15 minutes.
	r.check(t0.Add(200 * time.Second))
	if len(r.wakes) != 2 {
		t.Fatalf("director repeated early: %v", r.wakes)
	}
	// Recovery needs a fresh pass; then the incident closes as recovered.
	r.pass(t0.Add(250*time.Second), 0)
	v, did := r.check(t0.Add(260 * time.Second))
	st, _ = loadState(r.cfg.stateFile())
	if v.Alarm || st.Open != nil || len(st.History) != 1 || st.History[0].Outcome != "recovered" || !st.History[0].Escalated {
		t.Fatalf("not closed as recovered+escalated: %v %v %+v", v, did, st)
	}
}

func TestAckBindsAndExpires(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 1)
	r.check(t0.Add(101 * time.Second))
	st, _ := loadState(r.cfg.stateFile())
	id := st.Open.ID
	for _, bad := range []error{
		AckIncident(r.cfg, id, "kiln", "fix", time.Minute, t0),
		AckIncident(r.cfg, id, "tern", "", time.Minute, t0),
		AckIncident(r.cfg, id, "tern", "fix", 2*time.Hour, t0),
		AckIncident(r.cfg, "L-nope", "tern", "fix", time.Minute, t0),
	} {
		if bad == nil {
			t.Fatal("an invalid ack was accepted")
		}
	}
	if err := AckIncident(r.cfg, id, "tern", "restart the unit", 5*time.Minute, t0.Add(110*time.Second)); err != nil {
		t.Fatal(err)
	}
	// Acked and within its deadline: no director wake, still open (not recovered).
	r.check(t0.Add(150 * time.Second))
	st, _ = loadState(r.cfg.stateFile())
	if len(r.wakes) != 1 || st.Open == nil || st.Open.Ack == nil {
		t.Fatalf("ack treated as recovery or ignored: %v %+v", r.wakes, st.Open)
	}
	// Deadline passes with no recovery: the director is woken.
	r.check(t0.Add(420 * time.Second))
	if len(r.wakes) != 2 || !strings.Contains(r.wakes[1], "not recovered by") {
		t.Fatalf("an expired ack suppressed the fault: %v", r.wakes)
	}
}

func TestIntentionalStopAndRestAreQuiet(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 0)
	if v, _ := r.check(t0.Add(40 * time.Second)); v.State != "rest" || v.Alarm {
		t.Fatalf("rest: %v", v)
	}
	os.WriteFile(r.cfg.StopMarker(), []byte("x"), 0o644)
	os.Chtimes(r.cfg.StopMarker(), t0.Add(50*time.Second), t0.Add(50*time.Second))
	r.unit = "ActiveState=inactive\nSubState=dead\nResult=success\nNRestarts=0\n"
	for i := 0; i < 5; i++ {
		if v, _ := r.check(t0.Add(time.Duration(90+45*i) * time.Second)); v.State != "stopped" || v.Alarm {
			t.Fatalf("stopped check %d: %v", i, v)
		}
	}
	if len(r.wakes) != 0 {
		t.Fatalf("an intentional stop alarmed: %v", r.wakes)
	}
	// The same unit state with no marker is an unplanned stop.
	os.Remove(r.cfg.StopMarker())
	if v, _ := r.check(t0.Add(400 * time.Second)); v.State != "down" || len(r.wakes) != 1 {
		t.Fatalf("unplanned stop: %v %v", v, r.wakes)
	}
}

func TestRestartLoopEscalates(t *testing.T) {
	r := newLiveRig(t)
	r.pass(t0, 1)
	r.unit = "ActiveState=failed\nSubState=failed\nResult=start-limit-hit\nNRestarts=5\n"
	if v, _ := r.check(t0.Add(30 * time.Second)); v.State != "restart-loop" || len(r.wakes) != 1 {
		t.Fatalf("restart loop: %v %v", v, r.wakes)
	}
	r.check(t0.Add(75 * time.Second))
	if len(r.wakes) != 2 {
		t.Fatalf("restart loop not escalated to the director: %v", r.wakes)
	}
}

func TestUnknownIsNeverGreen(t *testing.T) {
	r := newLiveRig(t)
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		if argv[0] == "systemctl" {
			return host.Proc{}, host.ErrTimeout
		}
		return host.Proc{RC: 0, Stdout: "wake: x -> started"}, nil
	}
	if v, _ := r.check(t0); v.State != "unknown" || !v.Alarm {
		t.Fatalf("unreadable unit: %v", v)
	}
}

func TestRecordPassCountsErrors(t *testing.T) {
	r := newLiveRig(t)
	l := r.open()
	defer l.Close()
	for i := 0; i < 3; i++ {
		l.RecordPass(int64(i), 0, errors.New("tick failed"))
	}
	p, err := ReadPass(r.cfg.DB)
	if err != nil || p.ErrorStreak != 3 || p.LastError != "tick failed" {
		t.Fatalf("%+v %v", p, err)
	}
	l.RecordPass(4, 1, nil)
	if p, _ := ReadPass(r.cfg.DB); p.ErrorStreak != 0 {
		t.Fatalf("a good pass did not reset the streak: %+v", p)
	}
}
