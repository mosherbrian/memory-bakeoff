package host

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"testing"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// The evidence HOST-PORT-RULING-20260923 finding 2 requires on the Go
// port: no terminal-rest or done without the committed authorized
// disposition; one atomic close; crash on either side of the commit
// reconciles; wrong identity and a conflicting disposition reject.

type closeRig struct {
	t      *testing.T
	dir    string
	db     string
	a      *Adapter
	clock  *core.FakeClock
	end    *py.Dict
	launch *py.Dict
}

// newCloseRig puts question Q in CHECKING with verifier Q-v1/ev1 bound to
// a turn end whose claim and artifact are on disk.
func newCloseRig(t *testing.T) *closeRig {
	r := &closeRig{t: t, dir: t.TempDir(), clock: core.NewFakeClock(nil)}
	r.db = filepath.Join(r.dir, "h.db")
	r.open()
	d := r.a.Driver
	must := func(err error) {
		t.Helper()
		if err != nil {
			t.Fatal(err)
		}
	}
	must(d.AdmitAuthorize("Q"))
	_, err := d.StartDispatch("Q", "Q-w1", int64(1800), nil)
	must(err)
	_, err = r.a.DriveNext("Q-w1", "Q-v1", "2026-09-21T14:00:00Z", py.D("out", "h"), "Q")
	must(err)
	_, err = r.a.RegisterExecution("Q-v1", "ev1", "g", "2026-09-21T14:00:00Z")
	must(err)
	os.MkdirAll(filepath.Join(r.dir, "stream"), 0o755)
	os.MkdirAll(filepath.Join(r.dir, "art"), 0o755)
	os.WriteFile(filepath.Join(r.dir, "stream", "kv.jsonl"), []byte("{\"t\": \"end\", \"item\": \"j1\"}\n"), 0o644)
	os.WriteFile(filepath.Join(r.dir, "art", "review.md"), []byte("ok"), 0o644)
	h := sha256.Sum256([]byte("ok"))
	_, err = WriteClaim(filepath.Join(r.dir, "claims"), "ev1", py.D("package", "P", "attempt", "a1", "action", "Q-v1",
		"execution", "ev1", "contract_step", "verify-run", "outcome", "completed",
		"artifacts", py.D("review", py.D("path", "review.md", "sha256", hex.EncodeToString(h[:])))))
	must(err)
	evs, _, _, _, err := NewTurnWatcher(filepath.Join(r.dir, "stream")).Poll([]string{"kv"}, py.NewDict(),
		func(string) error { return nil }, func(string) bool { return false })
	must(err)
	r.end = evs[0]
	must(r.a.BindTurn("kv", "j1", "ev1", "Q-v1", "verify-run"))
	r.launch = py.D("package", "P", "attempt", "a1", "action", "Q-v1", "execution", "ev1",
		"contract_step", "verify-run", "escalation_deadline_utc", "2026-09-21T15:00:00Z",
		"artifact_base_dir", filepath.Join(r.dir, "art"), "stream_dir", filepath.Join(r.dir, "stream"))
	return r
}

func (r *closeRig) open() {
	d, err := core.NewDriver(r.db, r.clock, nil, nil)
	if err != nil {
		r.t.Fatal(err)
	}
	r.a, _ = NewAdapter(d, NewFakeTransport(), nil, false)
}

func (r *closeRig) reopen() {
	r.a.Driver.Close()
	r.open()
}

func (r *closeRig) handoff(disp *py.Dict) (*py.Dict, error) {
	l := r.launch.Copy()
	if disp != nil {
		l.Set("authorized_dispositions", []any{disp})
	}
	return RunHandoff(r.a, "Q", r.end, filepath.Join(r.dir, "claims"), l, nil)
}

func (r *closeRig) ledger() (phase string, disp any) {
	rec := r.a.Driver.Store.Revs.Get(core.RevKey{Q: "Q", Rev: int64(1)})
	return py.S(rec.Get("phase")), rec.Get("disposition")
}

func (r *closeRig) done() bool { return r.a.Driver.KV["handoff-done:Q-v1:ev1"] != "" }

func good() *py.Dict {
	return py.D("kind", "question_answered", "decision_ref", "tern-1", "reason", "fixture")
}

func code(err error) string {
	if f, ok := IsFault(err); ok {
		return f.Code
	}
	if err != nil {
		return err.Error()
	}
	return ""
}

func TestInvalidDispositionNeverRests(t *testing.T) {
	r := newCloseRig(t)
	bad := py.D("kind", "accept", "decision_ref", "tern-1", "reason", "x")
	for i, step := range []func(){func() {}, func() {}, r.reopen} {
		step()
		out, err := r.handoff(bad)
		if code(err) != "E_FORGED_DISPOSITION" || out != nil || r.done() {
			t.Fatalf("call %d: %v %v done=%v", i, out, err, r.done())
		}
		if phase, disp := r.ledger(); phase != "CHECKING" || disp != nil {
			t.Fatalf("call %d: ledger changed: %s %v", i, phase, disp)
		}
	}
}

func TestAtomicCloseSucceedsOnce(t *testing.T) {
	r := newCloseRig(t)
	out, err := r.handoff(good())
	if err != nil || py.S(out.Get("decision")) != "terminal-rest" || !r.done() {
		t.Fatalf("close: %v %v", out, err)
	}
	if phase, disp := r.ledger(); phase != "COMPLETE" || !py.Eq(py.AsDict(disp).Get("decision_ref"), "tern-1") {
		t.Fatalf("ledger: %s %v", phase, disp)
	}
	n := len(r.a.Driver.Store.SeenEvents)
	out, err = r.handoff(good())
	if err != nil || py.S(out.Get("decision")) != "duplicate-end-ignored" || len(r.a.Driver.Store.SeenEvents) != n {
		t.Fatalf("second call: %v %v (events %d -> %d)", out, err, n, len(r.a.Driver.Store.SeenEvents))
	}
}

func TestCrashBeforeCommitReconciles(t *testing.T) {
	r := newCloseRig(t)
	// The intent was declared, then the process died before the commit.
	intent := py.D("next", "director-close", "action", "Q-v1", "execution", "ev1", "disposition", good(),
		"verdict_event", "Q-v1-hend-v", "decide_event", "Q-v1-hend-d")
	r.a.putMany([2]string{"turn-seen:kv:j1:ev1", `{"outcome": "completed"}`}, [2]string{"handoff-intent:Q-v1:ev1", py.Dumps(intent)})
	r.reopen()
	out, err := r.handoff(good())
	if err != nil || !py.Truthy(out.Get("recovered")) || !r.done() {
		t.Fatalf("roll forward: %v %v", out, err)
	}
	if phase, disp := r.ledger(); phase != "COMPLETE" || disp == nil {
		t.Fatalf("ledger: %s %v", phase, disp)
	}
}

func TestCrashAfterCommitDoesNotRepeat(t *testing.T) {
	r := newCloseRig(t)
	if _, err := r.handoff(good()); err != nil {
		t.Fatal(err)
	}
	r.a.put("handoff-done:Q-v1:ev1", "") // the commit landed; done was never written
	r.reopen()
	n := len(r.a.Driver.Store.SeenEvents)
	out, err := r.handoff(good())
	if err != nil || !py.Truthy(out.Get("recovered")) || !r.done() || len(r.a.Driver.Store.SeenEvents) != n {
		t.Fatalf("reconcile: %v %v (events %d -> %d)", out, err, n, len(r.a.Driver.Store.SeenEvents))
	}
}

func TestConflictingDispositionRejects(t *testing.T) {
	r := newCloseRig(t)
	if _, err := r.handoff(good()); err != nil {
		t.Fatal(err)
	}
	other := py.D("next", "director-close", "action", "Q-v1", "execution", "ev1",
		"disposition", py.D("kind", "blocked", "decision_ref", "tern-2", "reason", "other"),
		"verdict_event", "Q-v1-hend-v", "decide_event", "Q-v1-hend-d")
	r.a.putMany([2]string{"handoff-intent:Q-v1:ev1", py.Dumps(other)}, [2]string{"handoff-done:Q-v1:ev1", ""})
	if _, err := r.handoff(good()); code(err) != "E_CONFLICTING_DISPOSITION" || r.done() {
		t.Fatalf("conflict: %v done=%v", err, r.done())
	}
	if _, disp := r.ledger(); !py.Eq(py.AsDict(disp).Get("decision_ref"), "tern-1") {
		t.Fatalf("the first disposition was overwritten: %v", disp)
	}
}

func TestPartialVerdictGetsOnlyTheDecide(t *testing.T) {
	r := newCloseRig(t)
	// The reference's partial close: verdict committed, decide refused.
	if _, err := r.a.Driver.Verify("Q", "Q-v1-hend-v", true, nil, nil, py.NewDict()); err != nil {
		t.Fatal(err)
	}
	intent := py.D("next", "director-close", "action", "Q-v1", "execution", "ev1", "disposition", good(),
		"verdict_event", "Q-v1-hend-v", "decide_event", "Q-v1-hend-d")
	r.a.putMany([2]string{"turn-seen:kv:j1:ev1", "x"}, [2]string{"handoff-intent:Q-v1:ev1", py.Dumps(intent)})
	out, err := r.handoff(good())
	if err != nil || !r.done() {
		t.Fatalf("partial close: %v %v", out, err)
	}
	if _, disp := r.ledger(); disp == nil {
		t.Fatal("no disposition recorded")
	}
}

func TestWrongIdentityRejects(t *testing.T) {
	r := newCloseRig(t)
	for name, mut := range map[string][2]string{
		"execution": {"execution", "ev9"},
		"action":    {"action", "Q-other"},
	} {
		l := r.launch.Copy()
		l.Set(mut[0], mut[1])
		l.Set("authorized_dispositions", []any{good()})
		if _, err := RunHandoff(r.a, "Q", r.end, filepath.Join(r.dir, "claims"), l, nil); code(err) != "E_STALE_TURN" || r.done() {
			t.Errorf("wrong %s: %v", name, err)
		}
	}
	// A wrong question has no flight and no verdict to close.
	l := r.launch.Copy()
	l.Set("authorized_dispositions", []any{good()})
	if _, err := RunHandoff(r.a, "OTHER", r.end, filepath.Join(r.dir, "claims"), l, nil); code(err) != "E_CLOSE_UNRESOLVED" || r.done() {
		t.Errorf("wrong question: %v done=%v", err, r.done())
	}
}

func TestMissingEscalationBoundIsOwned(t *testing.T) {
	r := newCloseRig(t)
	l := r.launch.Copy()
	l.Pop("escalation_deadline_utc")
	os.Remove(filepath.Join(r.dir, "claims", "ev1.json"))
	if _, err := RunHandoff(r.a, "Q", r.end, filepath.Join(r.dir, "claims"), l, nil); code(err) != "E_NO_ESCALATION_BOUND" {
		t.Fatalf("got %v", err)
	}
}
