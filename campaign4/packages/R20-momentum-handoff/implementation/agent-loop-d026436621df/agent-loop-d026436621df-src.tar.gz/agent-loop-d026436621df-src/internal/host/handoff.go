package host

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"sort"
	"strings"
	"syscall"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// ClaimRequired are the fields every completion claim carries.
var ClaimRequired = []string{"package", "attempt", "action", "execution", "contract_step", "outcome", "artifacts"}

// ForbiddenClaimFields: routing and authority belong to the launcher,
// never to the worker's claim.
var ForbiddenClaimFields = []string{"verifier", "destination", "next_task", "next_action", "accept", "accepted",
	"duration_s", "duration", "authority", "grant", "grant_ref", "deadline", "seat", "actor", "route", "router",
	"disposition", "recovery_deadline_utc"}

// ClaimError is Python's ValueError("E_CODE: detail").
type ClaimError struct{ Msg string }

func (e *ClaimError) Error() string { return e.Msg }

// Code is the part before the first colon.
func (e *ClaimError) Code() string { return strings.SplitN(e.Msg, ":", 2)[0] }

func claimErr(msg string) *ClaimError { return &ClaimError{msg} }

// TurnWatcher reads the runtime's per-seat stream files (acp-stream).
// Notified keys are served first; every line is emitted once, by a
// durable per-line seen set, so partial tails, same-length replacement,
// truncation and rotation lose nothing and repeat nothing.
type TurnWatcher struct {
	StreamDir string
	notified  map[string]bool
	Read      func(path string) (string, bool)
}

func NewTurnWatcher(dir string) *TurnWatcher {
	return &TurnWatcher{StreamDir: dir, notified: map[string]bool{}}
}

func (w *TurnWatcher) Notify(key string) { w.notified[key] = true }

// Poll returns (events, cursors, notes, labels).
func (w *TurnWatcher) Poll(keys []string, cursors *py.Dict, seenAdd func(string) error,
	seenHas func(string) bool) ([]*py.Dict, *py.Dict, *py.Dict, *py.Dict, error) {
	read := w.Read
	if read == nil {
		read = func(p string) (string, bool) {
			b, err := os.ReadFile(p)
			if err != nil {
				return "", false
			}
			// Python reads in text mode: universal newlines.
			s := strings.ReplaceAll(string(b), "\r\n", "\n")
			return strings.ReplaceAll(s, "\r", "\n"), true
		}
	}
	cur := cursors.Copy()
	notes, labels := py.NewDict(), py.NewDict()
	ordered := append([]string(nil), keys...)
	sort.SliceStable(ordered, func(i, j int) bool {
		ni, nj := w.notified[ordered[i]], w.notified[ordered[j]]
		if ni != nj {
			return ni
		}
		return ordered[i] < ordered[j]
	})
	var events []*py.Dict
	for _, key := range ordered {
		if w.notified[key] {
			labels.Set(key, "notified")
		} else {
			labels.Set(key, "replay-fallback")
		}
		delete(w.notified, key)
		text, ok := read(pyJoin(w.StreamDir, key+".jsonl"))
		if !ok {
			notes.Set(key, "rotated-missing")
			continue
		}
		scan, pending := text, false
		if text != "" && !strings.HasSuffix(text, "\n") {
			i := strings.LastIndex(text, "\n")
			scan, pending = text[:i+1], true
			if i < 0 {
				scan = "\n"
			}
		}
		if pending {
			notes.Set(key, "partial-tail-held")
		} else {
			notes.Set(key, "ok")
		}
		cur.Set(key, int64(len(text)))
		pos := len(text) - len(scan)
		for _, line := range splitLines(scan) {
			h := sha256.Sum256([]byte(line))
			token := key + ":" + hex.EncodeToString(h[:])
			start := pos
			pos += len(line) + 1
			if seenHas(token) {
				continue
			}
			v, err := py.Loads([]byte(line))
			if err != nil {
				continue
			}
			row := py.AsDict(v)
			if row == nil || !row.Has("t") || !row.Has("item") {
				continue
			}
			if err := seenAdd(token); err != nil {
				return nil, nil, nil, nil, err
			}
			extra := py.NewDict()
			for _, k := range row.Keys() {
				if k != "t" && k != "item" {
					extra.Set(k, row.Get(k))
				}
			}
			events = append(events, py.D("stream_key", key, "item", row.Get("item"), "kind", row.Get("t"),
				"_token", token, "_offset", int64(start), "extra", extra))
		}
	}
	return events, cur, notes, labels, nil
}

// checkIncarnation binds the stream file's identity at the first observed
// end; a replaced file (new inode) under the same key is a new incarnation
// and the old binding goes stale until rebound.
func checkIncarnation(a *Adapter, turn, binding, launch *py.Dict) error {
	path := pyJoin(py.S(launch.GetOr("stream_dir", "")), py.S(turn.Get("stream_key"))+".jsonl")
	var fp any
	if fi, err := os.Stat(path); err == nil {
		if st, ok := fi.Sys().(*syscall.Stat_t); ok {
			fp = py.D("inode", int64(st.Ino), "dev", int64(st.Dev))
		}
	}
	var recorded any
	if binding != nil {
		recorded = binding.Get("fingerprint")
	}
	if recorded == nil {
		if fp != nil {
			b := py.NewDict()
			if binding != nil {
				b = binding.Copy()
			}
			b.Set("fingerprint", fp)
			return a.put("turn-bind:"+py.S(turn.Get("stream_key"))+":"+py.S(turn.Get("item")), py.Dumps(b))
		}
		return nil
	}
	if fp != nil && !py.Eq(fp, recorded) {
		return fault("E_STALE_TURN", "stream incarnation replaced; explicit rebind required")
	}
	return nil
}

// ClaimPathFor is <claims>/<execution>.json.
func ClaimPathFor(dir, execution string) string { return pyJoin(dir, execution+".json") }

// WriteClaim publishes a route-free claim atomically (temp + rename).
func WriteClaim(dir, execution string, claim *py.Dict) (string, error) {
	var missing []any
	for _, f := range ClaimRequired {
		if !claim.Has(f) {
			missing = append(missing, f)
		}
	}
	if missing != nil {
		return "", claimErr("claim missing " + py.Repr(missing))
	}
	if err := os.MkdirAll(dir, 0o777); err != nil {
		return "", err
	}
	p := ClaimPathFor(dir, execution)
	if err := os.WriteFile(p+".tmp", []byte(py.Dumps(claim)), 0o666); err != nil {
		return "", err
	}
	return p, os.Rename(p+".tmp", p)
}

// ValidateClaim checks a claim against the launch manifest.
func ValidateClaim(claim, launch *py.Dict) error {
	for _, f := range ForbiddenClaimFields {
		if claim.Has(f) {
			return claimErr("E_FORGED_ROUTE: worker field " + f + " rejected; routing/authority belong to launcher")
		}
	}
	for _, f := range ClaimRequired {
		if !claim.Has(f) {
			return claimErr("E_CLAIM_INCOMPLETE: missing " + f)
		}
	}
	for _, f := range []string{"package", "attempt", "action", "execution", "contract_step"} {
		if !py.Eq(claim.Get(f), launch.Get(f)) {
			return claimErr("E_CLAIM_MISMATCH: " + f + " does not match launch manifest")
		}
	}
	if arts := py.AsDict(claim.Get("artifacts")); arts == nil || arts.Len() == 0 {
		return claimErr("E_CLAIM_INCOMPLETE: artifacts paths+hashes?")
	}
	return nil
}

func fileSHA(path string) (string, bool) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", false
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), true
}

func artifactSpecs(claim *py.Dict) *py.Dict {
	if d := py.AsDict(claim.Get("artifacts")); d != nil {
		return d
	}
	return py.NewDict()
}

// RecomputeArtifacts rehashes every claimed artifact from disk.
func RecomputeArtifacts(claim *py.Dict, base string) (*py.Dict, error) {
	verified := py.NewDict()
	arts := artifactSpecs(claim)
	for _, name := range arts.Keys() {
		spec := py.AsDict(arts.Get(name))
		if spec == nil || !spec.Has("path") || !spec.Has("sha256") {
			return nil, claimErr("E_CLAIM_INCOMPLETE: artifact " + name + " needs path+sha256")
		}
		digest, ok := fileSHA(pyJoin(base, py.S(spec.Get("path"))))
		if !ok {
			return nil, claimErr("E_ARTIFACT_MISSING: " + name + " unreadable")
		}
		if !py.Eq(digest, spec.Get("sha256")) {
			return nil, claimErr("E_ARTIFACT_MISMATCH: " + name + " mutated on disk")
		}
		verified.Set(name, digest)
	}
	if verified.Len() == 0 {
		return nil, claimErr("E_CLAIM_INCOMPLETE: artifacts paths+hashes?")
	}
	return verified, nil
}

func (a *Adapter) committedWorkerHashes(launch *py.Dict) *py.Dict {
	for _, k := range a.keys() {
		if !strings.HasPrefix(k, "handoff-intent:") {
			continue
		}
		raw := a.Driver.KV[k]
		if raw == "" {
			raw = "{}"
		}
		intent := loadDict(raw)
		if intent == nil {
			continue
		}
		if py.Eq(intent.Get("verify_action"), launch.Get("action")) && py.Eq(intent.Get("verify_execution"), launch.Get("execution")) {
			if h := py.AsDict(intent.Get("hashes")); h != nil && h.Len() > 0 {
				return h
			}
		}
	}
	return nil
}

func actualHashes(claim *py.Dict, base string) (*py.Dict, error) {
	out := py.NewDict()
	arts := artifactSpecs(claim)
	for _, name := range arts.Keys() {
		spec := py.AsDict(arts.Get(name))
		if spec == nil || !spec.Has("path") {
			return nil, claimErr("E_CLAIM_INCOMPLETE: artifact " + name + " needs path+sha256")
		}
		d, ok := fileSHA(pyJoin(base, py.S(spec.Get("path"))))
		if !ok {
			return nil, claimErr("E_ARTIFACT_MISSING: " + name + " unreadable")
		}
		out.Set(name, d)
	}
	return out, nil
}

// authenticatedRejection: a genuine verifier rejection is a failed
// outcome whose declared expected hashes equal the committed worker hashes
// while the bytes on disk differ. Persisted once.
func authenticatedRejection(a *Adapter, launch, claim *py.Dict, code string) (*py.Dict, error) {
	if !py.Eq(launch.Get("contract_step"), "verify-run") || claim == nil || !py.Eq(claim.Get("outcome"), "failed") {
		return nil, nil
	}
	if code != "E_ARTIFACT_MISMATCH" && code != "E_ARTIFACT_MISSING" {
		return nil, nil
	}
	if ValidateClaim(claim, launch) != nil {
		return nil, nil
	}
	whashes := a.committedWorkerHashes(launch)
	if whashes == nil {
		return nil, nil
	}
	declared := py.AsDict(claim.Get("artifacts"))
	if declared == nil || declared.Len() == 0 {
		return nil, nil
	}
	for _, n := range whashes.Keys() {
		spec := py.AsDict(declared.Get(n))
		if spec == nil || !py.Eq(spec.Get("sha256"), whashes.Get(n)) {
			return nil, nil
		}
	}
	actual, err := actualHashes(claim, py.S(launch.GetOr("artifact_base_dir", "")))
	if err != nil {
		return nil, nil
	}
	mismatch := false
	for _, n := range whashes.Keys() {
		if actual.Has(n) && !py.Eq(actual.Get(n), whashes.Get(n)) {
			mismatch = true
		}
	}
	if !mismatch {
		return nil, nil
	}
	act, ex := py.S(launch.Get("action")), py.S(launch.Get("execution"))
	doneKey, rejKey := "handoff-done:"+act+":"+ex, "verified-rejection:"+act+":"+ex
	if raw, ok := a.kv(rejKey); ok && raw != "" {
		if d := loadDict(raw); d != nil {
			return d, nil
		}
	}
	observed := py.NewDict()
	for _, n := range whashes.Keys() {
		observed.Set(n, actual.Get(n))
	}
	reason := claim.Get("check_detail")
	if !py.Truthy(reason) {
		reason = claim.Get("reason")
	}
	if !py.Truthy(reason) {
		reason = "hash mismatch: verifier rejected tampered artifact"
	}
	rec := py.D("decision", "verified-rejection", "action", launch.Get("action"), "execution", launch.Get("execution"),
		"expected", whashes.Copy(), "observed", observed, "reason", reason,
		"claim_execution", claim.Get("execution"), "durable", true)
	if err := a.putMany([2]string{rejKey, py.Dumps(rec)},
		[2]string{doneKey, py.Dumps(py.D("verified_rejection", true, "rejection", rejKey))}); err != nil {
		return nil, fault("E_NO_SUCCESSOR", "cannot persist verified rejection")
	}
	return rec, nil
}

func readClaim(dir, execution string) *py.Dict {
	b, err := os.ReadFile(ClaimPathFor(dir, execution))
	if err != nil {
		return nil
	}
	v, err := py.Loads(b)
	if err != nil {
		return nil
	}
	if d := py.AsDict(v); d != nil {
		return d
	}
	return py.NewDict() // valid JSON that is not an object: Python fails later on .get
}

// RunHandoff validates the turn (authority), the claim file and the
// artifacts, declares transition + next intent atomically, commits the
// ledger step, and outboxes the next intent. verifySpec is nil for a
// verify step.
func RunHandoff(a *Adapter, qid string, turn *py.Dict, claimsDir string, launch, verifySpec *py.Dict) (*py.Dict, error) {
	kv := func(k string) string { v, _ := a.kv(k); return v }
	if !py.Eq(turn.Get("kind"), "end") {
		return nil, fault("E_NOT_END", "not a turn-end event")
	}
	sk := py.S(turn.Get("stream_key"))
	binding := a.TurnBinding(sk, turn.Get("item"))
	if binding == nil {
		return nil, fault("E_UNBOUND_TURN", "no launcher binding for this stream/item")
	}
	if !py.Eq(binding.Get("execution"), launch.Get("execution")) || !py.Eq(binding.Get("action"), launch.Get("action")) ||
		!py.Eq(binding.Get("step"), launch.Get("contract_step")) {
		return nil, fault("E_STALE_TURN", "turn does not match the bound declaration")
	}
	action, execution := py.S(launch.Get("action")), py.S(launch.Get("execution"))
	if !py.Eq(launch.Get("execution"), a.CurrentExecution(action)) {
		return nil, fault("E_STALE_TURN", "bound execution is not current")
	}
	if err := checkIncarnation(a, turn, binding, launch); err != nil {
		return nil, err
	}
	seenKey := "turn-seen:" + sk + ":" + py.S(turn.Get("item")) + ":" + execution
	intentKey := "handoff-intent:" + action + ":" + execution
	doneKey := "handoff-done:" + action + ":" + execution
	if kv(doneKey) != "" {
		return py.D("decision", "duplicate-end-ignored", "durable", true), nil
	}
	if kv(seenKey) != "" && kv(intentKey) == "" {
		return py.D("decision", "duplicate-end-ignored", "durable", true), nil
	}
	if kv(seenKey) != "" {
		return rollForward(a, qid, launch, verifySpec, intentKey, doneKey)
	}
	claim := readClaim(claimsDir, execution)
	if claim == nil {
		return recoverOwned(a, launch, "missing-or-malformed-claim")
	}
	base := py.S(launch.Get("artifact_base_dir"))
	if !py.Truthy(launch.Get("artifact_base_dir")) {
		base = claimsDir
	}
	var hashes *py.Dict
	err := ValidateClaim(claim, launch)
	if err == nil {
		hashes, err = RecomputeArtifacts(claim, base)
	}
	if err != nil {
		ce, ok := err.(*ClaimError)
		if !ok {
			return nil, err
		}
		code := ce.Code()
		if code == "E_FORGED_ROUTE" || code == "E_CLAIM_MISMATCH" {
			return nil, fault(code, ce.Msg)
		}
		rej, err := authenticatedRejection(a, launch, readClaim(claimsDir, execution), code)
		if err != nil {
			return nil, err
		}
		if rej != nil {
			return rej, nil
		}
		return recoverOwned(a, launch, code)
	}
	outcome := claim.Get("outcome")
	if py.Eq(outcome, "failed") || py.Eq(outcome, "cancelled") {
		return recoverOwned(a, launch, "failed-turn:"+py.S(outcome))
	}
	if !py.Eq(outcome, "completed") {
		if _, isStr := outcome.(string); !isStr {
			return nil, &core.PyError{Class: "TypeError", Msg: "can only concatenate str (not \"" + pyTypeName(outcome) + "\") to str"}
		}
		return recoverOwned(a, launch, "non-completion:"+py.S(outcome))
	}
	switch py.S(launch.Get("contract_step")) {
	case "worker-run":
		if verifySpec == nil {
			return recoverOwned(a, launch, "no-successor-bound")
		}
		vaction := py.S(verifySpec.Get("action_id"))
		intent := py.D("next", "verifier-dispatch", "action", action, "execution", execution,
			"verify_action", vaction, "verify_execution", verifySpec.Get("execution_id"), "hashes", hashes)
		if err := a.putMany([2]string{seenKey, py.Dumps(py.D("outcome", outcome))},
			[2]string{intentKey, py.Dumps(intent)},
			[2]string{"turn-last:" + action, py.Dumps(turn)}); err != nil {
			return nil, err
		}
		res, err := a.DriveNext(action, vaction, verifySpec.Get("deadline_utc"), hashes, qid)
		if err != nil {
			return rollForward(a, qid, launch, verifySpec, intentKey, doneKey)
		}
		// Single-sender rule: a caller that owns the verifier dispatch
		// records intent only here and sends it itself.
		var oid any
		if !py.Truthy(launch.Get("defer_verifier_send")) {
			o, err := a.OutboxSend(vaction, py.D("kind", "verifier-dispatch", "action", vaction), verifySpec.Get("execution_id"))
			if err != nil {
				return nil, err
			}
			oid = o
		}
		next := py.AsDict(res[0]).Get("next_action")
		if err := a.put(doneKey, py.Dumps(py.D("next", next, "outbox", oid))); err != nil {
			return nil, err
		}
		return py.D("decision", "transition-committed", "next", res[0], "duplicate", res[1], "outbox", oid), nil
	case "verify-run":
		return closeVerify(a, qid, launch, turn, seenKey, intentKey, doneKey)
	}
	return nil, fault("E_CLAIM_MISMATCH", "unknown contract step")
}

// recoverOwned is Python's _recover. (Python raises NameError, not the
// owned fault, when the launch has no escalation bound: OwnedFault is not
// imported in that function. Reported to Tern; Go raises the fault.)
func recoverOwned(a *Adapter, launch *py.Dict, reason string) (*py.Dict, error) {
	bound := launch.Get("escalation_deadline_utc")
	if !py.Truthy(bound) {
		return nil, fault("E_NO_ESCALATION_BOUND", "launch must bound recovery/escalation")
	}
	esc, err := a.EscalateUnavailable(py.S(launch.Get("action")), a.director(), "bounded-recovery", bound)
	if err != nil {
		return nil, err
	}
	return py.D("decision", "owned-recovery", "escalation", esc[0], "duplicate", esc[1], "reason", reason), nil
}

// DispositionKinds are the director dispositions the core accepts.
var DispositionKinds = []string{"successor_opened", "question_answered", "budget_spent", "blocked"}

// closeVerify closes a verifier completion ONLY through a
// director-authorized disposition bound in the launch manifest.
//
// Tern's HOST-PORT-RULING-20260923 finding 2 (the Python reference commits
// the verdict, then submits the decide separately, and a retry reports
// terminal-rest without either): the disposition is validated first, the
// verdict and disposition commit in ONE core transaction, and the done
// marker is written only after the ledger holds that exact disposition.
// The intent written before the commit is recovery metadata, never proof.
func closeVerify(a *Adapter, qid string, launch, turn *py.Dict, seenKey, intentKey, doneKey string) (*py.Dict, error) {
	allowed, _ := launch.Get("authorized_dispositions").([]any)
	if len(allowed) == 0 {
		return nil, fault("E_FORGED_DISPOSITION", "no director-authorized disposition bound")
	}
	disp := py.AsDict(allowed[0])
	if disp == nil {
		return nil, fault("E_FORGED_DISPOSITION", "authorized disposition malformed")
	}
	disp = disp.Copy()
	for _, f := range []string{"kind", "decision_ref", "reason"} {
		if !py.Truthy(disp.Get(f)) {
			return nil, fault("E_FORGED_DISPOSITION", "authorized disposition malformed")
		}
	}
	known := false
	for _, k := range DispositionKinds {
		known = known || py.Eq(disp.Get("kind"), k)
	}
	if !known {
		return nil, fault("E_FORGED_DISPOSITION", "disposition kind "+py.S(disp.Get("kind"))+" is not one the core accepts")
	}
	action := py.S(launch.Get("action"))
	intent := py.D("next", "director-close", "action", action, "execution", launch.Get("execution"),
		"disposition", disp, "verdict_event", action+"-hend-v", "decide_event", action+"-hend-d")
	if err := a.putMany([2]string{seenKey, py.Dumps(py.D("outcome", "completed"))},
		[2]string{intentKey, py.Dumps(intent)},
		[2]string{"turn-last:" + action, py.Dumps(turn)}); err != nil {
		return nil, err
	}
	return commitClose(a, qid, intent, doneKey, false)
}

// commitClose reconciles a declared close with the ledger. It writes done
// only when the ledger holds the intended disposition, committing the
// missing part under the intent's stable event ids when it may.
func commitClose(a *Adapter, qid string, intent *py.Dict, doneKey string, recovered bool) (*py.Dict, error) {
	rest := func() (*py.Dict, error) {
		if err := a.put(doneKey, py.Dumps(py.D("closed", true))); err != nil {
			return nil, err
		}
		out := py.D("decision", "terminal-rest", "durable", true)
		if recovered {
			out.Set("recovered", true)
		}
		return out, nil
	}
	var rec *py.Dict
	if r := a.Driver.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)}); r != nil {
		rec = r
	} else {
		rec = py.NewDict()
	}
	want := py.AsDict(intent.Get("disposition"))
	if have := rec.Get("disposition"); have != nil {
		if want == nil || py.Eq(have, want) {
			return rest() // committed before a crash: deduplicate, never repeat
		}
		return nil, fault("E_CONFLICTING_DISPOSITION", "the ledger holds a different disposition; the first is final")
	}
	if want == nil {
		return nil, fault("E_CLOSE_UNRESOLVED", "no authorized disposition was declared and the ledger holds none: closure incomplete")
	}
	var err error
	switch py.S(rec.Get("phase")) {
	case "COMPLETE", "EXHAUSTED", "TERMINATED", "SUPERSEDED":
		// A verdict is already committed without a disposition (a partial
		// close): add the authorized decide alone, never a second verdict.
		_, err = a.Driver.Ingress.Append(py.D("event_id", intent.Get("decide_event"), "question_id", qid,
			"revision", int64(1), "type", "decide", "disposition", want),
			a.Driver.Budget, nil, a.Driver.Grants, py.D("seat", "tern", "role", "director"), nil)
	default:
		_, err = a.Driver.TerminalClose(qid, py.S(intent.Get("verdict_event")), py.S(intent.Get("decide_event")),
			py.D("type", "verify_pass", "who", "verifier", "body",
				py.D("elapsed_s", int64(60), "pass_budget_s", int64(1800), "finding", "positive")), want)
	}
	if err != nil {
		return nil, fault("E_CLOSE_UNRESOLVED", "verdict and disposition not committed: "+err.Error())
	}
	return rest()
}

// rollForward finishes a declared-but-unfinished handoff under the same
// identities, instead of reporting a duplicate.
func rollForward(a *Adapter, qid string, launch, verifySpec *py.Dict, intentKey, doneKey string) (*py.Dict, error) {
	raw, _ := a.kv(intentKey)
	if raw == "" {
		raw = "{}"
	}
	intent := loadDict(raw)
	if intent == nil {
		intent = py.NewDict()
	}
	if intent.Len() == 0 {
		return py.D("decision", "duplicate-end-ignored", "durable", true), nil
	}
	if py.Eq(intent.Get("next"), "verifier-dispatch") && verifySpec != nil {
		vaction := py.S(verifySpec.Get("action_id"))
		hashes := intent.Get("hashes")
		if !py.Truthy(hashes) {
			hashes = py.NewDict()
		}
		res, err := a.DriveNext(py.S(launch.Get("action")), vaction, verifySpec.Get("deadline_utc"), hashes, qid)
		if err != nil {
			return nil, err
		}
		oid, err := a.OutboxSend(vaction, py.D("kind", "verifier-dispatch", "action", vaction), intent.Get("verify_execution"))
		if err != nil {
			return nil, err
		}
		if err := a.put(doneKey, py.Dumps(py.D("next", "recovered", "outbox", oid))); err != nil {
			return nil, err
		}
		return py.D("decision", "transition-committed", "next", res[0], "duplicate", res[1], "outbox", oid, "recovered", true), nil
	}
	if py.Eq(intent.Get("next"), "director-close") {
		return commitClose(a, qid, intent, doneKey, true)
	}
	return nil, fault("E_NO_SUCCESSOR", "declared intent has no roll-forward")
}

func pyTypeName(v any) string {
	switch v.(type) {
	case nil:
		return "NoneType"
	case bool:
		return "bool"
	case int64, int:
		return "int"
	case float64:
		return "float"
	case *py.Dict:
		return "dict"
	case []any:
		return "list"
	}
	return "object"
}

// pyJoin is os.path.join for two parts: an absolute second part wins.
func pyJoin(base, p string) string {
	switch {
	case strings.HasPrefix(p, "/") || base == "":
		return p
	case strings.HasSuffix(base, "/"):
		return base + p
	}
	return base + "/" + p
}
