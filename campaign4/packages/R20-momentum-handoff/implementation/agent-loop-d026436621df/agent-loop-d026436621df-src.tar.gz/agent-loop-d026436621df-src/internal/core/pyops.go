package core

import (
	"fmt"
	"strconv"
	"strings"

	"agent-loop/internal/py"
)

// PyError is a Python built-in exception the reference would raise, such as
// the TypeError from comparing a str with None. Reproduced so a port fails
// in the same place and the same way, not silently.
type PyError struct{ Class, Msg string }

func (e *PyError) Error() string { return e.Msg }

func typeName(v any) string {
	switch v.(type) {
	case nil:
		return "NoneType"
	case bool:
		return "bool"
	case int64, int:
		return "int"
	case float64:
		return "float"
	case string:
		return "str"
	case *py.Dict:
		return "dict"
	case []any:
		return "list"
	case py.Tuple:
		return "tuple"
	}
	return fmt.Sprintf("%T", v)
}

func compare(op string, a, b any) (int, error) {
	if fa, ok := py.Num(a); ok {
		if fb, ok := py.Num(b); ok {
			switch {
			case fa < fb:
				return -1, nil
			case fa > fb:
				return 1, nil
			}
			return 0, nil
		}
	}
	if sa, ok := a.(string); ok {
		if sb, ok := b.(string); ok {
			return strings.Compare(sa, sb), nil
		}
	}
	return 0, &PyError{"TypeError", fmt.Sprintf(
		"'%s' not supported between instances of '%s' and '%s'",
		op, typeName(a), typeName(b))}
}

func pyLessEq(a, b any) (bool, error) {
	c, err := compare("<=", a, b)
	return c <= 0, err
}

func asList(v any) []any {
	switch x := v.(type) {
	case []any:
		return x
	case py.Tuple:
		return []any(x)
	}
	return nil
}

func incr(v any) any {
	if i, ok := py.Int(v); ok {
		return i + 1
	}
	if f, ok := v.(float64); ok {
		return f + 1
	}
	return v
}

func lower(s string) string { return strings.ToLower(s) }

// parseIntPy is int(str) for plain decimal text.
func parseIntPy(s string) (int64, bool) {
	s = strings.ReplaceAll(strings.TrimSpace(s), "_", "")
	i, err := strconv.ParseInt(s, 10, 64)
	return i, err == nil
}
