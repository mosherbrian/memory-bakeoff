package loop

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// P12-closure-1: never-acked escalation, clock discontinuity, and the one
// allowed duplicate director notice.

func (r *rig) wakesTo(seat string) []string {
	var out []string
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" && c[1] == seat {
			out = append(out, c[2])
		}
	}
	return out
}

// settledAt settles Q's worker deadline, then puts the fake clock at the
// settlement time recorded by the loop (the callback used the host clock).
func settledAt(t *testing.T, r *rig) *Loop {
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	l := r.open()
	at, _ := py.Instant(l.Pkg("Q").Timeout.At)
	now, _ := py.Instant(r.clock.Now())
	r.clock.Advance(at.Sub(now).Seconds())
	return l
}

func TestNeverAckedTimeoutEscalatesDutyThenDirector(t *testing.T) {
	r := newRig(t)
	r.cfg.Duty, r.cfg.Seats["corvid"] = "tern", "C" // rig: duty and director are both tern
	l := settledAt(t, r)
	defer l.Close()
	n := len(r.wakesTo("T"))
	r.clock.Advance(59)
	r.tick(l)
	if len(r.wakesTo("T")) != n {
		t.Fatal("escalated before NoAckAfter")
	}
	r.clock.Advance(1)
	r.tick(l)
	r.tick(l)
	w := r.wakesTo("T")[n:]
	if len(w) != 1 || !strings.Contains(w[0], "NO acknowledgement") || !strings.Contains(w[0], "You are duty") ||
		!strings.Contains(w[0], "timeout-ack --config") {
		t.Fatalf("duty escalation at 60 s: %v", w)
	}
	r.clock.Advance(59)
	r.tick(l)
	if len(r.wakesTo("T")) != n+1 {
		t.Fatal("director escalated before 2*NoAckAfter")
	}
	r.clock.Advance(1)
	r.tick(l)
	r.tick(l)
	w = r.wakesTo("T")[n:]
	if len(w) != 2 || !strings.Contains(w[1], "You are director") {
		t.Fatalf("director escalation at 120 s: %v", w)
	}
	// Durable across a reopen: no repeat.
	l.Close()
	l = r.open()
	r.tick(l)
	if len(r.wakesTo("T")) != n+2 {
		t.Fatalf("repeated after reopen: %v", r.wakesTo("T")[n:])
	}
	// Escalation is not an acknowledgement; a later valid ack is still accepted.
	if l.Pkg("Q").Timeout.Ack != nil {
		t.Fatal("escalation recorded as an ack")
	}
	if _, err := l.AckTimeout("Q", "Q-w1", "tern", "take it", 10*time.Minute); err != nil {
		t.Fatal(err)
	}
}

func TestAnAckStopsTheNoAckEscalation(t *testing.T) {
	r := newRig(t)
	l := settledAt(t, r)
	defer l.Close()
	n := len(r.wakesTo("T"))
	r.clock.Advance(30)
	must(t, func() error { _, err := l.AckTimeout("Q", "Q-w1", "tern", "on it", 10*time.Minute); return err }())
	r.clock.Advance(120)
	r.tick(l)
	if len(r.wakesTo("T")) != n {
		t.Fatalf("escalated an acknowledged timeout: %v", r.wakesTo("T")[n:])
	}
}

func TestFailedNoAckSendIsRetriedNotRecordedDelivered(t *testing.T) {
	r := newRig(t)
	l := settledAt(t, r)
	defer l.Close()
	r.clock.Advance(60)
	r.fail["wake"] = true
	r.tick(l)
	to := r.fresh("Q")
	if !strings.HasPrefix(to.NoAckDuty, "failed") || !strings.HasPrefix(to.NoAckDirector, "failed") {
		t.Fatalf("failed sends recorded as %q / %q", to.NoAckDuty, to.NoAckDirector)
	}
	r.fail["wake"] = false
	n := len(r.wakesTo("T"))
	r.tick(l) // duty retried and reached; the director waits for 2*NoAckAfter again
	to = r.fresh("Q")
	if !strings.HasPrefix(to.NoAckDuty, "sent") || !strings.HasPrefix(to.NoAckDirector, "failed") || len(r.wakesTo("T")) != n+1 {
		t.Fatalf("retry: %q / %q, %d new wakes", to.NoAckDuty, to.NoAckDirector, len(r.wakesTo("T"))-n)
	}
	r.clock.Advance(60)
	r.tick(l)
	r.tick(l)
	if to = r.fresh("Q"); !strings.HasPrefix(to.NoAckDirector, "sent") || len(r.wakesTo("T")) != n+2 {
		t.Fatalf("director at 120 s: %q, %d new wakes", to.NoAckDirector, len(r.wakesTo("T"))-n)
	}
}

func TestNoAckEscalationRefusesAChangedPrincipal(t *testing.T) {
	r := newRig(t)
	l := settledAt(t, r)
	l.Close()
	// duty was tern at dispatch; the config now names corvid: not the same principal.
	r.cfg.Duty = "corvid"
	l = r.open()
	defer l.Close()
	n := len(r.wakesTo("C"))
	r.clock.Advance(60)
	r.tick(l)
	to := r.fresh("Q")
	if !strings.Contains(to.NoAckDuty, "E_AUTHORITY") || len(r.wakesTo("C")) != n {
		t.Fatalf("changed duty: %q, corvid wakes %d", to.NoAckDuty, len(r.wakesTo("C"))-n)
	}
	if !strings.HasPrefix(to.NoAckDirector, "sent") {
		t.Fatalf("director not told when duty could not be: %q", to.NoAckDirector)
	}
}

// timerState makes the rig's systemctl report the deadline unit's state.
func (r *rig) timerState(active, sub string) {
	run := r.cfg.Run
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		if argv[0] == "systemctl" && len(argv) > 2 && argv[2] == "show" {
			r.calls = append(r.calls, argv)
			return host.Proc{RC: 0, Stdout: "ActiveState=" + active + "\nSubState=" + sub + "\n"}, nil
		}
		return run(argv, env, timeout)
	}
}

func (r *rig) count(argv0 string, from int) int {
	n := 0
	for _, c := range r.calls[from:] {
		if c[0] == argv0 {
			n++
		}
	}
	return n
}

// Injected clock (core.FakeClock) for the loop side of a clock discontinuity:
// the timer fired, then the callback read a clock earlier than the deadline.
// Real systemd delivery after a host clock rollback is NOT shown by this.
func TestEarlyCallbackRearmsTheSameUnitAndIsDueExactlyOnce(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	l := r.open()
	defer func() { l.Close() }()
	dl, _ := l.deadlineOf("Q")
	out, err := l.D.OnDeadline("Q-w1", "Q") // fake clock is before the deadline
	must(t, err)
	if py.S(out[0]) != "no-op-early" {
		t.Fatalf("early callback: %v", out)
	}
	from, duty := len(r.calls), len(r.wakesTo("T"))
	note, err := l.RearmEarly("Q", "Q-w1", "ex-Q-w1")
	must(t, err)
	var rearm []string
	for _, c := range r.calls[from:] {
		if c[0] == "systemd-run" {
			rearm = c
		}
	}
	want := "--on-calendar=" + dl.UTC().Add(time.Second-1).Truncate(time.Second).Format("2006-01-02 15:04:05") + " UTC"
	if rearm == nil || rearm[2] != "--unit="+l.unit("Q-w1")+".timer" || rearm[4] != want || rearm[len(rearm)-1] != "ex-Q-w1" {
		t.Fatalf("re-arm argv %v, want the same unit at %s", rearm, want)
	}
	if r.count("systemctl", from) < 2 { // the spent unit is stopped and reset first
		t.Fatalf("spent unit not stopped: %v", r.calls[from:])
	}
	if l.Pkg("Q").Step != "worker" || len(r.wakesTo("K")) != 1 || !strings.Contains(note, "discontinuity") {
		t.Fatalf("early callback settled, cancelled or dispatched: step %s, worker wakes %v", l.Pkg("Q").Step, r.wakesTo("K"))
	}
	if d := r.wakesTo("T"); len(d) != duty+1 || !strings.Contains(d[len(d)-1], "discontinuity") {
		t.Fatalf("duty not told once: %v", d[duty:])
	}
	// A replay while the re-armed unit waits: reused, no second timer, no second notice.
	r.timerState("active", "waiting")
	l.Close()
	l = r.open() // the replay is a fresh callback process
	from = len(r.calls)
	_, err = l.RearmEarly("Q", "Q-w1", "ex-Q-w1")
	must(t, err)
	if r.count("systemd-run", from) != 0 || len(r.wakesTo("T")) != duty+1 {
		t.Fatal("a replay armed a second timer or told duty again")
	}
	// The due callback: settled once, with its lateness; a replay adds nothing.
	now, _ := py.Instant(r.clock.Now())
	r.clock.Advance(dl.Sub(now).Seconds() + 45)
	out, err = l.D.OnDeadline("Q-w1", "Q")
	must(t, err)
	must(t, l.MarkTimedOut("Q", "Q-w1"))
	out2, err := l.D.OnDeadline("Q-w1", "Q")
	must(t, err)
	if py.S(out[0]) != "interrupted" || py.S(out2[0]) != "already-handled" || l.Pkg("Q").Timeout.Lateness != "45s" {
		t.Fatalf("due: %v then %v, lateness %q", out, out2, l.Pkg("Q").Timeout.Lateness)
	}
	cancels := 0
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" && c[2] == "/cancel" {
			cancels++
		}
	}
	if cancels != 1 {
		t.Fatalf("%d cancels, want exactly 1", cancels)
	}
	// Stale/terminal: the step is settled now; a late early-callback re-arms nothing.
	if _, err := l.RearmEarly("Q", "Q-w1", "ex-Q-w1"); err == nil {
		t.Fatal("re-armed a settled step")
	}
}

func TestRearmRefusesWrongActionAndOwnsAFailedTimer(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	l := r.open()
	defer l.Close()
	from, duty0 := len(r.calls), len(r.wakesTo("T"))
	if _, err := l.RearmEarly("Q", "Q-v1", "ex-Q-v1"); err == nil || r.count("systemctl", from)+r.count("systemd-run", from) != 0 || len(r.wakesTo("T")) != duty0 {
		t.Fatalf("an action that is not the running step's reached the timers or duty: %v", r.calls[from:])
	}
	r.fail["systemd-run"] = true
	duty := len(r.wakesTo("T"))
	note, err := l.RearmEarly("Q", "Q-w1", "ex-Q-w1")
	if err == nil || !strings.Contains(note, "RE-ARM FAILED") {
		t.Fatalf("failed re-arm not owned: %q %v", note, err)
	}
	if d := r.wakesTo("T"); len(d) != duty+1 || !strings.Contains(d[len(d)-1], "RE-ARM FAILED") {
		t.Fatalf("duty not told of the failed re-arm: %v", d[duty:])
	}
}

// The one allowed duplicate: a failed-cancel settlement tells the director,
// then the timer's replay delivers the cancel and the core's own wake tells
// the director again. Same incident, same ownership and deadline, one ack,
// no further notices, one delivered cancel.
func TestTheOnlyDuplicateNoticeIsBounded(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "", "wake: could not reach K")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	l := r.open()
	first := *l.Pkg("Q").Timeout
	l.Close()
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1") // replay: cancel now delivered
	r.settle(t, "Q", "Q-w1", "ex-Q-w1") // further replays add nothing
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	l = r.open()
	defer l.Close()
	to := l.Pkg("Q").Timeout
	if to.ID != first.ID || to.At != first.At || to.Action != first.Action {
		t.Fatalf("incident changed: %+v -> %+v", first, *to)
	}
	dir := 0
	for _, w := range r.wakesTo("T") {
		if strings.Contains(w, "Q") {
			dir++
		}
	}
	cancels := 0
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" && c[1] == "K" && c[2] == "/cancel" {
			cancels++
		}
	}
	dispatches := len(r.wakesTo("K")) - cancels
	if dir != 2 || cancels != 2 || dispatches != 1 {
		t.Fatalf("director notices %d (want 2), cancel attempts %d (1 failed + 1 delivered), dispatches %d", dir, cancels, dispatches)
	}
	_ = host.Proc{}
}

// fresh reads a package's timeout record from a newly opened ledger.
func (r *rig) fresh(qid string) *StepTimeout {
	f := r.open()
	defer f.Close()
	return f.Pkg(qid).Timeout
}

// P12-stopped-ownership-1: the outside liveness check escalates an
// unacknowledged timeout while run is stopped; the stop itself stays quiet.
func TestStoppedRunTimeoutIsEscalatedByTheOutsideCheck(t *testing.T) {
	r := newRig(t)
	l := settledAt(t, r)
	l.Close()
	os.WriteFile(r.cfg.StopMarker(), []byte("x"), 0o644) // agent-loop stop: run passes no longer happen
	r.timerState("inactive", "dead")
	n := len(r.wakesTo("T"))
	at, _ := py.Instant(r.fresh("Q").At)
	check := func(after time.Duration) (Verdict, []string) {
		v, did, err := (&Checker{Cfg: r.cfg, Now: at.Add(after)}).Check()
		must(t, err)
		return v, did
	}
	v, did := check(59 * time.Second)
	if len(r.wakesTo("T")) != n || v.Alarm {
		t.Fatalf("escalated before 60 s or alarmed: %v %v", v, did)
	}
	v, did = check(60 * time.Second)
	if v.State != "stopped" || v.Alarm || len(r.wakesTo("T")) != n+1 || !strings.Contains(strings.Join(did, "|"), "timeout: Q: no ack, duty sent") {
		t.Fatalf("stopped check at 60 s: verdict %v, did %v, wakes %v", v, did, r.wakesTo("T")[n:])
	}
	check(90 * time.Second)
	if len(r.wakesTo("T")) != n+1 {
		t.Fatal("duty escalated twice")
	}
	check(120 * time.Second)
	to := r.fresh("Q")
	if len(r.wakesTo("T")) != n+2 || !strings.HasPrefix(to.NoAckDirector, "sent") || to.Ack != nil {
		t.Fatalf("director at 120 s: %+v", to)
	}
	st, _ := loadState(r.cfg.stateFile())
	if st.Open != nil {
		t.Fatalf("the timeout opened a liveness incident: %+v", st.Open)
	}
}

// run's pass and the outside check at the same moment: one escalation; an
// ack taken between them is never overwritten by a stale view.
func TestRunAndCheckerNeverDoubleEscalateOrLoseAnAck(t *testing.T) {
	r := newRig(t)
	l := settledAt(t, r)
	l.Close()
	at, _ := py.Instant(r.fresh("Q").At)
	r.clock.Advance(60)
	n := r.noAckWakes()
	(&Checker{Cfg: r.cfg, Now: at.Add(60 * time.Second)}).Check()
	r.pass(t) // a real run pass: lock, fresh open, Tick, close
	if r.noAckWakes() != n+1 {
		t.Fatalf("double duty escalation: %v", r.wakesTo("T"))
	}
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	f := r.open()
	_, err = f.AckTimeout("Q", "Q-w1", "tern", "on it", 10*time.Minute)
	f.Close()
	k.Unlock()
	must(t, err)
	r.clock.Advance(60)
	r.pass(t)
	(&Checker{Cfg: r.cfg, Now: at.Add(120 * time.Second)}).Check()
	to := r.fresh("Q")
	if to.Ack == nil || to.Ack.By != "tern" || r.noAckWakes() != n+1 {
		t.Fatalf("ack lost or escalated after ack: %+v, wakes %v", to, r.wakesTo("T"))
	}
}

// pass runs one run pass the way `agent-loop run` does.
func (r *rig) pass(t *testing.T) {
	k, err := LockLedger(r.cfg, 5*time.Second)
	must(t, err)
	defer k.Unlock()
	l := r.open()
	defer l.Close()
	r.tick(l)
}

func TestLedgerLockIsExclusiveAndBounded(t *testing.T) {
	r := newRig(t)
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	start := time.Now()
	if _, err := LockLedger(r.cfg, 300*time.Millisecond); err == nil || !strings.Contains(err.Error(), "E_LEDGER_BUSY") {
		t.Fatalf("second writer got the lock: %v", err)
	}
	if w := time.Since(start); w < 300*time.Millisecond || w > 2*time.Second {
		t.Fatalf("bounded wait took %s", w)
	}
	k.Unlock()
	k2, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	k2.Unlock()
}

// noAckWakes counts never-acked escalations (not liveness incidents).
func (r *rig) noAckWakes() int {
	n := 0
	for _, w := range r.wakesTo("T") {
		if strings.Contains(w, "NO acknowledgement") {
			n++
		}
	}
	return n
}

// A settlement is recorded only for the core's current action: a callback
// for another action never overwrites the recorded timeout.
func TestMarkTimedOutOnlyForTheCoresCurrentAction(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	l := r.open()
	defer l.Close()
	must(t, l.MarkTimedOut("Q", "Q-v1"))
	if to := l.Pkg("Q").Timeout; to == nil || to.Action != "Q-w1" || to.ID != "T-Q-w1" {
		t.Fatalf("a callback for another action rewrote the timeout: %+v", to)
	}
}
