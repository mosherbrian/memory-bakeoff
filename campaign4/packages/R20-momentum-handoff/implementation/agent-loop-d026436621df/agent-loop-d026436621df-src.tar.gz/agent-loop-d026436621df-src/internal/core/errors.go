// Package core is the Go port of the campaign-4 loop core (P5-r2 atomic
// authority, pinned 80092f92). It is a line-for-line port first: the
// conformance suite in conformance/ compares every call and every state
// change with the Python reference, so the shape follows the reference
// until that suite makes a safe refactor possible.
package core

import (
	"fmt"

	"agent-loop/internal/py"
)

// TransitionError is lifecycle.TransitionError: a fail-closed rejection.
type TransitionError struct {
	Code   string
	Detail any
}

func (e *TransitionError) Error() string { return fmt.Sprintf("%s: %s", e.Code, py.S(e.Detail)) }

func terr(code string, detail any) error { return &TransitionError{code, detail} }

// IngressError is ingress.IngressError; with Evidence set it is a
// Quarantined claim that never touched the lifecycle.
type IngressError struct {
	Code        string
	Detail      any
	Owner       string
	Evidence    *py.Dict
	Quarantined bool
}

func (e *IngressError) Error() string { return fmt.Sprintf("%s: %s", e.Code, py.S(e.Detail)) }

func ierr(code string, detail any, owner ...string) error {
	o := "cairn"
	if len(owner) > 0 {
		o = owner[0]
	}
	return &IngressError{Code: code, Detail: detail, Owner: o}
}

func quarantine(code string, detail any, evidence *py.Dict) error {
	return &IngressError{Code: code, Detail: detail, Owner: "cairn",
		Evidence: evidence, Quarantined: true}
}

// SimulatedCrash is the rehearsal crash-injection signal.
type SimulatedCrash struct{ Point string }

func (e *SimulatedCrash) Error() string { return e.Point }
