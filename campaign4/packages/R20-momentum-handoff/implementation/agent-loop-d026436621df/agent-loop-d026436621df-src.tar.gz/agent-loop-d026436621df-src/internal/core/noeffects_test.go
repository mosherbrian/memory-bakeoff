package core

import (
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
)

// The Go form of the reference's source-inspection tests
// (test_no_live_effects_possible, test_no_alternate_public_write_path):
// the core itself may not start processes, open sockets or send signals,
// and only the ingress may call the store's write paths.
func TestNoLiveEffectsInCore(t *testing.T) {
	banned := map[string]bool{"os/exec": true, "net": true, "net/http": true, "syscall": true, "os/signal": true}
	files, _ := filepath.Glob("*.go")
	for _, f := range files {
		if strings.HasSuffix(f, "_test.go") {
			continue
		}
		pf, err := parser.ParseFile(token.NewFileSet(), f, nil, parser.ImportsOnly)
		if err != nil {
			t.Fatal(err)
		}
		for _, im := range pf.Imports {
			p, _ := strconv.Unquote(im.Path.Value)
			if banned[p] {
				t.Errorf("%s imports %s", f, p)
			}
		}
	}
}

func TestOnlyIngressWritesTheStore(t *testing.T) {
	files, _ := filepath.Glob("*.go")
	for _, f := range files {
		if strings.HasSuffix(f, "_test.go") || f == "ingress.go" || f == "store.go" {
			continue
		}
		src, _ := os.ReadFile(f)
		for _, call := range []string{"Store.Append(", "Store.RecordTerminal("} {
			if strings.Contains(string(src), call) {
				t.Errorf("%s calls %s; only ingress.go may", f, call)
			}
		}
	}
}
