package host

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// adjudicated lists the reference defects the director ruled on
// (conformance/host/adjudicated.json): Go is held to the corrected
// expectation there, not to the recorded Python outcome.
type adjudicated struct {
	Cases []struct {
		Scenario string         `json:"scenario"`
		Op       int            `json:"op"`
		Go       map[string]any `json:"go"`
	} `json:"cases"`
	FinalExcluded []struct {
		Scenario string `json:"scenario"`
	} `json:"final_excluded"`
	FinalCorrected []struct {
		Scenario string `json:"scenario"`
		Key      string `json:"key"`
		Go       any    `json:"go"`
	} `json:"final_corrected"`
}

type scenario struct {
	Name      string            `json:"name"`
	Ops       []json.RawMessage `json:"ops"`
	Runner    []map[string]any  `json:"runner"`
	Transport map[string]any    `json:"transport"`
	Timers    map[string]any    `json:"timers"`
	Live      bool              `json:"live"`
}

// TestParity runs conformance/host/scenarios.json on the Go port and
// compares every op and the final state with the Python recording
// (conformance/tools/host_py.py).
func TestParity(t *testing.T) {
	root := filepath.Join("..", "..", "conformance", "host")
	var scens []scenario
	mustJSON(t, filepath.Join(root, "scenarios.json"), &scens)
	var want []map[string]any
	mustJSON(t, filepath.Join(root, "expected.json"), &want)
	var adj adjudicated
	mustJSON(t, filepath.Join(root, "adjudicated.json"), &adj)
	corrected, noFinal := map[string]map[string]any{}, map[string]bool{}
	for _, c := range adj.Cases {
		corrected[c.Scenario+"#"+itoa(c.Op)] = c.Go
	}
	finalFix := map[string]any{}
	for _, f := range adj.FinalCorrected {
		finalFix[f.Scenario+"#"+f.Key] = f.Go
	}
	for _, f := range adj.FinalExcluded {
		noFinal[f.Scenario] = true
	}
	identical, total := 0, 0
	if len(want) != len(scens) {
		t.Fatalf("%d scenarios, %d recorded", len(scens), len(want))
	}
	for i, sc := range scens {
		t.Run(sc.Name, func(t *testing.T) {
			got := runScenario(t, sc)
			wops := want[i]["ops"].([]any)
			gops := got["ops"].([]any)
			for j := range wops {
				if j >= len(gops) {
					t.Fatalf("op %d missing", j)
				}
				total++
				if exp, ok := corrected[sc.Name+"#"+itoa(j)]; ok {
					if canon(gops[j]) != canon(exp) {
						t.Errorf("op %d: adjudicated expectation %s, got %s", j, canon(exp), canon(gops[j]))
					}
					continue
				}
				if canon(gops[j]) != canon(wops[j]) {
					t.Errorf("op %d differs\n  python: %s\n  go:     %s", j, canon(wops[j]), canon(gops[j]))
				} else {
					identical++
				}
			}
			if noFinal[sc.Name] {
				return
			}
			wf, gf := want[i]["final"].(map[string]any), got["final"].(map[string]any)
			for _, k := range []string{"kv", "runner_calls", "transport_calls", "escalations"} {
				if exp, ok := finalFix[sc.Name+"#"+k]; ok {
					if canon(gf[k]) != canon(exp) {
						t.Errorf("final %s: adjudicated expectation %s, got %s", k, canon(exp), canon(gf[k]))
					}
					continue
				}
				if canon(wf[k]) != canon(gf[k]) {
					t.Errorf("final %s differs\n  python: %s\n  go:     %s", k, canon(wf[k]), canon(gf[k]))
				}
			}
		})
	}
	t.Logf("%d of %d ops identical to Python; %d held to adjudicated corrections", identical, total, len(corrected))
}

func itoa(i int) string { return strconv.Itoa(i) }

func mustJSON(t *testing.T, path string, v any) {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(b, v); err != nil {
		t.Fatal(err)
	}
}

var inodeRe = regexp.MustCompile(`(\\?"(?:inode|dev)\\?": )\d+`)

// canon renders a value as sorted JSON, the way both sides compare.
func canon(v any) string {
	b, _ := json.Marshal(v)
	var x any
	d := json.NewDecoder(strings.NewReader(string(b)))
	d.UseNumber()
	d.Decode(&x)
	b, _ = json.Marshal(x)
	// The ingress epoch carries a random token on both sides.
	return epochRe.ReplaceAllString(string(b), "epoch-$1-<token>")
}

var epochRe = regexp.MustCompile(`epoch-(\d+)-[0-9a-f]+`)

// toPlain converts a py value into encoding/json values, via py.Dumps so
// numbers and key order match Python's json.dumps.
func toPlain(v any, tmp string) any {
	s := py.Dumps(normPy(v))
	s = strings.ReplaceAll(s, tmp, "$TMP")
	s = inodeRe.ReplaceAllString(s, "${1}0")
	var x any
	d := json.NewDecoder(strings.NewReader(s))
	d.UseNumber()
	if err := d.Decode(&x); err != nil {
		panic(err)
	}
	return x
}

func normPy(v any) any {
	switch x := v.(type) {
	case py.Tuple:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = normPy(e)
		}
		return out
	case []any:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = normPy(e)
		}
		return out
	case []*py.Dict:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = e
		}
		return out
	case []string:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = e
		}
		return out
	case *py.Dict:
		if x == nil {
			return nil
		}
		d := py.NewDict()
		for _, k := range x.Keys() {
			d.Set(k, normPy(x.Get(k)))
		}
		return d
	case map[string]any:
		d := py.NewDict()
		for k, e := range x {
			d.Set(k, normPy(e))
		}
		return d
	case json.Number:
		if i, err := x.Int64(); err == nil {
			return i
		}
		f, _ := x.Float64()
		return f
	case float64:
		if x == float64(int64(x)) {
			return int64(x)
		}
	}
	return v
}

// fromJSON turns a scenario argument into py values.
func fromJSON(v any, tmp string) any {
	switch x := v.(type) {
	case string:
		return strings.ReplaceAll(x, "$TMP", tmp)
	case []any:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = fromJSON(e, tmp)
		}
		return out
	case *orderedObj:
		d := py.NewDict()
		for _, kv := range x.kv {
			d.Set(kv.k, fromJSON(kv.v, tmp))
		}
		return d
	case json.Number:
		if i, err := x.Int64(); err == nil {
			return i
		}
		f, _ := x.Float64()
		return f
	}
	return v
}

type orderedObj struct {
	kv []struct {
		k string
		v any
	}
}

// decodeOrdered keeps object key order (payload order reaches the wake
// text, exactly as Python's json.dumps(payload) sends it).
func decodeOrdered(d *json.Decoder) (any, error) {
	tok, err := d.Token()
	if err != nil {
		return nil, err
	}
	switch tk := tok.(type) {
	case json.Delim:
		switch tk {
		case '{':
			o := &orderedObj{}
			for d.More() {
				kt, _ := d.Token()
				v, err := decodeOrdered(d)
				if err != nil {
					return nil, err
				}
				o.kv = append(o.kv, struct {
					k string
					v any
				}{kt.(string), v})
			}
			d.Token()
			return o, nil
		case '[':
			var xs []any
			for d.More() {
				v, err := decodeOrdered(d)
				if err != nil {
					return nil, err
				}
				xs = append(xs, v)
			}
			d.Token()
			if xs == nil {
				xs = []any{}
			}
			return xs, nil
		}
	}
	return tok, nil
}

func runScenario(t *testing.T, sc scenario) map[string]any {
	tmp := t.TempDir()
	os.MkdirAll(filepath.Join(tmp, "stream"), 0o755)
	queue := append([]map[string]any(nil), sc.Runner...)
	var calls []any
	runner := func(argv []string, env []string, timeout time.Duration) (Proc, error) {
		c := make([]any, len(argv))
		for i, a := range argv {
			c[i] = a
		}
		calls = append(calls, c)
		r := map[string]any{"rc": float64(0)}
		if len(queue) > 0 {
			r, queue = queue[0], queue[1:]
		}
		switch r["raise"] {
		case "timeout":
			return Proc{}, ErrTimeout
		case "spawn":
			return Proc{}, errors.New("spawn failed")
		}
		rc, _ := r["rc"].(float64)
		so, _ := r["stdout"].(string)
		se, _ := r["stderr"].(string)
		return Proc{RC: int(rc), Stdout: so, Stderr: se}, nil
	}
	db := filepath.Join(tmp, "h.db")
	clock := core.NewFakeClock(nil)
	var fake *FakeTransport
	build := func() *Adapter {
		d, err := core.NewDriver(db, clock, nil, nil)
		if err != nil {
			t.Fatal(err)
		}
		var tr Transport
		tc := sc.Transport
		if tc == nil || tc["kind"] == "fake" {
			if fake == nil {
				fake = NewFakeTransport()
			}
			tr = fake
		} else {
			en, ok := tc["enabled"].(bool)
			if !ok {
				en = true
			}
			wp, _ := tc["wake"].(string)
			if wp == "" {
				wp = "/bin/wake"
			}
			tr = &WakeTransport{WakePath: wp, Allowlist: strs(tc["allow"]), Enabled: en, KV: DriverKV(d), Run: runner}
		}
		tm := NewTimers(DriverKV(d))
		if mc := sc.Timers; mc != nil && mc["kind"] == "host" {
			en, ok := mc["enabled"].(bool)
			if !ok {
				en = true
			}
			tm.Host, tm.Enabled, tm.Allowlist, tm.Run, tm.CallbackArg = true, en, strs(mc["allow"]), runner, strs(mc["callback"])
		}
		a, err := NewAdapter(d, tr, tm, sc.Live)
		if err != nil {
			t.Fatal(err)
		}
		return a
	}
	ad := build()
	watcher := NewTurnWatcher(filepath.Join(tmp, "stream"))
	cursors := py.NewDict()
	var events []*py.Dict
	var out []any
	for _, raw := range sc.Ops {
		dec := json.NewDecoder(strings.NewReader(string(raw)))
		dec.UseNumber()
		ov, err := decodeOrdered(dec)
		if err != nil {
			t.Fatal(err)
		}
		op := fromJSON(ov, tmp).(*py.Dict)
		name := py.S(op.Get("op"))
		a := py.AsDict(op.GetOr("args", py.NewDict()))
		s := func(k string) string { v, _ := a.Get(k).(string); return v }
		var r any
		var e error
		switch name {
		case "clock_set":
			clock.SetNow(s("now"))
		case "clock_advance":
			f, _ := py.Num(a.Get("s"))
			r = clock.Advance(f)
		case "write", "append", "replace_file":
			p := filepath.Join(tmp, s("path"))
			os.MkdirAll(filepath.Dir(p), 0o755)
			switch name {
			case "write":
				e = os.WriteFile(p, []byte(s("text")), 0o644)
			case "append":
				f, _ := os.OpenFile(p, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0o644)
				f.WriteString(s("text"))
				f.Close()
			default:
				os.WriteFile(p+".new", []byte(s("text")), 0o644)
				e = os.Rename(p+".new", p)
			}
		case "reopen":
			ad.Driver.Close()
			ad = build()
		case "kv_put":
			e = ad.Driver.KVPut(s("k"), s("v"))
		case "admit_authorize":
			e = ad.Driver.AdmitAuthorize(s("qid"))
		case "start_dispatch":
			r, e = ad.Driver.StartDispatch(s("qid"), s("action"), a.Get("duration_s"), nil)
		case "send":
			kind := s("kind")
			if kind == "" {
				kind = "wake"
			}
			r, e = ad.Transport.Send(s("seat"), s("text"), kind, a.Get("action"), a.Get("execution"))
		case "state":
			r = ad.Transport.State(s("mid"))
		case "mark":
			if _, ok := fake.inbox[s("mid")]; !ok {
				e = &core.PyError{Class: "KeyError", Msg: s("mid")}
			} else {
				r = fake.Mark(s("mid"), s("state"))
			}
		case "timer_create":
			r, e = ad.Timers.Create(s("id"), a.Get("deadline"))
		case "timer_cancel":
			r, e = ad.Timers.Cancel(s("id"))
		case "timer_fire":
			r, e = ad.Timers.Fire(s("id"), a.Get("now"), a.Get("deadline"))
		case "timer_create_host":
			f, _ := py.Num(a.Get("delay_s"))
			var cb []string
			if a.Has("callback") {
				cb = strs(a.Get("callback"))
			}
			r, e = ad.Timers.CreateHost(s("id"), a.Get("deadline"), f, cb)
		case "timer_cancel_host":
			r, e = ad.Timers.CancelHost(s("id"))
		case "timer_query_host":
			r, e = ad.Timers.QueryHost(s("id"))
		case "capture":
			r, e = ad.Capture(s("package"), s("attempt"), s("action"), s("event"), s("execution"), a.Get("outcome"),
				a.Get("occurred_at"), a.Get("provenance"))
		case "receipt":
			r = ad.Receipt(s("package"), s("attempt"), s("action"), s("event"), s("execution"))
		case "trail":
			r = ad.Trail(s("action"))
		case "bound_artifacts":
			r = ad.BoundArtifacts(s("action"))
		case "bind_route":
			r, e = ad.BindRoute(s("action"), s("seat"))
		case "route_for":
			r, e = ad.RouteFor(s("action"))
		case "bind_turn":
			e = ad.BindTurn(s("stream_key"), a.Get("item"), s("execution"), s("action"), s("step"))
			r = py.T(s("stream_key"), a.Get("item"))
		case "turn_binding":
			r = ad.TurnBinding(s("stream_key"), a.Get("item"))
		case "outbox_send":
			r, e = ad.OutboxSend(s("target"), py.AsDict(a.Get("payload")), a.Get("execution"))
		case "outbox_ack":
			r, e = ad.OutboxAck(s("oid"))
		case "drain":
			q := s("qid")
			if q == "" {
				q = "P6F"
			}
			r, e = ad.DrainOutboxSettled(q)
		case "reconcile_outbox":
			r, e = ad.ReconcileOutbox()
		case "register_execution":
			r, e = ad.RegisterExecution(s("action"), s("execution"), a.Get("auth"), a.Get("deadline"))
		case "current_execution":
			r = ad.CurrentExecution(s("action"))
		case "apply_result":
			r, e = ad.ApplyExecutionResult(s("action"), s("execution"), a.Get("result"))
		case "resume_execution":
			r, e = ad.ResumeExecution(s("action"), a.Get("attempt"), s("old"), s("new"), a.Get("auth"), a.Get("deadline"), a.Get("phase"))
		case "replace_action":
			r, e = ad.ReplaceAction(s("old"), s("new"), s("execution"), a.Get("auth"), a.Get("deadline"), a.Get("attempt_changed"))
		case "drive_next":
			r, e = ad.DriveNext(s("action"), s("verify_action"), a.Get("deadline"), a.Get("hashes"), s("qid"))
		case "arm_from_ledger":
			r, e = ad.ArmFromLedger(s("id"), a.Get("deadline"), a.Get("now"))
		case "arm_current":
			r, e = ad.ArmCurrent(s("id"), s("qid"))
		case "reconcile_send":
			r = ad.ReconcileSend(s("mid"), s("action"))
		case "escalate":
			r, e = ad.EscalateUnavailable(s("action"), s("owner"), s("next"), a.Get("deadline"))
		case "confirm_ack":
			r, e = ad.ConfirmEscalationAck(s("action"))
		case "poll":
			for _, k := range strs(a.Get("notify")) {
				watcher.Notify(k)
			}
			d := ad.Driver
			var evs []*py.Dict
			var notes, labels *py.Dict
			evs, cursors, notes, labels, e = watcher.Poll(strs(a.Get("keys")), cursors,
				func(tok string) error { return d.KVPut("sidecar-seen:"+tok, "1") },
				func(tok string) bool { return d.KV["sidecar-seen:"+tok] == "1" })
			events = evs
			xs := []any{}
			for _, ev := range evs {
				xs = append(xs, ev)
			}
			r = []any{xs, cursors, notes, labels}
		case "write_claim":
			r, e = WriteClaim(s("dir"), s("execution"), py.AsDict(a.Get("claim")))
		case "validate_claim":
			e = ValidateClaim(py.AsDict(a.Get("claim")), py.AsDict(a.Get("launch")))
			r = a.Get("claim")
		case "recompute":
			r, e = RecomputeArtifacts(py.AsDict(a.Get("claim")), s("base"))
		case "run_handoff":
			var turn *py.Dict
			if a.Has("event") {
				i, _ := py.Int(a.Get("event"))
				turn = events[i]
			} else {
				turn = py.AsDict(a.Get("turn"))
			}
			var vs *py.Dict
			if a.Has("verify_spec") {
				vs = py.AsDict(a.Get("verify_spec"))
			}
			r, e = RunHandoff(ad, s("qid"), turn, s("claims"), py.AsDict(a.Get("launch")), vs)
		case "timer_callback":
			r, e = TimerCallback(db, s("timer"), s("qid"), s("action"), s("execution"), core.HostClock{}, nil)
		default:
			t.Fatalf("unknown op %s", name)
		}
		if e != nil {
			out = append(out, map[string]any{"op": name, "error": errCode(e)})
		} else {
			out = append(out, map[string]any{"op": name, "result": toPlain(r, tmp)})
		}
	}
	kv := py.NewDict()
	ks := make([]string, 0, len(ad.Driver.KV))
	for k := range ad.Driver.KV {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	for _, k := range ks {
		kv.Set(k, ad.Driver.KV[k])
	}
	var tcalls []any
	switch tr := ad.Transport.(type) {
	case *FakeTransport:
		for _, c := range tr.Calls {
			tcalls = append(tcalls, []any{c[0], c[1], c[2]})
		}
	case *WakeTransport:
		for _, c := range tr.Calls {
			tcalls = append(tcalls, []any{c[0], c[1], c[2]})
		}
	}
	var escs []any
	for _, x := range ad.Escalations {
		escs = append(escs, x)
	}
	final := py.D("kv", kv, "runner_calls", nonNil(calls), "transport_calls", nonNil(tcalls), "escalations", nonNil(escs))
	ad.Driver.Close()
	return map[string]any{"name": sc.Name, "ops": out, "final": toPlain(final, tmp)}
}

func errCode(e error) string {
	if f, ok := IsFault(e); ok {
		return f.Code
	}
	var ce *ClaimError
	if errors.As(e, &ce) {
		return ce.Code()
	}
	var pe *core.PyError
	if errors.As(e, &pe) {
		if code, ok := coreCode(pe); ok {
			return code
		}
		return pe.Class
	}
	if code, ok := coreCode(e); ok {
		return code
	}
	return "GoError:" + e.Error()
}

func strs(v any) []string {
	var out []string
	switch x := v.(type) {
	case []any:
		for _, e := range x {
			out = append(out, py.S(e))
		}
	case []string:
		return x
	}
	return out
}

func coreCode(e error) (string, bool) {
	var te *core.TransitionError
	if errors.As(e, &te) {
		return te.Code, true
	}
	var ie *core.IngressError
	if errors.As(e, &ie) {
		return ie.Code, true
	}
	return "", false
}
