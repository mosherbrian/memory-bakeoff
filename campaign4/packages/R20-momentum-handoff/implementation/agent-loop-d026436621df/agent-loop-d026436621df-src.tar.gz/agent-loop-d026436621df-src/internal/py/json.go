package py

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"sort"
	"strconv"
	"strings"
	"unicode/utf16"
)

// Loads is json.loads: objects keep their order, integers stay int64 and
// anything with a fraction or exponent becomes float64.
func Loads(data []byte) (any, error) {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	v, err := decode(dec)
	if err != nil {
		return nil, err
	}
	if _, err := dec.Token(); err != io.EOF {
		return nil, fmt.Errorf("extra data after JSON value")
	}
	return v, nil
}

func decode(dec *json.Decoder) (any, error) {
	tok, err := dec.Token()
	if err != nil {
		return nil, err
	}
	switch t := tok.(type) {
	case json.Delim:
		switch t {
		case '{':
			d := NewDict()
			for dec.More() {
				kt, err := dec.Token()
				if err != nil {
					return nil, err
				}
				v, err := decode(dec)
				if err != nil {
					return nil, err
				}
				d.Set(kt.(string), v)
			}
			_, err := dec.Token()
			return d, err
		case '[':
			out := []any{}
			for dec.More() {
				v, err := decode(dec)
				if err != nil {
					return nil, err
				}
				out = append(out, v)
			}
			_, err := dec.Token()
			return out, err
		}
	case json.Number:
		s := string(t)
		if !strings.ContainsAny(s, ".eE") {
			if i, err := strconv.ParseInt(s, 10, 64); err == nil {
				return i, nil
			}
		}
		return strconv.ParseFloat(s, 64)
	case string, bool, nil:
		return t, nil
	}
	return nil, fmt.Errorf("unexpected token %v", tok)
}

// Dumps is json.dumps(v, sort_keys=True) with Python's default separators
// and ensure_ascii. Durable rows hold exactly this text, so it must match.
func Dumps(v any) string {
	var b strings.Builder
	dump(&b, v, true)
	return b.String()
}

// DumpsUnsorted is json.dumps(v): keys in insertion order.
func DumpsUnsorted(v any) string {
	var b strings.Builder
	dump(&b, v, false)
	return b.String()
}

func dump(b *strings.Builder, v any, sorted bool) {
	switch x := v.(type) {
	case nil:
		b.WriteString("null")
	case bool:
		if x {
			b.WriteString("true")
		} else {
			b.WriteString("false")
		}
	case int64:
		b.WriteString(strconv.FormatInt(x, 10))
	case int:
		b.WriteString(strconv.Itoa(x))
	case float64:
		switch {
		case math.IsNaN(x):
			b.WriteString("NaN")
		case math.IsInf(x, 1):
			b.WriteString("Infinity")
		case math.IsInf(x, -1):
			b.WriteString("-Infinity")
		default:
			b.WriteString(FloatRepr(x))
		}
	case string:
		dumpStr(b, x)
	case *Dict:
		keys := x.Keys()
		if sorted {
			sort.Strings(keys)
		}
		b.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				b.WriteString(", ")
			}
			dumpStr(b, k)
			b.WriteString(": ")
			dump(b, x.Get(k), sorted)
		}
		b.WriteByte('}')
	case []any:
		dumpSeq(b, x, sorted)
	case Tuple:
		dumpSeq(b, x, sorted)
	default:
		panic(fmt.Sprintf("py.Dumps: %T is not JSON serializable", v))
	}
}

func dumpSeq(b *strings.Builder, xs []any, sorted bool) {
	b.WriteByte('[')
	for i, x := range xs {
		if i > 0 {
			b.WriteString(", ")
		}
		dump(b, x, sorted)
	}
	b.WriteByte(']')
}

func dumpStr(b *strings.Builder, s string) {
	b.WriteByte('"')
	for _, r := range s {
		switch r {
		case '"':
			b.WriteString(`\"`)
		case '\\':
			b.WriteString(`\\`)
		case '\n':
			b.WriteString(`\n`)
		case '\r':
			b.WriteString(`\r`)
		case '\t':
			b.WriteString(`\t`)
		case '\b':
			b.WriteString(`\b`)
		case '\f':
			b.WriteString(`\f`)
		default:
			if r >= 0x20 && r < 0x7f {
				b.WriteRune(r)
			} else if r > 0xffff {
				a, c := utf16.EncodeRune(r)
				fmt.Fprintf(b, `\u%04x\u%04x`, a, c)
			} else {
				fmt.Fprintf(b, `\u%04x`, r)
			}
		}
	}
	b.WriteByte('"')
}
