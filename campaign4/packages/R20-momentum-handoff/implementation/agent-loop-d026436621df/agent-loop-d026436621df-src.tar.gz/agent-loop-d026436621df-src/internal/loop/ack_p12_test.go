package loop

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// P12-ack-capacity-1: reserved ack/check admission, durable ack requests.

func settledQ(t *testing.T) *rig {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	return r
}

func req(by, next string, within time.Duration) AckRequest {
	now := time.Now().UTC()
	return AckRequest{QID: "Q", Action: "Q-w1", By: by, Next: next, Deadline: py.ISO(now.Add(within)), Submitted: py.ISO(now), PID: os.Getpid()}
}

func TestPriorityOrderAndNoTwoPriorityGrantsInARow(t *testing.T) {
	r := newRig(t)
	q := newQueue(r.cfg)
	os.MkdirAll(q.dir, 0o755)
	names := []string{"1", "2", "3", "4"}
	got := map[string]queueEntry{"1": {Class: "ordinary"}, "2": {Class: "run"}, "3": {Class: "check"}, "4": {Class: "ack"}}
	if h := q.pick(names, got); h != "4" {
		t.Fatalf("an ack is not granted first: %s", h)
	}
	q.granted("ack")
	if h := q.pick(names[:3], got); h != "1" {
		t.Fatalf("a second priority grant in a row starves the oldest writer: %s", h)
	}
	q.granted("ordinary")
	if h := q.pick([]string{"2", "3"}, got); h != "3" {
		t.Fatalf("the check is not granted after a non-priority grant: %s", h)
	}
	q.granted("check")
	if h := q.pick([]string{"3"}, map[string]queueEntry{"3": {Class: "check"}}); h != "3" {
		t.Fatalf("a lone priority writer is blocked: %s", h)
	}
}

func TestClassesOfTheAckAndTheOutsideCheck(t *testing.T) {
	old := os.Args
	t.Cleanup(func() { os.Args = old })
	for cmd, want := range map[string]string{"timeout-ack": "ack", "liveness": "check", "timer-callback": "due", "run": "run", "dispatch": "ordinary"} {
		os.Args = []string{"agent-loop", cmd}
		if c := lockClass(); c != want {
			t.Errorf("%s is class %s, want %s", cmd, c, want)
		}
	}
}

func TestDetectionIsTheEarliestTrustedTime(t *testing.T) {
	st := &StepTimeout{At: "2026-09-23T20:00:30Z", Deferred: "2026-09-23T20:00:08Z"}
	if d := Detection(st); d != st.Deferred {
		t.Fatalf("detection moved to the settlement: %s", d)
	}
	st.Deferred = ""
	if d := Detection(st); d != st.At {
		t.Fatalf("no marker: %s", d)
	}
}

func TestAPendingRequestIsNotAnAckUntilAHolderCommitsIt(t *testing.T) {
	r := settledQ(t)
	rq, err := SubmitAck(r.cfg, req("tern", "look", 10*time.Minute))
	must(t, err)
	l := r.open()
	if l.Pkg("Q").Timeout.Ack != nil || AckResult(r.cfg, rq) != nil {
		t.Fatal("a pending request reads as an acknowledgement")
	}
	l.Close()
	// the requester has exited; the next holder (any process) commits it
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	ProcessDue(r.cfg)
	k.Unlock()
	res := AckResult(r.cfg, rq)
	if res == nil || res.Outcome != "committed" || res.Detection == "" {
		t.Fatalf("not committed by the next holder: %+v", res)
	}
	l = r.open()
	defer l.Close()
	if a := l.Pkg("Q").Timeout.Ack; a == nil || a.By != "tern" || a.NextAction != "look" {
		t.Fatalf("ledger ack %+v", a)
	}
}

func TestReplayConflictAndQueueBound(t *testing.T) {
	r := settledQ(t)
	a, err := SubmitAck(r.cfg, req("tern", "look", 10*time.Minute))
	must(t, err)
	time.Sleep(1100 * time.Millisecond)
	b, err := SubmitAck(r.cfg, req("tern", "look", 10*time.Minute))
	if err != nil || b.Submitted != a.Submitted {
		t.Fatalf("a replay is not the first request: %v %+v", err, b)
	}
	if _, err := SubmitAck(r.cfg, req("tern", "other", 10*time.Minute)); err == nil || !strings.Contains(err.Error(), "E_ACK_CONFLICT") {
		t.Fatalf("a conflicting request was recorded: %v", err)
	}
	for i := 1; i < MaxPendingAcks; i++ {
		x := req("tern", "look", 10*time.Minute)
		x.QID = "P" + string(rune('a'+i))
		_, err := SubmitAck(r.cfg, x)
		must(t, err)
	}
	x := req("tern", "look", 10*time.Minute)
	x.QID = "overflow"
	if _, err := SubmitAck(r.cfg, x); err == nil || !strings.Contains(err.Error(), "E_ACK_QUEUE_FULL") {
		t.Fatalf("an unbounded request store: %v", err)
	}
}

func TestForgedExpiredAndLateRequests(t *testing.T) {
	r := settledQ(t)
	forged, _ := SubmitAck(r.cfg, req("kiln", "look", 10*time.Minute))
	expired := req("tern", "gone", time.Second)
	must(t, putPending(r.cfg, expired, "zzx.json")) // a second request by one principal: its own file
	time.Sleep(1100 * time.Millisecond)
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	ProcessDue(r.cfg)
	k.Unlock()
	if f := AckResult(r.cfg, forged); f == nil || f.Outcome != "rejected" {
		t.Fatalf("a forged principal's request: %+v", f)
	}
	var e *AckRequest
	if b, err := os.ReadFile(filepath.Join(ackDir(r.cfg), "done", "zzx.json")); err == nil {
		json.Unmarshal(b, &e)
	}
	if e == nil || e.Outcome != "rejected" || !strings.Contains(e.Reason, "passed") {
		t.Fatalf("an expired request: %+v", e)
	}
	l := r.open()
	if l.Pkg("Q").Timeout.Ack != nil {
		t.Fatal("a rejected request left an ack")
	}
	// A late commit: detection more than AckBound ago.
	p := l.Pkg("Q")
	p.Timeout.At = py.ISO(time.Now().UTC().Add(-2 * AckBound))
	must(t, l.save(p))
	l.Close()
	late, _ := SubmitAck(r.cfg, req("tern", "look", 10*time.Minute))
	n := len(r.wakesTo("T"))
	k, err = LockLedger(r.cfg, time.Second)
	must(t, err)
	ProcessDue(r.cfg)
	k.Unlock()
	res := AckResult(r.cfg, late)
	if res == nil || res.Outcome != "committed" || !res.Late || res.LateNotice != "sent" {
		t.Fatalf("a late commit is not recorded and escalated: %+v", res)
	}
	if w := r.wakesTo("T")[n:]; len(w) != 1 || !strings.Contains(w[0], "the bound was missed") {
		t.Fatalf("late escalation: %v", w)
	}
}

// putPending writes a pending request file directly (test helper).
func putPending(cfg *Config, r AckRequest, name string) error {
	b, _ := json.Marshal(r)
	os.MkdirAll(ackDir(cfg), 0o755)
	return os.WriteFile(filepath.Join(ackDir(cfg), name), b, 0o644)
}

func TestASpentBudgetLeavesTheRequestPendingNotRejected(t *testing.T) {
	r := settledQ(t)
	rq, err := SubmitAck(r.cfg, req("tern", "look", 10*time.Minute))
	must(t, err)
	run := r.cfg.Run
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		if argv[0] == "agent-deck" {
			return host.Proc{}, host.ErrBudget
		}
		return run(argv, env, timeout)
	}
	processAcks(r.cfg)
	if AckResult(r.cfg, rq) != nil || len(pendingAcks(r.cfg)) != 1 {
		t.Fatal("a transient budget refusal rejected the request")
	}
	r.cfg.Run = run
	processAcks(r.cfg)
	if res := AckResult(r.cfg, rq); res == nil || res.Outcome != "committed" {
		t.Fatalf("not committed on the next drain: %+v", res)
	}
}
