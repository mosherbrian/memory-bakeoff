package loop

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/py"
)

// P13: the director's decision is an owned obligation with a deadline.

func decisionRig(t *testing.T) (*rig, *Loop) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(Request{QID: "Q", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 3600, VerifyS: 3600})
	must(t, err)
	l = r.walk(l, "Q", false)
	if p := l.Pkg("Q"); p.Step != "decision" {
		t.Fatalf("not at decision: %s", p.Step)
	}
	return r, l
}

func wakesTo(r *rig, seat string) int { return len(r.wakesTo(seat)) }

func TestEnteringDecisionPersistsADeadlineAndArmsACalendarTimer(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	d := l.Pkg("Q").Decision
	at, _ := py.Instant(l.Pkg("Q").StepAt)
	dl, _ := py.Instant(d.Deadline)
	if d == nil || d.Incident != "D-Q-Q-v1" || dl.Sub(at) != 1800*time.Second {
		t.Fatalf("decision record %+v (step at %s)", d, at)
	}
	armed := false
	for _, c := range r.calls {
		j := strings.Join(c, " ")
		if c[0] == "systemd-run" && strings.Contains(j, "--on-calendar=") && strings.HasSuffix(j, "decision-check --config "+r.cfg.Path) {
			armed = true
		}
	}
	if !armed {
		t.Fatal("no calendar timer running decision-check was armed")
	}
	// A reopen never moves the deadline.
	l.Close()
	l = r.open()
	defer l.Close()
	r.clock.Advance(600)
	l.decisionLadder()
	if l.Pkg("Q").Decision.Deadline != d.Deadline {
		t.Fatal("the deadline moved on reopen/check")
	}
}

func TestTheLadderFiresEachRungOnceInOrder(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	r.cfg.Director, r.cfg.Duty = "tern", "corvid"
	n0 := wakesTo(r, "T")
	r.clock.Advance(1799)
	l.decisionLadder()
	if wakesTo(r, "T") != n0 {
		t.Fatal("reminded before the deadline")
	}
	r.clock.Advance(1)
	l.decisionLadder()
	l.decisionLadder()
	if wakesTo(r, "T") != n0+1 || !strings.Contains(r.wakesTo("T")[n0], "DECISION OVERDUE D-Q-Q-v1") {
		t.Fatalf("director rung: %v", r.wakesTo("T")[n0:])
	}
	c0 := wakesTo(r, "C")
	r.clock.Advance(299)
	l.decisionLadder()
	if wakesTo(r, "C") != c0 {
		t.Fatal("duty told before +300 s")
	}
	r.clock.Advance(1)
	l.decisionLadder()
	l.decisionLadder()
	if wakesTo(r, "C") != c0+1 {
		t.Fatalf("duty rung once: %d", wakesTo(r, "C")-c0)
	}
}

func TestAnActualDecisionResolvesAndStopsLaterRungs(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	r.clock.Advance(1800)
	l.decisionLadder()
	must(t, l.Decide("Q", "question_answered", "rec-1", "done"))
	p := l.Pkg("Q")
	if p.Decision.Resolved == "" || p.Step != "closed" {
		t.Fatalf("not resolved: %+v", p.Decision)
	}
	n := len(r.calls)
	r.clock.Advance(3600)
	l.decisionLadder() // a stale timer callback after close
	if len(r.calls) != n {
		t.Fatalf("a closed decision still escalated: %v", r.calls[n:])
	}
}

func extRig(t *testing.T) (*rig, *Loop, string) {
	r, l := decisionRig(t)
	led := filepath.Join(t.TempDir(), "escalations.jsonl")
	r.cfg.DecisionLadder = []Rung{{AfterS: 0, Seat: "tern"}, {AfterS: 300, Seat: "tern"},
		{AfterS: 600, Exec: []string{"/x/notify-claude", "decision"}, Ledger: led, LedgerKind: "decision", ResolveCmd: []string{"/x/escalations", "--ack"}}}
	r.cfg.DecisionResponders = []string{"claude"}
	return r, l, led
}

func lkey(kind, text string) string {
	h := md5.Sum([]byte(kind + "\n" + strings.TrimSpace(text)))
	return hex.EncodeToString(h[:])[:12]
}

func addLedger(t *testing.T, path, id, key string, at time.Time) {
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	must(t, err)
	fmt.Fprintf(f, "{\"t\": %d, \"id\": %q, \"kind\": \"decision\", \"key\": %q, \"text\": \"x\"}\n", at.Unix(), id, key)
	f.Close()
}

func execCalls(r *rig, argv0 string) int {
	n := 0
	for _, c := range r.calls {
		for _, a := range c {
			if a == argv0 {
				n++
			}
		}
	}
	return n
}

func TestTheExternalRungNeedsDurableRegistrationAndReraisesOnceWithTheSameKey(t *testing.T) {
	r, l, led := extRig(t)
	defer l.Close()
	r.clock.Advance(1800 + 600)
	l.decisionLadder()
	p := l.Pkg("Q")
	if !strings.HasPrefix(p.Decision.Rungs["2"], "failed") || !strings.Contains(p.Decision.Rungs["2"], "no durable ledger record") {
		t.Fatalf("rc 0 without a ledger record counted as delivered: %q", p.Decision.Rungs["2"])
	}
	l.decisionLadder() // a failed attempt is retried only RungRetryAfter later
	if execCalls(r, "/x/notify-claude") != 1 {
		t.Fatal("a failed rung was retried at once")
	}
	r.clock.Advance(30)
	now, _ := py.Instant(r.clock.Now())
	key := lkey("decision", l.decisionText(p, 2))
	addLedger(t, led, "E-1", key, now)
	l.decisionLadder()
	if !strings.HasPrefix(l.Pkg("Q").Decision.Rungs["2"], "sent") {
		t.Fatalf("registered record not accepted: %q", l.Pkg("Q").Decision.Rungs["2"])
	}
	// No acknowledgement within 15 min: re-raised once, same text (same ledger key).
	n := execCalls(r, "/x/notify-claude")
	r.clock.Advance(15*60 - 1)
	l.decisionLadder()
	if execCalls(r, "/x/notify-claude") != n {
		t.Fatal("re-raised before the response bound")
	}
	r.clock.Advance(1)
	now, _ = py.Instant(r.clock.Now())
	addLedger(t, led, "E-2", key, now)
	l.decisionLadder()
	l.decisionLadder()
	if execCalls(r, "/x/notify-claude") != n+1 || !strings.HasPrefix(l.Pkg("Q").Decision.Reraised, "sent") {
		t.Fatalf("re-raise once: %d, %q", execCalls(r, "/x/notify-claude")-n, l.Pkg("Q").Decision.Reraised)
	}
	// The decision resolves: ONE append-only resolution record for this key and incident.
	must(t, l.Decide("Q", "question_answered", "rec-1", "done"))
	last := r.calls[len(r.calls)-1]
	if execCalls(r, "/x/escalations") != 1 || last[0] != "/x/escalations" || last[2] != key || last[3] != "D-Q-Q-v1" {
		t.Fatalf("resolution call %v, want /x/escalations --ack KEY INCIDENT reason once", last)
	}
}

func TestTheAcknowledgementIsBoundedOnceAndNotADecision(t *testing.T) {
	r, l, led := extRig(t)
	defer l.Close()
	r.clock.Advance(1800 + 600)
	now, _ := py.Instant(r.clock.Now())
	addLedger(t, led, "E-1", lkey("decision", l.decisionText(l.Pkg("Q"), 2)), now)
	l.decisionLadder()
	sec := capSecret(t, l, "claude")
	for _, c := range []struct {
		by, sec, next string
		within        time.Duration
	}{{"mallory", sec, "look", 10 * time.Minute}, {"claude", "", "look", 10 * time.Minute}, {"claude", strings.Repeat("0", 64), "look", 10 * time.Minute},
		{"claude", sec, " ", 10 * time.Minute}, {"claude", sec, "look", 16 * time.Minute}, {"claude", sec, "look", 0}} {
		if _, err := l.DecisionAck("Q", c.by, c.sec, c.next, c.within); err == nil {
			t.Errorf("accepted %+v", c)
		}
	}
	a, err := l.DecisionAck("Q", "claude", sec, "pinged tern", 10*time.Minute)
	must(t, err)
	if l.Pkg("Q").Step != "decision" {
		t.Fatal("an acknowledgement closed the decision")
	}
	if b, err := l.DecisionAck("Q", "claude", sec, "pinged tern", 10*time.Minute); err != nil || b.At != a.At {
		t.Fatalf("replay: %v", err)
	}
	if _, err := l.DecisionAck("Q", "claude", sec, "renew", 15*time.Minute); err == nil || !strings.Contains(err.Error(), "not renewed") {
		t.Fatalf("an acknowledgement was renewed: %v", err)
	}
	if l.Pkg("Q").Decision.Ack == nil || l.Pkg("Q").Decision.Ack.Next != "pinged tern" {
		t.Fatal("a refused renewal disturbed the recorded acknowledgement")
	}
	// The ack's own deadline governs the re-raise.
	n := execCalls(r, "/x/notify-claude")
	r.clock.Advance(10*60 - 1)
	l.decisionLadder()
	if execCalls(r, "/x/notify-claude") != n {
		t.Fatal("re-raised before the ack expired")
	}
	r.clock.Advance(2)
	l.decisionLadder()
	if execCalls(r, "/x/notify-claude") != n+1 {
		t.Fatal("an expired ack did not re-raise")
	}
}

func TestAPackageAlreadyWaitingKeepsItsOriginalDeadline(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	p := l.Pkg("Q")
	p.Decision = nil // as a package that entered decision before P13
	must(t, l.save(p))
	r.clock.Advance(7200)
	l.decisionLadder()
	at, _ := py.Instant(p.StepAt)
	dl, _ := py.Instant(l.Pkg("Q").Decision.Deadline)
	if dl.Sub(at) != 1800*time.Second {
		t.Fatalf("migrated deadline from now, not from entry: %s vs %s", dl, at)
	}
	if !strings.HasPrefix(l.Pkg("Q").Decision.Rungs["0"], "sent") {
		t.Fatal("an overdue migrated decision was not escalated")
	}
}

func TestRunsPassWalksTheLadder(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	n := wakesTo(r, "T")
	r.clock.Advance(1800)
	r.tick(l) // run's pass, not a direct call
	if wakesTo(r, "T") != n+1 {
		t.Fatalf("run's pass did not walk the decision ladder: %v", r.wakesTo("T")[n:])
	}
}

func TestTheOutsideCheckWalksTheLadderWhileRunIsStopped(t *testing.T) {
	r, l := decisionRig(t)
	n := wakesTo(r, "T")
	l.Close() // run is not running: only the outside check (EscalateTimeouts) acts
	r.clock.Advance(1800)
	msgs, err := EscalateTimeouts(r.cfg, r.clock)
	must(t, err)
	if wakesTo(r, "T") != n+1 {
		t.Fatalf("the outside check did not walk the ladder: %v", msgs)
	}
}

func TestACrashBetweenIntentAndSendGetsOneLabelledRepeatNotAStorm(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	r.clock.Advance(1800)
	p := l.Pkg("Q")
	// crash after the intent was persisted and the notice attempt recorded, before its outcome
	p.Decision.Rungs = map[string]string{"0": "intended " + r.clock.Now()}
	must(t, l.save(p))
	crashMidSend(t, l, "decision|"+p.Decision.Incident+"|0", "T", "escalation")
	n := wakesTo(r, "T")
	l.decisionLadder()
	l.decisionLadder()
	w := r.wakesTo("T")[n:]
	if len(w) != 1 || !strings.HasPrefix(w[0], "REPEAT (") {
		t.Fatalf("after a crash: %v (want one labelled repeat)", w)
	}
}

func capSecret(t *testing.T, l *Loop, by string) string {
	b, err := os.ReadFile(l.capPath(l.Pkg("Q"), by))
	must(t, err)
	return strings.TrimSpace(string(b))
}

func TestAReopenNeverMovesTheDecisionDeadline(t *testing.T) {
	r, l := decisionRig(t)
	defer l.Close()
	d := l.Pkg("Q").Decision.Deadline
	r.clock.Advance(900)
	now, _ := py.Instant(r.clock.Now())
	must(t, l.openDecision(l.Pkg("Q"), now)) // a re-entry or re-arm
	if got := l.Pkg("Q").Decision.Deadline; got != d {
		t.Fatalf("deadline moved %s -> %s", d, got)
	}
}

func TestTheCapabilityIsPrivateUnguessableAndIncidentBound(t *testing.T) {
	r, l, led := extRig(t)
	defer l.Close()
	r.clock.Advance(1800 + 600)
	now, _ := py.Instant(r.clock.Now())
	addLedger(t, led, "E-1", lkey("decision", l.decisionText(l.Pkg("Q"), 2)), now)
	l.decisionLadder()
	p := l.Pkg("Q")
	f := l.capPath(p, "claude")
	fi, err := os.Stat(f)
	must(t, err)
	di, _ := os.Stat(filepath.Dir(f))
	if fi.Mode().Perm() != 0o600 || di.Mode().Perm() != 0o700 {
		t.Fatalf("modes file %v dir %v", fi.Mode().Perm(), di.Mode().Perm())
	}
	sec := capSecret(t, l, "claude")
	if len(sec) != 64 || strings.Contains(l.decisionText(p, 2), sec) || !strings.Contains(l.decisionText(p, 2), f) {
		t.Fatal("the notice must name the file, never the secret")
	}
	st, _ := json.Marshal(l.Pkg("Q"))
	if strings.Contains(string(st), sec) {
		t.Fatal("the secret is in the ledger")
	}
	// cross-incident replay: another incident's secret
	p.Decision.Incident = "D-Q-other"
	must(t, l.save(p))
	if _, err := l.DecisionAck("Q", "claude", "", "x", time.Minute); err == nil {
		t.Fatal("empty proof accepted")
	}
	p.Decision.Incident = "D-Q-Q-v1"
	must(t, l.save(p))
	// rotation: after a re-raise the old secret is stale
	r.clock.Advance(15 * 60)
	now, _ = py.Instant(r.clock.Now())
	addLedger(t, led, "E-2", lkey("decision", l.decisionText(l.Pkg("Q"), 2)), now)
	l.decisionLadder()
	if !strings.HasPrefix(l.Pkg("Q").Decision.Reraised, "sent") {
		t.Fatalf("no re-raise: %q", l.Pkg("Q").Decision.Reraised)
	}
	if _, err := l.DecisionAck("Q", "claude", sec, "x", time.Minute); err == nil {
		t.Fatal("a rotated (stale) capability was accepted")
	}
	if _, err := l.DecisionAck("Q", "claude", capSecret(t, l, "claude"), "x", time.Minute); err != nil {
		t.Fatalf("the current capability was refused: %v", err)
	}
	// expired capability
	r2, l2, led2 := extRig(t)
	defer l2.Close()
	r2.clock.Advance(1800 + 600)
	now, _ = py.Instant(r2.clock.Now())
	addLedger(t, led2, "E-1", lkey("decision", l2.decisionText(l2.Pkg("Q"), 2)), now)
	l2.decisionLadder()
	s2 := capSecret(t, l2, "claude")
	p2 := l2.Pkg("Q")
	p2.Decision.Reraised = "sent (test: no re-raise)"
	must(t, l2.save(p2))
	r2.clock.Advance(15*60 + 1)
	if _, err := l2.DecisionAck("Q", "claude", s2, "x", time.Minute); err == nil {
		t.Fatal("an expired capability was accepted")
	}
	// a secret for another incident (l's) is refused on l2's incident
	if _, err := l2.DecisionAck("Q", "claude", capSecret(t, l, "claude"), "x", time.Minute); err == nil {
		t.Fatal("cross-incident capability accepted")
	}
}

func TestAFailingExternalRungIsTriedTwiceThenUnresolvedAndOwned(t *testing.T) {
	r, l, _ := extRig(t)
	defer l.Close()
	r.clock.Advance(1800 + 600)
	n := wakesTo(r, "T")
	for i := 0; i < 10; i++ { // no ledger record ever: every attempt fails
		l.decisionLadder()
		r.clock.Advance(31)
	}
	p := l.Pkg("Q")
	if c := execCalls(r, "/x/notify-claude"); c != 2 || p.Decision.Attempts["2"] != 2 || !strings.HasPrefix(p.Decision.Rungs["2"], "unresolved") {
		t.Fatalf("attempts %d (%v), state %q", c, p.Decision.Attempts, p.Decision.Rungs["2"])
	}
	undelivered := 0
	for _, w := range r.wakesTo("T")[n:] {
		if strings.Contains(w, "DECISION NOTICE UNDELIVERED") {
			undelivered++
		}
	}
	if undelivered != 1 {
		t.Fatalf("director owner notices: %d, want 1", undelivered)
	}
	// a reopen does not reset the count
	l.Close()
	l = r.open()
	l.decisionLadder()
	if execCalls(r, "/x/notify-claude") != 2 {
		t.Fatal("reopen reset the attempt count")
	}
}

func TestAnUncertainExternalAttemptWithADurableRecordIsNotSentAgain(t *testing.T) {
	r, l, led := extRig(t)
	defer l.Close()
	r.clock.Advance(1800 + 600)
	p := l.Pkg("Q")
	// crash after "intended" and after the adapter wrote the ledger, before the outcome
	p.Decision.Rungs = map[string]string{"0": "sent x", "1": "sent x", "2": "intended " + r.clock.Now()}
	p.Decision.Attempts = map[string]int{"2": 1}
	must(t, l.save(p))
	now, _ := py.Instant(r.clock.Now())
	addLedger(t, led, "E-1", lkey("decision", l.decisionText(p, 2)), now)
	r.clock.Advance(5)
	l.decisionLadder()
	if c := execCalls(r, "/x/notify-claude"); c != 0 || !strings.HasPrefix(l.Pkg("Q").Decision.Rungs["2"], "sent") {
		t.Fatalf("resent %d times; state %q", c, l.Pkg("Q").Decision.Rungs["2"])
	}
}

func TestTheDecisionPolicyIsValidated(t *testing.T) {
	base := func() *Config {
		return &Config{Director: "tern", Duty: "corvid", Seats: map[string]string{"tern": "T", "corvid": "C"}}
	}
	full := []Rung{{AfterS: 0, Seat: "tern"}, {AfterS: 300, Seat: "corvid"},
		{AfterS: 600, Exec: []string{"/n", "decision"}, Ledger: "/l.jsonl", LedgerKind: "decision", ResolveCmd: []string{"/r"}}}
	c := base()
	if b := c.validateDecision(); len(b) != 0 {
		t.Fatalf("omitted generic policy refused: %v", b)
	}
	c.DecisionPolicy = "required"
	if len(c.validateDecision()) == 0 {
		t.Fatal("a campaign without its policy was accepted")
	}
	c.DecisionLadder, c.DecisionResponders = full, []string{"claude"}
	if b := c.validateDecision(); len(b) != 0 {
		t.Fatalf("full policy refused: %v", b)
	}
	for name, mut := range map[string]func(c *Config){
		"no responders":   func(c *Config) { c.DecisionResponders = nil },
		"relative exec":   func(c *Config) { c.DecisionLadder[2].Exec = []string{"notify", "x"} },
		"unknown seat":    func(c *Config) { c.DecisionLadder[1].Seat = "ghost" },
		"seat and exec":   func(c *Config) { c.DecisionLadder[0].Exec = []string{"/x"} },
		"out of order":    func(c *Config) { c.DecisionLadder[1].AfterS = -1 },
		"wrong offsets":   func(c *Config) { c.DecisionLadder[2].AfterS = 900 },
		"no resolve":      func(c *Config) { c.DecisionLadder[2].ResolveCmd = nil },
		"ledger no kind":  func(c *Config) { c.DecisionLadder[2].LedgerKind = "" },
		"negative window": func(c *Config) { c.DecisionDeadlineS = -1 },
		"unknown policy":  func(c *Config) { c.DecisionPolicy = "maybe" },
	} {
		c := base()
		c.DecisionPolicy, c.DecisionResponders = "required", []string{"claude"}
		c.DecisionLadder = append([]Rung{}, full...)
		mut(c)
		if len(c.validateDecision()) == 0 {
			t.Errorf("malformed policy accepted: %s", name)
		}
	}
}

func TestLoadConfigRefusesACampaignWithoutItsDecisionPolicy(t *testing.T) {
	r, l := decisionRig(t)
	l.Close()
	c := *r.cfg
	c.DecisionPolicy = "required"
	b, _ := json.Marshal(c)
	f := filepath.Join(t.TempDir(), "c.json")
	must(t, os.WriteFile(f, b, 0o600))
	if _, err := LoadConfig(f); err == nil || !strings.Contains(err.Error(), "decision_policy required") {
		t.Fatalf("campaign config without the policy loaded: %v", err)
	}
}
