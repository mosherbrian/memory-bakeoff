package loop

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// A deadline callback waits DueWait for the ledger lock; if it is still
// busy it writes a due marker (durable detection evidence) and keeps trying
// until DueWindow after it started, settling the marker itself if it gets the
// lock first. Every other holder settles due markers first, oldest first,
// within its hold budget (P12-lock-budget-1). A marker still unsettled after
// SaturationAge is reported to duty as an owned overload (once a minute).
const (
	DueWait       = 8 * time.Second
	DueWindow     = 22 * time.Second
	SaturationAge = 20 * time.Second
)

// DueHint is a deadline callback that could not take the ledger lock. It is
// only a hint: it names an action, and whoever holds the lock next checks it
// against the ledger (current package, action, execution, phase) before
// anything happens. It never extends a deadline or carries authority.
type DueHint struct {
	QID        string `json:"qid"`
	Action     string `json:"action"`
	Execution  string `json:"execution"`
	WrittenAt  string `json:"written_at"`
	PID        int    `json:"pid"`
	Invocation string `json:"invocation,omitempty"` // systemd INVOCATION_ID of the callback unit
}

var dueName = regexp.MustCompile(`^[A-Za-z0-9._-]{1,200}$`)

func dueDir(cfg *Config) string { return cfg.DB + ".due" }

// WriteDue records a due callback atomically (temp file + rename).
func WriteDue(cfg *Config, qid, action, execution string, now time.Time) (string, error) {
	for _, s := range []string{qid, action, execution} {
		if !dueName.MatchString(s) {
			return "", fmt.Errorf("refusing a due marker for unsafe identity %q", s)
		}
	}
	if err := os.MkdirAll(dueDir(cfg), 0o755); err != nil {
		return "", err
	}
	b, _ := json.Marshal(DueHint{QID: qid, Action: action, Execution: execution, WrittenAt: py.ISO(now),
		PID: os.Getpid(), Invocation: os.Getenv("INVOCATION_ID")})
	path := filepath.Join(dueDir(cfg), action+".json")
	tmp := path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o644)
	if err != nil {
		return "", err
	}
	if _, err := f.Write(b); err != nil {
		f.Close()
		return "", err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return "", err
	}
	f.Close()
	return path, os.Rename(tmp, path)
}

// ProcessDue settles every due marker. The caller holds the ledger lock and
// runs it before ordinary work and again before releasing the lock, so due
// deadlines are never starved. A marker is removed only after the deadline
// is settled or explicitly rejected (kept as <name>.rejected-<time>.json
// with the reason); any other failure keeps it for the next holder.
func ProcessDue(cfg *Config) []string {
	acks := processAcks(cfg) // pending acknowledgements first: they are local and bounded
	ents, err := os.ReadDir(dueDir(cfg))
	if err != nil {
		return acks
	}
	var names []string
	for _, e := range ents {
		if n := e.Name(); strings.HasSuffix(n, ".json") && !strings.Contains(n, ".rejected-") && !strings.Contains(n, ".unresolved-") {
			names = append(names, n)
		}
	}
	// Oldest first (by the marker's written_at), so a backlog drains in order.
	written := map[string]string{}
	for _, n := range names {
		var h DueHint
		if b, err := os.ReadFile(filepath.Join(dueDir(cfg), n)); err == nil && json.Unmarshal(b, &h) == nil {
			written[n] = h.WrittenAt
		}
	}
	sort.Slice(names, func(i, j int) bool {
		if written[names[i]] != written[names[j]] {
			return written[names[i]] < written[names[j]]
		}
		return names[i] < names[j]
	})
	var out []string
	for _, n := range names {
		if budgetShort(cfg) {
			out = append(out, "due: lock budget spent; remaining markers go to the next holder")
			break
		}
		path := filepath.Join(dueDir(cfg), n)
		reject := func(why string) {
			os.Rename(path, strings.TrimSuffix(path, ".json")+".rejected-"+time.Now().UTC().Format("20060102T150405Z")+".json")
			out = append(out, "due "+n+": REJECTED: "+why)
		}
		var h DueHint
		b, err := os.ReadFile(path)
		if err != nil || json.Unmarshal(b, &h) != nil {
			reject("unreadable or malformed marker")
			continue
		}
		if !dueName.MatchString(h.QID) || !dueName.MatchString(h.Action) || !dueName.MatchString(h.Execution) || n != h.Action+".json" {
			reject("identity does not match the marker name or is unsafe")
			continue
		}
		decision, note, err := RunDeadline(cfg, h.QID, h.Action, h.Execution, h.WrittenAt)
		switch {
		case err == nil && (decision == "interrupted" || decision == "recovered" || decision == "already-handled" || decision == "interrupted-effect-failed"):
			os.Remove(path)
			out = append(out, fmt.Sprintf("due %s: settled (%s) %s", n, decision, note))
		case err == nil && strings.HasPrefix(decision, "no-op") && decision != "no-op-early":
			reject("the ledger no longer has this deadline due (" + decision + ")")
		case err == nil && decision == "no-op-early":
			os.Remove(path) // re-armed at the original deadline by RunDeadline
			out = append(out, "due "+n+": early, re-armed: "+note)
		case decision == "interrupted-effect-failed" && err != nil && strings.Contains(err.Error(), "E_DELIVERY_UNRESOLVED"):
			// Settled with an owned failure (the director/duty notice of the
			// failed settlement was attempted): the notice's delivery stays
			// unknown and visible; the marker is kept aside, not retried forever.
			os.Rename(path, strings.TrimSuffix(path, ".json")+".unresolved-"+time.Now().UTC().Format("20060102T150405Z")+".json")
			out = append(out, fmt.Sprintf("due %s: settled with an owned delivery failure: %s (%v)", n, note, err))
		default:
			if f, ok := host.IsFault(err); ok && strings.HasPrefix(f.Code, "E_") && f.Code != "E_LEDGER_BUSY" && isIdentityFault(f.Code) {
				reject(f.Code + ": " + f.Detail)
				continue
			}
			out = append(out, fmt.Sprintf("due %s: kept for the next holder: %s %v", n, decision, err))
		}
	}
	return append(append(acks, out...), reportSaturation(cfg)...)
}

func isIdentityFault(code string) bool {
	switch code {
	case "E_UNKNOWN_PACKAGE", "E_ACTION_MISMATCH", "E_EXECUTION_MISMATCH", "E_SUPERSEDED_ACTION", "E_NO_EXECUTION_AUTHORITY", "E_NO_IDENTITY":
		return true
	}
	return false
}

// RunDeadline runs one deadline callback while the caller holds the ledger
// lock: the core's deadline handling, then the loop's settlement record, the
// re-arm of an early callback, or the owned settlement of a failed effect.
// deferredAt, when set, is the due marker's written_at (detection evidence).
func RunDeadline(cfg *Config, qid, action, execution, deferredAt string) (string, string, error) {
	out, err := TimerCallback(cfg, qid, action, execution)
	if err != nil {
		l, oerr := Open(cfg, nil)
		if oerr != nil {
			return "", "", err
		}
		defer l.Close()
		msg, serr := l.SettleTimeoutFailure(qid, action, err)
		if serr != nil {
			return "", "", err
		}
		l.noteDeferred(qid, action, deferredAt)
		return "interrupted-effect-failed", msg, err
	}
	d := py.S(out.Get("decision"))
	l, oerr := Open(cfg, nil)
	if oerr != nil {
		return d, "", oerr
	}
	defer l.Close()
	switch d {
	case "no-op-early":
		note, err := l.RearmEarly(qid, action, execution)
		return d, note, err
	case "interrupted", "recovered", "already-handled":
		if err := l.MarkTimedOut(qid, action); err != nil {
			return d, "", err
		}
		l.noteDeferred(qid, action, deferredAt)
	}
	return d, py.Dumps(out), nil
}

// noteDeferred records when a busy callback left its due marker.
func (l *Loop) noteDeferred(qid, action, at string) {
	if at == "" {
		return
	}
	if p := l.Pkg(qid); p != nil && p.Timeout != nil && p.Timeout.Action == action && p.Timeout.Deferred == "" {
		p.Timeout.Deferred = at
		l.save(p)
	}
}

// reportSaturation tells duty (at most once a minute) when due markers have
// waited longer than SaturationAge: the deadline load exceeds what the
// holders settle within their budgets. It is reported, never dropped.
func reportSaturation(cfg *Config) []string {
	ents, err := os.ReadDir(dueDir(cfg))
	if err != nil {
		return nil
	}
	now := time.Now().UTC()
	n, oldest := 0, time.Duration(0)
	for _, e := range ents {
		if !strings.HasSuffix(e.Name(), ".json") || strings.Contains(e.Name(), ".rejected-") || strings.Contains(e.Name(), ".unresolved-") {
			continue
		}
		var h DueHint
		b, err := os.ReadFile(filepath.Join(dueDir(cfg), e.Name()))
		if err != nil || json.Unmarshal(b, &h) != nil {
			continue
		}
		if at, ok := py.Instant(h.WrittenAt); ok && now.Sub(at) > SaturationAge {
			n++
			if now.Sub(at) > oldest {
				oldest = now.Sub(at)
			}
		}
	}
	if n == 0 {
		return nil
	}
	msg := fmt.Sprintf("due backlog SATURATED: %d deadline marker(s) unsettled for more than %s (oldest %s)", n, SaturationAge, oldest.Round(time.Second))
	stamp := filepath.Join(dueDir(cfg), ".saturation-reported")
	if fi, err := os.Stat(stamp); err == nil && now.Sub(fi.ModTime()) < time.Minute {
		return []string{msg + " (duty's wake accepted within the last minute)"}
	}
	run := cfg.Run
	if run == nil {
		run = host.ExecRunner
	}
	// Only the wake's own "started" (rc 0) or "queued" (rc 3) is an accepted
	// send (P12-realprocess-1 D1: a nil runner error with rc 1 is a refusal).
	// Accepted is transport only, never an acknowledgement. A refused, failed
	// or not-started send is kept in .saturation-attempts and retried by the
	// next holder; the stamp that suppresses reports for a minute is written
	// only after an accepted send, and a stamp that cannot be written says so.
	p, err := run([]string{cfg.Wake, cfg.Seats[cfg.Duty], "[agent-loop] " + msg + ". See: agent-loop status --config " + cfg.Path},
		[]string{"AGENTDECK_PROFILE=" + cfg.Profile}, 10*time.Second)
	outcome := fmt.Sprintf("rc %d", p.RC)
	if err != nil {
		outcome = "error: " + err.Error()
	}
	accepted := err == nil && (p.RC == host.WakeRCSent || p.RC == host.WakeRCQueued)
	if f, ferr := os.OpenFile(filepath.Join(dueDir(cfg), ".saturation-attempts"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644); ferr == nil {
		fmt.Fprintf(f, "%s accepted=%t %s\n", py.ISO(now), accepted, outcome)
		f.Close()
	}
	if !accepted {
		return []string{msg + " (report to duty NOT accepted: " + outcome + "; the next holder retries)"}
	}
	if err := os.WriteFile(stamp, []byte(py.ISO(now)), 0o644); err != nil {
		return []string{msg + " (duty's wake accepted; the suppression stamp was NOT written: " + err.Error() + "; the next holder reports again)"}
	}
	return []string{msg + " (duty's wake accepted, transport only: not an acknowledgement)"}
}
