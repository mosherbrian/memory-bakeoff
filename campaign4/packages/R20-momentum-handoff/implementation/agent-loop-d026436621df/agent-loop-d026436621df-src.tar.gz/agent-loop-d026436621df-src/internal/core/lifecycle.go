package core

import (
	"regexp"
	"strconv"
	"strings"
	"time"

	"agent-loop/internal/py"
)

// Deterministic lifecycle transition core. Pure: no I/O, no clock reads.
// Every rejection fails closed with a deterministic code.

var States = []string{"DRAFT", "ADMITTED", "REGISTERED", "RUNNING", "CHECKING",
	"REPAIR_ALLOWED", "BLOCKED"}
var Terminals = []string{"COMPLETE", "EXHAUSTED", "TERMINATED", "SUPERSEDED"}

func isTerminal(phase any) bool { return in(phase, Terminals...) }

func in(v any, xs ...string) bool {
	s, ok := v.(string)
	if !ok {
		return false
	}
	for _, x := range xs {
		if s == x {
			return true
		}
	}
	return false
}

// Permitted maps event type -> roles that may emit it.
var Permitted = map[string][]string{
	"admit": {"reader"}, "reject": {"reader"},
	"authorize": {"director", "duty"},
	"start":     {"duty"}, "alloc_repair": {"duty"},
	"publish":     {"worker"},
	"verify_pass": {"verifier"}, "verify_fail": {"verifier"},
	"accept": {"director"}, "withhold": {"director"},
	"interrupt": {"duty", "director"},
	"resolve":   {"duty", "director"}, "defer": {"duty", "director"},
	"terminate": {"duty", "director"}, "exhaust": {"duty", "director"},
	"amend":  {"director"},
	"decide": {"director"}, "decision_task": {"duty", "director"},
	"recover": {"duty"},
}

// HardRecoveryMaxS is the 10-minute per-pass controller-recovery ceiling.
const HardRecoveryMaxS = 600

func passes(budget *py.Dict) (int64, int64, error) {
	var p *py.Dict
	if budget != nil {
		p = py.AsDict(budget.GetOr("passes", py.NewDict()))
	}
	if !py.Truthy(p) {
		p = py.NewDict()
	}
	v, ok1 := pyInt(py.AsDict(p.GetOr("verify", py.NewDict())).GetOr("max_s", int64(1800)))
	r, ok2 := pyInt(py.AsDict(p.GetOr("controller_recovery", py.NewDict())).GetOr("max_s", int64(HardRecoveryMaxS)))
	if !ok1 || !ok2 {
		return 0, 0, terr("E_BAD_ALLOCATION", "passes ceilings malformed")
	}
	if v <= 0 || r <= 0 {
		return 0, 0, terr("E_BAD_ALLOCATION", "passes ceilings positive")
	}
	return v, r, nil
}

// pyInt is Python int(x) for the inputs a budget can hold.
func pyInt(v any) (int64, bool) {
	if i, ok := py.Int(v); ok {
		return i, true
	}
	switch x := v.(type) {
	case float64:
		if x != x || x > 9.2e18 || x < -9.2e18 {
			return 0, false
		}
		return int64(x), true
	case string:
		return parseIntPy(x)
	}
	return 0, false
}

func checkVerifierSpend(event, budget *py.Dict) error {
	vmax, _, err := passes(budget)
	if err != nil {
		return err
	}
	el, ok := py.Int(event.Get("elapsed_s"))
	if !ok || el < 0 {
		return terr("E_BAD_ALLOCATION", "verifier events need integer elapsed_s")
	}
	capv := event.GetOr("pass_budget_s", budget.GetOr("verifier_s", int64(1800)))
	c, ok := py.Int(capv)
	if !ok || c <= 0 {
		return terr("E_BAD_ALLOCATION", "pass_budget_s malformed")
	}
	if c > vmax {
		return terr("E_ALLOC_EXCEEDED", "pass budget exceeds per-pass ceiling")
	}
	if el > c {
		return terr("E_ALLOC_EXCEEDED", "verifier pass spent beyond its budget")
	}
	return nil
}

func checkGrant(value any, budget *py.Dict) (int64, error) {
	vmax, _, err := passes(budget)
	if err != nil {
		return 0, err
	}
	d, ok := value.(*py.Dict)
	if !ok {
		return 0, terr("E_BAD_ALLOCATION", "new_allocation must be an allocation object, not free-form")
	}
	g, ok := py.Int(d.Get("grant_s"))
	if !ok || g <= 0 {
		return 0, terr("E_BAD_ALLOCATION", "grant_s positive integer")
	}
	if !py.Eq(d.Get("granted_by"), "tern") {
		return 0, terr("E_BAD_ALLOCATION", "grants require an attributed director decision")
	}
	if g > vmax {
		return 0, terr("E_ALLOC_EXCEEDED", "grant exceeds per-pass ceiling")
	}
	return g, nil
}

// requireDistinctVerifier: the author is not the verifier (R13, finding 11).
// Identity is the seat alone, so relabelling a role cannot defeat it, and a
// missing producer fails closed.
func requireDistinctVerifier(st, event *py.Dict) error {
	producer := st.Get("producer_seat")
	if producer == nil {
		return terr("E_UNKNOWN_PRODUCER", "no authentic producer identity for this attempt; verdict refused")
	}
	if py.Eq(actorOf(event).Get("seat"), producer) {
		return terr("E_SELF_VERIFY", "producer may not verify own artifacts")
	}
	return nil
}

var strictRE = regexp.MustCompile(`^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(\.\d+)?(Z|[+-]\d{2}:?\d{2})?$`)

// strictInstant is lifecycle._parse_instant: an aware UTC instant with an
// optional fraction; a value with no zone is refused.
func strictInstant(v any) (time.Time, bool) {
	s, ok := v.(string)
	if !ok {
		return time.Time{}, false
	}
	m := strictRE.FindStringSubmatch(strings.TrimSpace(s))
	if m == nil || m[8] == "" {
		return time.Time{}, false
	}
	usec := 0
	if m[7] != "" {
		f, _ := strconv.ParseFloat("0"+m[7], 64)
		usec = int(f * 1000000)
	}
	n := func(i int) int { x, _ := strconv.Atoi(m[i]); return x }
	y, mo, d, h, mi, se := n(1), n(2), n(3), n(4), n(5), n(6)
	if y < 1 || mo < 1 || mo > 12 || d < 1 ||
		d > time.Date(y, time.Month(mo)+1, 0, 0, 0, 0, 0, time.UTC).Day() ||
		h > 23 || mi > 59 || se > 59 {
		return time.Time{}, false
	}
	t := time.Date(y, time.Month(mo), d, h, mi, se, usec*1000, time.UTC)
	if zone := m[8]; zone != "Z" {
		digits := strings.ReplaceAll(zone[1:], ":", "")
		if len(digits) != 4 {
			return time.Time{}, false
		}
		oh, _ := strconv.Atoi(digits[:2])
		om, _ := strconv.Atoi(digits[2:])
		if oh > 23 || om > 59 {
			return time.Time{}, false
		}
		off := time.Duration(oh)*time.Hour + time.Duration(om)*time.Minute
		if zone[0] == '+' {
			t = t.Add(-off)
		} else {
			t = t.Add(off)
		}
		if t.Year() < 1 || t.Year() > 9999 {
			return time.Time{}, false
		}
	}
	return t, true
}

// NewRevision is the initial per-revision lifecycle record.
func NewRevision(questionID any) *py.Dict {
	return py.D(
		"question_id", questionID,
		"revision", int64(1),
		"phase", "DRAFT",
		"attempt", int64(0),
		"repair_used", false,
		"blocked", nil,
		"verdict", nil,
		"decision_task", nil,
		"disposition", nil,
		"flight", nil,
		"producer_seat", nil, // the seat that published the current attempt (R13, finding 11)
		"handoff", nil,
		"history", []any{},
	)
}

func actorOf(event *py.Dict) *py.Dict {
	if a := py.AsDict(event.Get("actor")); a != nil {
		return a
	}
	return py.NewDict()
}

func requireRole(event *py.Dict) error {
	typ, _ := event.Get("type").(string)
	allowed, ok := Permitted[typ]
	if !ok {
		t := event.GetOr("type", "?")
		return terr("E_UNKNOWN_EVENT", t)
	}
	role := actorOf(event).Get("role")
	if !in(role, allowed...) {
		return terr("E_UNAUTHORIZED", py.S(role)+" may not emit "+typ)
	}
	return nil
}

// Apply applies one event and returns (new state, outcome). The input
// state is never modified.
func Apply(state, event *py.Dict, now any, budget *py.Dict) (*py.Dict, string, error) {
	if err := requireRole(event); err != nil {
		return nil, "", err
	}
	st := state.Copy()
	hist := append([]any(nil), asList(st.Get("history"))...)
	typ := event.Get("type").(string)
	phase := st.Get("phase")
	record := func(outcome string) (*py.Dict, string, error) {
		hist = append(hist, event.Get("event_id"))
		st.Set("history", hist)
		return st, outcome, nil
	}
	fail := func(code string, detail any) (*py.Dict, string, error) {
		return nil, "", terr(code, detail)
	}

	if isTerminal(phase) && !in(typ, "amend", "decide", "decision_task") {
		return fail("E_TERMINAL", phase)
	}
	switch typ {
	case "admit":
		if !py.Eq(phase, "DRAFT") {
			return fail("E_BAD_TRANSITION", typ)
		}
		st.Set("phase", "ADMITTED")
		return record("admitted")
	case "reject":
		if !py.Eq(phase, "DRAFT") {
			return fail("E_BAD_TRANSITION", typ)
		}
		return record("rejected-bounded")
	case "authorize":
		if !py.Eq(phase, "ADMITTED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		st.Set("phase", "REGISTERED")
		return record("registered")
	case "start":
		if py.Eq(phase, "REGISTERED") {
			att, _ := py.Num(st.Get("attempt"))
			lim, _ := py.Num(budget.Get("attempts"))
			if att >= lim {
				return fail("E_NO_ALLOCATION", "attempts spent")
			}
			if event.Get("deadline") == nil {
				return fail("E_NO_DEADLINE", "start needs deadline")
			}
			st.Set("attempt", incr(st.Get("attempt")))
			st.Set("phase", "RUNNING")
			st.Set("deadline", event.Get("deadline"))
			st.Set("flight", py.D("action_id", event.Get("action_id"),
				"owner", actorOf(event).Get("seat"),
				"deadline", event.Get("deadline")))
			st.Set("handoff", nil)
			return record("running")
		}
		if py.Eq(phase, "REPAIR_ALLOWED") {
			st.Set("attempt", incr(st.Get("attempt")))
			st.Set("phase", "RUNNING")
			st.Set("deadline", event.Get("deadline"))
			if st.Get("deadline") == nil {
				return fail("E_NO_DEADLINE", "repair needs deadline")
			}
			return record("running-repair")
		}
		return fail("E_BAD_TRANSITION", typ)
	case "publish":
		if !py.Eq(phase, "RUNNING") {
			return fail("E_BAD_TRANSITION", typ)
		}
		// Deadlines compare as validated instants, never as text (R13,
		// finding 10). Strictly after expires; equal does not.
		nowI, ok1 := strictInstant(now)
		dlI, ok2 := strictInstant(st.Get("deadline"))
		if !ok1 || !ok2 {
			return fail("E_BAD_DEADLINE", "publish needs valid aware instants")
		}
		if nowI.After(dlI) {
			return fail("E_DEADLINE_EXPIRED", "publish after deadline")
		}
		if !py.Truthy(event.Get("artifact_hashes")) {
			return fail("E_MISSING_ARTIFACTS", "no hashes")
		}
		st.Set("flight", nil)
		st.Set("handoff", nil)
		if v := event.Get("verify"); v != nil {
			vd, ok := v.(*py.Dict)
			if !ok || !py.Truthy(vd.Get("action_id")) || !py.Truthy(vd.Get("owner")) ||
				!py.Truthy(vd.Get("deadline")) {
				return fail("E_BAD_ALLOCATION", "verify needs action_id/owner/deadline")
			}
			st.Set("flight", py.D("action_id", vd.Get("action_id"),
				"owner", vd.Get("owner"), "deadline", vd.Get("deadline")))
		} else {
			hd := event.Get("handoff_deadline")
			ho := event.GetOr("handoff_owner", "duty")
			if !py.Truthy(hd) || !in(ho, "duty", "director") {
				return fail("E_BAD_ALLOCATION",
					"publication without a dispatched verifier needs an explicitly owned (duty/director) bounded handoff")
			}
			st.Set("handoff", py.D("owner", ho, "deadline", hd))
		}
		st.Set("phase", "CHECKING")
		st.Set("published", event.Get("artifact_hashes"))
		// The producer binds here, from the trusted actor of the publish;
		// a caller-supplied worker_seat is never consulted.
		st.Set("producer_seat", actorOf(event).Get("seat"))
		return record("checking")
	case "verify_pass", "verify_fail":
		if !py.Eq(phase, "CHECKING") {
			return fail("E_BAD_TRANSITION", typ)
		}
		if err := requireDistinctVerifier(st, event); err != nil {
			return nil, "", err
		}
		if err := checkVerifierSpend(event, budget); err != nil {
			return nil, "", err
		}
		if typ == "verify_pass" {
			st.Set("verdict", "COMPLETE")
			st.Set("finding", event.GetOr("finding", "positive"))
			st.Set("phase", "COMPLETE")
			return record("complete")
		}
		if py.Truthy(event.Get("eligible_repair")) && !py.Truthy(st.Get("repair_used")) {
			st.Set("phase", "REPAIR_ALLOWED")
			return record("repair-allowed")
		}
		st.Set("verdict", "EXHAUSTED")
		st.Set("why_ended", event.GetOr("reason", "failed-verification-no-allocation"))
		st.Set("phase", "EXHAUSTED")
		return record("exhausted")
	case "accept":
		if !py.Eq(phase, "COMPLETE") {
			return fail("E_BAD_TRANSITION", typ)
		}
		return record("accepted")
	case "withhold":
		if !in(phase, "COMPLETE", "CHECKING") {
			return fail("E_BAD_TRANSITION", typ)
		}
		st.Set("verdict", "EXHAUSTED")
		st.Set("why_ended", event.GetOr("reason", "acceptance-withheld"))
		st.Set("phase", "EXHAUSTED")
		return record("exhausted")
	case "alloc_repair":
		if !py.Eq(phase, "REPAIR_ALLOWED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		if py.Truthy(st.Get("repair_used")) {
			return fail("E_NO_ALLOCATION", "repair already spent")
		}
		st.Set("repair_used", true)
		return record("repair-allocated")
	case "interrupt":
		if !in(phase, "RUNNING", "CHECKING") {
			return fail("E_BAD_TRANSITION", typ)
		}
		st.Set("blocked", py.D("phase", phase, "attempt", st.Get("attempt"),
			"remaining_verifier_s", event.Get("remaining_verifier_s")))
		st.Set("block_reason", event.GetOr("reason", "interrupted"))
		st.Set("phase", "BLOCKED")
		return record("blocked")
	case "resolve":
		if !py.Eq(phase, "BLOCKED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		blk := py.AsDict(st.Get("blocked"))
		if !py.Truthy(blk) {
			blk = py.NewDict()
		}
		origin := blk.GetOr("phase", "RUNNING")
		switch {
		case py.Eq(origin, "CHECKING"):
			rem := blk.Get("remaining_verifier_s")
			if rem != nil {
				le, err := pyLessEq(rem, int64(0))
				if err != nil {
					return nil, "", err
				}
				if le && !py.Truthy(event.Get("new_allocation")) {
					return fail("E_NO_ALLOCATION", "expired verification needs a grant")
				}
			}
			if event.Get("new_allocation") != nil {
				g, err := checkGrant(event.Get("new_allocation"), budget)
				if err != nil {
					return nil, "", err
				}
				st.Set("remaining_verifier_s", g)
			}
			st.Set("phase", "CHECKING")
		case py.Eq(origin, "RUNNING"):
			st.Set("phase", "RUNNING")
		default:
			st.Set("phase", "REGISTERED")
		}
		st.Set("blocked", nil)
		return record("resumed-" + lower(st.Get("phase").(string)))
	case "defer":
		if !py.Eq(phase, "BLOCKED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		return record("deferred-owned")
	case "terminate":
		if !py.Eq(phase, "BLOCKED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		st.Set("verdict", "TERMINATED")
		st.Set("phase", "TERMINATED")
		return record("terminated")
	case "exhaust":
		if !py.Eq(phase, "BLOCKED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		st.Set("verdict", "EXHAUSTED")
		st.Set("why_ended", event.GetOr("reason", "budget-spent"))
		st.Set("phase", "EXHAUSTED")
		return record("exhausted")
	case "recover":
		if !py.Eq(phase, "BLOCKED") {
			return fail("E_BAD_TRANSITION", typ)
		}
		el, ok1 := py.Int(event.Get("elapsed_s"))
		c, ok2 := py.Int(event.Get("pass_budget_s"))
		if !ok1 || el < 0 || !ok2 || c <= 0 {
			return fail("E_BAD_ALLOCATION", "recover needs integer elapsed_s and pass_budget_s")
		}
		if c > HardRecoveryMaxS {
			return fail("E_ALLOC_EXCEEDED",
				"controller-recovery pass budget exceeds the 10-minute per-pass ceiling; no cumulative ceiling overrides it")
		}
		if el > c {
			return fail("E_ALLOC_EXCEEDED", "recovery pass spent beyond its budget")
		}
		return record("recovery-recorded")
	case "amend":
		st.Set("phase", "SUPERSEDED")
		st.Set("superseded_by", event.Get("new_revision"))
		return record("superseded")
	case "decision_task":
		if !isTerminal(phase) {
			return fail("E_BAD_TRANSITION", typ+" before verdict")
		}
		if st.Get("disposition") != nil {
			return fail("E_BAD_TRANSITION", "already closed")
		}
		st.Set("decision_task", py.D("task_id", event.Get("event_id"),
			"owner", "director", "deadline", event.Get("deadline")))
		return record("decision-pending")
	case "decide":
		if !isTerminal(phase) {
			return fail("E_BAD_TRANSITION", typ+" before verdict")
		}
		// The first disposition is final (R13, finding 6).
		if st.Get("disposition") != nil {
			return fail("E_ALREADY_DECIDED", "terminal disposition immutable; distinct later decide rejected")
		}
		disp := py.AsDict(event.Get("disposition"))
		if !py.Truthy(disp) {
			disp = py.NewDict()
		}
		if !in(disp.Get("kind"), "successor_opened", "question_answered", "budget_spent", "blocked") {
			return fail("E_MISSING_DISPOSITION", "enumerable kind?")
		}
		for _, f := range []string{"decision_ref", "reason"} {
			if s, ok := disp.Get(f).(string); !ok || s == "" {
				return fail("E_MISSING_DISPOSITION", "attributed decision needs "+f)
			}
		}
		st.Set("disposition", disp)
		st.Set("decision_task", nil)
		return record("closed-" + disp.Get("kind").(string))
	}
	return fail("E_UNKNOWN_EVENT", typ)
}
