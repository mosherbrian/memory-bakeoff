package host

import (
	"encoding/binary"
	"syscall"
	"time"
)

// DirNotifier watches a directory with inotify. Attach it BEFORE the
// first drain: events that exist at start are then seen once by that
// drain. It is a trigger, never a periodic poll; the durable cursors and
// seen sets reconcile overflow, truncation and restart.
type DirNotifier struct {
	Path      string
	fd        int
	closed    bool
	Overflows int
}

const subscribeMask = syscall.IN_CLOSE_WRITE | syscall.IN_MOVED_TO | syscall.IN_CREATE |
	syscall.IN_DELETE | syscall.IN_Q_OVERFLOW

// NewDirNotifier attaches to path, or returns E_NO_NOTIFY.
func NewDirNotifier(path string) (*DirNotifier, error) {
	fd, err := syscall.InotifyInit1(syscall.IN_NONBLOCK | syscall.IN_CLOEXEC)
	if err != nil || fd < 0 {
		return nil, fault("E_NO_NOTIFY", "inotify unavailable on this host")
	}
	if _, err := syscall.InotifyAddWatch(fd, path, subscribeMask); err != nil {
		syscall.Close(fd)
		return nil, fault("E_NO_NOTIFY", "cannot watch "+path)
	}
	return &DirNotifier{Path: path, fd: fd}, nil
}

// Wait blocks until a change event (true), the timeout (false), or
// closure (E_WATCHER_CLOSED).
func (n *DirNotifier) Wait(timeout time.Duration) (bool, error) {
	if n.closed {
		return false, fault("E_WATCHER_CLOSED", "notifier closed")
	}
	if timeout < 0 {
		timeout = 0
	}
	var set syscall.FdSet
	set.Bits[n.fd/64] |= 1 << (uint(n.fd) % 64)
	tv := syscall.NsecToTimeval(timeout.Nanoseconds())
	ready, err := syscall.Select(n.fd+1, &set, nil, nil, &tv)
	if err == syscall.EINTR || ready <= 0 {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	buf := make([]byte, 65536)
	got, err := syscall.Read(n.fd, buf)
	if err == syscall.EAGAIN {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	overflow := false
	for off := 0; off+16 <= got; {
		mask := binary.LittleEndian.Uint32(buf[off+4:])
		size := binary.LittleEndian.Uint32(buf[off+12:])
		off += 16 + int(size)
		if mask&syscall.IN_Q_OVERFLOW != 0 {
			overflow = true
		}
	}
	if overflow {
		n.Overflows++
	}
	return true, nil
}

// Close releases the descriptor.
func (n *DirNotifier) Close() error {
	if !n.closed {
		n.closed = true
		return syscall.Close(n.fd)
	}
	return nil
}
