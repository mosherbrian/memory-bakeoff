package host

import (
	"crypto/sha256"
	"encoding/hex"
	"sort"
	"strconv"
	"strings"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// FutureSkewToleranceS is the ingress tolerance for caller occurrence times.
const FutureSkewToleranceS = core.FutureSkewToleranceS

// Adapter is the narrow machinery over a core Driver: receipts, declared
// execution identity, routes, turn bindings, the durable outbox, timers
// and bounded escalation.
type Adapter struct {
	Driver      *core.Driver
	Transport   Transport
	Timers      *Timers
	Live        bool
	Cursor      any
	Escalations []*py.Dict
	// Director is the transport address escalations go to ("tern" when
	// empty, as in the reference).
	Director string
}

func (a *Adapter) director() string {
	if a.Director != "" {
		return a.Director
	}
	return "tern"
}

// NewAdapter builds an adapter. Live mode refuses a fake or missing
// transport: no fake defaults on the live path.
func NewAdapter(d *core.Driver, transport Transport, timers *Timers, live bool) (*Adapter, error) {
	if _, fake := transport.(*FakeTransport); live && fake {
		return nil, fault("E_DISABLED", "no fake defaults in live mode")
	}
	if live && transport == nil {
		return nil, fault("E_DISABLED", "live mode needs an explicit transport")
	}
	if transport == nil {
		transport = NewFakeTransport()
	}
	if timers == nil {
		timers = NewTimers(DriverKV(d))
	}
	a := &Adapter{Driver: d, Transport: transport, Timers: timers, Live: live}
	if v, ok := d.KV["host-cursor"]; ok {
		a.Cursor = v
	}
	return a, nil
}

func (a *Adapter) kv(k string) (string, bool) { v, ok := a.Driver.KV[k]; return v, ok }
func (a *Adapter) put(k, v string) error      { return a.Driver.KVPut(k, v) }
func (a *Adapter) putMany(p ...[2]string) error {
	return a.Driver.KVPutMany(p)
}

// keys returns the kv keys in sorted order. (Python iterates its dict in
// load order, which a reopen changes anyway; no result depends on it.)
func (a *Adapter) keys() []string {
	ks := make([]string, 0, len(a.Driver.KV))
	for k := range a.Driver.KV {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

// TrustedNow is the clock's UTC now.
func (a *Adapter) TrustedNow() string { return a.Driver.Clock.UtcNow() }

// Capture persists a source receipt stamped with TRUSTED receipt time.
// Caller occurrence is kept separately and never replaces it. A
// conflicting re-capture is refused; an identical one dedups.
func (a *Adapter) Capture(pkg, attempt, action, event, execution string, outcome any,
	occurredAt any, provenance any) (py.Tuple, error) {
	recorded, _ := py.Instant(a.TrustedNow())
	var occurred any
	var skew any
	if occurredAt != nil {
		o, ok := py.Instant(occurredAt)
		if !ok {
			return nil, fault("E_BAD_OCCURRED", "occurrence not a UTC instant")
		}
		occurred = py.ISO(o)
		s := o.Sub(recorded).Seconds()
		skew = s
		if s > FutureSkewToleranceS {
			return nil, fault("E_SKEW_EXCEEDED", "occurrence "+strconv.FormatFloat(s, 'f', 0, 64)+"s beyond tolerance")
		}
	}
	key := "receipt:" + pkg + ":" + attempt + ":" + action + ":" + event + ":" + execution
	if old, ok := a.kv(key); ok {
		if !py.Eq(loadDict(old).Get("outcome"), outcome) {
			return nil, fault("E_CONFLICT", "conflicting re-capture; identity kept")
		}
		return py.T(key, true), nil
	}
	if err := a.putMany([2]string{key, py.Dumps(py.D("package", pkg, "attempt", attempt,
		"action", action, "event", event, "execution", execution, "outcome", outcome,
		"receipt_at_utc", py.ISO(recorded), "occurred_at", occurred,
		"provenance", provenance, "skew_s", skew))}, [2]string{"host-cursor", event}); err != nil {
		return nil, err
	}
	a.Cursor = event
	return py.T(key, false), nil
}

// Receipt reads a captured receipt, or nil.
func (a *Adapter) Receipt(pkg, attempt, action, event, execution string) any {
	raw, ok := a.kv("receipt:" + pkg + ":" + attempt + ":" + action + ":" + event + ":" + execution)
	if !ok || raw == "" {
		return nil
	}
	return loadDict(raw)
}

// Trail correlates dispatch -> artifacts -> outcome for one action.
func (a *Adapter) Trail(action string) *py.Dict {
	execs := py.NewDict()
	var receipts, applied, stale []any
	for _, k := range a.keys() {
		v := a.Driver.KV[k]
		switch {
		case strings.HasPrefix(k, "exec:"+action+":"):
			execs.Set(k, loadDict(v))
		case strings.HasPrefix(k, "receipt:") && strings.Contains(k, ":"+action+":"):
			receipts = append(receipts, loadDict(v))
		case strings.HasPrefix(k, "applied:"+action+":"):
			applied = append(applied, loadDict(v))
		case strings.HasPrefix(k, "stale:"+action+":"):
			stale = append(stale, loadDict(v))
		}
	}
	return py.D("action", action, "executions", execs, "receipts", nonNil(receipts),
		"applied", nonNil(applied), "stale", nonNil(stale))
}

func nonNil(xs []any) []any {
	if xs == nil {
		return []any{}
	}
	return xs
}

// BoundArtifacts are the artifact names and hashes bound at dispatch,
// sorted (Python returns a set).
func (a *Adapter) BoundArtifacts(action string) []any {
	arts := py.AsDict(py.AsDict(a.Driver.World.State.GetOr(action, py.NewDict())).GetOr("artifacts", py.NewDict()))
	seen := map[string]bool{}
	if arts != nil {
		for _, k := range arts.Keys() {
			seen[k] = true
			seen[py.S(arts.Get(k))] = true
		}
	}
	return py.SortedStrings(seen)
}

// BindRoute records the contract-bound seat for an action.
func (a *Adapter) BindRoute(action, seat string) (string, error) {
	return seat, a.put("route:"+action, seat)
}

// RouteFor is the bound seat, or E_UNROUTED.
func (a *Adapter) RouteFor(action string) (string, error) {
	seat, _ := a.kv("route:" + action)
	if seat == "" {
		return "", fault("E_UNROUTED", "no contract-bound seat for "+action)
	}
	return seat, nil
}

// BindTurn records that this stream item is this execution's turn.
func (a *Adapter) BindTurn(streamKey string, item any, execution, action, step string) error {
	return a.put("turn-bind:"+streamKey+":"+py.S(item), py.Dumps(py.D("execution", execution, "action", action, "step", step)))
}

// TurnBinding reads a binding, or nil.
func (a *Adapter) TurnBinding(streamKey string, item any) *py.Dict {
	raw, ok := a.kv("turn-bind:" + streamKey + ":" + py.S(item))
	if !ok || raw == "" {
		return nil
	}
	return loadDict(raw)
}

// OutboxID is the stable identity of a payload.
func OutboxID(payload *py.Dict) string {
	h := sha256.Sum256([]byte(py.Dumps(payload)))
	return "ob-" + hex.EncodeToString(h[:])[:16]
}

// OutboxSend declares a pending intent durably, then delivers it. The
// pending record clears only after acknowledged delivery.
func (a *Adapter) OutboxSend(target string, payload *py.Dict, execution any) (string, error) {
	oid := OutboxID(payload)
	if execution == nil {
		execution = a.CurrentExecution(target)
	}
	if err := a.putMany([2]string{"outbox-pending:" + oid, py.Dumps(py.D("target", target,
		"payload", payload, "execution", execution))}); err != nil {
		return "", err
	}
	seat, err := a.RouteFor(target)
	if err != nil {
		return "", err
	}
	mid, err := a.Transport.Send(seat, py.DumpsUnsorted(payload), "dispatch", target, execution)
	if _, ok := IsFault(err); ok {
		return oid, nil // still pending; a restart reconciles the same identity
	} else if err != nil {
		return "", err
	}
	return oid, a.put("outbox-sent:"+oid, mid)
}

// OutboxAck acknowledges only after delivery evidence.
func (a *Adapter) OutboxAck(oid string) (py.Tuple, error) {
	mid, _ := a.kv("outbox-sent:" + oid)
	if mid != "" && a.Transport.State(mid) == "delivered" {
		return py.T("acked", false), a.putMany([2]string{"outbox-acked:" + oid, mid}, [2]string{"outbox-pending:" + oid, ""})
	}
	return py.T("pending", true), nil
}

// DrainOutboxSettled settles pending intents ONLY on proof: a valid
// transport receipt (sent/queued/delivered) PLUS evidence that the exact
// execution started or produced its outcome. Queued alone never settles.
func (a *Adapter) DrainOutboxSettled(qid string) ([]any, error) {
	settled := []any{}
	for _, k := range a.keys() {
		if !strings.HasPrefix(k, "outbox-pending:") || a.Driver.KV[k] == "" {
			continue
		}
		oid := strings.SplitN(k, ":", 2)[1]
		if v, _ := a.kv("outbox-acked:" + oid); v != "" {
			continue
		}
		ok, err := a.settleOne(oid, qid)
		if err != nil {
			if _, isF := IsFault(err); isF {
				continue
			}
			return nil, err
		}
		if ok {
			settled = append(settled, oid)
		}
	}
	return settled, nil
}

func (a *Adapter) settleOne(oid, qid string) (bool, error) {
	raw, _ := a.kv("outbox-pending:" + oid)
	pending := loadDict(raw)
	if pending == nil {
		return false, nil
	}
	mid, _ := a.kv("outbox-sent:" + oid)
	if mid == "" {
		return false, nil
	}
	receipt := a.msgReceipt(mid)
	if receipt == nil {
		return false, nil
	}
	switch py.S(receipt.Get("state")) {
	case "sent", "queued", "delivered":
	default:
		return false, nil
	}
	target, execution := pending.Get("target"), pending.Get("execution")
	if !py.Eq(receipt.Get("action"), target) {
		return false, nil
	}
	if !a.executionProven(target, execution, receipt, qid) {
		return false, nil
	}
	ts, _ := target.(string)
	seat, err := a.RouteFor(ts)
	if err != nil {
		return false, nil
	}
	if !py.Eq(receipt.Get("seat"), seat) {
		return false, nil
	}
	return true, a.putMany([2]string{"outbox-acked:" + oid, mid}, [2]string{"outbox-pending:" + oid, ""})
}

func (a *Adapter) msgReceipt(mid string) *py.Dict {
	raw, ok := a.kv("msg:" + mid)
	if !ok {
		return nil
	}
	return loadDict(raw)
}

func (a *Adapter) executionProven(action, execution any, receipt *py.Dict, qid string) bool {
	as, _ := action.(string)
	es, _ := execution.(string)
	if as == "" || es == "" {
		return false
	}
	if !py.Eq(receipt.Get("execution"), execution) {
		return false
	}
	if !py.Eq(a.CurrentExecution(as), execution) && !a.supersededToCurrent(as, execution) {
		return false
	}
	seen := false
	for k := range a.Driver.KV {
		if strings.HasPrefix(k, "turn-seen:") && strings.HasSuffix(k, ":"+es) {
			seen = true
			break
		}
	}
	if !seen {
		return false
	}
	for _, rk := range a.Driver.Store.Revs.Keys() {
		if !py.Eq(rk.Q, qid) {
			continue
		}
		rec := a.Driver.Store.Revs.Get(rk)
		fl := py.AsDict(rec.GetOr("flight", py.NewDict()))
		if fl != nil && py.Eq(fl.Get("action_id"), as) {
			return true
		}
		switch py.S(rec.Get("phase")) {
		case "COMPLETE", "EXHAUSTED", "TERMINATED", "SUPERSEDED":
			if rec.Get("disposition") != nil {
				return true
			}
		}
	}
	return false
}

func (a *Adapter) supersededToCurrent(action string, execution any) bool {
	for _, k := range a.keys() {
		if !strings.HasPrefix(k, "rel:") {
			continue
		}
		rel := loadDict(a.Driver.KV[k])
		if rel != nil && py.Eq(rel.Get("relationship"), "supersedes") && py.Eq(rel.Get("supersedes_action_id"), action) {
			return true
		}
	}
	return py.Eq(a.CurrentExecution(action), execution)
}

// ReconcileOutbox is restart reconciliation: pending intents resend under
// the SAME identity; ambiguous delivery holds without blind replay.
func (a *Adapter) ReconcileOutbox() (*py.Dict, error) {
	results := py.NewDict()
	for _, k := range a.keys() {
		if !strings.HasPrefix(k, "outbox-pending:") || a.Driver.KV[k] == "" {
			continue
		}
		oid := strings.SplitN(k, ":", 2)[1]
		if v, _ := a.kv("outbox-acked:" + oid); v != "" {
			continue
		}
		pending := loadDict(a.Driver.KV[k])
		target := py.S(pending.Get("target"))
		seat, err := a.RouteFor(target)
		if err != nil {
			return nil, err
		}
		mid, _ := a.kv("outbox-sent:" + oid)
		if mid != "" {
			switch a.Transport.State(mid) {
			case "delivered":
				if err := a.putMany([2]string{"outbox-acked:" + oid, mid}, [2]string{"outbox-pending:" + oid, ""}); err != nil {
					return nil, err
				}
				results.Set(oid, "acked-from-evidence")
			case "queued", "sent":
				results.Set(oid, "held-awaiting-receipt")
			default:
				results.Set(oid, "held-ambiguous")
			}
			continue
		}
		mid, err = a.Transport.Send(seat, py.DumpsUnsorted(py.AsDict(pending.Get("payload"))), "dispatch",
			target, a.CurrentExecution(target))
		if _, ok := IsFault(err); ok {
			results.Set(oid, "held-owned-fault")
			continue
		} else if err != nil {
			return nil, err
		}
		if err := a.put("outbox-sent:"+oid, mid); err != nil {
			return nil, err
		}
		results.Set(oid, "resent-same-identity")
	}
	return results, nil
}

// RegisterExecution declares a new execution of an authorized action.
func (a *Adapter) RegisterExecution(action, execution string, authRef, deadline any) (string, error) {
	return execution, a.putMany([2]string{"exec-current:" + action, execution},
		[2]string{"exec:" + action + ":" + execution, py.Dumps(py.D("authorization_ref", authRef, "deadline_utc", deadline))})
}

// CurrentExecution is the declared current execution, or nil.
func (a *Adapter) CurrentExecution(action string) any {
	v, ok := a.kv("exec-current:" + action)
	return orNil(v, ok)
}

// ApplyExecutionResult keeps late results of non-current executions as
// stale evidence, never applied.
func (a *Adapter) ApplyExecutionResult(action string, execution string, result any) (py.Tuple, error) {
	if !py.Eq(execution, a.CurrentExecution(action)) {
		return py.T("stale-retained-not-applied", true), a.put("stale:"+action+":"+execution,
			py.Dumps(py.D("result", result, "applied", false)))
	}
	return py.T("applied", false), a.put("applied:"+action+":"+execution, py.Dumps(py.D("result", result, "applied", true)))
}

// ResumeExecution is a same-action resume with the relationship recorded.
func (a *Adapter) ResumeExecution(action string, attempt any, oldExec, newExec string, authRef, deadline, phase any) (py.Tuple, error) {
	return py.T("resumed", false), a.putMany(
		[2]string{"exec-current:" + action, newExec},
		[2]string{"exec:" + action + ":" + newExec, py.Dumps(py.D("authorization_ref", authRef, "deadline_utc", deadline))},
		[2]string{"rel:" + action + ":" + newExec, py.Dumps(py.D("relationship", "resume", "resumes_action_id", action,
			"resumes_execution_id", oldExec, "attempt", attempt, "phase", phase))})
}

// ReplaceAction supersedes an action in ONE transaction.
func (a *Adapter) ReplaceAction(oldAction, newAction, newExec string, authRef, deadline, attemptChanged any) (py.Tuple, error) {
	return py.T("replaced", false), a.putMany(
		[2]string{"rel:" + newAction + ":" + newExec, py.Dumps(py.D("relationship", "supersedes",
			"supersedes_action_id", oldAction, "attempt_changed", attemptChanged, "authorization_ref", authRef))},
		[2]string{"exec-current:" + oldAction, "SUPERSEDED->" + newAction},
		[2]string{"exec-current:" + newAction, newExec},
		[2]string{"exec:" + newAction + ":" + newExec, py.Dumps(py.D("authorization_ref", authRef, "deadline_utc", deadline))})
}

// DriveNext: a verified worker completion publishes the completion, which
// creates the verifier flight.
func (a *Adapter) DriveNext(action, verifyAction string, verifyDeadline any, hashes any, qid string) (py.Tuple, error) {
	if qid == "" {
		qid, _ = a.kv("harness-qid")
	}
	if qid == "" {
		qid = "P6F"
	}
	out, err := a.Driver.PublishCompletion(qid, action, hashes,
		py.D("action_id", verifyAction, "owner", "corvid", "deadline", verifyDeadline), nil, nil, nil, nil)
	if err != nil {
		return nil, err
	}
	return py.T(py.D("published", out[0], "next_action", verifyAction), out[1]), nil
}

// ArmFromLedger creates a one-shot timer for the remaining duration.
func (a *Adapter) ArmFromLedger(id string, deadline any, now any) (py.Tuple, error) {
	if now == nil {
		now = a.TrustedNow()
	}
	n, ok1 := py.Instant(now)
	dl, ok2 := py.Instant(deadline)
	if !ok1 || !ok2 {
		return nil, fault("E_BAD_DEADLINE", "deadline not a UTC instant")
	}
	if dl.Sub(n) <= 0 {
		return nil, &Fault{"E_EXPIRED", "no remaining authorized duration", "tern"}
	}
	return a.Timers.Create(id, deadline)
}

// ArmCurrent arms from the current ledger action's deadline.
func (a *Adapter) ArmCurrent(id, qid string) (py.Tuple, error) {
	rec := a.Driver.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	var fl *py.Dict
	if rec != nil {
		fl = py.AsDict(rec.Get("flight"))
	}
	if fl == nil || !py.Truthy(fl.Get("action_id")) || !py.Truthy(fl.Get("deadline")) {
		return nil, fault("E_NO_ACTION", "no current ledger action")
	}
	return a.ArmFromLedger(id, fl.Get("deadline"), nil)
}

// ReconcileSend: only transport "delivered" settles; queued is not
// completion; ambiguous never blind-retries.
func (a *Adapter) ReconcileSend(mid, action string) *py.Dict {
	switch a.Transport.State(mid) {
	case "delivered":
		return py.D("decision", "settled-delivered")
	case "queued", "sent":
		return py.D("decision", "hold-for-receipt", "note", "started/queued ack is not completion")
	case "failed":
		return py.D("decision", "owned-failure", "note", "explicit dead-turn consumed; deadline fallback")
	}
	return py.D("decision", "hold-for-reconciliation", "note", "ambiguous delivery; never blind redispatch")
}

// EscalateUnavailable sends a bounded owned escalation. It stays pending
// until transport evidence acknowledges it.
func (a *Adapter) EscalateUnavailable(action, owner, next string, deadline any) (py.Tuple, error) {
	var mid any
	m, err := a.Transport.Send(owner, "escalation:"+action, "escalation", action, a.CurrentExecution(action))
	if err == nil {
		mid = m
	} else if _, ok := IsFault(err); !ok {
		return nil, err
	}
	e := py.D("action", action, "owner", owner, "next_action", next, "response_deadline_utc", deadline,
		"message_id", mid, "acknowledged", false)
	a.Escalations = append(a.Escalations, e)
	return py.T("escalated-owned", false), a.put("escalation:"+action, py.Dumps(e))
}

// ConfirmEscalationAck acknowledges only on transport "delivered".
func (a *Adapter) ConfirmEscalationAck(action string) (py.Tuple, error) {
	var e *py.Dict
	for _, x := range a.Escalations {
		if py.Eq(x.Get("action"), action) {
			e = x
		}
	}
	if e == nil {
		raw, ok := a.kv("escalation:" + action)
		if !ok {
			return nil, fault("E_NO_ESCALATION", "nothing pending")
		}
		e = loadDict(raw)
	}
	if mid, ok := e.Get("message_id").(string); ok && a.Transport.State(mid) == "delivered" {
		e.Set("acknowledged", true)
		return py.T("escalated-acknowledged", true), a.put("escalation:"+action, py.Dumps(e))
	}
	return py.T("escalation-pending", false), nil
}

// TimerCallback fires a due timer through ledger authority. Every callback
// names the DB, qid, action and execution; identity is checked against the
// persisted record before any deadline handling.
// prep, when set, wires production effects into the fresh driver.
func TimerCallback(dbPath, timerID, qid, action, execution string, clock core.DriverClock,
	prep func(*core.Driver)) (*py.Dict, error) {
	if qid == "" || action == "" || execution == "" {
		return nil, fault("E_NO_IDENTITY", "callback needs --db, --timer, --qid-cb, --action and --execution; omitted identity fails closed")
	}
	if clock == nil {
		clock = core.HostClock{}
	}
	d, err := core.NewDriver(dbPath, clock, nil, nil)
	if err != nil {
		return nil, err
	}
	defer d.Close()
	if prep != nil {
		prep(d)
	}
	rec := d.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if rec == nil || rec.Len() == 0 {
		return nil, fault("E_UNKNOWN_PACKAGE", "no persisted ledger package for qid "+qid)
	}
	fl := py.AsDict(rec.GetOr("flight", py.NewDict()))
	var cur any
	if fl != nil {
		cur = fl.Get("action_id")
	}
	if !py.Eq(action, cur) {
		return nil, fault("E_ACTION_MISMATCH", "callback action "+action+" is not the persisted current action "+py.S(cur))
	}
	ce, ok := d.KV["exec-current:"+action]
	if !ok || strings.TrimSpace(ce) == "" {
		return nil, fault("E_NO_EXECUTION_AUTHORITY", "no persisted current execution for action "+action)
	}
	if strings.HasPrefix(ce, "SUPERSEDED->") {
		return nil, fault("E_SUPERSEDED_ACTION", "action "+action+" is superseded; callback refused")
	}
	if ce != execution {
		return nil, fault("E_EXECUTION_MISMATCH", "callback execution "+execution+" is not the persisted current execution "+ce)
	}
	out, err := d.OnDeadline(action, qid)
	if err != nil {
		return nil, err
	}
	return py.D("timer", timerID, "decision", out[0], "dedup", out[1]), nil
}
