package core

import (
	"fmt"
	"time"

	"agent-loop/internal/py"
)

// Versioned terminal-boundary validator. The LEDGER is authoritative; the
// snapshot is compared against it before any ACTIVE/REST/ACTION_DUE
// verdict. It only returns data - it never wakes, stops or signals.

var kinds = []string{"successor_opened", "question_answered", "budget_spent", "blocked"}
var flightFields = []string{"action_id", "owner", "deadline", "dispatch_receipt"}
var allPhases = append(append([]string{}, States...), Terminals...)

const schemaVersion = 1

func invalid(code, detail string, owner ...string) *py.Dict {
	o := "tern"
	if len(owner) > 0 {
		o = owner[0]
	}
	return py.D("verdict", "INVALID", "code", code, "detail", detail,
		"action", py.D("type", "owner-reconcile", "owner", o))
}

func isStr(v any) bool       { _, ok := v.(string); return ok }
func isOptStr(v any) bool    { return v == nil || isStr(v) }
func nonEmptyStr(v any) bool { s, ok := v.(string); return ok && s != "" }

// triggerSet is set(triggers_fired or ()): ok=false where Python's set()
// would raise TypeError.
func triggerSet(v any) (*py.Set, bool) {
	s := py.NewSet()
	if !py.Truthy(v) {
		return s, true
	}
	switch x := v.(type) {
	case []any, py.Tuple:
		for _, e := range asList(x) {
			switch e.(type) {
			case *py.Dict, []any, *py.Set:
				return nil, false
			}
			s.Add(e)
		}
	case *py.Set:
		return x, true
	case string:
		for _, r := range x {
			s.Add(string(r))
		}
	case *py.Dict:
		for _, k := range x.Keys() {
			s.Add(k)
		}
	default:
		return nil, false
	}
	return s, true
}

// Validate validates a snapshot against the authoritative ledger.
func Validate(snapshot, ledger, now, triggersFired any) *py.Dict {
	fired, ok := triggerSet(triggersFired)
	if !ok {
		return invalid("E_MALFORMED", "triggers_fired not a set of ids")
	}
	tnow, ok := py.Instant(now)
	if !ok {
		return invalid("E_MALFORMED", "now is not a UTC instant")
	}
	if snapshot == nil {
		return invalid("E_ABSENT_STATE", "no snapshot; ledger authoritative")
	}
	snap, ok := snapshot.(*py.Dict)
	if !ok {
		return invalid("E_MALFORMED", "snapshot not an object")
	}
	led, ok := ledger.(*py.Dict)
	if !ok || py.AsDict(led.Get("packages")) == nil {
		return invalid("E_MALFORMED", "ledger packages not an object")
	}
	if !py.Eq(snap.Get("schema_version"), int64(schemaVersion)) {
		return invalid("E_VERSION", "unsupported schema_version")
	}
	if !py.Eq(snap.Get("ledger_revision"), led.Get("revision")) {
		return invalid("E_LEDGER_INCOMPLETE", "snapshot revision != authoritative ledger revision")
	}
	snapTerms, ok1 := snap.Get("terminal").(*py.Dict)
	snapFlight, ok2 := snap.Get("in_flight").([]any)
	if !ok1 || !ok2 {
		return invalid("E_MALFORMED", "terminal/in_flight shapes")
	}

	pkgs := py.AsDict(led.Get("packages"))
	for _, pid := range pkgs.Keys() {
		if pid == "" {
			return invalid("E_MALFORMED", "ledger package id shape")
		}
		rec, ok := pkgs.Get(pid).(*py.Dict)
		if !ok || !in(rec.Get("phase"), allPhases...) {
			return invalid("E_MALFORMED", fmt.Sprintf("ledger package %s shape", pid))
		}
		for _, key := range []string{"flight", "handoff", "decision_task"} {
			if v := rec.Get(key); v != nil {
				if _, ok := v.(*py.Dict); !ok {
					return invalid("E_MALFORMED", fmt.Sprintf("ledger package %s %s shape", pid, key))
				}
			}
		}
	}

	seen := map[string]bool{}
	for _, it := range snapFlight {
		item, ok := it.(*py.Dict)
		if !ok {
			return invalid("E_MALFORMED", "in_flight entry shape")
		}
		pid, ok := item.Get("package_id").(string)
		if !ok || pid == "" {
			return invalid("E_MALFORMED", "in_flight package_id shape")
		}
		if seen[pid] {
			return invalid("E_DUPLICATE", fmt.Sprintf("in-flight %s projected twice", pid))
		}
		seen[pid] = true
		if !nonEmptyStr(item.Get("phase")) {
			return invalid("E_MALFORMED", fmt.Sprintf("in_flight %s phase shape", pid))
		}
		for _, f := range flightFields {
			if !item.Has(f) || !isOptStr(item.Get(f)) {
				return invalid("E_MALFORMED", fmt.Sprintf("in_flight %s field %s shape", pid, f))
			}
		}
		if item.Get("deadline") != nil {
			dl, ok := py.Instant(item.Get("deadline"))
			if !ok {
				return invalid("E_MALFORMED", fmt.Sprintf("in_flight %s deadline not a UTC instant", pid))
			}
			if dl.Before(tnow) {
				return invalid("E_OVERDUE_ACTION", fmt.Sprintf("in-flight %s past deadline", pid))
			}
		}
	}

	for _, pid := range snapTerms.Keys() {
		if pid == "" {
			return invalid("E_MALFORMED", "terminal package id shape")
		}
	}

	var pendingDue *py.Dict
	for _, pid := range snapTerms.Keys() {
		entry, ok := snapTerms.Get(pid).(*py.Dict)
		if !ok {
			return invalid("E_MALFORMED", "terminal entry "+pid)
		}
		if !nonEmptyStr(entry.Get("state")) {
			return invalid("E_MALFORMED", fmt.Sprintf("terminal %s state shape", pid))
		}
		disp := entry.Get("disposition")
		if disp == nil {
			task := py.AsDict(py.AsDict(pkgs.Get(pid)).Get("decision_task"))
			tdl, tok := py.Instant(task.Get("deadline"))
			if py.Truthy(task) && tok && !tdl.Before(tnow) &&
				entry.Get("held") == true && hasDecision(snapFlight, pid) {
				continue
			}
			return invalid("E_MISSING_DISPOSITION", fmt.Sprintf("terminal %s has no disposition", pid))
		}
		dd, ok := disp.(*py.Dict)
		if !ok || !in(dd.Get("kind"), kinds...) {
			return invalid("E_MISSING_DISPOSITION", fmt.Sprintf("terminal %s kind not enumerable", pid))
		}
		if !py.Eq(entry.Get("decided_by"), "tern") || !nonEmptyStr(entry.Get("decision_ref")) {
			return invalid("E_OWNERSHIP", fmt.Sprintf("terminal %s needs attributed director decision", pid))
		}
		switch dd.Get("kind") {
		case "successor_opened":
			sid := dd.Get("successor_id")
			if !py.Truthy(sid) {
				return invalid("E_DANGLING_SUCCESSOR", pid+" names no successor")
			}
			if !isStr(sid) {
				return invalid("E_MALFORMED", fmt.Sprintf("terminal %s successor_id shape", pid))
			}
			if bad := checkSuccessor(pid, dd, snapTerms, snapFlight, pkgs); bad != nil {
				return bad
			}
		case "question_answered":
			refs, ok := dd.Get("evidence_refs").([]any)
			if !ok || len(refs) == 0 || !nonEmptyStr(dd.Get("reason")) {
				return invalid("E_INCOMPLETE_REST", pid+" needs evidence + reason")
			}
		case "budget_spent":
			if !nonEmptyStr(dd.Get("allocation_ref")) || !nonEmptyStr(dd.Get("reason")) {
				return invalid("E_INCOMPLETE_REST", pid+" needs allocation ref + decision")
			}
		case "blocked":
			if bad := blockedShape(pid, dd); bad != nil {
				return bad
			}
			if due := checkBlocked(pid, dd, tnow, fired); due != nil && pendingDue == nil {
				pendingDue = due
			}
		}
	}

	for _, pid := range snapTerms.Keys() {
		disp := py.AsDict(py.AsDict(snapTerms.Get(pid)).Get("disposition"))
		if py.Eq(disp.Get("kind"), "successor_opened") {
			if bad := followChain(pid, snapTerms, snapFlight, map[string]bool{}); bad != nil {
				return bad
			}
		}
	}

	if bad := authorityCheck(snapTerms, snapFlight, pkgs, tnow); bad != nil {
		return bad
	}
	if pendingDue != nil {
		return pendingDue
	}
	if len(snapFlight) > 0 {
		return py.D("verdict", "ACTIVE", "detail",
			fmt.Sprintf("%d acknowledged bounded action(s) in flight", len(snapFlight)))
	}
	return py.D("verdict", "REST", "detail", "all chains end in legitimate rest")
}

func authorityCheck(snapTerms *py.Dict, snapFlight []any, pkgs *py.Dict, tnow time.Time) *py.Dict {
	flightBy := py.NewDict()
	for _, it := range snapFlight {
		item := it.(*py.Dict)
		if py.Eq(item.Get("phase"), "DECISION") {
			continue
		}
		pid := item.Get("package_id").(string)
		if !flightBy.Has(pid) {
			flightBy.Set(pid, item)
		}
	}
	rec := func(pid string) *py.Dict { return py.AsDict(pkgs.Get(pid)) }

	for _, pid := range pkgs.Keys() {
		if !isTerminal(rec(pid).Get("phase")) && !flightBy.Has(pid) && !hasDecision(snapFlight, pid) {
			return invalid("E_LEDGER_INCOMPLETE", fmt.Sprintf("ledger-active %s missing from projection", pid))
		}
	}
	for _, pid := range flightBy.Keys() {
		if !pkgs.Has(pid) || isTerminal(rec(pid).Get("phase")) {
			return invalid("E_FABRICATED", fmt.Sprintf("in-flight %s unknown to the ledger", pid))
		}
	}
	for _, pid := range pkgs.Keys() {
		if isTerminal(rec(pid).Get("phase")) && !snapTerms.Has(pid) {
			return invalid("E_LEDGER_INCOMPLETE", fmt.Sprintf("ledger terminal %s missing from projection", pid))
		}
	}
	for _, pid := range snapTerms.Keys() {
		entry := py.AsDict(snapTerms.Get(pid))
		if !pkgs.Has(pid) || !isTerminal(rec(pid).Get("phase")) {
			return invalid("E_FABRICATED", fmt.Sprintf("terminal %s unknown to the ledger", pid))
		}
		r := rec(pid)
		if !py.Eq(entry.Get("state"), r.Get("phase")) {
			return invalid("E_MISMATCH", fmt.Sprintf("terminal %s state contradicts ledger", pid))
		}
		ldisp, sdisp := r.Get("disposition"), entry.Get("disposition")
		if ldisp == nil && sdisp == nil {
			continue
		}
		if ldisp == nil {
			return invalid("E_FABRICATED", fmt.Sprintf("terminal %s disposition invented", pid))
		}
		if sdisp == nil {
			return invalid("E_MISSING_DISPOSITION", fmt.Sprintf("terminal %s hides its disposition", pid))
		}
		ld := py.AsDict(ldisp)
		sd, ok := sdisp.(*py.Dict)
		if !ok || !py.Eq(sd.Get("kind"), ld.Get("kind")) {
			return invalid("E_MISMATCH", fmt.Sprintf("terminal %s disposition kind changed", pid))
		}
		for _, k := range ld.Keys() {
			if !py.Eq(sd.Get(k), ld.Get(k)) {
				return invalid("E_MISMATCH", fmt.Sprintf("terminal %s disposition.%s changed", pid, k))
			}
		}
		if !py.Eq(entry.Get("decided_by"), "tern") {
			return invalid("E_MISMATCH", fmt.Sprintf("terminal %s decision attribution changed", pid))
		}
		for _, f := range []string{"decision_ref", "reason"} {
			stated := ld.Get(f)
			if !nonEmptyStr(stated) {
				return invalid("E_MISMATCH", fmt.Sprintf("terminal %s decision %s invented", pid, f))
			}
			if !py.Eq(entry.Get(f), stated) {
				return invalid("E_MISMATCH", fmt.Sprintf("terminal %s decision %s changed", pid, f))
			}
		}
	}

	for _, pid := range flightBy.Keys() {
		item := py.AsDict(flightBy.Get(pid))
		r := rec(pid)
		if !py.Eq(item.Get("phase"), r.Get("phase")) {
			return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s phase forged", pid))
		}
		lf := py.AsDict(r.Get("flight"))
		ho := py.AsDict(r.Get("handoff"))
		switch {
		case py.Truthy(lf.Get("action_id")):
			for _, f := range []string{"action_id", "owner"} {
				if !py.Eq(item.Get(f), lf.Get(f)) {
					return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s %s forged", pid, f))
				}
			}
			if bad := deadlineEqual(item.Get("deadline"), lf.Get("deadline"), pid); bad != nil {
				return bad
			}
			lrec := r.Get("receipt")
			if lrec != nil {
				if !py.Eq(item.Get("dispatch_receipt"), lrec) {
					return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s ack forged", pid))
				}
			} else if py.Eq(item.Get("dispatch_receipt"), "acknowledged") {
				return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s ack unrecorded", pid))
			}
		case py.Truthy(ho):
			if item.Get("action_id") != nil {
				return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s action invented", pid))
			}
			if !py.Eq(item.Get("owner"), ho.Get("owner")) {
				return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s owner forged", pid))
			}
			if bad := deadlineEqual(item.Get("deadline"), ho.Get("deadline"), pid); bad != nil {
				return bad
			}
			if !py.Eq(item.Get("dispatch_receipt"), r.Get("receipt")) {
				return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s handoff ack forged", pid))
			}
		default:
			if item.Get("action_id") != nil {
				return invalid("E_FABRICATED", fmt.Sprintf("in-flight %s action never dispatched", pid))
			}
			for _, f := range []string{"owner", "deadline", "dispatch_receipt"} {
				if item.Get(f) != nil {
					return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s %s without ledger action", pid, f))
				}
			}
		}
	}

	for _, pid := range pkgs.Keys() {
		r := rec(pid)
		task := py.AsDict(r.Get("decision_task"))
		if py.Truthy(task) && r.Get("disposition") == nil {
			tdl, ok := py.Instant(task.Get("deadline"))
			if !ok {
				return invalid("E_MALFORMED", "ledger decision task "+pid+" deadline")
			}
			match := false
			for _, it := range snapFlight {
				i, ok := it.(*py.Dict)
				if !ok {
					continue
				}
				idl, iok := py.Instant(i.Get("deadline"))
				if py.Eq(i.Get("phase"), "DECISION") && py.Eq(i.Get("package_id"), pid) &&
					py.Eq(i.Get("action_id"), task.Get("task_id")) &&
					py.Eq(i.Get("owner"), "tern") &&
					py.Eq(i.Get("dispatch_receipt"), "acknowledged") &&
					iok && idl.Equal(tdl) {
					match = true
				}
			}
			if !match {
				return invalid("E_LEDGER_INCOMPLETE", fmt.Sprintf("ledger decision task %s unprojected", pid))
			}
		}
	}
	for _, it := range snapFlight {
		item := py.AsDict(it)
		if py.Eq(item.Get("phase"), "DECISION") {
			pid := item.Get("package_id")
			ps, _ := pid.(string)
			r := py.AsDict(pkgs.Get(ps))
			if !py.Truthy(r.Get("decision_task")) || r.Get("disposition") != nil {
				return invalid("E_FABRICATED", fmt.Sprintf("decision entry %s unrecorded", py.S(pid)))
			}
		}
	}
	return nil
}

func deadlineEqual(snapDL, ledgerDL any, pid string) *py.Dict {
	a, ok1 := py.Instant(snapDL)
	b, ok2 := py.Instant(ledgerDL)
	if !ok1 || !ok2 {
		return invalid("E_MALFORMED", fmt.Sprintf("in-flight %s deadline not a UTC instant", pid))
	}
	if !a.Equal(b) {
		return invalid("E_MISMATCH", fmt.Sprintf("in-flight %s deadline extended", pid))
	}
	return nil
}

func hasDecision(snapFlight []any, pid string) bool {
	for _, it := range snapFlight {
		if i, ok := it.(*py.Dict); ok && py.Eq(i.Get("package_id"), pid) && py.Eq(i.Get("phase"), "DECISION") {
			return true
		}
	}
	return false
}

// liveIDs: D3 liveness - acknowledged dispatch AND a finite deadline.
func liveIDs(snapFlight []any) *py.Set {
	s := py.NewSet()
	for _, it := range snapFlight {
		if i, ok := it.(*py.Dict); ok && py.Eq(i.Get("dispatch_receipt"), "acknowledged") &&
			py.Truthy(i.Get("deadline")) {
			s.Add(i.Get("package_id"))
		}
	}
	return s
}

func checkSuccessor(pid string, disp, snapTerms *py.Dict, snapFlight []any, pkgs *py.Dict) *py.Dict {
	sid := disp.Get("successor_id")
	if !py.Truthy(sid) {
		return invalid("E_DANGLING_SUCCESSOR", pid+" names no successor")
	}
	ss, _ := sid.(string)
	if liveIDs(snapFlight).Has(sid) {
		return nil
	}
	if snapTerms.Has(ss) {
		return nil
	}
	if pkgs.Has(ss) {
		return invalid("E_DANGLING_SUCCESSOR", fmt.Sprintf("%s -> %s has no acknowledged work", pid, ss))
	}
	return invalid("E_DANGLING_SUCCESSOR", fmt.Sprintf("%s -> unknown %s", pid, ss))
}

func followChain(pid string, snapTerms *py.Dict, snapFlight []any, seen map[string]bool) *py.Dict {
	if seen[pid] {
		return invalid("E_CYCLE", "successor cycle at "+pid)
	}
	next := map[string]bool{pid: true}
	for k := range seen {
		next[k] = true
	}
	entry := py.AsDict(snapTerms.GetOr(pid, py.NewDict()))
	disp := py.AsDict(entry.Get("disposition"))
	if !py.Eq(disp.Get("kind"), "successor_opened") {
		return nil
	}
	sid := disp.Get("successor_id")
	if liveIDs(snapFlight).Has(sid) {
		return nil
	}
	ss, _ := sid.(string)
	if !snapTerms.Has(ss) || !isStr(sid) {
		return invalid("E_DANGLING_SUCCESSOR", fmt.Sprintf("chain %s -> %s dangling", pid, py.S(sid)))
	}
	return followChain(ss, snapTerms, snapFlight, next)
}

func blockedShape(pid string, disp *py.Dict) *py.Dict {
	blk, ok := disp.Get("blocker").(*py.Dict)
	if !ok {
		return invalid("E_INCOMPLETE_REST", pid+" blocked needs a blocker object")
	}
	trigV := blk.Get("wake_trigger")
	if trigV != nil {
		if _, ok := trigV.(*py.Dict); !ok {
			return invalid("E_MALFORMED", pid+" wake_trigger shape")
		}
	}
	trig := py.AsDict(trigV)
	if trig == nil {
		trig = py.NewDict()
	}
	for _, f := range []string{"id", "owner", "resumption"} {
		if v := blk.Get(f); v != nil && !isStr(v) {
			return invalid("E_MALFORMED", fmt.Sprintf("%s blocker.%s shape", pid, f))
		}
	}
	for _, f := range []string{"event_id", "revisit_at"} {
		if v := trig.Get(f); v != nil && !isStr(v) {
			return invalid("E_MALFORMED", fmt.Sprintf("%s trigger.%s shape", pid, f))
		}
	}
	if !py.Truthy(blk.Get("id")) || !py.Truthy(blk.Get("owner")) || !py.Truthy(blk.Get("resumption")) {
		return invalid("E_INCOMPLETE_REST", pid+" blocked needs id/owner/resumption")
	}
	if !py.Truthy(trig.Get("event_id")) && !py.Truthy(trig.Get("revisit_at")) {
		return invalid("E_INCOMPLETE_REST", pid+" blocked needs a machine trigger")
	}
	if py.Truthy(trig.Get("revisit_at")) {
		if _, ok := py.Instant(trig.Get("revisit_at")); !ok {
			return invalid("E_MALFORMED", pid+" trigger revisit_at not a UTC instant")
		}
	}
	return nil
}

func checkBlocked(pid string, disp *py.Dict, tnow time.Time, fired *py.Set) *py.Dict {
	blk := py.AsDict(disp.Get("blocker"))
	trig := py.AsDict(blk.Get("wake_trigger"))
	if trig == nil {
		trig = py.NewDict()
	}
	var tid any = trig.Get("event_id")
	if !py.Truthy(tid) {
		tid = "revisit:" + trig.Get("revisit_at").(string)
	}
	if py.Truthy(trig.Get("revisit_at")) {
		revisit, ok := py.Instant(trig.Get("revisit_at"))
		if ok && !revisit.After(tnow) && !fired.Has(tid) {
			return py.D("verdict", "ACTION_DUE",
				"action", py.D("type", "owner-reconcile", "owner", blk.Get("owner"),
					"trigger_id", tid, "package_id", pid, "bounded", true),
				"detail", "blocker trigger due for "+pid)
		}
	}
	return nil
}
