package host

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestDirNotifier(t *testing.T) {
	dir := t.TempDir()
	n, err := NewDirNotifier(dir)
	if err != nil {
		t.Fatal(err)
	}
	if got, _ := n.Wait(50 * time.Millisecond); got {
		t.Fatal("event reported with nothing written")
	}
	os.WriteFile(filepath.Join(dir, "k.jsonl"), []byte("x\n"), 0o644)
	if got, err := n.Wait(time.Second); !got || err != nil {
		t.Fatalf("write not seen: %v %v", got, err)
	}
	n.Close()
	if _, err := n.Wait(0); err == nil {
		t.Fatal("wait after close did not fail")
	}
	if _, err := NewDirNotifier(filepath.Join(dir, "absent")); err == nil {
		t.Fatal("watching a missing directory did not fail")
	}
}
