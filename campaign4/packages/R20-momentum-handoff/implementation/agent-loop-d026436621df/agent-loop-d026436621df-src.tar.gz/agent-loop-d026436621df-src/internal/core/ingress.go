package core

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"agent-loop/internal/py"
)

// Trusted timestamp ingress: the single accepted external write route. It
// owns receipt time, actor attribution and deadline derivation. See the
// reference ingress.py docstring for the full D1/D2/D3 rules.

var explicitZoneRE = regexp.MustCompile(`(Z|[+-]\d{2}:?\d{2})$`)

const (
	FutureSkewToleranceS   = 120
	DiscontinuityThreshold = 60
	NestedDeadlineCapS     = 86400
)

var TrustedSeats = []string{"tern", "corvid", "kiln", "cairn"}
var TrustedRoles = []string{"director", "reader", "worker", "verifier", "duty"}

var phaseFor = map[string][]string{
	"admit": {"__absent__", "DRAFT"}, "reject": {"DRAFT"},
	"authorize": {"ADMITTED"}, "start": {"REGISTERED", "REPAIR_ALLOWED"},
	"publish": {"RUNNING"}, "verify_pass": {"CHECKING"}, "verify_fail": {"CHECKING"},
	"accept": {"COMPLETE"}, "withhold": {"COMPLETE", "CHECKING"},
	"alloc_repair": {"REPAIR_ALLOWED"}, "interrupt": {"RUNNING", "CHECKING"},
	"resolve": {"BLOCKED"}, "defer": {"BLOCKED"}, "terminate": {"BLOCKED"},
	"exhaust": {"BLOCKED"}, "recover": {"BLOCKED"},
	"decide": Terminals, "decision_task": Terminals,
}

var grantPhaseForRoute = map[string][]any{
	"start": {nil, "run"}, "verify": {"verify"}, "handoff": {"handoff"},
	"hold": {"verify", "decision"}, "decision": {"decision"},
}

// TokenHex is the random source for epochs. Conformance runs replace it
// with a counter so recordings replay.
var TokenHex = func(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// Clock is the injected time source.
type Clock interface {
	UtcNow() string
	Monotonic() float64
}

// HostClock reads host UTC. It never changes the clock.
type HostClock struct{ start time.Time }

func (HostClock) UtcNow() string { return py.ISO(time.Now()) }
func (HostClock) Now() string    { return py.ISO(time.Now()) }
func (h HostClock) Monotonic() float64 {
	return float64(time.Since(processStart)) / float64(time.Second)
}

var processStart = time.Now()

type Ingress struct {
	Store     *Store
	Clock     Clock
	kvPut     func(k, v string) error
	kvGet     func(k string) (string, bool)
	Epoch     string
	Ambiguous *py.Dict
	Last      *py.Dict
}

func NewIngress(store *Store, clock Clock, kvPut func(k, v string) error,
	kvGet func(k string) (string, bool), epoch string) (*Ingress, error) {
	g := &Ingress{Store: store, Clock: clock, kvPut: kvPut, kvGet: kvGet}
	boot := int64(1)
	raw, _ := kvGet("ingress-boot")
	if raw == "" {
		raw = "0"
	}
	if n, ok := parseIntPy(raw); ok {
		boot = n + 1
	}
	if err := kvPut("ingress-boot", strconv.FormatInt(boot, 10)); err != nil {
		return nil, err
	}
	if epoch == "" {
		epoch = fmt.Sprintf("epoch-%d-%s", boot, TokenHex(8))
	}
	g.Epoch = epoch
	if err := kvPut("ingress-epoch", epoch); err != nil {
		return nil, err
	}
	if last, ok := kvGet("ingress-last"); ok && last != "" {
		prev, err := py.Loads([]byte(last))
		if err != nil {
			prev = nil
		}
		if py.Truthy(prev) {
			g.checkRestartContinuity(py.AsDict(prev))
		}
	}
	g.Last = nil
	return g, nil
}

func (g *Ingress) checkRestartContinuity(prev *py.Dict) {
	nowRaw := g.Clock.UtcNow()
	now, ok1 := py.Instant(nowRaw)
	then, ok2 := py.Instant(prev.Get("utc"))
	switch {
	case !ok1 || !ok2:
		g.Ambiguous = py.D("owner", "cairn", "previous_utc", prev.Get("utc"),
			"current_utc", nowRaw, "response",
			"unreadable persisted clock fact; bounded reconciliation required; deadlines unchanged")
	case now.Before(then):
		g.Ambiguous = py.D("owner", "cairn", "previous_utc", prev.Get("utc"),
			"current_utc", nowRaw, "response",
			"backward UTC at reopen; bounded reconciliation required; deadlines unchanged")
	}
}

func (g *Ingress) requireContinuity() error {
	if g.Ambiguous != nil {
		return quarantine("E_AMBIGUOUS_RESTART", "ambiguous restart clock continuity", g.Ambiguous.Copy())
	}
	return nil
}

func (g *Ingress) checkContinuity(recorded time.Time) error {
	mono := g.Clock.Monotonic()
	if g.Last != nil {
		wall := 0.0
		if prev, ok := py.Instant(g.Last.Get("utc")); ok {
			wall = recorded.Sub(prev).Seconds()
		}
		lastMono, _ := py.Num(g.Last.Get("mono"))
		drift := math.Abs(wall - (mono - lastMono))
		if drift > DiscontinuityThreshold {
			return quarantine("E_DISCONTINUITY",
				fmt.Sprintf("wall-vs-monotonic drift %.1fs exceeds %ds", drift, DiscontinuityThreshold),
				py.D("owner", "cairn", "epoch", g.Epoch, "wall_delta_s", wall,
					"mono_delta_s", mono-lastMono,
					"response", "bounded reconciliation required; deadlines unchanged"))
		}
	}
	g.Last = py.D("epoch", g.Epoch, "utc", py.ISO(recorded), "mono", mono)
	return g.kvPut("ingress-last", py.Dumps(g.Last))
}

// ReconcileClock opens a fresh epoch with an owned note after a
// discontinuity or ambiguous restart. It never touches deadlines.
func (g *Ingress) ReconcileClock(note any, owner any) (string, error) {
	if owner == nil {
		owner = "cairn"
	}
	g.Epoch = fmt.Sprintf("epoch-reconciled-%s-%s", g.Clock.UtcNow(), TokenHex(4))
	if err := g.kvPut("ingress-epoch", g.Epoch); err != nil {
		return "", err
	}
	if err := g.kvPut("ingress-reconcile-note", py.Dumps(py.D(
		"owner", owner, "note", note, "at", g.Clock.UtcNow()))); err != nil {
		return "", err
	}
	g.Last = nil
	g.Ambiguous = nil
	return g.Epoch, nil
}

func (g *Ingress) bindActor(claim *py.Dict, actor any, where string) (*py.Dict, error) {
	if claim.Has("actor") {
		return nil, ierr("E_FORGED_ATTRIBUTION",
			"caller actor claim rejected at "+where+"; authority comes only from the trusted adapter context",
			"tern")
	}
	a, ok := actor.(*py.Dict)
	if !ok || !in(a.Get("seat"), TrustedSeats...) || !in(a.Get("role"), TrustedRoles...) {
		return nil, ierr("E_UNTRUSTED_ACTOR", "adapter must supply a trusted seat/role")
	}
	return py.D("seat", a.Get("seat"), "role", a.Get("role")), nil
}

func (g *Ingress) actualPhase(q, rev any) any {
	rec := g.Store.Revs.Get(RevKey{q, rev})
	if rec == nil {
		return "__absent__"
	}
	return rec.Get("phase")
}

func (g *Ingress) checkPhase(typ, q, rev any) error {
	t, ok := typ.(string)
	if !ok {
		return nil
	}
	allowed, ok := phaseFor[t]
	if !ok || t == "amend" {
		return nil
	}
	actual := g.actualPhase(q, rev)
	if !in(actual, allowed...) {
		return ierr("E_PHASE_MISMATCH", fmt.Sprintf("%s not allowed in actual phase %s", t, py.S(actual)))
	}
	return nil
}

func (g *Ingress) receipt(claim *py.Dict, recorded time.Time) (*py.Dict, error) {
	for _, forged := range []string{"recorded_at", "receipt", "_trusted", "phase_hint"} {
		if claim.Has(forged) {
			if forged == "phase_hint" {
				return nil, ierr("E_FORGED_HINT",
					"caller may not supply phase_hint; actual phase comes from authoritative ledger state", "tern")
			}
			return nil, ierr("E_FORGED_RECEIPT", "caller may not supply "+forged, "tern")
		}
	}
	occurredRaw := claim.Pop("occurred_at")
	provenance := claim.Pop("provenance")
	var occurredISO, skew any
	if occurredRaw != nil {
		occurred, ok := py.Instant(occurredRaw)
		if !ok || !explicitZoneRE.MatchString(strings.TrimSpace(py.S(occurredRaw))) {
			return nil, quarantine("E_BAD_OCCURRED",
				"occurred_at is not a supported UTC instant (explicit zone required)",
				py.D("owner", "cairn", "claimed", occurredRaw))
		}
		sk := occurred.Sub(recorded).Seconds()
		if sk > FutureSkewToleranceS {
			return nil, quarantine("E_SKEW_EXCEEDED",
				fmt.Sprintf("claimed occurrence %.0fs in the future exceeds %ds", sk, FutureSkewToleranceS),
				py.D("owner", "cairn", "claimed", occurredRaw, "recorded_at", py.ISO(recorded)))
		}
		occurredISO, skew = py.ISO(occurred), sk
	}
	callerAt, hadAt := claim.Get("at"), claim.Has("at")
	claim.Pop("at")
	r := py.D("recorded_at", py.ISO(recorded), "occurred_at", occurredISO,
		"provenance", provenance, "skew_s", skew, "epoch", g.Epoch)
	if hadAt && callerAt != nil {
		r.Set("caller_at_ignored", callerAt)
	}
	return r, nil
}

func (g *Ingress) grantCover(route string, deadline time.Time, ok bool, recorded time.Time,
	grants *py.Dict, grantRef any) error {
	if !ok {
		return ierr("E_BAD_DEADLINE", "deadline not a UTC instant")
	}
	if deadline.Before(recorded) {
		return ierr("E_BAD_DEADLINE", "deadline before trusted receipt")
	}
	if !deadline.After(recorded.Add(NestedDeadlineCapS * time.Second)) {
		return nil
	}
	var grant any
	switch r := grantRef.(type) {
	case string:
		grant = grants.Get(r)
	default:
		if !py.Truthy(grantRef) {
			grant = grants.Get("")
		}
	}
	if grant == nil {
		return ierr("E_DEADLINE_UNAUTHORIZED",
			"deadline beyond the authorized window needs a pinned covering grant")
	}
	gd := py.AsDict(grant)
	gdl, gok := py.Instant(gd.Get("absolute_deadline"))
	if !gok || gdl.Before(deadline) {
		return ierr("E_DEADLINE_UNAUTHORIZED", "covering grant does not cover the deadline")
	}
	if !inAny(gd.Get("phase"), grantPhaseForRoute[route]) {
		return ierr("E_GRANT_MISMATCH", "grant phase does not bind route "+route)
	}
	return nil
}

func inAny(v any, xs []any) bool {
	for _, x := range xs {
		if (x == nil && v == nil) || (x != nil && py.Eq(v, x)) {
			return true
		}
	}
	return false
}

func (g *Ingress) nestedDeadline(claim *py.Dict, recorded time.Time, grants *py.Dict) error {
	if v, ok := claim.Get("verify").(*py.Dict); ok && v.Get("deadline") != nil {
		dl, dok := py.Instant(v.Get("deadline"))
		if err := g.grantCover("verify", dl, dok, recorded, grants, claim.Get("verify_grant_ref")); err != nil {
			return err
		}
	}
	if hd := claim.Get("handoff_deadline"); hd != nil {
		dl, dok := py.Instant(hd)
		return g.grantCover("handoff", dl, dok, recorded, grants, claim.Get("handoff_grant_ref"))
	}
	return nil
}

func (g *Ingress) startDeadline(claim *py.Dict, recorded time.Time, grants *py.Dict) error {
	grantRef := claim.Pop("grant_ref")
	duration := claim.Pop("duration_s")
	if claim.Has("deadline") {
		return ierr("E_DEADLINE_FORGE", "caller may not supply a start deadline", "tern")
	}
	if grantRef != nil {
		var grant any
		if r, ok := grantRef.(string); ok {
			grant = grants.Get(r)
		}
		if grant == nil {
			return ierr("E_GRANT_UNKNOWN", "no such pinned grant")
		}
		gd := py.AsDict(grant)
		gdl, ok := py.Instant(gd.Get("absolute_deadline"))
		if !ok {
			return ierr("E_GRANT_MALFORMED", "grant deadline malformed")
		}
		if gdl.Before(recorded) {
			return ierr("E_GRANT_EXPIRED", "grant deadline already past")
		}
		if !inAny(gd.Get("phase"), grantPhaseForRoute["start"]) {
			return ierr("E_GRANT_MISMATCH", "grant phase does not authorize a start")
		}
		claim.Set("deadline", gd.Get("absolute_deadline"))
		claim.Set("grant_ref", grantRef)
		return nil
	}
	if duration == nil {
		return ierr("E_NO_AUTHORIZATION", "start needs an explicit duration_s or pinned grant_ref")
	}
	d, ok := py.Int(duration)
	if !ok || d <= 0 {
		return ierr("E_BAD_DURATION", "duration positive integer seconds")
	}
	capv, _ := py.Num(grants.GetOr("__allocation_cap_s__", int64(7200)))
	if float64(d) > capv {
		return ierr("E_ALLOC_EXCEEDED", "duration exceeds allocation")
	}
	claim.Set("deadline", py.ISO(recorded.Add(time.Duration(d)*time.Second)))
	claim.Set("duration_s", duration)
	return nil
}

func (g *Ingress) checkAtomic(atomic any, recorded time.Time, grants *py.Dict, atomicActor any) (*py.Dict, error) {
	if atomic == nil {
		return nil, nil
	}
	a, ok := atomic.(*py.Dict)
	if !ok {
		return nil, ierr("E_BAD_ATOMIC", "atomic must be a supported operation object")
	}
	if a.Has("hold") && a.Has("decide") {
		return nil, ierr("E_MIXED_ATOMIC", "mixed hold+decide is not a supported atomic form", "tern")
	}
	var op []string
	for _, k := range a.Keys() {
		if k != "grant_ref" {
			op = append(op, k)
		}
	}
	if len(op) != 1 || (op[0] != "hold" && op[0] != "decide") {
		keys := a.Keys()
		sort.Strings(keys)
		ks := make([]any, len(keys))
		for i, k := range keys {
			ks[i] = k
		}
		return nil, ierr("E_BAD_ATOMIC", "unsupported atomic form: "+py.Repr(ks))
	}
	// grant_ref belongs to hold only; a decide carrying one is refused
	// rather than silently dropped (R13, finding 7).
	if a.Has("decide") && a.Get("grant_ref") != nil {
		return nil, ierr("E_BAD_ATOMIC", "decide with grant_ref is not a supported atomic form", "tern")
	}
	if a.Has("hold") {
		if atomicActor != nil {
			return nil, ierr("E_FORGED_ATTRIBUTION", "atomic hold attribution is store-fixed", "tern")
		}
		dl, ok := py.Instant(a.Get("hold"))
		return nil, g.grantCover("hold", dl, ok, recorded, grants, a.Get("grant_ref"))
	}
	sub, ok := a.Get("decide").(*py.Dict)
	if !ok {
		return nil, ierr("E_BAD_ATOMIC", "decide malformed")
	}
	if sub.Has("actor") {
		return nil, ierr("E_FORGED_ATTRIBUTION", "atomic decide actor must come from the trusted context", "tern")
	}
	if atomicActor == nil {
		return nil, ierr("E_UNTRUSTED_ACTOR", "atomic decide needs a trusted actor")
	}
	if _, err := g.bindActor(py.NewDict(), atomicActor, "atomic decide"); err != nil {
		return nil, err
	}
	return sub, nil
}

func (g *Ingress) stampAtomicDecide(sub *py.Dict, recorded time.Time, atomicActor any) (*py.Dict, error) {
	stamped := sub.Copy()
	bound, err := g.bindActor(py.NewDict(), atomicActor, "atomic decide")
	if err != nil {
		return nil, err
	}
	stamped.Set("actor", bound)
	r, err := g.receipt(stamped, recorded)
	if err != nil {
		return nil, err
	}
	stamped.Set("at", r.Get("recorded_at"))
	stamped.Set("receipt", r)
	stamped.Set("_trusted", true)
	return stamped, nil
}

func (g *Ingress) checkAtomicPair(verdict, sub *py.Dict, budget *py.Dict) error {
	if !py.Eq(sub.Get("type"), "decide") {
		return ierr("E_BAD_ATOMIC", "atomic subevent must be type decide")
	}
	if !py.Eq(sub.Get("question_id"), verdict.Get("question_id")) ||
		!py.Eq(sub.GetOr("revision", int64(1)), verdict.GetOr("revision", int64(1))) {
		return ierr("E_BAD_ATOMIC", "atomic pair package/revision mismatch")
	}
	post, err := g.simulatePostPhase(verdict, budget)
	if err != nil {
		return err
	}
	if post == nil {
		return nil
	}
	if !isTerminal(post) {
		return ierr("E_PHASE_MISMATCH",
			"atomic disposition needs a terminal post-verdict phase, verdict lands "+py.S(post))
	}
	return nil
}

func (g *Ingress) simulatePostPhase(verdict, budget *py.Dict) (any, error) {
	q, rev := revOf(verdict)
	base := g.Store.base(q, rev)
	b := budget
	if !py.Truthy(b) {
		b = DefaultBudget()
	}
	rec, _, err := Apply(base.Copy(), verdict.Copy(), verdict.Get("at"), b)
	if err != nil {
		if _, ok := err.(*TransitionError); ok {
			return nil, nil
		}
		return nil, err
	}
	return rec.Get("phase"), nil
}

func (g *Ingress) stamped(event *py.Dict, recorded time.Time, grants *py.Dict, actor any, where string) (*py.Dict, error) {
	claim := event.Copy()
	bound, err := g.bindActor(claim, actor, where)
	if err != nil {
		return nil, err
	}
	r, err := g.receipt(claim, recorded)
	if err != nil {
		return nil, err
	}
	typ := claim.Get("type")
	q, rev := revOf(claim)
	if err := g.checkPhase(typ, q, rev); err != nil {
		return nil, err
	}
	if py.Eq(typ, "start") {
		err = g.startDeadline(claim, recorded, grants)
	} else {
		err = g.nestedDeadline(claim, recorded, grants)
	}
	if err != nil {
		return nil, err
	}
	claim.Set("actor", bound)
	claim.Set("at", r.Get("recorded_at"))
	claim.Set("receipt", r)
	claim.Set("_trusted", true)
	return claim, nil
}

func (g *Ingress) now() (time.Time, error) {
	t, ok := py.Instant(g.Clock.UtcNow())
	if !ok {
		return t, ierr("E_CLOCK", "clock did not return UTC")
	}
	return t, nil
}

// Append is the accepted external write route.
func (g *Ingress) Append(event, budget *py.Dict, atomic any, grants *py.Dict, actor, atomicActor any) (py.Tuple, error) {
	if err := g.requireContinuity(); err != nil {
		return nil, err
	}
	recorded, err := g.now()
	if err != nil {
		return nil, err
	}
	if err := g.checkContinuity(recorded); err != nil {
		return nil, err
	}
	if id, ok := event.Get("event_id").(string); ok && g.Store.SeenEvents[id] {
		return py.T("duplicate-ignored", true), nil
	}
	sub, err := g.checkAtomic(atomic, recorded, grants, atomicActor)
	if err != nil {
		return nil, err
	}
	claim, err := g.stamped(event, recorded, grants, actor, "append")
	if err != nil {
		return nil, err
	}
	atomicD := py.AsDict(atomic)
	if sub != nil {
		ss, err := g.stampAtomicDecide(sub, recorded, atomicActor)
		if err != nil {
			return nil, err
		}
		if err := g.checkAtomicPair(claim, ss, budget); err != nil {
			return nil, err
		}
		atomicD = atomicD.Copy()
		atomicD.Set("decide", ss)
	}
	return g.Store.Append(claim, budget, atomicD)
}

// RecordTerminal is the accepted external route for a verdict + decision.
func (g *Ingress) RecordTerminal(verdictEv, decideEv, budget, grants *py.Dict, actorV, actorD any) (py.Tuple, error) {
	if err := g.requireContinuity(); err != nil {
		return nil, err
	}
	recorded, err := g.now()
	if err != nil {
		return nil, err
	}
	if err := g.checkContinuity(recorded); err != nil {
		return nil, err
	}
	verdict, err := g.stamped(verdictEv, recorded, grants, actorV, "terminal verdict")
	if err != nil {
		return nil, err
	}
	decide, err := g.stampedDecide(decideEv, recorded, actorD)
	if err != nil {
		return nil, err
	}
	post, err := g.simulatePostPhase(verdict, budget)
	if err != nil {
		return nil, err
	}
	if post != nil && !isTerminal(post) {
		return nil, ierr("E_PHASE_MISMATCH",
			"terminal disposition needs a terminal post-verdict phase, verdict lands "+py.S(post))
	}
	if !py.Eq(decide.Get("question_id"), verdict.Get("question_id")) ||
		!py.Eq(decide.GetOr("revision", int64(1)), verdict.GetOr("revision", int64(1))) {
		return nil, ierr("E_BAD_ATOMIC", "terminal pair package/revision mismatch")
	}
	return g.Store.RecordTerminal(verdict, decide, budget)
}

func (g *Ingress) stampedDecide(event *py.Dict, recorded time.Time, actor any) (*py.Dict, error) {
	claim := event.Copy()
	bound, err := g.bindActor(claim, actor, "terminal decide")
	if err != nil {
		return nil, err
	}
	r, err := g.receipt(claim, recorded)
	if err != nil {
		return nil, err
	}
	claim.Set("actor", bound)
	claim.Set("at", r.Get("recorded_at"))
	claim.Set("receipt", r)
	claim.Set("_trusted", true)
	return claim, nil
}
