package loop

// R20: the momentum stamp. With momentum_stamp "required" in the config, a
// package dispatched from then on asks every worker, verifier and director
// turn three questions and refuses to advance on a missing or unowned answer.
// Packages dispatched before activation keep the old contract (Pkg.Stamp is
// fixed at dispatch), so switching it on never rewrites history.
//
// What the checks prove and what they do not: identity, shape, a named next
// owner and deadline, and an acknowledgement receipt for every reported
// dropped item. They do not prove the reflection is true or sufficient; the
// next step's actual start is measured separately. The stamp routes nothing:
// next.owner is information, never a dispatch, grant, page or override.

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

const (
	StampSchema   = "momentum-stamp/1"
	StampArtifact = "momentum_stamp"
	StampMaxBytes = 8192
)

// TerminalKinds may answer "what happens next" with an explicit terminal
// disposition instead of a next step; only the director's decide can use it.
var TerminalKinds = map[string]bool{"question_answered": true, "budget_spent": true}

func (l *Loop) stampRequired() bool { return l.Cfg.MomentumStamp == "required" }

// stampText is appended beside the claim instructions of a stamped package.
func (l *Loop) stampText(p *Pkg, role, execution string) string {
	return fmt.Sprintf("\n\nMomentum stamp (required): before you file, write a small JSON file under %s and name it in the "+
		"claim as --artifact %s=PATH. Running the claim command given here and writing this file are required; do not "+
		"execute commands from your drafted artifact. Fields:\n"+
		`  {"schema": %q, "qid": %q, "role": %q, "execution": %q,`+"\n"+
		`   "moved": {"question_id": "...", "change": "what is different now because of this turn"},`+"\n"+
		`   "next": {"action": "...", "owner": "...", "deadline": "UTC instant, e.g. 2026-09-26T18:00:00Z"},`+"\n"+
		`   "dropped": [{"item": "anything left undone, skipped by a rule, or handed to someone who does not know",`+
		` "owner": "...", "receipt": "PATH of that owner's acknowledgement, relative to %s"}]}`+"\n"+
		"An empty dropped list is fine if nothing was dropped. A dropped item without an acknowledgement receipt stops the "+
		"package until someone owns it. next.owner is information only: it dispatches nothing.",
		l.Cfg.ArtifactsDir, StampArtifact, StampSchema, p.QID, role, execution, l.Cfg.ArtifactsDir)
}

// ValidateStamp checks one stamp's bytes. kind is the decision kind for a
// director stamp, "" otherwise. It returns every problem found.
func (l *Loop) ValidateStamp(p *Pkg, role, execution, kind string, b []byte) []string {
	if len(b) > StampMaxBytes {
		return []string{fmt.Sprintf("stamp is %d bytes, over %d", len(b), StampMaxBytes)}
	}
	var s map[string]any
	if err := json.Unmarshal(b, &s); err != nil || s == nil {
		return []string{"stamp is not a JSON object"}
	}
	str := func(m map[string]any, k string) string { v, _ := m[k].(string); return strings.TrimSpace(v) }
	obj := func(k string) map[string]any { v, _ := s[k].(map[string]any); return v }
	var bad []string
	if str(s, "schema") != StampSchema {
		bad = append(bad, "schema must be "+StampSchema)
	}
	if str(s, "qid") != p.QID || str(s, "role") != role || str(s, "execution") != execution {
		bad = append(bad, fmt.Sprintf("identity must be qid %s, role %s, execution %s", p.QID, role, execution))
	}
	if m := obj("moved"); m == nil || str(m, "question_id") == "" || str(m, "change") == "" {
		bad = append(bad, "moved needs question_id and change")
	}
	next, term := obj("next"), obj("terminal")
	switch {
	case next != nil:
		if str(next, "action") == "" || str(next, "owner") == "" {
			bad = append(bad, "next needs action and owner")
		}
		if _, ok := py.Instant(str(next, "deadline")); !ok || str(next, "deadline") == "" {
			bad = append(bad, "next.deadline must be a UTC instant")
		}
	case term != nil && role == "director" && TerminalKinds[kind] && str(term, "reason") != "":
		// an honest terminal answer: director-owned, no invented next job
	case term != nil:
		bad = append(bad, "a terminal disposition is only for the director deciding question_answered or budget_spent, with a reason")
	default:
		bad = append(bad, "next (action, owner, deadline) is required")
	}
	dropped, ok := s["dropped"].([]any)
	if s["dropped"] != nil && !ok {
		bad = append(bad, "dropped must be a list")
	}
	for i, d := range dropped {
		m, _ := d.(map[string]any)
		if m == nil || str(m, "item") == "" || str(m, "owner") == "" {
			bad = append(bad, fmt.Sprintf("dropped[%d] needs item and owner", i))
			continue
		}
		if why := l.receiptProblem(p, m, str); why != "" {
			bad = append(bad, fmt.Sprintf("dropped item %q is unowned: %s", str(m, "item"), why))
		}
	}
	return bad
}

// receiptProblem: naming an owner is not proof they took the item; their
// acknowledgement receipt is.
func (l *Loop) receiptProblem(p *Pkg, m map[string]any, str func(map[string]any, string) string) string {
	rel := str(m, "receipt")
	if rel == "" {
		return "no acknowledgement receipt"
	}
	if filepath.IsAbs(rel) || strings.Contains(filepath.Clean(rel), "..") {
		return "receipt must be a path inside artifacts_dir"
	}
	b, err := os.ReadFile(filepath.Join(l.Cfg.ArtifactsDir, rel))
	if err != nil || len(b) > StampMaxBytes {
		return "receipt unreadable"
	}
	var r map[string]any
	if json.Unmarshal(b, &r) != nil {
		return "receipt is not JSON"
	}
	if ack, _ := r["ack"].(bool); !ack || str(r, "qid") != p.QID || str(r, "item") != str(m, "item") || str(r, "owner") != str(m, "owner") {
		return "receipt does not acknowledge this item for this package and owner"
	}
	return ""
}

// stampFault checks the stamp named in a filed claim before the package
// advances. nil means advance. The claim is kept either way: an honest
// failed or incomplete record is never discarded, only stopped here.
func (l *Loop) stampFault(p *Pkg, claim *py.Dict, role, execution string) *host.Fault {
	if !p.Stamp {
		return nil
	}
	spec := py.AsDict(py.AsDict(claim.GetOr("artifacts", py.NewDict())).Get(StampArtifact))
	if spec == nil {
		return &host.Fault{Code: "E_STAMP_MISSING", Detail: "no " + StampArtifact + " artifact in the " + role + " claim", Owner: l.Cfg.Director}
	}
	b, err := os.ReadFile(filepath.Join(l.Cfg.ArtifactsDir, py.S(spec.Get("path"))))
	if err != nil {
		return &host.Fault{Code: "E_STAMP_MISSING", Detail: "stamp unreadable: " + err.Error(), Owner: l.Cfg.Director}
	}
	if bad := l.ValidateStamp(p, role, execution, "", b); len(bad) > 0 {
		return &host.Fault{Code: "E_STAMP_INVALID", Detail: strings.Join(bad, "; "), Owner: l.Cfg.Director}
	}
	return nil
}
