package loop

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
)

// P12-lock-budget-1: every lock hold is bounded; work yields, I/O is capped.

func shortBudget(t *testing.T, hold, reserve, minio time.Duration) {
	h, u, m := HoldBudget, UnitReserve, MinIO
	HoldBudget, UnitReserve, MinIO = hold, reserve, minio
	t.Cleanup(func() { HoldBudget, UnitReserve, MinIO = h, u, m })
}

func TestTheBudgetedRunnerCapsAndRefusesIO(t *testing.T) {
	r := newRig(t)
	var got []time.Duration
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		got = append(got, timeout)
		return host.Proc{}, nil
	}
	shortBudget(t, 2*time.Second, time.Second, 500*time.Millisecond)
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	r.cfg.Run([]string{"x"}, nil, 30*time.Second)
	if len(got) != 1 || got[0] > 2*time.Second {
		t.Fatalf("a 30 s I/O was not capped to the hold budget: %v", got)
	}
	time.Sleep(1600 * time.Millisecond) // < MinIO left
	if _, err := r.cfg.Run([]string{"x"}, nil, 30*time.Second); err != host.ErrBudget || len(got) != 1 {
		t.Fatalf("an I/O started with too little budget left: %v %v", err, got)
	}
	k.Unlock()
	if !r.cfg.HoldDeadline.IsZero() {
		t.Fatal("the hold deadline outlived the lock")
	}
	if _, err := r.cfg.Run([]string{"x"}, nil, 30*time.Second); err != nil || got[len(got)-1] != 30*time.Second {
		t.Fatalf("the unlocked runner is still budgeted: %v %v", err, got)
	}
}

func TestAPassYieldsWhenTheBudgetIsShortAndSaysSo(t *testing.T) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(Request{QID: "Q", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 600, VerifyS: 600})
	must(t, err)
	l.Close()
	shortBudget(t, 3*time.Second, 5*time.Second, 500*time.Millisecond) // reserve > budget: no unit fits
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	defer k.Unlock()
	l = r.open()
	defer l.Close()
	msgs, err := l.Tick()
	must(t, err)
	if !l.Yielded || !strings.Contains(strings.Join(msgs, "|"), "yield") {
		t.Fatalf("no yield: %v", msgs)
	}
	must(t, l.RecordPass(1, len(msgs), nil))
	p, _ := ReadPass(r.cfg.DB)
	if p == nil || !p.Yielded {
		t.Fatalf("the heartbeat hides the yield: %+v", p)
	}
}

func TestDueMarkersAreBudgetedOldestFirstAndSaturationIsReported(t *testing.T) {
	r := newRig(t)
	for _, q := range []string{"A", "B"} {
		l := r.open()
		_, err := l.Dispatch(Request{QID: q, Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 60})
		must(t, err)
		l.Close()
	}
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	old := time.Now().UTC().Add(-time.Minute)
	WriteDue(r.cfg, "B", "B-w1", "ex-B-w1", old)                  // older
	WriteDue(r.cfg, "A", "A-w1", "ex-A-w1", old.Add(time.Second)) // newer
	shortBudget(t, 2*time.Second, 5*time.Second, 500*time.Millisecond)
	k, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	msgs := ProcessDue(r.cfg) // no unit fits: nothing settled, both kept, saturation told to duty
	k.Unlock()
	j := strings.Join(msgs, "|")
	if !strings.Contains(j, "lock budget spent") || !strings.Contains(j, "SATURATED: 2") || r.fresh("A") != nil || r.fresh("B") != nil {
		t.Fatalf("budget/saturation: %v", msgs)
	}
	sat := 0
	for _, w := range r.wakesTo("T") {
		if strings.Contains(w, "SATURATED") {
			sat++
		}
	}
	order := ProcessDue(r.cfg) // unlocked (no budget): settles both, oldest first; saturation not re-sent within a minute
	if sat != 1 || r.fresh("A") == nil || r.fresh("B") == nil {
		t.Fatalf("saturation wakes %d; A %+v B %+v", sat, r.fresh("A"), r.fresh("B"))
	}
	j2 := strings.Join(order, "|")
	if strings.Index(j2, "due B-w1.json: settled") < 0 || strings.Index(j2, "due B-w1.json: settled") > strings.Index(j2, "due A-w1.json: settled") {
		t.Fatalf("not oldest first: %v", order)
	}
	if _, err := os.Stat(filepath.Join(r.cfg.DB+".due", "A-w1.json")); err == nil {
		t.Fatal("settled marker left")
	}
}
