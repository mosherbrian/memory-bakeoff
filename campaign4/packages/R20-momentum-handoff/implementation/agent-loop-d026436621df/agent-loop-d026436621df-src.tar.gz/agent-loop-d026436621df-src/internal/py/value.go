// Package py holds the small slice of Python value semantics the reference
// implementation depends on: insertion-ordered dicts, the int/float split,
// Python equality, `%s` formatting and json.dumps(sort_keys=True) output.
//
// The reference is Python, and its observable behaviour leaks these rules:
// the order of a snapshot's in-flight list follows dict insertion order, a
// durable key holds the exact text json.dumps wrote, and a detail string
// prints None as "None". Matching them is what lets the conformance suite
// compare a Go run with a Python run value for value.
//
// Values are: nil, bool, int64, float64, string, *Dict, []any, Tuple, *Set.
package py

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
)

// Dict is an insertion-ordered string-keyed map, like a Python dict.
type Dict struct {
	keys []string
	m    map[string]any
}

func NewDict() *Dict { return &Dict{m: map[string]any{}} }

// D builds a Dict from alternating key, value arguments.
func D(kv ...any) *Dict {
	d := NewDict()
	for i := 0; i+1 < len(kv); i += 2 {
		d.Set(kv[i].(string), kv[i+1])
	}
	return d
}

func (d *Dict) Len() int {
	if d == nil {
		return 0
	}
	return len(d.keys)
}

func (d *Dict) Keys() []string {
	if d == nil {
		return nil
	}
	return append([]string(nil), d.keys...)
}

func (d *Dict) Has(k string) bool {
	if d == nil {
		return false
	}
	_, ok := d.m[k]
	return ok
}

// Get is dict.get(k): nil when absent.
func (d *Dict) Get(k string) any {
	if d == nil {
		return nil
	}
	return d.m[k]
}

// GetOr is dict.get(k, def).
func (d *Dict) GetOr(k string, def any) any {
	if d == nil {
		return def
	}
	if v, ok := d.m[k]; ok {
		return v
	}
	return def
}

func (d *Dict) Set(k string, v any) {
	if _, ok := d.m[k]; !ok {
		d.keys = append(d.keys, k)
	}
	d.m[k] = v
}

// Pop is dict.pop(k, None).
func (d *Dict) Pop(k string) any {
	v, ok := d.m[k]
	if !ok {
		return nil
	}
	delete(d.m, k)
	for i, x := range d.keys {
		if x == k {
			d.keys = append(d.keys[:i], d.keys[i+1:]...)
			break
		}
	}
	return v
}

// Copy is dict(d): a shallow copy.
func (d *Dict) Copy() *Dict {
	n := NewDict()
	if d == nil {
		return n
	}
	for _, k := range d.keys {
		n.Set(k, d.m[k])
	}
	return n
}

// Update is d.update(o).
func (d *Dict) Update(o *Dict) {
	if o == nil {
		return
	}
	for _, k := range o.keys {
		d.Set(k, o.m[k])
	}
}

// Tuple is a Python tuple. It serialises distinctly from a list.
type Tuple []any

func T(v ...any) Tuple { return Tuple(v) }

// Set is a Python set of hashable scalars.
type Set struct{ m map[string]any }

func NewSet() *Set { return &Set{m: map[string]any{}} }

func setKey(v any) string { return fmt.Sprintf("%T:%s", v, Repr(v)) }

func (s *Set) Add(v any)      { s.m[setKey(v)] = v }
func (s *Set) Has(v any) bool { _, ok := s.m[setKey(v)]; return ok }
func (s *Set) Len() int       { return len(s.m) }
func (s *Set) Items() []any {
	out := make([]any, 0, len(s.m))
	for _, v := range s.m {
		out = append(out, v)
	}
	sort.Slice(out, func(i, j int) bool { return Dumps(out[i]) < Dumps(out[j]) })
	return out
}

// AsDict returns v as a dict, or nil when it is not one.
func AsDict(v any) *Dict {
	d, _ := v.(*Dict)
	return d
}

// Str reports whether v is a Python str.
func Str(v any) (string, bool) {
	s, ok := v.(string)
	return s, ok
}

// Int reports isinstance(v, int). Python bools are ints.
func Int(v any) (int64, bool) {
	switch x := v.(type) {
	case int64:
		return x, true
	case int:
		return int64(x), true
	case bool:
		if x {
			return 1, true
		}
		return 0, true
	}
	return 0, false
}

// Num returns v as a float for arithmetic, if it is a number.
func Num(v any) (float64, bool) {
	if i, ok := Int(v); ok {
		return float64(i), true
	}
	if f, ok := v.(float64); ok {
		return f, true
	}
	return 0, false
}

// Truthy is Python truthiness.
func Truthy(v any) bool {
	switch x := v.(type) {
	case nil:
		return false
	case bool:
		return x
	case int64:
		return x != 0
	case int:
		return x != 0
	case float64:
		return x != 0
	case string:
		return x != ""
	case *Dict:
		return x.Len() > 0
	case []any:
		return len(x) > 0
	case Tuple:
		return len(x) > 0
	case *Set:
		return x.Len() > 0
	}
	return true
}

// Eq is Python ==.
func Eq(a, b any) bool {
	if fa, ok := Num(a); ok {
		if fb, ok := Num(b); ok {
			return fa == fb
		}
		return false
	}
	switch x := a.(type) {
	case nil:
		return b == nil
	case string:
		y, ok := b.(string)
		return ok && x == y
	case *Dict:
		y, ok := b.(*Dict)
		if !ok || x.Len() != y.Len() {
			return false
		}
		for _, k := range x.keys {
			if !y.Has(k) || !Eq(x.m[k], y.m[k]) {
				return false
			}
		}
		return true
	case []any:
		y, ok := b.([]any)
		return ok && seqEq(x, y)
	case Tuple:
		y, ok := b.(Tuple)
		return ok && seqEq(x, y)
	}
	return false
}

func seqEq(a, b []any) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if !Eq(a[i], b[i]) {
			return false
		}
	}
	return true
}

// S formats v the way Python's "%s" does.
func S(v any) string {
	switch x := v.(type) {
	case nil:
		return "None"
	case bool:
		if x {
			return "True"
		}
		return "False"
	case string:
		return x
	}
	return Repr(v)
}

// Repr is Python repr() for the value kinds this code handles.
func Repr(v any) string {
	switch x := v.(type) {
	case nil, bool:
		return S(v)
	case int64:
		return strconv.FormatInt(x, 10)
	case int:
		return strconv.Itoa(x)
	case float64:
		return FloatRepr(x)
	case string:
		return reprStr(x)
	case []any:
		return "[" + joinRepr(x) + "]"
	case Tuple:
		if len(x) == 1 {
			return "(" + Repr(x[0]) + ",)"
		}
		return "(" + joinRepr(x) + ")"
	case *Dict:
		parts := make([]string, 0, x.Len())
		for _, k := range x.keys {
			parts = append(parts, reprStr(k)+": "+Repr(x.m[k]))
		}
		return "{" + strings.Join(parts, ", ") + "}"
	}
	return fmt.Sprint(v)
}

func joinRepr(xs []any) string {
	parts := make([]string, len(xs))
	for i, x := range xs {
		parts[i] = Repr(x)
	}
	return strings.Join(parts, ", ")
}

func reprStr(s string) string {
	q := "'"
	if strings.Contains(s, "'") && !strings.Contains(s, "\"") {
		q = "\""
	}
	var b strings.Builder
	b.WriteString(q)
	for _, r := range s {
		switch {
		case r == '\\':
			b.WriteString(`\\`)
		case string(r) == q:
			b.WriteString(`\` + q)
		case r == '\n':
			b.WriteString(`\n`)
		case r == '\r':
			b.WriteString(`\r`)
		case r == '\t':
			b.WriteString(`\t`)
		case r < 0x20 || r == 0x7f:
			fmt.Fprintf(&b, `\x%02x`, r)
		default:
			b.WriteRune(r)
		}
	}
	b.WriteString(q)
	return b.String()
}

// FloatRepr is Python repr(float).
func FloatRepr(f float64) string {
	switch {
	case f != f:
		return "nan"
	case f > 1.7976931348623157e308:
		return "inf"
	case f < -1.7976931348623157e308:
		return "-inf"
	}
	e := strconv.FormatFloat(f, 'e', -1, 64)
	exp, _ := strconv.Atoi(e[strings.IndexByte(e, 'e')+1:])
	if exp >= -4 && exp < 16 {
		s := strconv.FormatFloat(f, 'f', -1, 64)
		if !strings.ContainsAny(s, ".") {
			s += ".0"
		}
		return s
	}
	return e
}

// SortedStrings is sorted() over a set of strings.
func SortedStrings(m map[string]bool) []any {
	ks := make([]string, 0, len(m))
	for k := range m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	out := make([]any, len(ks))
	for i, k := range ks {
		out[i] = k
	}
	return out
}
