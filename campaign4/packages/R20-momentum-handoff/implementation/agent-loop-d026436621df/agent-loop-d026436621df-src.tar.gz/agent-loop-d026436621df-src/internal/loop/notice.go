package loop

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// P12-fair-handoff-1 D3: a person cannot be told exactly once when the sender
// dies mid-send, so the loop does not claim it. Every send has a stable
// incident identity. Its attempt is recorded durably BEFORE the wake runs. A
// replay that finds an attempt with no known outcome (a crash, a timeout, a
// malformed receipt) sends ONE labelled repeat for that incident, across all
// restarts. After that the notice is "unresolved": visible, never recorded as
// delivered or acknowledged. A definitive failure (the wake refused) is
// retried with backoff, at most MaxFailedSends times. A /cancel is never
// repeated after an unknown outcome (no extra cancel).
const MaxFailedSends = 5

type noticeRec struct {
	Key       string `json:"key"`
	State     string `json:"state"` // attempting | accepted | ambiguous | failed | not-started | unresolved
	Attempts  int    `json:"attempts"`
	Repeats   int    `json:"repeats"`
	Failures  int    `json:"failures"`
	NextRetry string `json:"next_retry,omitempty"`
	LastMID   string `json:"last_mid,omitempty"`
	LastState string `json:"last_state,omitempty"`
	Updated   string `json:"updated"`
}

func noticeKey(key string) string {
	h := sha256.Sum256([]byte(key))
	return "notice:" + hex.EncodeToString(h[:12])
}

func deliveryFault(code, detail string) error {
	return &host.Fault{Code: code, Detail: detail, Owner: "cairn"}
}

// sendIncident delivers text to session id once per incident key (see above).
func (l *Loop) sendIncident(incident, id, text, kind, action string) error {
	key := id + "|" + kind + "|" + incident
	kv := noticeKey(key)
	var r noticeRec
	if raw, ok := l.D.KV[kv]; ok && json.Unmarshal([]byte(raw), &r) != nil {
		r = noticeRec{State: "unresolved"} // an unreadable record is never read as "not sent"
	}
	now := l.now()
	save := func() error {
		r.Key, r.Updated = key, py.ISO(now)
		b, _ := json.Marshal(r)
		return l.D.KVPut(kv, string(b))
	}
	switch r.State {
	case "accepted":
		return nil // this incident's notice was accepted by the transport already
	case "unresolved":
		return deliveryFault("E_DELIVERY_UNRESOLVED", fmt.Sprintf("notice %s to %s: delivery unknown after its one labelled repeat, or failed %d times; reconcile by hand", kv, id, r.Failures))
	case "attempting", "ambiguous":
		if kind == "stop" || r.Repeats >= 1 {
			r.State = "unresolved"
			if err := save(); err != nil {
				return err
			}
			return deliveryFault("E_DELIVERY_UNRESOLVED", fmt.Sprintf("notice %s to %s: the outcome of an earlier send is unknown (%s)", kv, id, r.LastState))
		}
		r.Repeats = 1
	case "failed":
		if r.Failures >= MaxFailedSends {
			r.State = "unresolved"
			if err := save(); err != nil {
				return err
			}
			return deliveryFault("E_DELIVERY_UNRESOLVED", fmt.Sprintf("notice %s to %s: refused %d times", kv, id, r.Failures))
		}
		if t, ok := py.Instant(r.NextRetry); ok && now.Before(t) {
			return deliveryFault("E_DELIVERY_BACKOFF", fmt.Sprintf("notice %s to %s: refused %d time(s); next retry at %s", kv, id, r.Failures, r.NextRetry))
		}
	}
	if r.Repeats >= 1 && kind != "stop" {
		text = "REPEAT (" + kv + "): an earlier send of this notice may or may not have arrived. " + text
	}
	prev := r.State
	r.State = "attempting"
	r.Attempts++
	if err := save(); err != nil { // durable before the wake runs
		return err
	}
	var act any
	if action != "" {
		act = action
	}
	mid, err := l.Adapter.Transport.Send(id, text, kind, act, nil)
	if err != nil {
		if f, ok := host.IsFault(err); ok && f.Code == "E_BUDGET_EXHAUSTED" {
			r.State, r.Attempts = "not-started", r.Attempts-1 // never started: no attempt, no repeat used
			if prev == "failed" {
				r.State = "failed"
			}
		} else {
			r.State, r.LastState = "ambiguous", err.Error()
		}
		if serr := save(); serr != nil {
			return serr
		}
		return err
	}
	st := l.Adapter.Transport.State(mid)
	r.LastMID, r.LastState = mid, st
	switch {
	case st == "sent" || st == "queued", kind == "stop" && (st == "cancelled" || st == "idle"):
		r.State = "accepted"
	case st == "failed":
		r.State = "failed"
		r.Failures++
		// The first retry is immediate (the next pass or replay); then 1, 2, 4... s, at most 32 s.
		if r.Failures > 1 {
			r.NextRetry = py.ISO(now.Add(time.Duration(1<<min(r.Failures-2, 5)) * time.Second))
		}
	default:
		r.State = "ambiguous"
	}
	if err := save(); err != nil {
		return err
	}
	if r.State != "accepted" {
		return fmt.Errorf("wake to %s: %s (receipt %s)", id, st, mid)
	}
	return nil
}
