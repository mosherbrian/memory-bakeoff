package loop

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// P12-ack-capacity-1: a timeout acknowledgement must commit within AckBound
// of the authoritative detection: the EARLIEST trusted time the loop knew the
// deadline had passed (the due marker's written time when the callback had
// to leave one, else the settlement time). Detection never moves on retry.
//
// Scheduling bound (see lockQueue.pick). timeout-ack (class "ack", one
// place) is granted before every other writer, except that it may have to
// let ONE non-priority writer go first when the previous grant was a
// priority one. So an admitted ack waits at most for the current holder and
// one other writer (each HoldBudget + 0.5 s WaitDelay), then commits locally
// before any due work (measured under 0.2 s): 2 x 10.5 s + 1 s = 22 s,
// declared AckWorstCase = 25 s. A request refused at admission (the one ack
// place is taken) is drained by that ack's holder, which commits every
// pending request first: the same bound. So a requester that waits can be
// promised the bound if it submits by detection + 60 s - 25 s = detection +
// 35 s. If the requester exits before it is admitted, and run is stopped,
// the next drain is the outside liveness check on its own 30 s calendar timer
// (AccuracySec 1 s): 31 s + the same 22 s = 53 s, declared AckStoppedWorst =
// 55 s, so the promise for that path needs submission by detection + 5 s.
// Later requests are still committed, but are told up front that no timely
// promise is made; a commit after the bound is recorded late and escalated.
//
// Durable retry. Every request is written to <db>.acks/ BEFORE the lock is
// tried, so it survives the requester's exit and any restart. Every ledger
// holder drains pending requests before its due work (ProcessDue): run,
// callbacks, dispatch, and, when run is stopped, the outside liveness check on
// its own timer. A pending request is NOT an acknowledgement: only a commit
// through AckTimeout on a fresh ledger (principal, authority, action, next
// action, response deadline revalidated) records one.
const (
	AckBound        = 60 * time.Second
	AckWorstCase    = 25 * time.Second
	AckStoppedWorst = 55 * time.Second
	MaxPendingAcks  = 16
	KeepAckResults  = 64
)

// AckRequest is a durable timeout-ack request.
type AckRequest struct {
	QID       string `json:"qid"`
	Action    string `json:"action"`
	By        string `json:"by"`
	Next      string `json:"next"`
	Deadline  string `json:"response_deadline"` // absolute: submitted + --within
	Submitted string `json:"submitted_at"`
	PID       int    `json:"pid"`
	// Outcome fields (in done/ only).
	Outcome     string `json:"outcome,omitempty"` // committed | rejected
	Reason      string `json:"reason,omitempty"`
	CommittedAt string `json:"committed_at,omitempty"`
	Detection   string `json:"detection,omitempty"`
	Late        bool   `json:"late,omitempty"`
	LateNotice  string `json:"late_notice,omitempty"`
}

func ackDir(cfg *Config) string { return cfg.DB + ".acks" }

func ackName(r AckRequest) string {
	h := sha256.Sum256([]byte(r.QID + "|" + r.Action + "|" + r.By))
	return hex.EncodeToString(h[:12]) + ".json"
}

// SubmitAck records a request durably. An identical pending request is a
// replay; a different one from the same principal for the same action is a
// conflict; more than MaxPendingAcks pending is refused (E_ACK_QUEUE_FULL).
func SubmitAck(cfg *Config, r AckRequest) (AckRequest, error) {
	if err := os.MkdirAll(ackDir(cfg), 0o755); err != nil {
		return r, err
	}
	var path string
	err := newQueue(cfg).locked(func() error { // the queue mutex also guards the request store
		path = filepath.Join(ackDir(cfg), ackName(r))
		if b, err := os.ReadFile(path); err == nil {
			var old AckRequest
			if json.Unmarshal(b, &old) == nil && old.Next == r.Next {
				r = old // replay of a pending request: the first one stands
				return nil
			}
			return fmt.Errorf("E_ACK_CONFLICT: a different pending request by %s for %s exists (%s)", r.By, r.Action, path)
		}
		if n := len(pendingAcks(cfg)); n >= MaxPendingAcks {
			return fmt.Errorf("E_ACK_QUEUE_FULL: %d requests already pending in %s; nothing recorded", n, ackDir(cfg))
		}
		b, _ := json.Marshal(r)
		tmp := path + ".tmp"
		if err := os.WriteFile(tmp, b, 0o644); err != nil {
			return err
		}
		return os.Rename(tmp, path)
	})
	return r, err
}

func pendingAcks(cfg *Config) []string {
	ents, _ := os.ReadDir(ackDir(cfg))
	var out []string
	for _, e := range ents {
		if n := e.Name(); strings.HasSuffix(n, ".json") && !e.IsDir() {
			out = append(out, n)
		}
	}
	return out
}

// AckResult reads a request's outcome (nil while pending).
func AckResult(cfg *Config, r AckRequest) *AckRequest {
	b, err := os.ReadFile(filepath.Join(ackDir(cfg), "done", ackName(r)))
	if err != nil {
		return nil
	}
	var d AckRequest
	if json.Unmarshal(b, &d) != nil || d.Submitted != r.Submitted || d.Next != r.Next {
		return nil // an older request's outcome, not this one's
	}
	return &d
}

// processAcks commits or rejects every pending request, oldest first. The
// caller holds the ledger lock. It escalates, once, a commit after the bound
// and a request still pending past it.
func processAcks(cfg *Config) []string {
	names := pendingAcks(cfg)
	if len(names) == 0 {
		return nil
	}
	reqs := map[string]AckRequest{}
	for _, n := range names {
		var r AckRequest
		b, err := os.ReadFile(filepath.Join(ackDir(cfg), n))
		if err != nil || json.Unmarshal(b, &r) != nil {
			r = AckRequest{Outcome: "rejected", Reason: "unreadable request"}
		}
		reqs[n] = r
	}
	sort.Slice(names, func(i, j int) bool { return reqs[names[i]].Submitted < reqs[names[j]].Submitted })
	l, err := Open(cfg, nil)
	if err != nil {
		return []string{"acks: ledger not opened, requests stay pending: " + err.Error()}
	}
	defer l.Close()
	var out []string
	for i, n := range names {
		if budgetShort(cfg) {
			out = append(out, fmt.Sprintf("acks: lock budget short; %d request(s) stay pending for the next holder", len(names)-i))
			break
		}
		r := reqs[n]
		now := l.now()
		if r.Outcome == "" {
			if p := l.Pkg(r.QID); p != nil && p.Timeout != nil {
				r.Detection = Detection(p.Timeout)
			}
			dl, ok := py.Instant(r.Deadline)
			switch {
			case !ok || !now.Before(dl):
				r.Outcome, r.Reason = "rejected", "the requested response deadline "+r.Deadline+" has passed"
			default:
				a, err := l.AckTimeout(r.QID, r.Action, r.By, r.Next, dl.Sub(now).Round(time.Second))
				if f, ok := host.IsFault(err); ok && f.Code == "E_BUDGET_EXHAUSTED" {
					out = append(out, "ack "+n+": not checked (lock budget spent); stays pending for the next holder")
					continue // transient: never a rejection
				}
				if err != nil {
					r.Outcome, r.Reason = "rejected", err.Error()
				} else {
					r.Outcome, r.CommittedAt = "committed", a.At
				}
			}
		}
		if det, ok := py.Instant(r.Detection); ok && r.Outcome == "committed" {
			if at, ok := py.Instant(r.CommittedAt); ok && at.Sub(det) > AckBound {
				r.Late = true
				msg := fmt.Sprintf("[agent-loop] %s: the acknowledgement of T-%s by %s committed %s after detection (bound %s). It is recorded; the bound was missed.",
					r.QID, r.Action, r.By, at.Sub(det).Round(time.Second), AckBound)
				if err := l.sendSeat("acklate|"+r.QID+"|"+r.Action, l.Cfg.Director, msg, "escalation", r.QID); err != nil {
					r.LateNotice = "failed: " + err.Error()
				} else {
					r.LateNotice = "sent"
				}
			}
		}
		if err := finishAck(cfg, n, r); err != nil {
			out = append(out, "ack "+n+": outcome not recorded, stays pending: "+err.Error())
			continue
		}
		out = append(out, fmt.Sprintf("ack %s/%s by %s: %s %s", r.QID, r.Action, r.By, r.Outcome, r.Reason))
	}
	return out
}

func finishAck(cfg *Config, n string, r AckRequest) error {
	done := filepath.Join(ackDir(cfg), "done")
	if err := os.MkdirAll(done, 0o755); err != nil {
		return err
	}
	b, _ := json.Marshal(r)
	if err := os.WriteFile(filepath.Join(done, n+".tmp"), b, 0o644); err != nil {
		return err
	}
	if err := os.Rename(filepath.Join(done, n+".tmp"), filepath.Join(done, n)); err != nil {
		return err
	}
	if err := os.Remove(filepath.Join(ackDir(cfg), n)); err != nil {
		return err
	}
	// Keep the newest KeepAckResults outcomes.
	ents, _ := os.ReadDir(done)
	if len(ents) > KeepAckResults {
		sort.Slice(ents, func(i, j int) bool {
			a, _ := ents[i].Info()
			b, _ := ents[j].Info()
			return a.ModTime().Before(b.ModTime())
		})
		for _, e := range ents[:len(ents)-KeepAckResults] {
			os.Remove(filepath.Join(done, e.Name()))
		}
	}
	return nil
}

// ReadDetection reads a package's settlement time read-only (no lock, no
// write): the requester's up-front promise check. "" when not settled.
func ReadDetection(dbPath, qid string) string {
	db, err := sql.Open("sqlite", "file:"+dbPath+"?mode=ro&_pragma=busy_timeout(1000)")
	if err != nil {
		return ""
	}
	defer db.Close()
	var raw string
	if db.QueryRow("SELECT value FROM driver_kv WHERE key=?", "loop-pkg:"+qid).Scan(&raw) != nil {
		return ""
	}
	var p Pkg
	if json.Unmarshal([]byte(raw), &p) != nil || p.Timeout == nil {
		return ""
	}
	return Detection(p.Timeout)
}

// Detection is the earliest trusted detection time of a step timeout: the
// due marker's written time if the callback left one, else the settlement.
func Detection(t *StepTimeout) string {
	at, ok1 := py.Instant(t.At)
	d, ok2 := py.Instant(t.Deferred)
	if ok2 && (!ok1 || d.Before(at)) {
		return t.Deferred
	}
	return t.At
}
