// Package expose is the read-only status view (campaign 4 P9, reusing P7's
// requirements): what exists, what is running or blocked, who owns the next
// action, which decisions hold progress, and the loop's own overhead
// counts. It opens the ledger read-only and never writes anything; every
// value comes from a recorded event, a loop record or a declared,
// hash-pinned inventory pointer. Missing, stale or contradictory inputs are
// UNKNOWN or CONFLICT, never healthy. The view never reports the product as
// qualified: this build is a supervised preview.
package expose

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

// Label is printed on every view.
const Label = "SUPERVISED PREVIEW / NOT QUALIFIED FOR UNATTENDED USE"

// KnownLimits are the recorded reasons the product is not qualified
// (P8 terminal disposition and liveness-blockers addendum, 2026-09-23).
var KnownLimits = []string{
	"Not qualified for unattended use: P8 ended NOT READY; P10 requalification is in progress.",
	"The three P8 liveness blockers (damaged incident state, future pass time, process incarnation) are fixed in the P10 candidate and tested with stubs; not yet observed live.",
	"Real systemd behaviour (restart, watchdog, exit 64, start limit, timer accuracy) was never observed live; the unit files are unqualified examples.",
	"The CLI does not authenticate its caller: any host user who can run it acts for the recorded roles.",
	"Packages registered before principals were recorded cannot be continued (E_AUTHORITY_MISSING, by design).",
}

// StaleAfter matches the liveness check's threshold.
const StaleAfter = 100 * time.Second

// Inventory is a declared list of pointers to authoritative records the
// loop ledger does not hold (campaign decisions, qualification, code pins).
// It is pointers, not authority: each item is resolved against its file.
type Inventory struct {
	Items []Item `json:"items"`
}

// Item is one pointer.
type Item struct {
	ID         string   `json:"id"`
	Kind       string   `json:"kind"` // decision (open until resolved_by) | ruling | qualification | code | deployment | finding
	Title      string   `json:"title"`
	Status     string   `json:"status"` // as recorded in the source, copied verbatim
	Owner      string   `json:"owner,omitempty"`
	Question   string   `json:"question,omitempty"`
	Dependents []string `json:"dependents,omitempty"`
	NextAction string   `json:"next_action,omitempty"`
	Source     string   `json:"source"`
	SHA256     string   `json:"sha256"`
	ResolvedBy *Ref     `json:"resolved_by,omitempty"`
}

// Ref is a hash-pinned file.
type Ref struct {
	Source string `json:"source"`
	SHA256 string `json:"sha256"`
}

// Resolved is an item after its pointers were checked.
type Resolved struct {
	Item
	Evidence string `json:"evidence"` // OK | UNKNOWN: why | CONFLICT: why
}

// Pending is one decision that holds progress.
type Pending struct {
	ID         string   `json:"id"`
	Question   string   `json:"question"`
	Owner      string   `json:"owner"`
	Dependents []string `json:"dependents"`
	NextAction string   `json:"next_action"`
	Since      string   `json:"since,omitempty"`
	Source     string   `json:"source"`
	Evidence   string   `json:"evidence"`
}

// Package is one loop package as the ledger and the loop record show it.
type Package struct {
	QID        string            `json:"qid"`
	Step       string            `json:"step"`
	Since      string            `json:"since"`
	LastEvent  string            `json:"last_ledger_event"`
	Owner      string            `json:"owner"`
	NextAction string            `json:"next_action"`
	Verdict    string            `json:"verdict,omitempty"`
	After      []string          `json:"waits_for,omitempty"`
	Last       string            `json:"last_note,omitempty"`
	Principals map[string]string `json:"principals,omitempty"` // role -> seat (session)
}

// Step is one measured step, with the fields an external cost UI joins on.
type Step struct {
	QID       string `json:"qid"`
	Step      string `json:"step"` // worker | verify | decision
	Seat      string `json:"seat,omitempty"`
	Session   string `json:"session,omitempty"`
	StartedAt string `json:"started_at"`
	EndedAt   string `json:"ended_at,omitempty"`
	Seconds   *int64 `json:"seconds"` // nil: not ended or unknown
	Note      string `json:"note,omitempty"`
}

// Overhead is counted from ledger events by event type, never by name.
type Overhead struct {
	WorkerDispatches   int    `json:"worker_dispatches"`   // start events
	VerifierDispatches int    `json:"verifier_dispatches"` // publish events that open a verifier flight
	Repairs            int    `json:"repairs"`             // alloc_repair events (this loop has no repair path)
	Timeouts           int    `json:"timeouts"`            // interrupt events with reason deadline-expired
	DirectorDecisions  int    `json:"director_decisions"`  // decide events
	CurrentlyBlocked   int    `json:"currently_blocked"`   // packages now blocked/recovery/timed-out (a state, not an event count)
	BlockEvents        string `json:"block_events"`        // not recorded as ledger events
	Steps              []Step `json:"steps"`
	Costs              string `json:"costs"`
}

// View is the whole read-only view.
type View struct {
	Label       string     `json:"label"`
	AsOf        string     `json:"as_of"`
	Project     string     `json:"project"`
	Ledger      string     `json:"ledger"`
	Freshness   string     `json:"freshness"`
	Research    string     `json:"research"`
	Packages    []Package  `json:"packages"`
	Pending     []Pending  `json:"pending"`
	Resolved    []Resolved `json:"resolved"`
	Inventory   []Resolved `json:"inventory"`
	Overhead    *Overhead  `json:"overhead,omitempty"`
	KnownLimits []string   `json:"known_limits"`
	Problems    []string   `json:"problems,omitempty"` // UNKNOWN / CONFLICT, never hidden
}

type loopPkg struct {
	QID, Worker, Verifier, Step, Verdict string
	StepAt                               string   `json:"step_at"`
	After                                []string `json:"after"`
	Notes                                []string `json:"notes"`
	VerifyExec                           string   `json:"verify_exec"`
	WorkExec                             string   `json:"work_exec"`
	Principals                           map[string]struct{ Seat, Session string }
}

type event struct {
	ID, Q, Type, Seat, Role, At, Body string
}

// Options are the view's inputs.
type Options struct {
	Project   string
	DB        string
	Inventory string // optional
	BaseDir   string // inventory sources resolve against this
	ClaimsDir string
	Bin       string
	Config    string
	Director  string
	Now       time.Time
}

func fileHash(p string) (string, error) {
	b, err := os.ReadFile(p)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

func (o Options) resolve(p string) string {
	if filepath.IsAbs(p) || o.BaseDir == "" {
		return p
	}
	return filepath.Join(o.BaseDir, p)
}

func (o Options) check(r Ref) string {
	if r.Source == "" {
		return "UNKNOWN: no source"
	}
	h, err := fileHash(o.resolve(r.Source))
	if err != nil {
		return "UNKNOWN: " + r.Source + " unreadable"
	}
	if r.SHA256 == "" {
		return "UNKNOWN: " + r.Source + " has no pinned hash"
	}
	if h != r.SHA256 {
		return "CONFLICT: " + r.Source + " no longer matches its pinned hash"
	}
	return "OK"
}

// Build renders the view. It only reads.
func Build(o Options) (*View, error) {
	v := &View{Label: Label, AsOf: o.Now.UTC().Format(time.RFC3339), Project: o.Project, Ledger: o.DB,
		Research:    "Not advanced by this machinery: no research package has run through the loop.",
		KnownLimits: KnownLimits, Packages: []Package{}, Pending: []Pending{}, Resolved: []Resolved{}, Inventory: []Resolved{}}
	if o.Inventory != "" {
		b, err := os.ReadFile(o.Inventory)
		var inv Inventory
		if err == nil {
			err = json.Unmarshal(b, &inv)
		}
		if err != nil {
			v.Problems = append(v.Problems, "UNKNOWN: inventory "+o.Inventory+" unreadable: "+err.Error())
		}
		seen := map[string]bool{}
		for _, it := range inv.Items {
			r := Resolved{Item: it, Evidence: o.check(Ref{it.Source, it.SHA256})}
			if seen[it.ID] {
				r.Evidence = "CONFLICT: duplicate inventory id " + it.ID
			}
			seen[it.ID] = true
			if r.Evidence != "OK" {
				v.Problems = append(v.Problems, it.ID+": "+r.Evidence)
			}
			v.Inventory = append(v.Inventory, r)
			if it.Kind != "decision" {
				continue
			}
			if it.ResolvedBy != nil {
				if ev := o.check(*it.ResolvedBy); ev == "OK" {
					v.Resolved = append(v.Resolved, Resolved{Item: it, Evidence: "resolved by " + it.ResolvedBy.Source})
					continue
				} else {
					r.Evidence = ev + " (claimed resolution not verified)"
					v.Problems = append(v.Problems, it.ID+": "+r.Evidence)
				}
			}
			owner := it.Owner
			if owner == "" {
				owner = "UNKNOWN"
			}
			if it.Question == "" || it.NextAction == "" || it.Owner == "" {
				v.Problems = append(v.Problems, it.ID+": UNKNOWN: pending decision lacks an owner, question or next action")
				if it.Question == "" {
					it.Question = "UNKNOWN: no question recorded"
				}
				if it.NextAction == "" {
					it.NextAction = "UNKNOWN: no next action recorded"
				}
			}
			v.Pending = append(v.Pending, Pending{ID: it.ID, Question: it.Question, Owner: owner, Dependents: nonNil(it.Dependents),
				NextAction: it.NextAction, Source: it.Source, Evidence: r.Evidence})
		}
	}
	if err := o.ledger(v); err != nil {
		v.Problems = append(v.Problems, "UNKNOWN: ledger "+o.DB+": "+err.Error())
		v.Freshness = "UNKNOWN: ledger unreadable"
		v.Overhead = nil
	}
	sort.Slice(v.Pending, func(i, j int) bool { return v.Pending[i].ID < v.Pending[j].ID })
	return v, nil
}

func nonNil(xs []string) []string {
	if xs == nil {
		return []string{}
	}
	return xs
}

func (o Options) ledger(v *View) error {
	// Read a private copy of the ledger and its WAL. Opening the ledger
	// itself, even read-only, makes SQLite create or update its -wal and
	// -shm files; the view must change no file. A copy torn by a concurrent
	// writer fails to open or read, and the view then says UNKNOWN.
	snap, err := os.MkdirTemp("", "agent-loop-expose-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(snap)
	for _, suffix := range []string{"", "-wal"} {
		b, err := os.ReadFile(o.DB + suffix)
		if err != nil {
			if suffix == "" || !os.IsNotExist(err) {
				return err
			}
			continue
		}
		if err := os.WriteFile(filepath.Join(snap, "ledger.db"+suffix), b, 0o600); err != nil {
			return err
		}
	}
	db, err := sql.Open("sqlite", "file:"+filepath.Join(snap, "ledger.db")+"?mode=ro")
	if err != nil {
		return err
	}
	defer db.Close()
	kv := map[string]string{}
	rows, err := db.Query("SELECT key, value FROM driver_kv WHERE key LIKE 'loop-%'")
	if err != nil {
		return err
	}
	for rows.Next() {
		var k, val string
		rows.Scan(&k, &val)
		kv[k] = val
	}
	rows.Close()
	var evs []event
	rows, err = db.Query("SELECT event_id, question_id, type, COALESCE(actor_seat,''), COALESCE(actor_role,''), at, body FROM events ORDER BY rowid")
	if err != nil {
		return err
	}
	for rows.Next() {
		var e event
		rows.Scan(&e.ID, &e.Q, &e.Type, &e.Seat, &e.Role, &e.At, &e.Body)
		evs = append(evs, e)
	}
	rows.Close()
	phase := map[string]string{}
	pkgs := map[string]*loopPkg{}
	for k, val := range kv {
		if strings.HasPrefix(k, "loop-pkg:") {
			p := &loopPkg{}
			if json.Unmarshal([]byte(val), p) != nil || p.QID == "" {
				v.Problems = append(v.Problems, "CONFLICT: unreadable loop record "+k)
				continue
			}
			pkgs[p.QID] = p
		}
	}
	for _, e := range evs {
		phase[e.Q] = e.Type
	}
	// Freshness: the loop's last completed pass.
	v.Freshness = "UNKNOWN: no loop pass recorded (the loop has not run, or not since this ledger was created)"
	if pr := kv["loop-pass"]; pr != "" {
		var p struct {
			At  string `json:"at"`
			PID int    `json:"pid"`
		}
		if json.Unmarshal([]byte(pr), &p) == nil {
			if at, err := time.Parse(time.RFC3339, p.At); err == nil {
				age := o.Now.Sub(at)
				switch {
				case age < -5*time.Second:
					v.Freshness = fmt.Sprintf("UNKNOWN: last pass time %s is in the future (clock step?)", p.At)
					v.Problems = append(v.Problems, v.Freshness)
				case age > StaleAfter:
					v.Freshness = fmt.Sprintf("STALE: last loop pass %s, %s ago (pid %d)", p.At, age.Round(time.Second), p.PID)
					v.Problems = append(v.Problems, v.Freshness)
				default:
					v.Freshness = fmt.Sprintf("last loop pass %s, %s ago (pid %d; not proof this process is the current one)", p.At, age.Round(time.Second), p.PID)
				}
			}
		}
	}
	owner := func(p *loopPkg, role string) string {
		if pr, ok := p.Principals[role]; ok && pr.Seat != "" {
			return pr.Seat
		}
		return "UNKNOWN"
	}
	dependents := func(qid string) []string {
		var ds []string
		for _, p := range pkgs {
			for _, a := range p.After {
				if a == qid {
					ds = append(ds, p.QID)
				}
			}
		}
		sort.Strings(ds)
		return nonNil(ds)
	}
	var qids []string
	for q := range pkgs {
		qids = append(qids, q)
	}
	sort.Strings(qids)
	for _, q := range qids {
		p := pkgs[q]
		pk := Package{QID: q, Step: p.Step, Since: p.StepAt, LastEvent: phase[q], Verdict: p.Verdict, After: p.After}
		if n := len(p.Notes); n > 0 {
			pk.Last = p.Notes[n-1]
		}
		if len(p.Principals) > 0 {
			pk.Principals = map[string]string{}
			for r, pr := range p.Principals {
				pk.Principals[r] = pr.Seat + " (" + pr.Session + ")"
			}
		}
		decide := fmt.Sprintf("%s decide --config %s --qid %s --kind KIND --ref REF --reason TEXT", o.Bin, o.Config, q)
		if len(p.Principals) == 0 && p.Step != "closed" {
			// Registered before principals were recorded: every core step
			// is refused (E_AUTHORITY_MISSING), so no loop command can move it.
			decide = "none in the loop: registered without recorded principals (E_AUTHORITY_MISSING); dispose of it outside the loop"
			v.Problems = append(v.Problems, q+": UNKNOWN owner: no recorded principals; the loop cannot continue it")
		}
		switch p.Step {
		case "held":
			pk.Owner, pk.NextAction = "director (via prerequisites)", "waits for "+strings.Join(p.After, ", ")+" to close with an eligible decision"
		case "worker":
			pk.Owner, pk.NextAction = owner(p, "worker"), "finish the work, run agent-loop claim, end the turn"
		case "verify":
			pk.Owner, pk.NextAction = owner(p, "verifier"), "review, run agent-loop claim --step verify, end the turn"
		case "decision":
			pk.Owner, pk.NextAction = owner(p, "director"), decide
			v.Pending = append(v.Pending, Pending{ID: q + "/decision", Owner: pk.Owner, Dependents: dependents(q), Since: p.StepAt,
				Question:   fmt.Sprintf("The verifier returned %s for %s. Accept, answer, open a successor, or block?", p.Verdict, q),
				NextAction: decide, Source: filepath.Join(o.ClaimsDir, p.VerifyExec+".json"), Evidence: o.claimEvidence(p.VerifyExec)})
		case "blocked", "recovery", "timed-out":
			pk.Owner, pk.NextAction = owner(p, "director"), "read the last note and dispose: decide, or dispatch a new package"
			v.Pending = append(v.Pending, Pending{ID: q + "/" + p.Step, Owner: pk.Owner, Dependents: dependents(q), Since: p.StepAt,
				Question: fmt.Sprintf("%s is %s: %s", q, p.Step, pk.Last), NextAction: pk.NextAction,
				Source: o.DB + " (loop-pkg:" + q + ")", Evidence: "OK"})
		case "closed":
			pk.Owner, pk.NextAction = "none", "none"
			v.Resolved = append(v.Resolved, Resolved{Item: Item{ID: q + "/decision", Kind: "decision", Title: q, Status: "closed",
				Source: o.DB + " (decide event)"}, Evidence: "resolved: " + pk.Last})
		default:
			pk.Owner, pk.NextAction = "UNKNOWN", "UNKNOWN: unrecognised step "+p.Step
			v.Problems = append(v.Problems, "UNKNOWN: "+q+" has step "+p.Step)
		}
		v.Packages = append(v.Packages, pk)
	}
	v.Overhead = overhead(evs, pkgs, o.Now)
	return nil
}

func (o Options) claimEvidence(exec string) string {
	if exec == "" {
		return "UNKNOWN: no verifier execution recorded"
	}
	if _, err := os.Stat(filepath.Join(o.ClaimsDir, exec+".json")); err != nil {
		return "UNKNOWN: verifier claim missing"
	}
	return "OK"
}

func overhead(evs []event, pkgs map[string]*loopPkg, now time.Time) *Overhead {
	ov := &Overhead{BlockEvents: "not recorded as ledger events; see currently_blocked",
		Costs: "not in this binary: join steps[].session and started_at/ended_at with the provider's billing (e.g. go-budget)", Steps: []Step{}}
	type span struct{ start, pub, verdict, decide string }
	spans := map[string]*span{}
	get := func(q string) *span {
		if spans[q] == nil {
			spans[q] = &span{}
		}
		return spans[q]
	}
	for _, e := range evs {
		var body map[string]any
		json.Unmarshal([]byte(e.Body), &body)
		switch e.Type {
		case "start":
			ov.WorkerDispatches++
			if get(e.Q).start == "" {
				get(e.Q).start = e.At
			}
		case "publish":
			if _, ok := body["verify"]; ok {
				ov.VerifierDispatches++
			}
			if get(e.Q).pub == "" {
				get(e.Q).pub = e.At
			}
		case "verify_pass", "verify_fail":
			if get(e.Q).verdict == "" {
				get(e.Q).verdict = e.At
			}
		case "decide":
			ov.DirectorDecisions++
			if get(e.Q).decide == "" {
				get(e.Q).decide = e.At
			}
		case "interrupt":
			if r, _ := body["reason"].(string); r == "deadline-expired" {
				ov.Timeouts++
			}
		case "alloc_repair":
			ov.Repairs++
		}
	}
	for _, p := range pkgs {
		switch p.Step {
		case "blocked", "recovery", "timed-out":
			ov.CurrentlyBlocked++
		}
	}
	var qs []string
	for q := range spans {
		qs = append(qs, q)
	}
	sort.Strings(qs)
	for _, q := range qs {
		s, p := spans[q], pkgs[q]
		seat := func(role string) (string, string) {
			if p != nil {
				if pr, ok := p.Principals[role]; ok {
					return pr.Seat, pr.Session
				}
			}
			return "", ""
		}
		add := func(step, role, a, b, openNote string) {
			if a == "" {
				return
			}
			st := Step{QID: q, Step: step, StartedAt: a, EndedAt: b}
			st.Seat, st.Session = seat(role)
			ta, err1 := time.Parse(time.RFC3339, a)
			if b == "" {
				st.Note = openNote
			} else if tb, err2 := time.Parse(time.RFC3339, b); err1 == nil && err2 == nil && !tb.Before(ta) {
				secs := int64(tb.Sub(ta).Seconds())
				st.Seconds = &secs
			} else {
				st.Note = "UNKNOWN: unreadable or reversed timestamps"
			}
			ov.Steps = append(ov.Steps, st)
		}
		add("worker", "worker", s.start, s.pub, "not ended")
		add("verify", "verifier", s.pub, s.verdict, "not ended")
		add("decision", "director", s.verdict, s.decide, "waiting for the director")
	}
	return ov
}

// Text renders the view for a terminal.
func Text(v *View) string {
	var b strings.Builder
	w := func(f string, a ...any) { fmt.Fprintf(&b, f+"\n", a...) }
	w("# %s — agent-loop status", v.Project)
	w("")
	w("**%s**", v.Label)
	w("As of %s. Ledger: %s", v.AsOf, v.Ledger)
	w("Loop: %s", v.Freshness)
	w("Research: %s", v.Research)
	if len(v.Problems) > 0 {
		w("")
		w("## Problems (UNKNOWN or CONFLICT: not healthy)")
		for _, p := range v.Problems {
			w("- %s", p)
		}
	}
	w("")
	w("## Pending decisions (%d)", len(v.Pending))
	if len(v.Pending) == 0 {
		w("None recorded.")
	}
	for _, p := range v.Pending {
		w("- **%s** — owner %s. %s", p.ID, p.Owner, p.Question)
		w("  - next: %s", p.NextAction)
		if len(p.Dependents) > 0 {
			w("  - blocks: %s", strings.Join(p.Dependents, ", "))
		}
		w("  - source: %s (%s)", p.Source, p.Evidence)
	}
	w("")
	w("## Packages (%d)", len(v.Packages))
	for _, p := range v.Packages {
		w("- %s: %s since %s (last ledger event %s); owner %s; next: %s", p.QID, p.Step, p.Since, p.LastEvent, p.Owner, p.NextAction)
	}
	if len(v.Resolved) > 0 {
		w("")
		w("## Resolved")
		for _, r := range v.Resolved {
			w("- %s: %s", r.ID, r.Evidence)
		}
	}
	if len(v.Inventory) > 0 {
		w("")
		w("## Recorded campaign state (inventory pointers)")
		for _, it := range v.Inventory {
			w("- [%s] %s: %s — %s (%s)", it.Kind, it.ID, it.Status, it.Source, it.Evidence)
		}
	}
	if o := v.Overhead; o != nil {
		w("")
		w("## Overhead (from ledger events)")
		w("worker dispatches %d, verifier dispatches %d, repairs %d, timeouts %d, director decisions %d, currently blocked %d",
			o.WorkerDispatches, o.VerifierDispatches, o.Repairs, o.Timeouts, o.DirectorDecisions, o.CurrentlyBlocked)
		for _, s := range o.Steps {
			d := "UNKNOWN"
			if s.Seconds != nil {
				d = fmt.Sprintf("%ds", *s.Seconds)
			} else if s.Note != "" {
				d = s.Note
			}
			who := "principal UNKNOWN"
			if s.Seat != "" {
				who = s.Seat + " " + s.Session
			}
			w("- %s %s: %s (%s)", s.QID, s.Step, d, who)
		}
		w("Costs: %s", o.Costs)
	}
	w("")
	w("## Known limits")
	for _, l := range v.KnownLimits {
		w("- %s", l)
	}
	return b.String()
}
