package py

import (
	"regexp"
	"strconv"
	"strings"
	"time"
)

var utcRE = regexp.MustCompile(
	`^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(Z|[+-]\d{2}:?\d{2})?$`)

// Instant is validator._instant: a strict UTC instant, or ok=false. It
// never panics. Offsets are range-checked, fields must form a real
// datetime, and results outside years 1..9999 are refused, as Python's
// datetime refuses them.
func Instant(v any) (time.Time, bool) {
	s, ok := v.(string)
	if !ok {
		return time.Time{}, false
	}
	m := utcRE.FindStringSubmatch(strings.TrimSpace(s))
	if m == nil {
		return time.Time{}, false
	}
	n := func(i int) int { x, _ := strconv.Atoi(m[i]); return x }
	y, mo, d, h, mi, se := n(1), n(2), n(3), n(4), n(5), n(6)
	if y < 1 || mo < 1 || mo > 12 || d < 1 || d > daysIn(y, mo) ||
		h > 23 || mi > 59 || se > 59 {
		return time.Time{}, false
	}
	t := time.Date(y, time.Month(mo), d, h, mi, se, 0, time.UTC)
	zone := m[7]
	if zone != "" && zone != "Z" {
		digits := strings.ReplaceAll(zone[1:], ":", "")
		if len(digits) != 4 {
			return time.Time{}, false
		}
		oh, _ := strconv.Atoi(digits[:2])
		om, _ := strconv.Atoi(digits[2:])
		if oh > 23 || om > 59 {
			return time.Time{}, false
		}
		off := time.Duration(oh)*time.Hour + time.Duration(om)*time.Minute
		if zone[0] == '+' {
			t = t.Add(-off)
		} else {
			t = t.Add(off)
		}
		if t.Year() < 1 || t.Year() > 9999 {
			return time.Time{}, false
		}
	}
	return t, true
}

func daysIn(y, m int) int {
	return time.Date(y, time.Month(m)+1, 0, 0, 0, 0, 0, time.UTC).Day()
}

// ISO is strftime("%Y-%m-%dT%H:%M:%SZ").
func ISO(t time.Time) string {
	return t.UTC().Format("2006-01-02T15:04:05Z")
}
