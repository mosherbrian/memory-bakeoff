package loop

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// P12-fair-handoff-1: the ledger lock is granted in arrival order.
//
// flock alone has no order: a holder that locks again at once (run after a
// yield) wins every time, and polling waiters can starve run (P12-realprocess-1
// D2: 114 s). Every writer therefore first takes a numbered place in
// <db>.queue/ and may try the flock only while it is the oldest live entry.
// The entry is removed when the lock is taken, so a holder that wants the lock
// again goes to the back. Admission is capped per class (QueueCap): a full
// class is refused at once (E_LEDGER_SATURATED), never queued without bound.
// An entry whose process is gone (dead pid, or pid reused: different start
// time), that has not been refreshed for QueueStale (a stuck waiter), or that
// cannot be read is removed by whoever sees it, so no waiter can wedge the
// queue. No daemon: a short flock on <db>.queue/.mutex makes every
// admission, scan and removal atomic.
var (
	QueueCap   = map[string]int{"run": 1, "due": 3, "ordinary": 2, "ack": 1, "check": 1}
	QueueStale = 3 * time.Second
	queuePoll  = 25 * time.Millisecond
)

// AdmittedWait is how long an admitted non-priority writer waits at most:
// the current holder, then every non-priority entry ahead, each of which may
// be preceded by one priority (ack/check) grant; every hold is at most
// HoldBudget (+ the 0.5 s WaitDelay and hand-off, rounded to 1 s):
// (1 + 2 x (run + due + ordinary)) x 11 s = 13 x 11 s = 143 s. This is the
// arithmetic worst case; it needs an ack or check arriving before every grant.
func AdmittedWait() time.Duration {
	n := 0
	for c, v := range QueueCap {
		if c != "ack" && c != "check" {
			n += v
		}
	}
	return time.Duration(1+2*n) * (HoldBudget + time.Second)
}

// lockClass is the queue class of this process's command.
func lockClass() string {
	cmd := ""
	if len(os.Args) > 1 {
		cmd = os.Args[1]
	}
	switch cmd {
	case "run":
		return "run"
	case "timer-callback", "decision-check":
		return "due"
	case "timeout-ack", "decision-ack":
		return "ack"
	case "liveness":
		return "check"
	}
	return "ordinary"
}

var errQueueFull = errors.New("queue class full")

type queueEntry struct {
	PID   int    `json:"pid"`
	Start string `json:"start"` // /proc/<pid>/stat starttime: tells a reused pid apart
	Class string `json:"class"`
	Cmd   string `json:"cmd"`
	At    string `json:"at"`
}

type lockQueue struct{ dir string }

func newQueue(cfg *Config) *lockQueue { return &lockQueue{dir: cfg.DB + ".queue"} }

// procStart is field 22 of /proc/<pid>/stat ("" when unreadable).
func procStart(pid int) string {
	b, err := os.ReadFile(fmt.Sprintf("/proc/%d/stat", pid))
	if err != nil {
		return ""
	}
	s := string(b)
	i := strings.LastIndexByte(s, ')')
	if i < 0 {
		return ""
	}
	f := strings.Fields(s[i+1:])
	if len(f) < 20 {
		return ""
	}
	return f[19]
}

// locked runs fn under the queue mutex.
func (q *lockQueue) locked(fn func() error) error {
	if err := os.MkdirAll(q.dir, 0o755); err != nil {
		return err
	}
	m, err := os.OpenFile(filepath.Join(q.dir, ".mutex"), os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return err
	}
	defer m.Close()
	if err := syscall.Flock(int(m.Fd()), syscall.LOCK_EX); err != nil {
		return err
	}
	defer syscall.Flock(int(m.Fd()), syscall.LOCK_UN)
	return fn()
}

// live lists the live entries oldest first, removing dead, reused, stale and
// malformed ones (malformed ones are kept aside in rejected/, visible).
// The caller holds the mutex.
func (q *lockQueue) live() ([]string, map[string]queueEntry) {
	ents, _ := os.ReadDir(q.dir)
	var names []string
	got := map[string]queueEntry{}
	for _, e := range ents {
		n := e.Name()
		if strings.HasPrefix(n, ".") || e.IsDir() || strings.HasSuffix(n, ".tmp") {
			continue
		}
		p := filepath.Join(q.dir, n)
		var qe queueEntry
		b, err := os.ReadFile(p)
		if _, perr := strconv.ParseUint(n, 10, 64); err != nil || perr != nil || json.Unmarshal(b, &qe) != nil || qe.PID <= 0 {
			os.MkdirAll(filepath.Join(q.dir, "rejected"), 0o755)
			os.Rename(p, filepath.Join(q.dir, "rejected", n+"."+time.Now().UTC().Format("20060102T150405.000Z")))
			lockLog("queue-rejected-malformed")
			continue
		}
		fi, serr := os.Stat(p)
		switch {
		case syscall.Kill(qe.PID, 0) == syscall.ESRCH, procStart(qe.PID) != qe.Start,
			serr == nil && time.Since(fi.ModTime()) > QueueStale:
			os.Remove(p)
			lockLog(fmt.Sprintf("queue-reaped:%d", qe.PID))
			continue
		}
		names = append(names, n)
		got[n] = qe
	}
	sort.Strings(names)
	return names, got
}

// admit takes a place at the back of the queue, or errQueueFull.
func (q *lockQueue) admit(class string) (string, error) {
	var name string
	err := q.locked(func() error {
		names, got := q.live()
		n := 0
		for _, x := range names {
			if got[x].Class == class {
				n++
			}
		}
		if n >= QueueCap[class] {
			return errQueueFull
		}
		// The next number is above both the counter and every entry present,
		// so a lost or damaged counter can never reuse a live entry's name.
		seqPath := filepath.Join(q.dir, ".seq")
		b, _ := os.ReadFile(seqPath)
		seq, _ := strconv.ParseUint(strings.TrimSpace(string(b)), 10, 64)
		for _, x := range names {
			if v, err := strconv.ParseUint(x, 10, 64); err == nil && v > seq {
				seq = v
			}
		}
		seq++
		if err := os.WriteFile(seqPath, []byte(strconv.FormatUint(seq, 10)), 0o644); err != nil {
			return err
		}
		name = fmt.Sprintf("%020d", seq)
		cmd := ""
		if len(os.Args) > 1 {
			cmd = os.Args[1]
		}
		eb, _ := json.Marshal(queueEntry{PID: os.Getpid(), Start: procStart(os.Getpid()), Class: class, Cmd: cmd,
			At: time.Now().UTC().Format(time.RFC3339Nano)})
		tmp := filepath.Join(q.dir, name+".tmp")
		if err := os.WriteFile(tmp, eb, 0o644); err != nil {
			return err
		}
		return os.Rename(tmp, filepath.Join(q.dir, name))
	})
	return name, err
}

// head reports whether name is the oldest live entry, and whether it still exists.
func (q *lockQueue) head(name string) (isHead, exists bool) {
	q.locked(func() error {
		names, got := q.live()
		head := q.pick(names, got)
		for _, n := range names {
			if n == name && got[n].PID == os.Getpid() { // a reaped name is never taken for ours
				isHead, exists = n == head, true
			}
		}
		return nil
	})
	return
}

// pick is the grant order (P12-ack-capacity-1). timeout-ack goes first, then
// the outside check, then everyone else oldest first, EXCEPT that two
// priority grants never follow each other while a non-priority writer waits:
// so an ack waits at most for the current holder and one other writer, and a
// non-priority writer is overtaken by at most one priority grant per
// non-priority grant. The last grant's class is in .last (under the mutex).
func (q *lockQueue) pick(names []string, got map[string]queueEntry) string {
	prio := func(c string) bool { return c == "ack" || c == "check" }
	last, _ := os.ReadFile(filepath.Join(q.dir, ".last"))
	oldest := func(want func(string) bool) string {
		for _, n := range names {
			if want(got[n].Class) {
				return n
			}
		}
		return ""
	}
	other := oldest(func(c string) bool { return !prio(c) })
	if prio(string(last)) && other != "" {
		return other
	}
	if a := oldest(func(c string) bool { return c == "ack" }); a != "" {
		return a
	}
	if c := oldest(func(c string) bool { return c == "check" }); c != "" {
		return c
	}
	return other
}

// granted records the class of the writer that just took the lock.
func (q *lockQueue) granted(class string) {
	q.locked(func() error { return os.WriteFile(filepath.Join(q.dir, ".last"), []byte(class), 0o644) })
}

func (q *lockQueue) touch(name string) {
	now := time.Now()
	os.Chtimes(filepath.Join(q.dir, name), now, now)
}

func (q *lockQueue) remove(name string) {
	q.locked(func() error { return os.Remove(filepath.Join(q.dir, name)) })
}
