package host

import (
	"testing"
	"time"
)

// P12: a deadline with a known instant is armed as an explicit-UTC
// calendar timer (daemon-reload restarts --on-active countdowns); the
// relative form stays for a deadline without an instant.

func TestCommandForKeepsTheRelativeForm(t *testing.T) {
	tm := &Timers{SystemdRun: "systemd-run"}
	got := tm.CommandFor("u", 59, []string{"cb"})
	if len(got) != 5 || got[3] != "--on-active=59s" || got[4] != "cb" {
		t.Fatalf("argv %q", got)
	}
}

func TestCommandAtIsAnExplicitUTCInstant(t *testing.T) {
	tm := &Timers{SystemdRun: "systemd-run"}
	la, _ := time.LoadLocation("America/Los_Angeles")
	for _, c := range []struct {
		at   time.Time
		want string
	}{
		{time.Date(2026, 9, 21, 12, 30, 0, 0, time.UTC), "--on-calendar=2026-09-21 12:30:00 UTC"},
		// never before the deadline: a fraction rounds up
		{time.Date(2026, 9, 21, 12, 29, 59, 200e6, time.UTC), "--on-calendar=2026-09-21 12:30:00 UTC"},
		// a zoned instant is written in UTC
		{time.Date(2026, 9, 21, 5, 30, 0, 0, la), "--on-calendar=2026-09-21 12:30:00 UTC"},
	} {
		got := tm.CommandAt("u", c.at, []string{"cb"})
		if len(got) != 6 || got[3] != "--timer-property=AccuracySec=1s" || got[4] != c.want || got[5] != "cb" {
			t.Errorf("%v: argv %q", c.at, got)
		}
	}
}

func TestCancelReceiptsAreClassifiedExactly(t *testing.T) {
	for _, c := range []struct {
		kind, stdout, want string
		rc                 int
	}{
		{"stop", "wake: K -> nothing running\n", "idle", 1},
		{"stop", "wake: K -> cancelled\n", "cancelled", 1},
		{"stop", "wake: X -> cancelled\n", "failed", 1}, // another session's receipt
		{"stop", "nothing running\n", "failed", 1},      // no receipt
		{"stop", "", "failed", 1},                       // transport error (stderr only)
		{"dispatch", "wake: K -> nothing running\n", "failed", 1},
		{"stop", "wake: K -> started\n", "sent", 0},
	} {
		kv := mapKV{}
		tr := &WakeTransport{WakePath: "wake", Allowlist: []string{"K"}, Enabled: true, KV: kv,
			Run: func(argv []string, env []string, timeout time.Duration) (Proc, error) {
				return Proc{RC: c.rc, Stdout: c.stdout, Stderr: "could not reach"}, nil
			}}
		mid, err := tr.Send("K", "/cancel", c.kind, "a", nil)
		if err != nil || tr.State(mid) != c.want {
			t.Errorf("%s %q rc %d: %s %v, want %s", c.kind, c.stdout, c.rc, tr.State(mid), err, c.want)
		}
	}
}

type mapKV map[string]string

func (m mapKV) Get(k string) (string, bool) { v, ok := m[k]; return v, ok }
func (m mapKV) Put(k, v string) error       { m[k] = v; return nil }

// An early callback's re-arm: the same unit at the armed instant; a replay
// while that unit waits reuses it (one due timer); another instant is refused.
func TestRearmHostReusesTheWaitingUnitAndNeverMovesTheDeadline(t *testing.T) {
	kv := mapKV{}
	var calls [][]string
	state := "ActiveState=inactive\nSubState=dead\n"
	tm := NewTimers(kv)
	tm.Host, tm.Enabled, tm.SystemdRun, tm.Systemctl, tm.Allowlist = true, true, "systemd-run", "systemctl", []string{"u"}
	tm.Run = func(argv []string, env []string, timeout time.Duration) (Proc, error) {
		calls = append(calls, argv)
		if argv[0] == "systemctl" && argv[2] == "show" {
			return Proc{Stdout: state}, nil
		}
		return Proc{}, nil
	}
	at := time.Date(2026, 9, 21, 12, 30, 0, 0, time.UTC)
	if _, err := tm.CreateHost("u", "2026-09-21T12:30:00Z", 60, []string{"cb"}); err != nil {
		t.Fatal(err)
	}
	out, err := tm.RearmHost("u", at, []string{"cb"})
	if err != nil || out[0] != "rearmed" || calls[len(calls)-1][2] != "--unit=u.timer" {
		t.Fatalf("re-arm %v %v %v", out, err, calls[len(calls)-1])
	}
	n := len(calls)
	state = "ActiveState=active\nSubState=waiting\n"
	out, err = tm.RearmHost("u", at, []string{"cb"})
	for _, c := range calls[n:] {
		if c[0] == "systemd-run" {
			t.Fatalf("a replay armed a second timer: %v", calls[n:])
		}
	}
	if err != nil || out[0] != "rearmed-reused" {
		t.Fatalf("replay %v %v", out, err)
	}
	if _, err := tm.RearmHost("u", at.Add(time.Minute), []string{"cb"}); err == nil {
		t.Fatal("a re-arm moved the deadline")
	}
}
