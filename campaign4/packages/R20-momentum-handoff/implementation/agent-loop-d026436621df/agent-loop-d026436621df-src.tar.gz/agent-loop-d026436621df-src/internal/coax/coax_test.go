package coax

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/shadow"
)

var now = time.Date(2026, 9, 22, 12, 0, 0, 0, time.UTC)

// turn writes a stream file for seat id: started at start, ended at end
// (zero end = still running).
func turn(t *testing.T, dir, id string, start, end time.Time, text string) {
	t.Helper()
	item := fmt.Sprintf("i%d", start.UnixMilli())
	s := fmt.Sprintf(`{"t": "start", "item": %q}`+"\n"+`{"t": "d", "item": %q, "x": %q}`+"\n", item, item, text)
	mtime := start
	if !end.IsZero() {
		s += fmt.Sprintf(`{"t": "end", "item": %q}`+"\n", item)
		mtime = end
	}
	p := filepath.Join(dir, id+".jsonl")
	if err := os.WriteFile(p, []byte(s), 0o644); err != nil {
		t.Fatal(err)
	}
	os.Chtimes(p, mtime, mtime)
}

func ledger(t *testing.T, dir, text string) []shadow.Row {
	t.Helper()
	p := filepath.Join(dir, "events.tsv")
	os.WriteFile(p, []byte(strings.ReplaceAll(text, "|", "\t")), 0o644)
	rows, _, err := shadow.ReadLedger(p)
	if err != nil {
		t.Fatal(err)
	}
	return rows
}

func TestCoax(t *testing.T) {
	seats := map[string]string{"kiln": "K", "corvid": "C"}
	at := func(hm string) time.Time {
		x, _ := time.Parse("15:04:05", hm)
		return now.Add(x.Sub(time.Date(0, 1, 1, 12, 0, 0, 0, time.UTC)))
	}
	for _, c := range []struct {
		name, rows string
		start, end time.Time
		want       bool
	}{
		{"lost completion: turn ended, no result row", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|2026-09-22T12:00Z|go\n",
			at("11:30:20"), at("11:50:00"), true},
		{"result recorded: nothing to do", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n2026-09-22T11:51Z|P|P-w-1|COMPLETED|kiln|-|done\n",
			at("11:30:20"), at("11:50:00"), false},
		{"a long turn that has not ended is work, not a stall", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n",
			at("11:30:20"), time.Time{}, false},
		{"ended inside the grace period: give the controller time", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n",
			at("11:30:20"), at("11:59:00"), false},
		{"the ended turn is from before this dispatch", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n",
			at("11:10:00"), at("11:20:00"), false},
		{"PREPARED answers a prepare dispatch", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n2026-09-22T11:41Z|P|P-w-1|PREPARED|kiln|-|ready\n",
			at("11:30:20"), at("11:50:00"), false},
		{"only a CONFIRMED row since: still unanswered", "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n2026-09-22T11:40Z|P|P-w-1|CONFIRMED|cairn|-|looks busy\n",
			at("11:30:20"), at("11:50:00"), true},
	} {
		t.Run(c.name, func(t *testing.T) {
			dir := t.TempDir()
			turn(t, dir, "K", c.start, c.end, "all tests pass; claim written")
			got := Find(ledger(t, dir, c.rows), seats, dir, dir, "", "cairn", now, 2*time.Minute)
			if (len(got) > 0) != c.want {
				t.Fatalf("want coax=%v, got %+v", c.want, got)
			}
		})
	}
}

// The corvid matrix case (2026-09-22 20:34Z): output written outside the
// package folder, so openwork saw nothing. The turn end sees it; the
// receipt's claim path is named in the message.
func TestCoaxNamesClaimAndLastWords(t *testing.T) {
	dir := t.TempDir()
	pkg := filepath.Join(dir, "P")
	os.MkdirAll(pkg, 0o755)
	claim := filepath.Join(dir, "elsewhere", "claim.json")
	os.MkdirAll(filepath.Dir(claim), 0o755)
	os.WriteFile(claim, []byte("{}"), 0o644)
	os.WriteFile(filepath.Join(pkg, "dispatch-receipt.json"),
		[]byte(fmt.Sprintf(`{"action_id": "P-v-1", "claim_path": %q}`, claim)), 0o644)
	turn(t, dir, "C", now.Add(-20*time.Minute), now.Add(-5*time.Minute), "9 REPRODUCED, 1 UNTESTED. Returned to Tern.")
	rows := ledger(t, dir, "2026-09-22T11:40Z|P|P-v-1|DISPATCHED|corvid|-|review\n")
	got := Find(rows, map[string]string{"corvid": "C"}, dir, dir, "", "cairn", now, 2*time.Minute)
	if len(got) != 1 {
		t.Fatalf("want 1 coax, got %+v", got)
	}
	msg := got[0].Message(now)
	for _, want := range []string{"P-v-1", claim + " is present", "Returned to Tern", "5 min ago"} {
		if !strings.Contains(msg, want) {
			t.Errorf("message lacks %q: %s", want, msg)
		}
	}
}

// The three cases, from the send log.
func TestCoaxClassifies(t *testing.T) {
	for _, c := range []struct {
		name, log, text, want string
	}{
		{"never sent", "", "done, claim written", "a"},
		{"cut off with no text (turn limit)", "", "", "a"},
		{"killed by the stall watchdog", "", "[stall] no response for 120s", "a"},
		{"sent and failed", "2026-09-22T11:49:30Z\tcampaign4\tcairn\t-\tFAILED: 'cairn' matches no session\t40\t-\tP-w-1 COMPLETE", "done", "b"},
		{"delivered, not acted on", "2026-09-22T11:49:30Z\tcampaign4\tcairn\tCAIRN\tstarted\t40\t-\tP-w-1 COMPLETE claim at x", "done", "c"},
		{"an openwork nudge is not the worker's completion", "2026-09-22T11:49:30Z\tcampaign4\tcairn\tCAIRN\tstarted\t576\t-\tOPEN DISPATCH, IDLE WORKER - nothing is going to happen on its own: P-w-1", "done", "a"},
		{"a coax's own wake is not the worker's completion", "2026-09-22T11:49:30Z\tcampaign4\tcairn\tCAIRN\tstarted\t502\t-\tCase c: a wake to cairn about P-w-1 was delivered", "done", "a"},
		{"a wake about other work does not count", "2026-09-22T11:49:30Z\tcampaign4\tcairn\tCAIRN\tstarted\t40\t-\tP-other-9 COMPLETE", "done", "a"},
	} {
		t.Run(c.name, func(t *testing.T) {
			dir := t.TempDir()
			turn(t, dir, "K", now.Add(-30*time.Minute), now.Add(-10*time.Minute), c.text)
			wl := filepath.Join(dir, "wake.log")
			os.WriteFile(wl, []byte(c.log+"\n"), 0o644)
			rows := ledger(t, dir, "2026-09-22T11:30Z|P|P-w-1|DISPATCHED|kiln|-|go\n")
			got := Find(rows, map[string]string{"kiln": "K", "cairn": "CAIRN"}, dir, dir, wl, "cairn", now, 2*time.Minute)
			if len(got) != 1 || got[0].Case != c.want {
				t.Fatalf("want case %s, got %+v", c.want, got)
			}
			if c.text == "" && !strings.Contains(got[0].Why, "20m0s with no text") {
				t.Errorf("an empty turn is not named as cut off: %s", got[0].Why)
			}
			if !strings.HasPrefix(got[0].Message(now), "Case "+c.want+": ") {
				t.Errorf("message does not lead with the case: %s", got[0].Message(now))
			}
		})
	}
}

// P6r15-failed-prepare-1 (2026-09-23 00:47Z): cairn dispatched a step to
// itself; the coax woke cairn about cairn's own turn.
func TestCoaxSkipsTheControllersOwnSteps(t *testing.T) {
	dir := t.TempDir()
	turn(t, dir, "CAIRN", now.Add(-20*time.Minute), now.Add(-5*time.Minute), "bound")
	rows := ledger(t, dir, "2026-09-22T11:40Z|P|P-prep-1|DISPATCHED|cairn|-|prepare\n")
	if got := Find(rows, map[string]string{"cairn": "CAIRN"}, dir, dir, "", "cairn", now, 2*time.Minute); len(got) != 0 {
		t.Fatalf("coaxed the controller about its own step: %+v", got)
	}
}
