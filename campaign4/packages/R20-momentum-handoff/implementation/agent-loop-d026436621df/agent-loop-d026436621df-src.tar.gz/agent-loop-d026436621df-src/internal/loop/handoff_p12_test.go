package loop

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
)

// P12-fair-handoff-1: arrival-order lock grant (D2), accepted-only SATURATED
// stamping (D1), one labelled repeat per notice incident (D3).

func TestAHolderThatLocksAgainGoesBehindAWaiter(t *testing.T) {
	r := newRig(t)
	poll := queuePoll
	queuePoll = 300 * time.Millisecond // the waiter polls slowly: only the queue order can put it first
	t.Cleanup(func() { queuePoll = poll })
	a, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	got := make(chan string, 2)
	go func() {
		b, err := LockLedger(r.cfg, 5*time.Second)
		if err == nil {
			got <- "waiter"
			time.Sleep(100 * time.Millisecond)
			b.Unlock()
		}
	}()
	time.Sleep(450 * time.Millisecond) // the waiter is queued and between polls
	a.Unlock()
	a2, err := LockLedger(r.cfg, 5*time.Second) // the yielding holder, at once
	must(t, err)
	got <- "relocker"
	a2.Unlock()
	if first := <-got; first != "waiter" {
		t.Fatalf("the re-locking holder went first (%s): no hand-off", first)
	}
}

func TestHoldersAndGivenUpWaitersLeaveNoQueueEntry(t *testing.T) {
	r := newRig(t)
	a, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	if _, err := LockLedger(r.cfg, 100*time.Millisecond); err == nil {
		t.Fatal("a second writer got a held lock")
	}
	a.Unlock()
	ents, _ := os.ReadDir(r.cfg.DB + ".queue")
	for _, e := range ents {
		if !strings.HasPrefix(e.Name(), ".") {
			t.Fatalf("an entry outlived its holder or its waiter: %s", e.Name())
		}
	}
}

func TestAdmissionIsCappedAndRefusalIsVisible(t *testing.T) {
	r := newRig(t)
	old := QueueCap["ordinary"]
	QueueCap["ordinary"] = 1
	t.Cleanup(func() { QueueCap["ordinary"] = old })
	a, err := LockLedger(r.cfg, time.Second)
	must(t, err)
	defer a.Unlock()
	done := make(chan struct{})
	go func() { LockLedger(r.cfg, 800*time.Millisecond); close(done) }() // takes the one place
	time.Sleep(100 * time.Millisecond)
	_, err = LockLedger(r.cfg, 300*time.Millisecond)
	<-done // the waiter gives up before the test's directory is removed
	if f, ok := host.IsFault(err); !ok || f.Code != "E_LEDGER_SATURATED" {
		t.Fatalf("a full class was not refused visibly: %v", err)
	}
}

func TestDeadReusedStaleAndMalformedEntriesCannotWedgeTheQueue(t *testing.T) {
	r := newRig(t)
	q := newQueue(r.cfg)
	os.MkdirAll(q.dir, 0o755)
	put := func(name string, e queueEntry) {
		b, _ := json.Marshal(e)
		os.WriteFile(filepath.Join(q.dir, name), b, 0o644)
	}
	put("00000000000000000001", queueEntry{PID: 1 << 22, Class: "ordinary"})                                    // dead
	put("00000000000000000002", queueEntry{PID: os.Getpid(), Start: "reused", Class: "ordinary"})               // pid reused
	put("00000000000000000003", queueEntry{PID: os.Getpid(), Start: procStart(os.Getpid()), Class: "ordinary"}) // stale
	old := time.Now().Add(-time.Minute)
	os.Chtimes(filepath.Join(q.dir, "00000000000000000003"), old, old)
	os.WriteFile(filepath.Join(q.dir, "00000000000000000004"), []byte("{not json"), 0o644) // malformed
	k, err := LockLedger(r.cfg, 2*time.Second)
	if err != nil {
		t.Fatalf("wedged by dead/reused/stale/malformed entries: %v", err)
	}
	k.Unlock()
	if ents, _ := os.ReadDir(filepath.Join(q.dir, "rejected")); len(ents) != 1 {
		t.Fatalf("the malformed entry was not kept aside: %v", ents)
	}
}

func saturate(t *testing.T, r *rig) {
	WriteDue(r.cfg, "Q", "Q-w1", "ex-Q-w1", time.Now().UTC().Add(-time.Minute))
}

func TestSaturationIsStampedOnlyOnAnAcceptedWake(t *testing.T) {
	for _, c := range []struct {
		name    string
		proc    host.Proc
		err     error
		stamped bool
	}{
		{"rc 1 refused", host.Proc{RC: 1, Stderr: "could not reach"}, nil, false},
		{"runner error", host.Proc{}, host.ErrTimeout, false},
		{"budget refusal", host.Proc{}, host.ErrBudget, false},
		{"rc 0 started", host.Proc{RC: 0, Stdout: "wake: T -> started"}, nil, true},
		{"rc 3 queued", host.Proc{RC: 3, Stdout: "wake: T -> queued"}, nil, true},
	} {
		t.Run(c.name, func(t *testing.T) {
			r := newRig(t)
			saturate(t, r)
			sends := 0
			r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
				sends++
				return c.proc, c.err
			}
			msgs := reportSaturation(r.cfg)
			_, serr := os.Stat(filepath.Join(dueDir(r.cfg), ".saturation-reported"))
			if (serr == nil) != c.stamped {
				t.Fatalf("stamped=%v, want %v: %v", serr == nil, c.stamped, msgs)
			}
			if log, _ := os.ReadFile(filepath.Join(dueDir(r.cfg), ".saturation-attempts")); !strings.Contains(string(log), "accepted=") {
				t.Fatal("the attempt was not kept")
			}
			if !c.stamped && !strings.Contains(msgs[0], "NOT accepted") {
				t.Fatalf("a failed report claims success: %v", msgs)
			}
			reportSaturation(r.cfg) // the next holder
			if want := map[bool]int{true: 1, false: 2}[c.stamped]; sends != want {
				t.Fatalf("sends %d, want %d (failed reports are retried, accepted ones suppressed)", sends, want)
			}
		})
	}
}

// crashMidSend leaves the durable record a SIGKILL during the wake leaves.
func crashMidSend(t *testing.T, l *Loop, incident, id, kind string) {
	key := id + "|" + kind + "|" + incident
	b, _ := json.Marshal(noticeRec{Key: key, State: "attempting", Attempts: 1})
	must(t, l.D.KVPut(noticeKey(key), string(b)))
}

func TestOneLabelledRepeatPerIncidentAcrossCrashes(t *testing.T) {
	r := newRig(t)
	l := r.open()
	crashMidSend(t, l, "wake|x", "T", "wake")
	l.Close()
	l = r.open() // restart
	must(t, l.sendIncident("wake|x", "T", "hello", "wake", ""))
	if w := r.wakesTo("T"); len(w) != 1 || !strings.HasPrefix(w[0], "REPEAT (") {
		t.Fatalf("no single labelled repeat: %v", w)
	}
	must(t, l.sendIncident("wake|x", "T", "hello", "wake", "")) // replay after the repeat was accepted
	if len(r.wakesTo("T")) != 1 {
		t.Fatal("an accepted notice was sent again")
	}
	// A second crash during the repeat: no third send, visible, never delivered.
	crashMidSend(t, l, "wake|y", "T", "wake")
	must(t, l.sendIncident("wake|y", "T", "hi", "wake", "")) // repeat 1
	var rec noticeRec
	k := noticeKey("T|wake|wake|y")
	json.Unmarshal([]byte(l.D.KV[k]), &rec)
	rec.State = "attempting" // crash during the repeat
	b, _ := json.Marshal(rec)
	l.D.KVPut(k, string(b))
	l.Close()
	l = r.open()
	defer l.Close()
	n := len(r.wakesTo("T"))
	err := l.sendIncident("wake|y", "T", "hi", "wake", "")
	if f, ok := host.IsFault(err); !ok || f.Code != "E_DELIVERY_UNRESOLVED" || len(r.wakesTo("T")) != n {
		t.Fatalf("a second crash bought another repeat: %v, %d sends", err, len(r.wakesTo("T"))-n)
	}
	json.Unmarshal([]byte(l.D.KV[k]), &rec)
	if rec.State != "unresolved" || rec.Repeats != 1 {
		t.Fatalf("record %+v", rec)
	}
}

func TestACancelIsNeverRepeatedAfterAnUnknownOutcome(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	crashMidSend(t, l, "stop|Q-w1", "K", "stop")
	err := l.sendIncident("stop|Q-w1", "K", "/cancel", "stop", "Q-w1")
	if f, ok := host.IsFault(err); !ok || f.Code != "E_DELIVERY_UNRESOLVED" || len(r.wakesTo("K")) != 0 {
		t.Fatalf("an extra cancel: %v %v", err, r.wakesTo("K"))
	}
}

func TestDefinitiveFailuresRetryWithBoundedBackoff(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	r.fail["wake"] = true
	var codes []string
	for i := 0; i < 20; i++ {
		err := l.sendIncident("esc|z", "T", "x", "escalation", "")
		if f, ok := host.IsFault(err); ok {
			codes = append(codes, f.Code)
		} else {
			codes = append(codes, "failed")
		}
		r.clock.Advance(40)
	}
	if n := len(r.wakesTo("T")); n != MaxFailedSends {
		t.Fatalf("%d sends, want %d: %v", n, MaxFailedSends, codes)
	}
	if codes[len(codes)-1] != "E_DELIVERY_UNRESOLVED" {
		t.Fatalf("exhausted failures not unresolved: %v", codes)
	}
	r.fail["wake"] = false
	l2 := r.open()
	defer l2.Close()
	r.clock.Advance(1)
	if err := l2.sendIncident("esc|w", "T", "x", "escalation", ""); err != nil {
		t.Fatal(err)
	}
	r.fail["wake"] = true
	if err := l2.sendIncident("esc|v", "T", "x", "escalation", ""); err == nil {
		t.Fatal("refused send reported delivered")
	}
	if err := l2.sendIncident("esc|v", "T", "x", "escalation", ""); err == nil || strings.Contains(err.Error(), "BACKOFF") {
		t.Fatalf("the first retry is not immediate: %v", err)
	}
	if err := l2.sendIncident("esc|v", "T", "x", "escalation", ""); err == nil || !strings.Contains(err.Error(), "BACKOFF") {
		t.Fatalf("no backoff after the second failure: %v", err)
	}
}

func TestAnUnresolvedNoticeClosesItsDueMarkerAsAnOwnedFailure(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	l := r.open()
	key := "T|wake|wake|deadline-expired:Q|Q-w1"
	b, _ := json.Marshal(noticeRec{Key: key, State: "unresolved", Repeats: 1})
	must(t, l.D.KVPut(noticeKey(key), string(b)))
	l.Close()
	WriteDue(r.cfg, "Q", "Q-w1", "ex-Q-w1", time.Now().UTC())
	msgs := strings.Join(ProcessDue(r.cfg), "|")
	if !strings.Contains(msgs, "owned delivery failure") {
		t.Fatalf("not closed as an owned failure: %s", msgs)
	}
	ents, _ := os.ReadDir(dueDir(r.cfg))
	var kept []string
	for _, e := range ents {
		kept = append(kept, e.Name())
	}
	if j := strings.Join(kept, ","); !strings.Contains(j, ".unresolved-") || strings.Contains(j, "Q-w1.json,") {
		t.Fatalf("marker not kept aside visibly: %v", kept)
	}
	l = r.open()
	defer l.Close()
	if p := l.Pkg("Q"); p.Step != "timed-out" || p.Timeout == nil {
		t.Fatalf("not settled: %s %+v", p.Step, p.Timeout)
	}
	if c := p0(l).Timeout.Cancel; !strings.HasPrefix(c, "idle") {
		t.Fatalf("a confirmed cancel recorded as failed: %q", c)
	}
	if w := r.wakesTo("T"); !strings.Contains(w[len(w)-1], "the cancel was confirmed") {
		t.Fatalf("the director is told the cancel failed: %q", w[len(w)-1])
	}
	if again := ProcessDue(r.cfg); strings.Contains(strings.Join(again, "|"), "Q-w1") {
		t.Fatalf("an unresolved marker is retried forever: %v", again)
	}
}

func p0(l *Loop) *Pkg { return l.Pkg("Q") }

func TestALostCounterNeverReusesALiveEntrysName(t *testing.T) {
	r := newRig(t)
	q := newQueue(r.cfg)
	os.MkdirAll(q.dir, 0o755)
	b, _ := json.Marshal(queueEntry{PID: os.Getpid(), Start: procStart(os.Getpid()), Class: "run"})
	os.WriteFile(filepath.Join(q.dir, "00000000000000000005"), b, 0o644) // live; no .seq counter
	name, err := q.admit("ordinary")
	must(t, err)
	if name != "00000000000000000006" {
		t.Fatalf("admitted as %s: a lost counter reused or undercut a live entry", name)
	}
}
