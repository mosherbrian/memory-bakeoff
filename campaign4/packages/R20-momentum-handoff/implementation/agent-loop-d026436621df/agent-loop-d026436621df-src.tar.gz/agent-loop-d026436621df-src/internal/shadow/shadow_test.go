package shadow

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// A made-up ledger with one of each thing the shadow must tell apart. Each
// check below fails if the shadow stops seeing its case.
const ledger = `2026-09-22T10:00Z	PK	PK-work-1	DISPATCHED	kiln	2026-09-22T10:30Z	go
2026-09-22T10:20Z	PK	PK-work-1	COMPLETED	kiln	-	done on time
2026-09-22T10:21Z	PK	PK-workverify-1	DISPATCHED	corvid	2026-09-22T10:51Z	verify
2026-09-22T10:40Z	PK	PK-workverify-1	PASS	corvid	-	ok
2026-09-22T10:45Z	PK	PK-terminal	ACCEPTED	tern	-	accept package
2026-09-22T11:00Z	PL	PL-late-1	DISPATCHED	kiln	2026-09-22T11:10Z	go
2026-09-22T11:15Z	PL	PL-late-1	COMPLETED	kiln	-	after the deadline
2026-09-22T12:00Z	PS	PS-self-1	DISPATCHED	corvid	2026-09-22T12:30Z	go
2026-09-22T12:10Z	PS	PS-self-1	COMPLETED	corvid	-	done
2026-09-22T12:11Z	PS	PS-selfverify-1	DISPATCHED	corvid	2026-09-22T12:40Z	verify
2026-09-22T12:20Z	PS	PS-selfverify-1	PASS	corvid	-	ok
2026-09-22T13:00Z	PD	PD-twice-1	DISPATCHED	kiln	2026-09-22T13:30Z	go
2026-09-22T13:01Z	PD	PD-twice-1	DISPATCHED	kiln	2026-09-22T13:30Z	again
2026-09-22T14:00Z	PO	PO-lost-1	DISPATCHED	kiln	2026-09-22T14:30Z	never finishes
2026-09-22T14:05Z	PO	PO-bindingcheck-1	DISPATCHED	corvid	2026-09-22T14:30Z	review
2026-09-22T14:10Z	PO	PO-bindingcheck-1	PASS	corvid	-	ok
2026-09-22T16:00Z	PF	PF-work-1	DISPATCHED	kiln	2026-09-22T16:30Z	go
2026-09-22T16:10Z	PF	PF-work-1	COMPLETED	kiln	-	done
2026-09-22T16:11Z	PF	PF-workverify-1	DISPATCHED	corvid	2026-09-22T16:40Z	verify
2026-09-22T16:20Z	PF	PF-workverify-1	PASS	corvid	-	ok, decided in a file
`

func TestShadowSeesEachCase(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "events.tsv")
	os.WriteFile(path, []byte(ledger), 0o644)
	rows, gaps, err := ReadLedger(path)
	if err != nil || len(gaps) != 0 {
		t.Fatal(err, gaps)
	}
	os.MkdirAll(filepath.Join(dir, "packages", "PF"), 0o755)
	os.WriteFile(filepath.Join(dir, "packages", "PF", "acceptance.json"), []byte("{}"), 0o644)
	rep, err := Run(rows, dir, filepath.Join(dir, "packages"), time.Date(2026, 9, 22, 17, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	all := func(fs []Finding) string {
		var b strings.Builder
		for _, f := range fs {
			b.WriteString(f.Kind + " " + f.QID + " | ")
		}
		return b.String()
	}
	finds, rejs := all(rep.Findings), all(rep.Rejections)
	open := strings.Join(rep.Open, " | ")
	for _, c := range []struct{ name, in, want string }{
		{"self-verification", finds, "self-verification PS-self-1"},
		{"dispatched twice", finds, "dispatched twice PD-twice-1"},
		{"late completion", rejs, "E_DEADLINE_EXPIRED PL-late-1"},
		{"lost completion", open, "PO-lost-1: worker deadline passed"},
	} {
		if !strings.Contains(c.in, c.want) {
			t.Errorf("%s: want %q in %q", c.name, c.want, c.in)
		}
	}
	for _, clean := range []string{"PK-work-1"} {
		if strings.Contains(finds+rejs+open, clean) {
			t.Errorf("%s ran cleanly and was decided, but the shadow reports it", clean)
		}
	}
	cert := map[string]string{}
	for _, f := range append(rep.Findings, rep.Rejections...) {
		cert[f.Kind+" "+f.QID] = f.Certainty
		if len(f.Sources) == 0 {
			t.Errorf("%s %s has no source lines", f.Kind, f.QID)
		}
	}
	for k, want := range map[string]string{
		"self-verification PS-self-1":  "name-linked",
		"dispatched twice PD-twice-1":  "exact",
		"E_DEADLINE_EXPIRED PL-late-1": "exact",
	} {
		if cert[k] != want {
			t.Errorf("%s: certainty %q, want %q", k, cert[k], want)
		}
	}
	files := strings.Join(rep.FileDecisions, " | ")
	if !strings.Contains(files, "PF-work-1") || strings.Contains(open, "PF-work-1") {
		t.Errorf("PF-work-1 is decided in a file: want it under file decisions, got files=%q open=%q", files, open)
	}
	if len(rep.Reviews) != 1 || rep.Reviews[0] != "PO-bindingcheck-1" {
		t.Errorf("reviews: want [PO-bindingcheck-1], got %v", rep.Reviews)
	}
}

// E-44, E-46: the director gave a 40m verify window; a pass inside it is not
// an overrun, even though the core's default ceiling is 30m.
func TestShadowHonoursTheLedgerVerifyWindow(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "events.tsv")
	os.WriteFile(path, []byte(`2026-09-22T10:00Z	PW	PW-work-1	DISPATCHED	kiln	2026-09-22T10:30Z	go
2026-09-22T10:20Z	PW	PW-work-1	COMPLETED	kiln	-	done
2026-09-22T10:21Z	PW	PW-workverify-1	DISPATCHED	corvid	2026-09-22T11:01Z	40m review
2026-09-22T10:55Z	PW	PW-workverify-1	PASS	corvid	-	ok
`), 0o644)
	rows, _, _ := ReadLedger(path)
	rep, err := Run(rows, dir, filepath.Join(dir, "packages"), time.Date(2026, 9, 22, 12, 0, 0, 0, time.UTC))
	if err != nil {
		t.Fatal(err)
	}
	for _, r := range rep.Rejections {
		t.Errorf("a pass inside its 40m window was rejected: %+v", r)
	}
}
