package loop

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// P12-bounded-deadline-1: a busy deadline callback leaves a due marker; the
// next lock holder settles it after checking it against the ledger.

func (r *rig) cancels() int {
	n := 0
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" && c[2] == "/cancel" {
			n++
		}
	}
	return n
}

func TestDueMarkerIsSettledByTheNextHolder(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	path, err := WriteDue(r.cfg, "Q", "Q-w1", "ex-Q-w1", time.Now().UTC())
	must(t, err)
	msgs := ProcessDue(r.cfg)
	to := r.fresh("Q")
	if _, err := os.Stat(path); err == nil || to == nil || to.Deferred == "" || !strings.Contains(strings.Join(msgs, "|"), "settled (interrupted)") {
		t.Fatalf("not settled: %v %+v", msgs, to)
	}
	// A replayed marker (the timer or a second busy callback): no second cancel.
	n := r.cancels()
	WriteDue(r.cfg, "Q", "Q-w1", "ex-Q-w1", time.Now().UTC())
	msgs = ProcessDue(r.cfg)
	if r.cancels() != n || !strings.Contains(strings.Join(msgs, "|"), "already-handled") {
		t.Fatalf("replay: %v, cancels %d -> %d", msgs, n, r.cancels())
	}
}

func TestDueMarkerHintsAreCheckedAgainstTheLedger(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	dir := r.cfg.DB + ".due"
	os.MkdirAll(dir, 0o755)
	for _, c := range []struct{ name, body string }{
		{"Q-v1.json", `{"qid": "Q", "action": "Q-v1", "execution": "ex-Q-v1", "written_at": "x"}`},   // not the current action
		{"Q-w1.json", `{"qid": "Q", "action": "Q-w1", "execution": "ex-forged", "written_at": "x"}`}, // wrong execution
		{"Z-w1.json", `{"qid": "Z", "action": "Z-w1", "execution": "ex-Z-w1", "written_at": "x"}`},   // no such package
		{"bad.json", `{not json`}, // malformed
		{"other.json", `{"qid": "Q", "action": "Q-w1", "execution": "ex-Q-w1", "written_at": "x"}`},   // name != action
		{"dots.json", `{"qid": "Q", "action": "../../x", "execution": "ex-Q-w1", "written_at": "x"}`}, // unsafe
	} {
		os.WriteFile(filepath.Join(dir, c.name), []byte(c.body), 0o644)
		n := r.cancels()
		msgs := ProcessDue(r.cfg)
		if r.cancels() != n || !strings.Contains(strings.Join(msgs, "|"), "REJECTED") {
			t.Errorf("%s: not rejected or acted on: %v", c.name, msgs)
		}
		if _, err := os.Stat(filepath.Join(dir, c.name)); err == nil {
			t.Errorf("%s: left in place", c.name)
		}
	}
	if r.fresh("Q") != nil {
		t.Fatal("a forged hint settled the step")
	}
	if _, err := WriteDue(r.cfg, "Q", "../../x", "e", time.Now()); err == nil {
		t.Fatal("an unsafe due marker was written")
	}
}
