package core

import (
	"database/sql"
	"os"

	"agent-loop/internal/py"

	_ "modernc.org/sqlite"
)

// Durable authoritative SQLite event store plus an atomic derived snapshot.
// One SQLite file is the authority. Terminal status and disposition commit
// in the same transaction. Restart rebuilds state from the ledger.

var terminalMakers = []string{"verify_pass", "verify_fail", "withhold", "terminate", "exhaust", "amend"}

const schema = `
CREATE TABLE IF NOT EXISTS events (
  event_id TEXT PRIMARY KEY,
  question_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  type TEXT NOT NULL,
  actor_seat TEXT, actor_role TEXT,
  at TEXT NOT NULL,
  body TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
`

// RevKey identifies one revision, like the Python (question_id, revision)
// tuple key.
type RevKey struct {
	Q   any
	Rev any
}

func (k RevKey) id() string { return py.Repr(k.Q) + "|" + py.Repr(normNum(k.Rev)) }

func normNum(v any) any {
	if f, ok := v.(float64); ok && f == float64(int64(f)) {
		return int64(f)
	}
	if b, ok := v.(bool); ok {
		if b {
			return int64(1)
		}
		return int64(0)
	}
	return v
}

// Revisions is the insertion-ordered (question_id, revision) -> record map.
type Revisions struct {
	order []RevKey
	m     map[string]*py.Dict
}

func (r *Revisions) Get(k RevKey) *py.Dict { return r.m[k.id()] }
func (r *Revisions) Set(k RevKey, v *py.Dict) {
	if _, ok := r.m[k.id()]; !ok {
		r.order = append(r.order, k)
	}
	r.m[k.id()] = v
}
func (r *Revisions) Keys() []RevKey { return append([]RevKey(nil), r.order...) }

type Store struct {
	Path       string
	DB         *sql.DB
	Revs       *Revisions
	SeenEvents map[string]bool
	Acks       *py.Dict
}

func OpenStore(path string) (*Store, error) {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1)
	// Wait for another process's write, as Python's sqlite3 does (5 s).
	if _, err := db.Exec("PRAGMA busy_timeout=5000"); err != nil {
		return nil, err
	}
	if _, err := db.Exec("PRAGMA journal_mode=WAL"); err != nil {
		return nil, err
	}
	if _, err := db.Exec(schema); err != nil {
		return nil, err
	}
	s := &Store{Path: path, DB: db, Revs: &Revisions{m: map[string]*py.Dict{}},
		SeenEvents: map[string]bool{}, Acks: py.NewDict()}
	return s, s.replay()
}

func (s *Store) replay() error {
	var raw string
	if err := s.DB.QueryRow("SELECT value FROM meta WHERE key='acks'").Scan(&raw); err == nil {
		v, err := py.Loads([]byte(raw))
		if err != nil {
			return err
		}
		s.Acks.Update(py.AsDict(v))
	}
	rows, err := s.DB.Query("SELECT event_id, question_id, revision, type, actor_seat," +
		" actor_role, at, body FROM events ORDER BY rowid")
	if err != nil {
		return err
	}
	type row struct {
		eid, q, typ, at, body string
		rev                   int64
		seat, role            sql.NullString
	}
	var all []row
	for rows.Next() {
		var r row
		if err := rows.Scan(&r.eid, &r.q, &r.rev, &r.typ, &r.seat, &r.role, &r.at, &r.body); err != nil {
			rows.Close()
			return err
		}
		all = append(all, r)
	}
	rows.Close()
	for _, r := range all {
		s.SeenEvents[r.eid] = true
		pv, err := py.Loads([]byte(r.body))
		if err != nil {
			return err
		}
		payload := py.AsDict(pv)
		event := py.D("event_id", r.eid, "type", r.typ,
			"actor", py.D("seat", nullable(r.seat), "role", nullable(r.role)), "at", r.at)
		event.Update(payload)
		key := RevKey{r.q, r.rev}
		if s.Revs.Get(key) == nil {
			rec := NewRevision(r.q)
			rec.Set("revision", r.rev)
			s.Revs.Set(key, rec)
		}
		b := py.AsDict(payload.GetOr("_budget", DefaultBudget()))
		newRec, _, err := Apply(s.Revs.Get(key), event, r.at, b)
		if err != nil {
			return err
		}
		s.Revs.Set(key, newRec)
		aid := payload.Get("action_id")
		if as, ok := aid.(string); ok && py.Truthy(aid) {
			if py.Truthy(payload.Get("acknowledged")) {
				s.Acks.Set(as, "acknowledged")
			} else if !s.Acks.Has(as) {
				s.Acks.Set(as, "intended")
			}
		}
	}
	return nil
}

func nullable(n sql.NullString) any {
	if n.Valid {
		return n.String
	}
	return nil
}

func revOf(event *py.Dict) (any, any) {
	return event.Get("question_id"), event.GetOr("revision", int64(1))
}

func (s *Store) base(q, rev any) *py.Dict {
	if b := s.Revs.Get(RevKey{q, rev}); b != nil {
		return b
	}
	b := NewRevision(q)
	b.Set("revision", rev)
	return b
}

func bodyOf(event *py.Dict, budget *py.Dict) *py.Dict {
	body := py.NewDict()
	for _, k := range event.Keys() {
		switch k {
		case "event_id", "question_id", "revision", "type", "actor", "at":
			continue
		}
		body.Set(k, event.Get(k))
	}
	body.Set("_budget", budget)
	return body
}

// Append validates and durably stores one event; idempotent on event_id.
// Returns (outcome, duplicate).
func (s *Store) Append(event, budget, atomic *py.Dict) (py.Tuple, error) {
	if !py.Truthy(budget) {
		budget = DefaultBudget()
	}
	eid := event.Get("event_id")
	eids, _ := eid.(string)
	if s.SeenEvents[eids] {
		return py.T("duplicate-ignored", true), nil
	}
	q, rev := revOf(event)
	newRec, out, err := Apply(s.base(q, rev), event, event.Get("at"), budget)
	if err != nil {
		return nil, err
	}
	var outcome any = out
	var extra []*py.Dict
	if in(newRec.Get("phase"), Terminals...) && in(event.Get("type"), terminalMakers...) &&
		newRec.Get("disposition") == nil {
		switch {
		case atomic == nil:
			return nil, terr("E_MISSING_DISPOSITION",
				"terminal verdict needs a same-transaction disposition (use close) or bounded hold (row 17)")
		case atomic.Has("decide"):
			dec := py.AsDict(atomic.Get("decide"))
			r2, o2, err := Apply(newRec, dec, dec.Get("at"), budget)
			if err != nil {
				return nil, err
			}
			newRec, outcome = r2, py.T(out, o2)
			extra = append(extra, dec)
		case atomic.Has("hold"):
			hold := py.D("event_id", eids+"-hold", "type", "decision_task",
				"actor", py.D("seat", "cairn", "role", "duty"),
				"at", event.Get("at"), "deadline", atomic.Get("hold"))
			r2, o2, err := Apply(newRec, hold, event.Get("at"), budget)
			if err != nil {
				return nil, err
			}
			newRec, outcome = r2, py.T(out, o2)
			extra = append(extra, hold)
		default:
			return nil, terr("E_MISSING_DISPOSITION", "atomic must be decide or hold")
		}
	}
	body := bodyOf(event, budget)
	tx, err := s.DB.Begin()
	if err != nil {
		return nil, err
	}
	if err := insert(tx, eids, q, rev, event, body); err != nil {
		tx.Rollback()
		return nil, err
	}
	for _, x := range extra {
		xid, _ := x.Get("event_id").(string)
		if err := insert(tx, xid, q, rev, x, bodyOf(x, budget)); err != nil {
			tx.Rollback()
			return nil, err
		}
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	// Projections publish only after commit: a rollback leaves no phantom
	// seen ids (R13, finding 2).
	for _, x := range extra {
		xid, _ := x.Get("event_id").(string)
		s.SeenEvents[xid] = true
	}
	s.SeenEvents[eids] = true
	s.Revs.Set(RevKey{q, rev}, newRec)
	if aid, ok := body.Get("action_id").(string); ok && aid != "" {
		st := "intended"
		if py.Truthy(body.Get("acknowledged")) {
			st = "acknowledged"
		}
		if err := s.SetAck(aid, st); err != nil {
			return nil, err
		}
	}
	fl := py.AsDict(newRec.Get("flight"))
	if py.Eq(event.Get("type"), "publish") && py.Truthy(fl.Get("action_id")) {
		st := "intended"
		if py.Truthy(event.Get("verify_acknowledged")) {
			st = "acknowledged"
		}
		if err := s.SetAck(fl.Get("action_id").(string), st); err != nil {
			return nil, err
		}
	}
	return py.T(outcome, false), nil
}

func insert(tx *sql.Tx, eid string, q, rev any, event, body *py.Dict) error {
	a := actorOf(event)
	_, err := tx.Exec("INSERT INTO events (event_id, question_id, revision, type,"+
		" actor_seat, actor_role, at, body) VALUES (?,?,?,?,?,?,?,?)",
		eid, q, normNum(rev), event.Get("type"), a.Get("seat"), a.Get("role"),
		event.Get("at"), py.Dumps(body))
	return err
}

// RecordTerminal commits a terminal verdict and director disposition in one
// transaction; either failure rolls back both.
func (s *Store) RecordTerminal(verdict, decide, budget *py.Dict) (py.Tuple, error) {
	if !py.Truthy(budget) {
		budget = DefaultBudget()
	}
	q, rev := revOf(verdict)
	rec1, out1, err := Apply(s.base(q, rev), verdict, verdict.Get("at"), budget)
	if err != nil {
		return nil, err
	}
	rec2, out2, err := Apply(rec1, decide, decide.Get("at"), budget)
	if err != nil {
		return nil, err
	}
	if rec2.Get("disposition") == nil {
		return nil, terr("E_MISSING_DISPOSITION", "record_terminal needs a decide event")
	}
	// Fail closed BEFORE the transaction, and publish seen ids only after
	// the commit, so a rolled-back pair leaves nothing behind (R13).
	pair := []*py.Dict{verdict, decide}
	for _, ev := range pair {
		if id, _ := ev.Get("event_id").(string); s.SeenEvents[id] {
			return nil, terr("E_DUP_EVENT", ev.Get("event_id"))
		}
	}
	tx, err := s.DB.Begin()
	if err != nil {
		return nil, err
	}
	for _, ev := range pair {
		id, _ := ev.Get("event_id").(string)
		if err := insert(tx, id, q, rev, ev, bodyOf(ev, budget)); err != nil {
			tx.Rollback()
			return nil, err
		}
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	for _, ev := range pair {
		id, _ := ev.Get("event_id").(string)
		s.SeenEvents[id] = true
	}
	s.Revs.Set(RevKey{q, rev}, rec2)
	return py.T(out1, out2), nil
}

// SetAck persists delivery state (acknowledged vs intended).
func (s *Store) SetAck(actionID, status string) error {
	s.Acks.Set(actionID, status)
	_, err := s.DB.Exec("INSERT OR REPLACE INTO meta (key, value) VALUES ('acks', ?)", py.Dumps(s.Acks))
	return err
}

// LedgerView is the authoritative inventory for the validator: question ->
// revision -> facts. Revision keys are the decimal revision number.
func (s *Store) LedgerView() *py.Dict {
	out := py.NewDict()
	for _, k := range s.Revs.Keys() {
		rec := s.Revs.Get(k)
		fl := py.AsDict(rec.Get("flight"))
		var receipt any
		if aid, ok := fl.Get("action_id").(string); ok && aid != "" {
			receipt = s.Acks.Get(aid)
		}
		qk := py.S(k.Q)
		if !out.Has(qk) {
			out.Set(qk, py.NewDict())
		}
		py.AsDict(out.Get(qk)).Set(py.Repr(normNum(k.Rev)), py.D(
			"phase", rec.Get("phase"), "attempt", rec.Get("attempt"),
			"verdict", rec.Get("verdict"), "disposition", rec.Get("disposition"),
			"decision_task", rec.Get("decision_task"), "blocked", rec.Get("blocked"),
			"flight", rec.Get("flight"), "handoff", rec.Get("handoff"),
			"receipt", receipt))
	}
	return out
}

func (s *Store) LedgerRevision() (int64, error) {
	var n int64
	err := s.DB.QueryRow("SELECT COUNT(*) FROM events").Scan(&n)
	return n, err
}

// PublishSnapshot writes the derived snapshot atomically, after commit.
func (s *Store) PublishSnapshot(path string, extra *py.Dict) (*py.Dict, error) {
	lr, err := s.LedgerRevision()
	if err != nil {
		return nil, err
	}
	terminal := py.NewDict()
	var inFlight []any
	view := s.LedgerView()
	for _, q := range view.Keys() {
		revs := py.AsDict(view.Get(q))
		for _, rev := range revs.Keys() {
			r := py.AsDict(revs.Get(rev))
			pid := q + "-r" + rev
			if isTerminal(r.Get("phase")) {
				entry := py.D("state", r.Get("phase"))
				if d := py.AsDict(r.Get("disposition")); r.Get("disposition") != nil {
					entry.Set("disposition", r.Get("disposition"))
					entry.Set("decided_by", "tern")
					entry.Set("decision_ref", d.GetOr("decision_ref", ""))
					entry.Set("reason", d.GetOr("reason", ""))
				} else if task := py.AsDict(r.Get("decision_task")); task != nil {
					entry.Set("held", true)
					inFlight = append(inFlight, py.D("package_id", pid, "phase", "DECISION",
						"action_id", task.Get("task_id"), "owner", "tern",
						"deadline", task.Get("deadline"), "dispatch_receipt", "acknowledged"))
				}
				terminal.Set(pid, entry)
				continue
			}
			fl := py.AsDict(r.Get("flight"))
			ho := py.AsDict(r.Get("handoff"))
			var entry *py.Dict
			if aid := fl.Get("action_id"); py.Truthy(aid) {
				as, _ := aid.(string)
				entry = py.D("package_id", pid, "phase", r.Get("phase"), "action_id", aid,
					"owner", fl.Get("owner"), "deadline", fl.Get("deadline"),
					"dispatch_receipt", s.Acks.GetOr(as, "none"))
			} else if py.Truthy(ho) {
				entry = py.D("package_id", pid, "phase", r.Get("phase"), "action_id", nil,
					"owner", ho.Get("owner"), "deadline", ho.Get("deadline"),
					"dispatch_receipt", nil)
			} else {
				entry = py.D("package_id", pid, "phase", r.Get("phase"), "action_id", nil,
					"owner", nil, "deadline", nil, "dispatch_receipt", nil)
			}
			inFlight = append(inFlight, entry)
		}
	}
	if inFlight == nil {
		inFlight = []any{}
	}
	snap := py.D("schema_version", int64(1), "ledger_revision", lr,
		"terminal", terminal, "in_flight", inFlight)
	if py.Truthy(extra) {
		snap.Update(extra)
	}
	tmp := path + ".tmp"
	f, err := os.Create(tmp)
	if err != nil {
		return nil, err
	}
	if _, err := f.WriteString(py.Dumps(snap)); err != nil {
		f.Close()
		return nil, err
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return nil, err
	}
	f.Close()
	return snap, os.Rename(tmp, path)
}

func (s *Store) Close() error { return s.DB.Close() }

func DefaultBudget() *py.Dict {
	return py.D("attempts", int64(1), "repairs", int64(1), "verifier_s", int64(1800),
		"passes", py.D("verify", py.D("max_s", int64(1800)),
			"controller_recovery", py.D("max_s", int64(600))))
}
