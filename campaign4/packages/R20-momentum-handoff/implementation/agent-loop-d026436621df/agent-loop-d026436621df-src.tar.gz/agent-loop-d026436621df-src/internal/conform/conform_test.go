package conform

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// TestCases replays every recorded case against the Go core.
func TestCases(t *testing.T) {
	root := filepath.Join("..", "..", "conformance", "cases")
	var files []string
	filepath.WalkDir(root, func(p string, d os.DirEntry, err error) error {
		if err == nil && !d.IsDir() && strings.HasSuffix(p, ".json") && d.Name() != "RECORDING.json" {
			files = append(files, p)
		}
		return nil
	})
	if len(files) == 0 {
		t.Fatal("no cases found under " + root)
	}
	for _, f := range files {
		rel, _ := filepath.Rel(root, f)
		t.Run(rel, func(t *testing.T) {
			if r := RunFile(f); !r.OK {
				t.Error(r.FirstDiff)
			}
		})
	}
}
