package conform

import (
	"fmt"
	"strings"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// Python-style argument binding: positional args fill names in order, then
// keywords. absent reports a parameter the caller did not pass, so the
// handler can apply the Python default.
type bound map[string]any

func bind(args []any, kw *py.Dict, names ...string) (bound, error) {
	b := bound{}
	for i, a := range args {
		if i >= len(names) {
			return nil, fmt.Errorf("too many positional arguments")
		}
		b[names[i]] = a
	}
	for _, k := range kw.Keys() {
		b[k] = kw.Get(k)
	}
	return b, nil
}

func (b bound) or(name string, def any) any {
	if v, ok := b[name]; ok {
		return v
	}
	return def
}

func (b bound) s(name string) string { v, _ := b[name].(string); return v }
func (b bound) d(name string) *py.Dict {
	v, _ := b[name].(*py.Dict)
	return v
}
func (b bound) f(name string) float64 { f, _ := py.Num(b[name]); return f }

func (r *runner) construct(class, id string, args []any, kw *py.Dict) (any, error) {
	switch class {
	case "FakeClock":
		b, _ := bind(args, kw, "start")
		c := core.NewFakeClock(b.or("start", nil))
		r.register(id, c)
		return nil, nil
	case "FakeExternalWorld":
		b, _ := bind(args, kw, "path")
		w, err := core.NewFakeWorld(b.s("path"))
		if err != nil {
			return nil, err
		}
		r.register(id, w)
		return nil, nil
	case "Store":
		b, _ := bind(args, kw, "path")
		st, err := core.OpenStore(b.s("path"))
		if err != nil {
			return nil, err
		}
		r.register(id, st)
		return nil, nil
	case "Driver":
		b, err := bind(args, kw, "db_path", "clock", "world", "artifacts")
		if err != nil {
			return nil, err
		}
		clock, _ := b["clock"].(*core.FakeClock)
		world, _ := b["world"].(*core.FakeWorld)
		d, err := core.NewDriver(b.s("db_path"), clock, world, b.d("artifacts"))
		if err != nil {
			return nil, err
		}
		r.register(id, d)
		r.register(id+".store", d.Store)
		r.register(id+".ingress", d.Ingress)
		if _, ok := r.idOf(d.World); !ok {
			r.register(id+".world", d.World)
		}
		if _, ok := r.idOf(d.Clock); !ok {
			r.register(id+".clock", d.Clock)
		}
		return nil, nil
	}
	return nil, fmt.Errorf("unknown class %s", class)
}

func (r *runner) setattr(o any, attr string, v any) error {
	switch x := o.(type) {
	case *core.FakeClock:
		switch attr {
		case "now":
			s, _ := v.(string)
			x.SetNow(s)
			return nil
		case "_mono":
			x.Mono, _ = py.Num(v)
			return nil
		}
	case *core.Driver:
		if attr == "crash_points" {
			x.CrashPoints = map[string]bool{}
			if s, ok := v.(*py.Set); ok {
				for _, e := range s.Items() {
					x.CrashPoints[py.S(e)] = true
				}
			}
			return nil
		}
	}
	return fmt.Errorf("setattr %T.%s not supported", o, attr)
}

func none(err error) (any, error) { return nil, err }

func (r *runner) call(o any, method string, args []any, kw *py.Dict) (any, error) {
	switch x := o.(type) {
	case *core.Driver:
		return callDriver(x, method, args, kw)
	case *core.Store:
		switch method {
		case "append":
			b, _ := bind(args, kw, "event", "budget", "atomic")
			return x.Append(b.d("event"), b.d("budget"), b.d("atomic"))
		case "record_terminal":
			b, _ := bind(args, kw, "verdict_event", "decide_event", "budget")
			return x.RecordTerminal(b.d("verdict_event"), b.d("decide_event"), b.d("budget"))
		case "set_ack":
			b, _ := bind(args, kw, "action_id", "status")
			return none(x.SetAck(b.s("action_id"), b.s("status")))
		case "ledger_view":
			return x.LedgerView(), nil
		case "ledger_revision":
			return x.LedgerRevision()
		case "publish_snapshot":
			b, _ := bind(args, kw, "path", "extra")
			return x.PublishSnapshot(b.s("path"), b.d("extra"))
		case "close":
			return none(x.Close())
		}
	case *core.Ingress:
		switch method {
		case "append":
			b, _ := bind(args, kw, "event", "budget", "atomic", "grants", "actor", "atomic_actor")
			return x.Append(b.d("event"), b.d("budget"), b["atomic"], b.d("grants"), b["actor"], b["atomic_actor"])
		case "record_terminal":
			b, _ := bind(args, kw, "verdict_event", "decide_event", "budget", "grants", "actor_v", "actor_d")
			return x.RecordTerminal(b.d("verdict_event"), b.d("decide_event"), b.d("budget"),
				b.d("grants"), b["actor_v"], b["actor_d"])
		case "reconcile_clock":
			b, _ := bind(args, kw, "note", "owner")
			return x.ReconcileClock(b["note"], b.or("owner", "cairn"))
		}
	case *core.FakeClock:
		b, _ := bind(args, kw, "seconds")
		switch method {
		case "advance":
			return x.Advance(b.f("seconds")), nil
		case "advance_wall_only":
			return x.AdvanceWallOnly(b.f("seconds")), nil
		case "advance_mono_only":
			return x.AdvanceMonoOnly(b.f("seconds")), nil
		case "utc_now":
			return x.UtcNow(), nil
		case "monotonic":
			return x.Monotonic(), nil
		}
	case *core.FakeWorld:
		b, _ := bind(args, kw, "action_id", "delivery")
		switch method {
		case "record":
			return none(x.Record(b.s("action_id"), b["delivery"]))
		case "delivery":
			return x.Delivery(b.s("action_id")), nil
		}
	}
	return nil, fmt.Errorf("no method %T.%s", o, method)
}

func callDriver(d *core.Driver, method string, args []any, kw *py.Dict) (any, error) {
	switch method {
	case "close":
		return none(d.Close())
	case "admit_authorize":
		b, _ := bind(args, kw, "qid")
		return none(d.AdmitAuthorize(b.s("qid")))
	case "start_dispatch":
		b, _ := bind(args, kw, "qid", "action_id", "duration_s", "grant_ref", "owner_seat")
		return d.StartDispatch(b.s("qid"), b.s("action_id"), b["duration_s"], b["grant_ref"])
	case "acknowledge":
		b, _ := bind(args, kw, "action_id")
		return none(d.Acknowledge(b.s("action_id")))
	case "publish_completion":
		b, _ := bind(args, kw, "qid", "action_id", "hashes", "verify", "handoff", "eid",
			"verify_grant_ref", "handoff_grant_ref")
		return d.PublishCompletion(b.s("qid"), b.s("action_id"), b["hashes"], b["verify"],
			b["handoff"], b["eid"], b["verify_grant_ref"], b["handoff_grant_ref"])
	case "verify":
		names := []string{"qid", "eid", "passed", "elapsed_s", "hold_deadline"}
		b, _ := bind(args, py.NewDict(), names...)
		extra := py.NewDict()
		for _, k := range kw.Keys() {
			switch k {
			case "qid", "eid", "passed", "elapsed_s", "hold_deadline":
				b[k] = kw.Get(k)
			default:
				extra.Set(k, kw.Get(k))
			}
		}
		return d.Verify(b.s("qid"), b.s("eid"), py.Truthy(b["passed"]), b["elapsed_s"], b["hold_deadline"], extra)
	case "terminal_close":
		b, _ := bind(args, kw, "qid", "verdict_eid", "decide_eid", "verdict_body", "disposition")
		return d.TerminalClose(b.s("qid"), b.s("verdict_eid"), b.s("decide_eid"), b.d("verdict_body"), b["disposition"])
	case "on_deadline":
		b, _ := bind(args, kw, "action_id", "qid")
		return d.OnDeadline(b.s("action_id"), b.s("qid"))
	case "on_handoff_deadline":
		b, _ := bind(args, kw, "qid")
		return d.OnHandoffDeadline(b.s("qid"))
	case "cancel_deadline":
		b, _ := bind(args, kw, "action_id", "qid", "owner", "reason")
		return d.CancelDeadline(b.s("action_id"), b["qid"], b.or("owner", "cairn"), b.or("reason", "owned-hold"))
	case "is_cancelled":
		b, _ := bind(args, kw, "timer_id")
		return d.IsCancelled(b.s("timer_id")), nil
	case "handled":
		b, _ := bind(args, kw, "effect_id")
		return d.Handled(b.s("effect_id")), nil
	case "mark_handled":
		b, _ := bind(args, kw, "effect_id")
		return none(d.MarkHandled(b.s("effect_id")))
	case "reconcile_restart":
		b, _ := bind(args, kw, "qid", "action_id")
		return d.ReconcileRestart(b.s("qid"), b.s("action_id")), nil
	case "reconstruct_timers":
		d.ReconstructTimers()
		return nil, nil
	case "dedupe_trigger":
		b, _ := bind(args, kw, "trigger_id")
		return d.DedupeTrigger(b.s("trigger_id"))
	case "pin_grant":
		b, _ := bind(args, kw, "grant_ref", "absolute_deadline", "phase", "decided_by")
		return d.PinGrant(b.s("grant_ref"), b["absolute_deadline"], b["phase"], b.or("decided_by", "tern"))
	case "ledger":
		return d.Ledger()
	case "snapshot":
		b, _ := bind(args, kw, "path")
		return d.Snapshot(b.s("path"))
	case "_submit":
		b, _ := bind(args, kw, "claim", "actor_key", "budget", "atomic", "atomic_actor_key")
		return d.Submit(b.d("claim"), b.s("actor_key"), b.d("budget"), b["atomic"], b.s("atomic_actor_key"))
	}
	return nil, fmt.Errorf("no method Driver.%s", method)
}

func callFunc(name string, args []any, kw *py.Dict) (any, error) {
	switch name {
	case "lifecycle.apply":
		b, _ := bind(args, kw, "state", "event", "now", "budget")
		st, out, err := core.Apply(b.d("state"), b.d("event"), b["now"], b.d("budget"))
		if err != nil {
			return nil, err
		}
		return py.T(st, out), nil
	case "lifecycle.new_revision":
		b, _ := bind(args, kw, "question_id")
		return core.NewRevision(b["question_id"]), nil
	case "validator.validate":
		b, _ := bind(args, kw, "snapshot", "ledger", "now", "triggers_fired")
		return core.Validate(b["snapshot"], b["ledger"], b["now"], b["triggers_fired"]), nil
	case "supervisor.supervise":
		b, _ := bind(args, kw, "snapshot", "ledger", "now", "triggers_fired", "file_activity", "busy_seats")
		return core.Supervise(b["snapshot"], b["ledger"], b["now"], b["triggers_fired"]), nil
	case "supervisor.dedupe_action_due":
		b, _ := bind(args, kw, "seen_trigger_ids", "verdict")
		seen, _ := b["seen_trigger_ids"].(*py.Set)
		if seen == nil {
			seen = py.NewSet()
		}
		return core.DedupeActionDue(seen, b.d("verdict")), nil
	case "supervisor.load_snapshot":
		b, _ := bind(args, kw, "path")
		v, e := core.LoadSnapshot(b.s("path"))
		return py.T(v, e), nil
	case "status.status_report":
		b, _ := bind(args, kw, "package_id", "ledger_packages", "snapshot", "verdict")
		return core.StatusReport(b["package_id"], b.d("ledger_packages"), b.d("snapshot"), b.d("verdict")), nil
	}
	return nil, fmt.Errorf("no function %s", name)
}

// FirstDiff is compare.py's rule: same shape, same leaves, numbers by value.
func FirstDiff(want, got any, path string) string {
	wb, wIsB := want.(bool)
	gb, gIsB := got.(bool)
	if wIsB || gIsB {
		if wIsB && gIsB && wb == gb {
			return ""
		}
		return fmt.Sprintf("%s: want %s, got %s", path, py.Repr(want), py.Repr(got))
	}
	if fw, ok := py.Num(want); ok {
		if fg, ok := py.Num(got); ok {
			if fw == fg {
				return ""
			}
		}
		return fmt.Sprintf("%s: want %s, got %s", path, py.Repr(want), py.Repr(got))
	}
	switch w := want.(type) {
	case *py.Dict:
		g, ok := got.(*py.Dict)
		if !ok {
			return fmt.Sprintf("%s: want object, got %s", path, trim(py.Repr(got)))
		}
		var missing, extra []string
		for _, k := range w.Keys() {
			if !g.Has(k) {
				missing = append(missing, k)
			}
		}
		for _, k := range g.Keys() {
			if !w.Has(k) {
				extra = append(extra, k)
			}
		}
		if missing != nil || extra != nil {
			return fmt.Sprintf("%s: keys missing %v, extra %v", path, missing, extra)
		}
		keys := w.Keys()
		sortStrings(keys)
		for _, k := range keys {
			if d := FirstDiff(w.Get(k), g.Get(k), path+"."+k); d != "" {
				return d
			}
		}
		return ""
	case []any:
		g, ok := got.([]any)
		if !ok {
			return fmt.Sprintf("%s: want list, got %s", path, trim(py.Repr(got)))
		}
		if len(w) != len(g) {
			return fmt.Sprintf("%s: length %d, got %d", path, len(w), len(g))
		}
		for i := range w {
			if d := FirstDiff(w[i], g[i], fmt.Sprintf("%s[%d]", path, i)); d != "" {
				return d
			}
		}
		return ""
	}
	if want == nil && got == nil {
		return ""
	}
	ws, ok1 := want.(string)
	gs, ok2 := got.(string)
	if ok1 && ok2 && ws == gs {
		return ""
	}
	return fmt.Sprintf("%s: want %s, got %s", path, trim(py.Repr(want)), trim(py.Repr(got)))
}

func trim(s string) string {
	if len(s) > 200 {
		return s[:200] + "..."
	}
	return s
}

func sortStrings(s []string) {
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && strings.Compare(s[j-1], s[j]) > 0; j-- {
			s[j-1], s[j] = s[j], s[j-1]
		}
	}
}
