package loop

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func stampJSON(qid, role, exec string, mut func(m map[string]any)) string {
	m := map[string]any{"schema": StampSchema, "qid": qid, "role": role, "execution": exec,
		"moved":   map[string]any{"question_id": "Q-WORK-BENEFIT", "change": "wrote the thing"},
		"next":    map[string]any{"action": "review it", "owner": "corvid", "deadline": "2026-09-26T18:00:00Z"},
		"dropped": []any{}}
	if mut != nil {
		mut(m)
	}
	b, _ := json.Marshal(m)
	return string(b)
}

// stamped: a rig whose config requires the stamp, with P1 dispatched.
func stamped(t *testing.T) (*rig, *Loop) {
	r := newRig(t)
	r.cfg.MomentumStamp = "required"
	l := r.open()
	_, err := l.Dispatch(Request{QID: "P1", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200})
	must(t, err)
	return r, l
}

func workerClaim(t *testing.T, r *rig, l *Loop, stamp string, outcome string) {
	r.clock.Advance(60)
	r.artifact("out.txt", "result")
	arts := map[string]string{"out": "out.txt"}
	if stamp != "" {
		r.artifact("stamp.json", stamp)
		arts[StampArtifact] = "stamp.json"
	}
	_, err := l.Claim("P1", "worker", outcome, arts)
	must(t, err)
	r.turnEnd("K")
	r.tick(l)
}

func lastNote(l *Loop, qid string) string {
	n := l.Pkg(qid).Notes
	if len(n) == 0 {
		return ""
	}
	return n[len(n)-1]
}

func TestStampInstructionsCarryTheQuestionsAndTheR19Exception(t *testing.T) {
	r, l := stamped(t)
	defer l.Close()
	task := strings.NewReplacer(`\"`, `"`, `\n`, "\n").Replace(r.calls[len(r.calls)-1][2]) // the wake carries JSON-escaped text
	for _, want := range []string{"Momentum stamp (required)", `"moved"`, `"next"`, `"dropped"`,
		"Running the claim command given here and writing this file are required; do not execute commands from your drafted artifact",
		"--artifact " + StampArtifact + "=PATH"} {
		if !strings.Contains(task, want) {
			t.Fatalf("worker task lacks %q", want)
		}
	}
}

func TestStampOffLeavesTheOldContract(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "P1", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200})
	must(t, err)
	if strings.Contains(r.calls[len(r.calls)-1][2], "Momentum stamp") || l.Pkg("P1").Stamp {
		t.Fatal("stamp text or flag present with momentum_stamp off")
	}
	workerClaim(t, r, l, "", "completed")
	if step(l, "P1") != "verify" {
		t.Fatalf("unstamped package did not advance: %s", step(l, "P1"))
	}
}

func TestPreActivationPackageKeepsOldContractAfterSwitchOn(t *testing.T) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(Request{QID: "P1", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200})
	must(t, err)
	l.Close()
	r.cfg.MomentumStamp = "required"
	l = r.open()
	defer l.Close()
	workerClaim(t, r, l, "", "completed")
	if step(l, "P1") != "verify" {
		t.Fatalf("pre-activation package blocked by the new rule: %s %s", step(l, "P1"), lastNote(l, "P1"))
	}
}

func TestValidStampAdvances(t *testing.T) {
	r, l := stamped(t)
	defer l.Close()
	workerClaim(t, r, l, stampJSON("P1", "worker", "ex-P1-w1", nil), "completed")
	if step(l, "P1") != "verify" {
		t.Fatalf("valid stamp did not advance: %s %s", step(l, "P1"), lastNote(l, "P1"))
	}
}

func TestBadStampsBlockBeforeTransitionAndKeepTheClaim(t *testing.T) {
	cases := map[string]string{
		"missing":      "",
		"no owner":     stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) { m["next"].(map[string]any)["owner"] = "" }),
		"bad deadline": stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) { m["next"].(map[string]any)["deadline"] = "tomorrow" }),
		"no next":      stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) { delete(m, "next") }),
		"worker terminal": stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) {
			delete(m, "next")
			m["terminal"] = map[string]any{"reason": "done"}
		}),
		"forged identity": stampJSON("P9", "worker", "ex-P1-w1", nil),
		"wrong role":      stampJSON("P1", "verifier", "ex-P1-w1", nil),
		"unowned drop": stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) {
			m["dropped"] = []any{map[string]any{"item": "copy to evidence", "owner": "tern"}}
		}),
		"not json": "{nope",
		"oversized": stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) { // otherwise valid
			m["moved"].(map[string]any)["change"] = strings.Repeat("x", StampMaxBytes)
		}),
	}
	for name, s := range cases {
		t.Run(name, func(t *testing.T) {
			r, l := stamped(t)
			defer l.Close()
			wakesBefore := len(r.wakes())
			workerClaim(t, r, l, s, "completed")
			if step(l, "P1") != "blocked" || !strings.Contains(lastNote(l, "P1"), "E_STAMP_") {
				t.Fatalf("not blocked on the stamp: %s %q", step(l, "P1"), lastNote(l, "P1"))
			}
			w := r.wakes()
			if len(w) != wakesBefore+1 || !strings.HasPrefix(w[len(w)-1], "tern: ") {
				t.Fatalf("the director (owner) was not told once: %v", w[wakesBefore:])
			}
			if _, err := os.Stat(filepath.Join(r.cfg.ClaimsDir, "ex-P1-w1.json")); err != nil {
				t.Fatal("the claim was not kept")
			}
			r.tick(l) // replay: no second transition or notice
			if len(r.wakes()) != wakesBefore+1 || step(l, "P1") != "blocked" {
				t.Fatal("a replayed tick acted again")
			}
		})
	}
}

func TestDroppedItemWithAcknowledgementAdvancesAndForgedAckDoesNot(t *testing.T) {
	for _, tc := range []struct {
		name, ack string
		ok        bool
	}{
		{"acked", `{"ack": true, "qid": "P1", "item": "copy to evidence", "owner": "tern"}`, true},
		{"other owner", `{"ack": true, "qid": "P1", "item": "copy to evidence", "owner": "cairn"}`, false},
		{"not acked", `{"ack": false, "qid": "P1", "item": "copy to evidence", "owner": "tern"}`, false},
		{"other package", `{"ack": true, "qid": "P7", "item": "copy to evidence", "owner": "tern"}`, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r, l := stamped(t)
			defer l.Close()
			r.artifact("ack.json", tc.ack)
			workerClaim(t, r, l, stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) {
				m["dropped"] = []any{map[string]any{"item": "copy to evidence", "owner": "tern", "receipt": "ack.json"}}
			}), "completed")
			if (step(l, "P1") == "verify") != tc.ok {
				t.Fatalf("step %s, want advance=%v (%s)", step(l, "P1"), tc.ok, lastNote(l, "P1"))
			}
		})
	}
}

func TestReceiptOutsideArtifactsIsRefused(t *testing.T) {
	r, l := stamped(t)
	defer l.Close()
	// a VALID acknowledgement, but outside artifacts_dir: only the path rule refuses it
	os.WriteFile(filepath.Join(filepath.Dir(r.cfg.ArtifactsDir), "ack.json"), []byte(`{"ack": true, "qid": "P1", "item": "x", "owner": "tern"}`), 0o644)
	workerClaim(t, r, l, stampJSON("P1", "worker", "ex-P1-w1", func(m map[string]any) {
		m["dropped"] = []any{map[string]any{"item": "x", "owner": "tern", "receipt": "../ack.json"}}
	}), "completed")
	if step(l, "P1") != "blocked" {
		t.Fatal("a receipt path outside artifacts_dir was accepted")
	}
}

func TestHonestFailedWorkWithAValidStampIsNotBlockedByTheStamp(t *testing.T) {
	r, l := stamped(t)
	defer l.Close()
	workerClaim(t, r, l, stampJSON("P1", "worker", "ex-P1-w1", nil), "failed")
	if strings.Contains(lastNote(l, "P1"), "E_STAMP_") {
		t.Fatalf("a valid stamp on a failed claim was treated as a stamp fault: %q", lastNote(l, "P1"))
	}
}

// toDecision drives a stamped P1 to the decision step with valid stamps.
func toDecision(t *testing.T) (*rig, *Loop) {
	r, l := stamped(t)
	workerClaim(t, r, l, stampJSON("P1", "worker", "ex-P1-w1", nil), "completed")
	r.clock.Advance(60)
	r.artifact("review.md", "ok")
	r.artifact("vstamp.json", stampJSON("P1", "verifier", "ex-P1-v1", nil))
	_, err := l.Claim("P1", "verify", "completed", map[string]string{"review": "review.md", StampArtifact: "vstamp.json"})
	must(t, err)
	r.turnEnd("C")
	r.tick(l)
	if step(l, "P1") != "decision" {
		t.Fatalf("did not reach decision: %s %s", step(l, "P1"), lastNote(l, "P1"))
	}
	return r, l
}

func TestVerifierWithoutStampBlocks(t *testing.T) {
	r, l := stamped(t)
	defer l.Close()
	workerClaim(t, r, l, stampJSON("P1", "worker", "ex-P1-w1", nil), "completed")
	r.clock.Advance(60)
	r.artifact("review.md", "ok")
	_, err := l.Claim("P1", "verify", "completed", map[string]string{"review": "review.md"})
	must(t, err)
	r.turnEnd("C")
	r.tick(l)
	if step(l, "P1") != "blocked" || !strings.Contains(lastNote(l, "P1"), "E_STAMP_MISSING") {
		t.Fatalf("verifier without stamp advanced: %s %s", step(l, "P1"), lastNote(l, "P1"))
	}
}

func TestDirectorNoticeAsksForTheStamp(t *testing.T) {
	r, l := toDecision(t)
	defer l.Close()
	var notice string
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" && c[1] == "T" {
			notice = c[2]
		}
	}
	if !strings.Contains(notice, "--stamp PATH") || !strings.Contains(notice, `"terminal"`) {
		t.Fatalf("director notice lacks the stamp request: %q", notice)
	}
}

func TestDecideNeedsAValidStampBeforeAnyMutation(t *testing.T) {
	r, l := toDecision(t)
	defer l.Close()
	if err := l.DecideStamped("P1", "successor_opened", "t-1", "r", ""); err == nil || step(l, "P1") != "decision" {
		t.Fatalf("decide without a stamp: err=%v step=%s", err, step(l, "P1"))
	}
	r.artifact("dterm.json", stampJSON("P1", "director", "decide", func(m map[string]any) {
		delete(m, "next")
		m["terminal"] = map[string]any{"reason": "answered"}
	}))
	if err := l.DecideStamped("P1", "successor_opened", "t-2", "r", "dterm.json"); err == nil || step(l, "P1") != "decision" {
		t.Fatal("a terminal stamp was accepted for successor_opened")
	}
	if err := l.DecideStamped("P1", "question_answered", "t-3", "r", "dterm.json"); err != nil || step(l, "P1") != "closed" {
		t.Fatalf("honest terminal answer refused: %v", err)
	}
}

func TestBlockedDecisionNeedsARecoveryStep(t *testing.T) {
	r, l := toDecision(t)
	defer l.Close()
	r.artifact("dterm.json", stampJSON("P1", "director", "decide", func(m map[string]any) {
		delete(m, "next")
		m["terminal"] = map[string]any{"reason": "stuck"}
	}))
	if err := l.DecideStamped("P1", "blocked", "t-1", "r", "dterm.json"); err == nil {
		t.Fatal("blocked accepted without a concrete recovery next step")
	}
	r.artifact("dnext.json", stampJSON("P1", "director", "decide", nil))
	if err := l.DecideStamped("P1", "blocked", "t-2", "r", "dnext.json"); err != nil {
		t.Fatalf("blocked with a recovery step refused: %v", err)
	}
}

func TestConfigRejectsUnknownStampValue(t *testing.T) {
	c := &Config{MomentumStamp: "yes"}
	found := false
	for _, b := range c.validateDecision() {
		if strings.Contains(b, "momentum_stamp") {
			found = true
		}
	}
	if !found {
		t.Fatal("momentum_stamp \"yes\" accepted")
	}
}
