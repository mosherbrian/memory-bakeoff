// Package shadow replays the live campaign ledger (control-events.tsv)
// through the Go core in observe-only mode.
//
// It never wakes a seat, writes a file the campaign reads, or changes
// anything. It answers one question: if the core had been the loop, where
// would it have disagreed with what the fleet actually did?
//
// Unit of translation. A campaign package holds many dispatches (admission
// reviews, candidates, cases, repairs); the core models one piece of work and
// its independent verification. So each WORKER dispatch becomes its own core
// question, and the verifier dispatch that follows its completion is linked
// to it. A review with no worker product behind it is counted, not modelled.
//
// Every core event here is synthesized from a ledger row, and the report says
// which. The core's own rules then decide what is accepted.
package shadow

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/py"
)

// Row is one control-events.tsv line.
type Row struct {
	Line                          int
	At, Pkg, QID, Verb, Seat, Due string
	Note                          string
}

func instant(s string) (time.Time, bool) {
	// The ledger writes minutes without seconds ("2026-09-22T17:20Z").
	if len(s) == 17 && strings.HasSuffix(s, "Z") {
		s = s[:16] + ":00Z"
	}
	return py.Instant(s)
}

// ReadLedger parses the ledger; malformed lines are returned as gaps.
func ReadLedger(path string) ([]Row, []string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, nil, err
	}
	defer f.Close()
	var rows []Row
	var bad []string
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	n := 0
	for sc.Scan() {
		n++
		p := strings.Split(sc.Text(), "\t")
		if len(p) < 5 || !strings.HasPrefix(p[0], "20") {
			if strings.TrimSpace(sc.Text()) != "" {
				bad = append(bad, fmt.Sprintf("line %d: not a ledger row", n))
			}
			continue
		}
		r := Row{Line: n, At: p[0], Pkg: p[1], QID: p[2], Verb: p[3], Seat: p[4]}
		if len(p) > 5 && p[5] != "-" {
			r.Due = p[5]
		}
		if len(p) > 6 {
			r.Note = p[6]
		}
		if _, ok := instant(r.At); !ok {
			bad = append(bad, fmt.Sprintf("line %d: time %q is not an instant", n, r.At))
			continue
		}
		rows = append(rows, r)
	}
	return rows, bad, sc.Err()
}

// Finding is one disagreement worth a person's attention.
//
// Certainty says how much of the translation it rests on (Tern's ruling,
// SHADOW-TIME-AND-IDENTITY-RULING-20260922): "exact" uses only the rows of
// one dispatch; "name-linked" and "order-linked" rest on a verifier link made
// by name or by order; "synthesized" rests on a core event the shadow made
// up from a row with no core equivalent. Sources are the ledger lines used.
type Finding struct {
	Kind, QID, Detail string
	Line              int
	Certainty         string
	Sources           []int
}

// Report is the shadow's whole output.
type Report struct {
	Rows, Events, Rejected int
	Findings               []Finding
	Rejections             []Finding
	NotModelled            map[string]int // verb -> count, rows with no core meaning
	Reviews                []string       // review dispatches with no worker product
	Gaps                   []string
	Open                   []string
	Guesses                []string // verify links made by order, not by name
	FollowOn               int      // rejections that only follow an earlier one
	FileDecisions          []string // held in the core, decided in a pinned file
}

type question struct {
	qid, pkg, worker string
	completedBy      string
	completedAt      time.Time
	verifyQID        string
	verifyAt         time.Time
	verifyDue        time.Time
	hasVerifyDue     bool
	done             bool   // a verdict or terminal was applied
	lines            []int  // ledger lines this question was built from
	link             string // how its verifier was linked: name, order, re-dispatch
}

func (q *question) certainty() string {
	switch q.link {
	case "name":
		return "name-linked"
	case "":
		return "exact"
	}
	return "order-linked"
}

func withLine(lines []int, l int) []int { return append(append([]int(nil), lines...), l) }

// Run replays rows through a fresh core in dir and returns the report. now
// is the instant open work is judged against.
func Run(rows []Row, dir, pkgRoot string, now time.Time) (*Report, error) {
	st, err := core.OpenStore(filepath.Join(dir, "shadow.db"))
	if err != nil {
		return nil, err
	}
	defer st.Close()
	clock := core.NewFakeClock(nil)
	kv := map[string]string{}
	ing, err := core.NewIngress(st, clock,
		func(k, v string) error { kv[k] = v; return nil },
		func(k string) (string, bool) { v, ok := kv[k]; return v, ok }, "shadow")
	if err != nil {
		return nil, err
	}
	rep := &Report{Rows: len(rows), NotModelled: map[string]int{}}

	// Classify each dispatch from all of its rows, not only the last one:
	// work ends in COMPLETED/INCOMPLETE or goes to kiln; a verification is a
	// dispatch whose own seat gives PASS/FAIL; anything else (admission
	// reviews, preparations) is counted, not modelled.
	type info struct {
		seat          string
		ends, verdict bool
	}
	disp := map[string]*info{}
	for _, r := range rows {
		i := disp[r.QID]
		if i == nil {
			i = &info{}
			disp[r.QID] = i
		}
		if r.Verb == "DISPATCHED" && i.seat == "" {
			i.seat = r.Seat
		}
		if r.Verb == "COMPLETED" || r.Verb == "INCOMPLETE" {
			i.ends = true
		}
		if (r.Verb == "PASS" || r.Verb == "FAIL") && r.Seat == i.seat {
			i.verdict = true
		}
	}
	// Names carry the role the director gave a dispatch. A check of the
	// director's own artifacts (binding, checklist, readiness, admission,
	// amendment, preparation) verifies no worker's product.
	named := func(q string, words ...string) bool {
		l := strings.ToLower(q)
		for _, w := range words {
			if strings.Contains(l, w) {
				return true
			}
		}
		return false
	}
	isReview := func(q string) bool {
		return named(q, "check", "binding", "readiness", "admission", "amendment", "prepare")
	}
	isVerify := func(q string) bool {
		i := disp[q]
		return i != nil && !isReview(q) && (i.verdict || named(q, "verify", "review"))
	}
	isWork := func(q string) bool {
		i := disp[q]
		return i != nil && !isReview(q) && !isVerify(q) && (i.ends || i.seat == "kiln")
	}

	qs := map[string]*question{}
	verifyOf := map[string]*question{}        // verify qid -> worker question
	pendingVerify := map[string][]*question{} // pkg -> finished work, unverified
	dispatched := map[string]bool{}
	firstLine := map[string]int{}
	derailed := map[string]bool{} // a rejection already knocked it off the core's path
	isVerdict := func(v string) bool { return v == "PASS" || v == "FAIL" }

	submit := func(r Row, typ, seat, role string, body *py.Dict, atomic any) error {
		t, _ := instant(r.At)
		clock.SetNow(py.ISO(t))
		qid := body.Get("_q")
		// One row can yield events for several questions (a director
		// decision closes every held question in the package), so the id
		// names the question too. Without it the core correctly ignored
		// every event after the first as a duplicate.
		ev := py.D("event_id", fmt.Sprintf("L%d-%s-%s", r.Line, typ, py.S(qid)), "question_id", qid,
			"revision", int64(1), "type", typ)
		body.Pop("_q")
		ev.Update(body)
		// The director sets each verify window in the ledger (40m is common).
		// That window is the grant, so the per-pass ceiling follows it; the
		// core's 30m default raised a false E_ALLOC_EXCEEDED twice (E-44, E-46).
		var budget *py.Dict
		if w, ok := py.Int(body.Get("pass_budget_s")); ok && w > 1800 {
			budget = core.DefaultBudget()
			budget.Set("verifier_s", w)
			budget.Set("passes", py.D("verify", py.D("max_s", w), "controller_recovery", py.D("max_s", int64(600))))
		}
		_, err := ing.Append(ev, budget, atomic, nil, py.D("seat", seat, "role", role), nil)
		rep.Events++
		if err != nil {
			rep.Rejected++
			if derailed[py.S(qid)] {
				rep.FollowOn++
				return err
			}
			derailed[py.S(qid)] = true
			cert, src := "exact", []int{r.Line}
			if q := qs[py.S(qid)]; q != nil {
				src = withLine(q.lines, r.Line)
				if typ == "verify_pass" || typ == "verify_fail" {
					cert = q.certainty()
				}
			}
			if typ == "interrupt" || typ == "admit" || typ == "authorize" {
				cert = "synthesized"
			}
			rep.Rejections = append(rep.Rejections, Finding{errCode(err), py.S(qid),
				fmt.Sprintf("%s: %s (row: %s %s by %s: %q)", typ, errText(err), r.QID, r.Verb, r.Seat, trim(r.Note, 70)),
				r.Line, cert, src})
		}
		return err
	}
	hold := func(r Row) *py.Dict {
		t, _ := instant(r.At)
		return py.D("hold", py.ISO(t.Add(time.Hour)))
	}
	// link picks the finished work a verifier dispatch verifies: by name
	// first (rejectionverify-1 -> rejection-1), else the most recent.
	link := func(r Row) (*question, bool) {
		pend := pendingVerify[r.Pkg]
		if len(pend) == 0 {
			return nil, false
		}
		vs := stem(strings.Replace(r.QID, "verify", "", 1))
		prefix := stem(strings.SplitN(r.QID, "-", 2)[0])
		best := -1
		for i := len(pend) - 1; i >= 0 && vs != prefix; i-- {
			if ws := flat(pend[i].qid); strings.HasPrefix(ws, vs) {
				best = i
				break
			}
		}
		byName := best >= 0
		if !byName {
			best = len(pend) - 1
		}
		w := pend[best]
		pendingVerify[r.Pkg] = append(pend[:best:best], pend[best+1:]...)
		return w, byName
	}

	for _, r := range rows {
		t, _ := instant(r.At)
		q := qs[r.QID]
		switch {
		case r.Verb == "DISPATCHED" && dispatched[r.QID]:
			rep.Findings = append(rep.Findings, Finding{"dispatched twice", r.QID,
				fmt.Sprintf("a second DISPATCHED row for the same id, by %s", r.Seat), r.Line,
				"exact", []int{firstLine[r.QID], r.Line}})
		case r.Verb == "DISPATCHED" && isReview(r.QID):
			dispatched[r.QID], firstLine[r.QID] = true, r.Line
			rep.Reviews = append(rep.Reviews, r.QID)
		case r.Verb == "DISPATCHED" && isVerify(r.QID):
			dispatched[r.QID], firstLine[r.QID] = true, r.Line
			w, byName := link(r)
			if w == nil {
				// A verification dispatched again (the first ran out or lost
				// its verdict) continues the latest unverified work.
				for _, id := range sortedKeys(qs) {
					c := qs[id]
					if named(r.QID, "verify", "review") && c.pkg == r.Pkg && c.verifyQID != "" && !c.done &&
						(w == nil || c.verifyAt.After(w.verifyAt)) {
						w = c
					}
				}
				if w != nil {
					rep.Guesses = append(rep.Guesses, fmt.Sprintf("%s -> %s (re-dispatched verification)", r.QID, w.qid))
					w.verifyQID, w.verifyAt = r.QID, t
					w.lines = append(w.lines, r.Line)
					w.link = "re-dispatch"
					if d, ok := instant(r.Due); ok {
						w.verifyDue, w.hasVerifyDue = d, true
					}
					verifyOf[r.QID] = w
					continue
				}
				// A check of the director's own artifacts (a binding, a
				// contract, a live run): verification, but of no worker's
				// product. The core has nothing to hold it against.
				rep.Reviews = append(rep.Reviews, r.QID)
				continue
			}
			w.verifyQID, w.verifyAt = r.QID, t
			w.lines = append(w.lines, r.Line)
			w.link = "order"
			if byName {
				w.link = "name"
			}
			if d, ok := instant(r.Due); ok {
				w.verifyDue, w.hasVerifyDue = d, true
			}
			if !byName {
				rep.Guesses = append(rep.Guesses, fmt.Sprintf("%s -> %s (by order, not by name)", r.QID, w.qid))
			}
			verifyOf[r.QID] = w
		case r.Verb == "DISPATCHED" && isWork(r.QID):
			dispatched[r.QID], firstLine[r.QID] = true, r.Line
			qs[r.QID] = &question{qid: r.QID, pkg: r.Pkg, worker: r.Seat, lines: []int{r.Line}}
			submit(r, "admit", "corvid", "reader", py.D("_q", r.QID), nil)
			submit(r, "authorize", "tern", "director", py.D("_q", r.QID), nil)
			body := py.D("_q", r.QID, "action_id", r.QID, "acknowledged", true)
			if d, ok := instant(r.Due); ok {
				body.Set("duration_s", int64(d.Sub(t).Seconds()))
			}
			submit(r, "start", "cairn", "duty", body, nil)
		case r.Verb == "DISPATCHED":
			dispatched[r.QID], firstLine[r.QID] = true, r.Line
			rep.Reviews = append(rep.Reviews, r.QID)
		case r.Verb == "COMPLETED" && q != nil:
			q.completedBy, q.completedAt = r.Seat, t
			q.lines = append(q.lines, r.Line)
			if r.Seat != q.worker {
				rep.Findings = append(rep.Findings, Finding{"completed by another seat", r.QID,
					fmt.Sprintf("dispatched to %s, completed by %s", q.worker, r.Seat), r.Line,
					"exact", append([]int(nil), q.lines...)})
			}
			submit(r, "publish", r.Seat, "worker", py.D("_q", r.QID,
				"artifact_hashes", py.D("evidence", r.Note),
				"handoff_deadline", py.ISO(t.Add(30*time.Minute)), "handoff_owner", "duty"), nil)
			pendingVerify[r.Pkg] = append(pendingVerify[r.Pkg], q)
		case (r.Verb == "INCOMPLETE" || r.Verb == "BLOCKED" || r.Verb == "INFRA_FAILURE") && q != nil:
			if r.Seat == q.worker {
				q.completedBy = r.Seat // the worker's own stop, not duty recording one
			}
			submit(r, "interrupt", "cairn", "duty", py.D("_q", r.QID, "reason", strings.ToLower(r.Verb)), nil)
			if r.Verb == "INCOMPLETE" {
				pendingVerify[r.Pkg] = append(pendingVerify[r.Pkg], q)
			}
		case r.Verb == "RESOLVED" && q != nil:
			submit(r, "resolve", r.Seat, "director", py.D("_q", r.QID), nil)
		case r.Verb == "CANCELLED" && q != nil:
			submit(r, "terminate", "cairn", "duty", py.D("_q", r.QID), hold(r))
		case isVerdict(r.Verb) && verifyOf[r.QID] != nil:
			w := verifyOf[r.QID]
			if r.Seat == w.completedBy || r.Seat == w.worker {
				rep.Findings = append(rep.Findings, Finding{"self-verification", w.qid,
					fmt.Sprintf("%s gave %s on work that %s finished (%s)", r.Seat, r.Verb, w.completedBy, r.QID), r.Line,
					w.certainty(), withLine(w.lines, r.Line)})
			}
			budget := int64(1800)
			if w.hasVerifyDue {
				budget = int64(w.verifyDue.Sub(w.verifyAt).Seconds())
			}
			typ := "verify_pass"
			if r.Verb == "FAIL" {
				typ = "verify_fail"
			}
			if submit(r, typ, r.Seat, "verifier", py.D("_q", w.qid,
				"elapsed_s", int64(t.Sub(w.verifyAt).Seconds()), "pass_budget_s", budget,
				"eligible_repair", false), hold(r)) == nil {
				w.done = true
			}
		case r.Seat == "tern" && q != nil && (r.Verb == "ACCEPTED" || r.Verb == "SUPERSEDED" || r.Verb == "EXHAUSTED"):
			// The director decided this dispatch directly.
			rec := st.Revs.Get(core.RevKey{Q: q.qid, Rev: int64(1)})
			phase := py.S(rec.Get("phase"))
			if r.Verb == "SUPERSEDED" {
				// Superseding is itself the director's decision.
				if submit(r, "amend", "tern", "director", py.D("_q", q.qid, "new_revision", int64(2)), hold(r)) == nil {
					submit(r, "decide", "tern", "director", py.D("_q", q.qid, "disposition",
						py.D("kind", "successor_opened", "decision_ref", r.QID, "reason", trim(r.Note, 120))), nil)
				}
				continue
			}
			if !isTerminalPhase(phase) {
				cert := q.certainty()
				if q.verifyQID == "" {
					cert = "order-linked" // no verifier was linked; a missed link looks the same
				}
				rep.Findings = append(rep.Findings, Finding{"decided without a verdict", q.qid,
					fmt.Sprintf("director %s it while the core had it %s: no independent verifier verdict", r.Verb, phase), r.Line,
					cert, withLine(q.lines, r.Line)})
				derailed[q.qid] = true
				continue
			}
			kind := "question_answered"
			if r.Verb == "EXHAUSTED" {
				kind = "budget_spent"
			}
			submit(r, "decide", r.Seat, "director", py.D("_q", q.qid,
				"disposition", py.D("kind", kind, "decision_ref", r.QID,
					"reason", trim(r.Note, 120), "evidence_refs", []any{r.QID})), nil)
		case r.Seat == "tern" && (r.Verb == "ACCEPTED" || r.Verb == "EXHAUSTED" || r.Verb == "SUPERSEDED"):
			// A director decision on the package decides every finished,
			// undecided question in it.
			kind := "question_answered"
			if r.Verb != "ACCEPTED" {
				kind = "budget_spent"
			}
			for _, id := range sortedKeys(qs) {
				w := qs[id]
				if w.pkg != r.Pkg {
					continue
				}
				rec := st.Revs.Get(core.RevKey{Q: w.qid, Rev: int64(1)})
				if rec == nil || rec.Get("disposition") != nil || !isTerminalPhase(rec.Get("phase")) {
					continue
				}
				submit(r, "decide", r.Seat, "director", py.D("_q", w.qid,
					"disposition", py.D("kind", kind, "decision_ref", r.QID,
						"reason", trim(r.Note, 120), "evidence_refs", []any{r.QID})), nil)
			}
		case isVerdict(r.Verb) || r.Verb == "COMPLETED" || r.Verb == "INCOMPLETE" ||
			r.Verb == "CANCELLED" || r.Verb == "ACCEPTED":
			// Belongs to a review or preparation dispatch: no core event.
		default:
			rep.NotModelled[r.Verb]++
		}
	}

	// Judge what is still open against now, as the core's supervisor would.
	var ids []string
	for id := range qs {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	for _, id := range ids {
		rec := st.Revs.Get(core.RevKey{Q: id, Rev: int64(1)})
		if rec == nil || derailed[id] {
			continue
		}
		phase := py.S(rec.Get("phase"))
		switch {
		case phase == "RUNNING" || phase == "CHECKING":
			dl := py.AsDict(rec.Get("flight")).Get("deadline")
			if dl == nil {
				dl = py.AsDict(rec.Get("handoff")).Get("deadline")
			}
			if d, ok := py.Instant(dl); ok && d.Before(now) {
				what := "worker deadline passed with no completion"
				if phase == "CHECKING" {
					what = "completed, but no verifier verdict before the handoff deadline"
				}
				rep.Open = append(rep.Open, fmt.Sprintf("%s: %s (%s, deadline %s)", id, what, phase, py.S(dl)))
			}
		case isTerminalPhase(phase) && rec.Get("disposition") == nil:
			// Resolve a decision only from an exact file in the package, never
			// from message order (Tern's ruling). The file is named, not read
			// as proof: it shows where the decision lives, outside the ledger.
			if f := decisionFile(pkgRoot, qs[id].pkg); f != "" {
				rep.FileDecisions = append(rep.FileDecisions, fmt.Sprintf("%s: %s in the core; decision is in %s, not in the ledger", id, phase, f))
				continue
			}
			rep.Open = append(rep.Open, fmt.Sprintf("%s: %s, no director decision in the ledger or the package folder", id, phase))
		}
	}
	return rep, nil
}

func isTerminalPhase(v any) bool {
	s, _ := v.(string)
	return s == "COMPLETE" || s == "EXHAUSTED" || s == "TERMINATED" || s == "SUPERSEDED"
}

func contains(xs []string, s string) bool {
	for _, x := range xs {
		if x == s {
			return true
		}
	}
	return false
}

func trim(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

// stem normalises a dispatch id for name matching: lower case, no dashes,
// no trailing attempt number ("P6r9-repair-2" -> "p6r9repair2").
func stem(q string) string {
	q = strings.ToLower(q)
	if i := strings.LastIndex(q, "-"); i > 0 && strings.Trim(q[i+1:], "0123456789") == "" {
		q = q[:i]
	}
	return strings.ReplaceAll(q, "-", "")
}

// decisionFile names the director's decision file for a package, if any.
func decisionFile(root, pkg string) string {
	if root == "" || pkg == "" {
		return ""
	}
	for _, f := range []string{"acceptance.json", "acceptance-withheld.json", "terminal-disposition.json"} {
		p := filepath.Join(root, pkg, f)
		if _, err := os.Stat(p); err == nil {
			return filepath.Join("packages", pkg, f)
		}
	}
	return ""
}

// flat is the id lower-cased with dashes removed, attempt number kept.
func flat(q string) string { return strings.ReplaceAll(strings.ToLower(q), "-", "") }

func sortedKeys(m map[string]*question) []string {
	var ks []string
	for k := range m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

func errCode(err error) string {
	switch e := err.(type) {
	case *core.TransitionError:
		return e.Code
	case *core.IngressError:
		return e.Code
	}
	return "ERROR"
}

func errText(err error) string {
	switch e := err.(type) {
	case *core.TransitionError:
		return e.Code + ": " + py.S(e.Detail)
	case *core.IngressError:
		return e.Code + ": " + py.S(e.Detail)
	}
	return err.Error()
}
