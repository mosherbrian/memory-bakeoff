package host

import (
	"testing"
	"time"
)

// The timeout bounds the call even when a grandchild holds the pipes open.
func TestExecRunnerTimeoutBoundsAGrandchildHoldingThePipes(t *testing.T) {
	start := time.Now()
	_, err := ExecRunner([]string{"/bin/sh", "-c", "sleep 5; echo late"}, nil, 500*time.Millisecond)
	if el := time.Since(start); el > 2*time.Second || err != ErrTimeout {
		t.Fatalf("took %s, err %v", el, err)
	}
}
