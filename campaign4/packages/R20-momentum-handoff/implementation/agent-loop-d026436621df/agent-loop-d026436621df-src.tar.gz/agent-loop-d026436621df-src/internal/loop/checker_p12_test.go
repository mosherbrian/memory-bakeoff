package loop

import (
	"os"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
)

// P12-checker-ownership-1: a check that cannot do its ledger work is never a
// completed check; its failure is owned without the ledger lock.

func TestACheckThatCannotTakeTheLedgerIsPendingAndFailed(t *testing.T) {
	r := newLiveRig(t)
	now := time.Now().UTC()
	r.pass(now, 1)
	k, err := LockLedger(r.cfg, time.Second) // another writer holds the ledger
	must(t, err)
	_, did, err := (&Checker{Cfg: r.cfg, Now: now}).Check()
	k.Unlock()
	var p PendingCheck
	if err == nil || !readJSONInto(pendingCheckPath(r.cfg), &p) || p.Count != 1 {
		t.Fatalf("an incomplete check passed or left no pending marker: %v %+v %v", err, p, did)
	}
	// The handler owns it without the ledger lock (held again here).
	k, err = LockLedger(r.cfg, time.Second)
	must(t, err)
	in, err := CheckerFailed(r.cfg, "chk.service", "exit-code 1", now)
	k.Unlock()
	must(t, err)
	if !strings.HasPrefix(in.Duty, "sent") || in.Director != "" || !strings.Contains(in.Pending, "1 check(s)") {
		t.Fatalf("incident %+v", in)
	}
	// Only a completed check clears the marker and closes the incident.
	if _, _, err := (&Checker{Cfg: r.cfg, Now: now.Add(30 * time.Second)}).Check(); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(pendingCheckPath(r.cfg)); err == nil {
		t.Fatal("the pending marker survived a completed check")
	}
	var c CheckerIncident
	if !readJSONInto(checkerIncidentPath(r.cfg), &c) || c.ClosedAt == "" || !strings.HasPrefix(c.RecoveryMsg, "sent") {
		t.Fatalf("not closed by the completed check: %+v", c)
	}
}

func TestTheHandlerEscalatesToTheDirectorAndDedupes(t *testing.T) {
	r := newLiveRig(t)
	r.cfg.Duty = "corvid" // duty and director are different seats here
	now := time.Now().UTC()
	in, err := CheckerFailed(r.cfg, "chk.service", "timeout", now)
	must(t, err)
	if !strings.HasPrefix(in.Duty, "sent") || in.Director != "" {
		t.Fatalf("first failure: %+v", in)
	}
	in2, _ := CheckerFailed(r.cfg, "chk.service", "timeout", now.Add(30*time.Second))
	if in2.ID != in.ID || in2.Failures != 2 || in2.Director != "" {
		t.Fatalf("not one incident, or director too early: %+v", in2)
	}
	in3, _ := CheckerFailed(r.cfg, "chk.service", "signal", now.Add(61*time.Second))
	if !strings.HasPrefix(in3.Director, "sent") {
		t.Fatalf("still failing after 60 s, director not told: %+v", in3)
	}
	// Duty unreachable: the director at once, and the failed send is not success.
	r2 := newLiveRig(t)
	r2.cfg.Duty = "corvid"
	run := r2.cfg.Run
	r2.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		if len(argv) > 1 && argv[1] == r2.cfg.Seats["corvid"] {
			return host.Proc{RC: 1, Stderr: "could not reach"}, nil
		}
		return run(argv, env, timeout)
	}
	d, _ := CheckerFailed(r2.cfg, "chk.service", "exit-code 1", now)
	if !strings.HasPrefix(d.Duty, "failed") || !strings.HasPrefix(d.Director, "sent") {
		t.Fatalf("duty failure not escalated: %+v", d)
	}
}
