package loop

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"syscall"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// P12-checker-ownership-1: the outside check's own failures have an owner
// that needs neither the ledger lock nor a healthy run or checker.
//
//   - A check that cannot take the ledger lock within CheckLockWait (refused
//     at admission, or the lock held) records a coalesced pending-check marker
//     (<db>.check-pending.json, one file) WITHOUT the ledger lock and exits
//     nonzero: it never reports a completed health check. The pending work is
//     the ledger part of the check (timeout escalations, ack drain). It is
//     retried by run after every pass (EscalateTimeouts) and by every ledger
//     holder (ProcessDue drains acks), and, when run is stopped, by the next
//     check on the 30 s calendar timer. Only a check that completes (verdict
//     and ledger work) clears the marker and closes the incident.
//   - The check service has a numeric TimeoutStartSec and OnFailure= a
//     separate handler unit that runs `agent-loop checker-failed`. It covers a
//     nonzero exit (including the refusal above), a killed checker (signal)
//     and a hung one (killed at the timeout). The handler takes only its own
//     small file lock (<db>.checker.lock), reads the failed unit's result,
//     and keeps one incident (<db>.checker-incident.json): duty is told at
//     once; the director when duty's wake is not accepted, or when the
//     incident is still failing CheckerDirectorAfter after duty was told.
//     Every send is bounded (CheckerSendTimeout); only wake rc 0 (started) or
//     3 (queued) counts as told, and neither is an acknowledgement.
//   - Not covered (host boundary): the timer itself not firing, and the
//     systemd user manager being down. Those stop both the check and its
//     handler; nothing in this process tree can report them.
const (
	CheckLockWait        = 10 * time.Second
	CheckerSendTimeout   = 5 * time.Second
	CheckerDirectorAfter = 60 * time.Second
)

// PendingCheck is the coalesced record of checks that did not complete.
type PendingCheck struct {
	FirstAt    string `json:"first_at"`
	LastAt     string `json:"last_at"`
	Count      int    `json:"count"`
	LastReason string `json:"last_reason"`
	LastPID    int    `json:"last_pid"`
}

// CheckerIncident is the handler's one open (or last closed) incident.
type CheckerIncident struct {
	ID          string `json:"id"`
	OpenedAt    string `json:"opened_at"`
	Failures    int    `json:"failures"`
	LastAt      string `json:"last_at"`
	LastResult  string `json:"last_result"`
	Pending     string `json:"pending,omitempty"`
	Duty        string `json:"duty,omitempty"`     // "sent <time>" | "failed <time>: why"
	Director    string `json:"director,omitempty"` // same
	ClosedAt    string `json:"closed_at,omitempty"`
	ClosedBy    string `json:"closed_by,omitempty"`
	RecoveryMsg string `json:"recovery_notice,omitempty"`
}

func pendingCheckPath(cfg *Config) string    { return cfg.DB + ".check-pending.json" }
func checkerIncidentPath(cfg *Config) string { return cfg.DB + ".checker-incident.json" }

// withCheckerLock runs fn under <db>.checker.lock, never the ledger lock.
func withCheckerLock(cfg *Config, fn func() error) error {
	f, err := os.OpenFile(cfg.DB+".checker.lock", os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	if err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX); err != nil {
		return err
	}
	defer syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
	return fn()
}

func readJSONInto(path string, v any) bool {
	b, err := os.ReadFile(path)
	return err == nil && json.Unmarshal(b, v) == nil
}

func writeJSON(path string, v any) error {
	b, _ := json.MarshalIndent(v, "", " ")
	if err := os.WriteFile(path+".tmp", b, 0o644); err != nil {
		return err
	}
	return os.Rename(path+".tmp", path)
}

// RecordPendingCheck coalesces a check that did not complete.
func RecordPendingCheck(cfg *Config, now time.Time, reason string) error {
	return withCheckerLock(cfg, func() error {
		var p PendingCheck
		if !readJSONInto(pendingCheckPath(cfg), &p) {
			p = PendingCheck{FirstAt: py.ISO(now)}
		}
		p.LastAt, p.Count, p.LastReason, p.LastPID = py.ISO(now), p.Count+1, reason, os.Getpid()
		return writeJSON(pendingCheckPath(cfg), p)
	})
}

// ReconcileCheck runs after a check COMPLETED: it clears the pending marker
// and closes an open checker incident, telling duty once.
func ReconcileCheck(cfg *Config, now time.Time) []string {
	var out []string
	withCheckerLock(cfg, func() error {
		if os.Remove(pendingCheckPath(cfg)) == nil {
			out = append(out, "pending check cleared by a completed check")
		}
		var in CheckerIncident
		if !readJSONInto(checkerIncidentPath(cfg), &in) || in.ClosedAt != "" {
			return nil
		}
		in.ClosedAt, in.ClosedBy = py.ISO(now), fmt.Sprintf("a completed check (pid %d)", os.Getpid())
		in.RecoveryMsg = checkerSend(cfg, cfg.Duty, fmt.Sprintf("[agent-loop] checker incident %s RECOVERED at %s: the outside check completed again after %d failure(s) (last: %s).",
			in.ID, in.ClosedAt, in.Failures, in.LastResult), now)
		out = append(out, "checker incident "+in.ID+" closed; duty "+in.RecoveryMsg)
		return writeJSON(checkerIncidentPath(cfg), in)
	})
	return out
}

// checkerSend is one bounded wake; "sent <time>" only on rc 0/3.
func checkerSend(cfg *Config, seat, text string, now time.Time) string {
	run := cfg.Run
	if run == nil {
		run = host.ExecRunner
	}
	p, err := run([]string{cfg.Wake, cfg.Seats[seat], text}, []string{"AGENTDECK_PROFILE=" + cfg.Profile}, CheckerSendTimeout)
	switch {
	case err != nil:
		return "failed " + py.ISO(now) + ": " + err.Error()
	case p.RC == host.WakeRCSent || p.RC == host.WakeRCQueued:
		return "sent " + py.ISO(now)
	default:
		return fmt.Sprintf("failed %s: wake rc %d %s", py.ISO(now), p.RC, strings.TrimSpace(p.Stderr))
	}
}

// CheckerFailed is the OnFailure handler: record the failed check and own it.
// result describes the failed unit (systemd Result, exit code/status).
func CheckerFailed(cfg *Config, unit, result string, now time.Time) (*CheckerIncident, error) {
	var in CheckerIncident
	err := withCheckerLock(cfg, func() error {
		if !readJSONInto(checkerIncidentPath(cfg), &in) || in.ClosedAt != "" {
			in = CheckerIncident{ID: fmt.Sprintf("C-%d", now.Unix()), OpenedAt: py.ISO(now)}
		}
		in.Failures++
		in.LastAt, in.LastResult = py.ISO(now), unit+": "+result
		var p PendingCheck
		if readJSONInto(pendingCheckPath(cfg), &p) {
			in.Pending = fmt.Sprintf("%d check(s) did not complete since %s (last: %s)", p.Count, p.FirstAt, p.LastReason)
		}
		if err := writeJSON(checkerIncidentPath(cfg), in); err != nil { // the failure is recorded before any send
			return err
		}
		text := func(role string) string {
			return fmt.Sprintf("[agent-loop] OUTSIDE CHECK FAILED (checker incident %s, %d failure(s) since %s): %s. %s You are %s. The loop's liveness and timeout escalations are not being checked until the check completes again. See: agent-loop status --config %s; journalctl --user -u %s",
				in.ID, in.Failures, in.OpenedAt, in.LastResult, in.Pending, role, cfg.Path, unit)
		}
		if !strings.HasPrefix(in.Duty, "sent") {
			in.Duty = checkerSend(cfg, cfg.Duty, text("duty"), now)
		}
		dutySent, _ := py.Instant(strings.TrimPrefix(in.Duty, "sent "))
		if !strings.HasPrefix(in.Director, "sent") &&
			(!strings.HasPrefix(in.Duty, "sent") || now.Sub(dutySent) >= CheckerDirectorAfter) {
			in.Director = checkerSend(cfg, cfg.Director, text("director"), now)
		}
		return writeJSON(checkerIncidentPath(cfg), in)
	})
	return &in, err
}
