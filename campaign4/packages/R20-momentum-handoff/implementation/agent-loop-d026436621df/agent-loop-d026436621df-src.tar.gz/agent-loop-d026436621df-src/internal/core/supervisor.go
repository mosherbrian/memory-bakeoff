package core

import (
	"os"

	"agent-loop/internal/py"
)

// Supervision: authoritative ledger + versioned snapshot. Owned faults are
// returned explicitly, never as silent success. File activity and busy
// seats are informational only and never mask INVALID.

func LoadSnapshot(path string) (any, any) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, "E_ABSENT_STATE: snapshot unreadable (" + err.Error() + ")"
	}
	v, err := py.Loads(data)
	if err != nil {
		return nil, "E_ABSENT_STATE: snapshot unreadable (" + err.Error() + ")"
	}
	return v, nil
}

func ownerReconcile(code, detail string) *py.Dict {
	return py.D("verdict", "INVALID", "code", code, "detail", detail,
		"action", py.D("type", "owner-reconcile", "owner", "cairn"))
}

func Supervise(snapshot, ledger, now, triggersFired any) *py.Dict {
	led, ok := ledger.(*py.Dict)
	if !ok || !led.Has("packages") {
		return ownerReconcile("E_LEDGER", "ledger unavailable")
	}
	if snapshot == nil {
		return ownerReconcile("E_ABSENT_STATE", "missing snapshot; ledger authoritative")
	}
	if snap, ok := snapshot.(*py.Dict); ok && snap.Has("ledger_revision") && led.Has("revision") &&
		!py.Eq(snap.Get("ledger_revision"), led.Get("revision")) {
		return ownerReconcile("E_LEDGER_INCOMPLETE", "stale snapshot revision")
	}
	v := Validate(snapshot, ledger, now, triggersFired)
	if py.Eq(v.Get("verdict"), "INVALID") && !v.Has("code") {
		v.Set("code", "E_INVALID")
	}
	return v
}

// DedupeActionDue deduplicates ACTION_DUE via durable trigger ids.
func DedupeActionDue(seen *py.Set, verdict *py.Dict) py.Tuple {
	if !py.Eq(verdict.Get("verdict"), "ACTION_DUE") {
		return py.T(verdict, false)
	}
	tid := py.AsDict(verdict.Get("action")).Get("trigger_id")
	if seen.Has(tid) {
		return py.T(py.D("verdict", "ACTIVE", "detail",
			"deduplicated; trigger "+py.S(tid)+" already owned"), true)
	}
	seen.Add(tid)
	return py.T(verdict, false)
}
