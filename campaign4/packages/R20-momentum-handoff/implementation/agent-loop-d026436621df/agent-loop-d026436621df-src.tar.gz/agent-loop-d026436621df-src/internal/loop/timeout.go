package loop

import (
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// StepTimeout is the durable record of a step whose deadline passed: how
// the cancel went, whether the director was told, and who acknowledged
// ownership. It never resumes or closes the package.
type StepTimeout struct {
	ID           string   `json:"id"` // T-<action>
	Action       string   `json:"action"`
	At           string   `json:"at"`       // host clock when the timeout was settled
	Cancel       string   `json:"cancel"`   // cancelled | idle | failed: <receipt state and error>
	Director     string   `json:"director"` // told | failed: <why>
	Ack          *StepAck `json:"ack,omitempty"`
	AckExpiredAt string   `json:"ack_expired_escalated_at,omitempty"`
	// Never-acked escalation (P12-closure-1): duty first, then the director.
	// Each is "sent <time>" or "failed <time>: <why>" (a failed send is retried
	// on the next pass; it is never recorded as delivered). An escalation is
	// not an acknowledgement and not a recovery.
	NoAckDuty     string `json:"no_ack_duty,omitempty"`
	NoAckDirector string `json:"no_ack_director,omitempty"`
	Lateness      string `json:"callback_lateness,omitempty"` // settlement time minus the ledger deadline
	Deferred      string `json:"deferred_callback,omitempty"` // a busy callback's due marker time (detection evidence, not settlement)
}

// NoAckAfter is how long a settled timeout may stay unacknowledged before
// duty is told; the director is told NoAckAfter later (or at once if duty
// cannot be reached). Both run (after every pass, --every 30 s) and the
// outside liveness check (its timer, 45 s, also while run is stopped) run
// the escalation, so the bound is NoAckAfter + the shorter of the two
// intervals that is running + the check time: at most 60 s + 45 s + check
// time while run is stopped, 60 s + 30 s + pass time while it runs.
const NoAckAfter = 60 * time.Second

// StepAck is an acknowledgement of a step timeout by the director or duty.
type StepAck struct {
	By         string `json:"by"`
	NextAction string `json:"next_action"`
	Deadline   string `json:"response_deadline"`
	At         string `json:"at"`
}

// AckCommand is the exact command a principal runs to acknowledge a timeout.
func (l *Loop) AckCommand(qid, action string) string {
	return fmt.Sprintf("%s timeout-ack --config %s --qid %s --action %s --by SEAT --next 'NEXT ACTION' --within 15m",
		l.Cfg.Bin, l.Cfg.Path, qid, action)
}

// lastReceipt is the newest transport receipt for an action and kind.
func (l *Loop) lastReceipt(action, kind string) (string, string) {
	best, bestN, state := "", int64(-1), ""
	for k, v := range l.D.KV {
		if !strings.HasPrefix(k, "msg:") {
			continue
		}
		d := py.AsDict(mustLoads(v))
		if d == nil || py.S(d.Get("kind")) != kind || py.S(d.Get("action")) != action {
			continue
		}
		i := strings.LastIndex(k, "-")
		n, _ := strconv.ParseInt(k[i+1:], 10, 64)
		if n > bestN {
			best, bestN, state = strings.TrimPrefix(k, "msg:"), n, py.S(d.Get("state"))
		}
	}
	return best, state
}

func mustLoads(s string) any { v, _ := py.Loads([]byte(s)); return v }

// MarkTimedOut records a timeout that the core settled: the cancel was
// confirmed (or found nothing running) and the director was told.
func (l *Loop) MarkTimedOut(qid, action string) error {
	p := l.Pkg(qid)
	if p == nil || p.Step == "closed" {
		return nil
	}
	if p.Step == "timed-out" && p.Timeout != nil && p.Timeout.Action == action {
		return nil // already recorded
	}
	// The core's current action is the authority, not the loop step: a step
	// the loop marked blocked (or recovery) is still timed out by its deadline.
	rec := l.D.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if rec == nil || py.S(rec.Get("phase")) != "BLOCKED" ||
		py.S(py.AsDict(rec.GetOr("flight", py.NewDict())).Get("action_id")) != action {
		return nil // not the core's current action, or the core did not interrupt it
	}
	if p.Timeout == nil || p.Timeout.Action != action {
		mid, st := l.lastReceipt(action, "stop")
		p.Timeout = &StepTimeout{ID: "T-" + action, Action: action, At: py.ISO(l.now()),
			Cancel: st + " (" + mid + ")", Director: "told", Lateness: l.lateness(qid)}
	}
	return l.setStep(p, "timed-out", "deadline passed for "+action+"; cancel "+p.Timeout.Cancel+", director told")
}

// deadlineOf is the ledger's authoritative deadline for qid's current flight.
func (l *Loop) deadlineOf(qid string) (time.Time, bool) {
	rec := l.D.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if rec == nil {
		return time.Time{}, false
	}
	return py.Instant(py.AsDict(rec.GetOr("flight", py.NewDict())).Get("deadline"))
}

// RearmEarly handles a deadline callback that ran before the ledger's
// deadline (possible only after a host clock step back, since the timer and
// the ledger read the same UTC clock). Only for the current action of a
// running step, with the recorded duty principal: the same unit is re-armed
// at the original ledger instant and duty is told. Nothing is cancelled,
// dispatched or settled. A failed re-arm is an owned failure, told to duty.
func (l *Loop) RearmEarly(qid, action, execution string) (string, error) {
	p := l.Pkg(qid)
	if p == nil {
		return "", fmt.Errorf("no package %s", qid)
	}
	cur := map[string]string{"worker": p.WorkAction, "verify": p.VerifyAction}[p.Step]
	rec := l.D.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if cur != action || rec == nil || py.S(rec.Get("phase")) != "RUNNING" {
		return "", fmt.Errorf("%s: %s is not the running step's action (step %s): not re-armed", qid, action, p.Step)
	}
	if _, err := l.authority(p, "duty"); err != nil {
		return "", err
	}
	dl, ok := l.deadlineOf(qid)
	if !ok {
		return "", fmt.Errorf("no ledger deadline for %s", qid)
	}
	cb := []string{l.Cfg.Bin, "timer-callback", "--config", l.Cfg.Path, "--qid", qid, "--action", action, "--execution", execution}
	out, err := l.Adapter.Timers.RearmHost(l.unit(action), dl, cb)
	note := fmt.Sprintf("%s deadline callback for %s ran %s before its deadline %s (host clock discontinuity)",
		py.ISO(l.now()), action, dl.Sub(l.now()).Round(time.Second), py.ISO(dl))
	if err != nil {
		note += "; RE-ARM FAILED, the deadline has no timer: " + err.Error()
	} else {
		note += "; " + py.S(out[0]) + " " + l.unit(action) + ".timer at the original deadline"
	}
	if err == nil && py.Truthy(out[1]) {
		return note, nil // a replay of an already re-armed timer: nothing new to tell
	}
	p.Notes = append(p.Notes, note)
	if serr := l.save(p); serr != nil {
		return note, serr
	}
	if werr := l.send(l.Cfg.Duty, "[agent-loop] "+qid+": "+note+". See: agent-loop status --config "+l.Cfg.Path, "escalation", qid); werr != nil && err == nil {
		err = werr
	}
	return note, err
}

// lateness is the settlement time minus the ledger deadline.
func (l *Loop) lateness(qid string) string {
	if dl, ok := l.deadlineOf(qid); ok {
		return l.now().Sub(dl).Round(time.Millisecond).String()
	}
	return "unknown (no ledger deadline)"
}

// SettleTimeoutFailure owns a timeout whose effects failed after the core
// recorded the interrupt (e.g. the /cancel did not arrive): the step is
// settled as timed-out with the truthful failure, and the director (else
// duty) is told with the evidence and the ack command. It does nothing if
// the package is not at that action, or the core did not interrupt it.
func (l *Loop) SettleTimeoutFailure(qid, action string, cause error) (string, error) {
	p := l.Pkg(qid)
	if p == nil {
		return "", fmt.Errorf("no package %s", qid)
	}
	cur := map[string]string{"worker": p.WorkAction, "verify": p.VerifyAction}[p.Step]
	if p.Step == "timed-out" && p.Timeout != nil && p.Timeout.Action == action && p.Timeout.Director == "told" {
		return "already settled", nil
	}
	if p.Step != "timed-out" && cur != action {
		return "", fmt.Errorf("%s is at step %s, not at %s: not settled", qid, p.Step, action)
	}
	rec := l.D.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if rec == nil || py.S(rec.Get("phase")) != "BLOCKED" {
		return "", fmt.Errorf("the core did not interrupt %s: not settled", qid)
	}
	mid, st := l.lastReceipt(action, "stop")
	if p.Timeout == nil || p.Timeout.Action != action {
		p.Timeout = &StepTimeout{ID: "T-" + action, Action: action, At: py.ISO(l.now()), Lateness: l.lateness(qid)}
	}
	p.Timeout.Cancel = fmt.Sprintf("failed: receipt %s state %q: %v", mid, st, cause)
	text := fmt.Sprintf("[agent-loop] %s: step %s passed its deadline and the cancel was NOT confirmed (%s). "+
		"The turn may still be running. Acknowledge ownership with: %s", qid, action, p.Timeout.Cancel, l.AckCommand(qid, action))
	if st == "idle" || st == "cancelled" {
		// The cancel was confirmed; what failed is the core's notice to the
		// director (refused, or delivery unknown after its labelled repeat).
		p.Timeout.Cancel = fmt.Sprintf("%s (%s); settlement notice: %v", st, mid, cause)
		text = fmt.Sprintf("[agent-loop] %s: step %s passed its deadline; the cancel was confirmed (%s (%s)) but the settlement notice to the director was not confirmed (%v). "+
			"Acknowledge ownership with: %s", qid, action, st, mid, cause, l.AckCommand(qid, action))
	}
	p.Timeout.Director = "told"
	if err := l.sendSeat("settlefail|"+qid+"|"+action, l.Cfg.Director, text, "escalation", qid); err != nil {
		p.Timeout.Director = "failed: " + err.Error()
		if derr := l.sendSeat("settlefail|"+qid+"|"+action, l.Cfg.Duty, text, "escalation", qid); derr != nil {
			p.Timeout.Director += "; duty failed: " + derr.Error()
		} else {
			p.Timeout.Director += "; duty told"
		}
	}
	if err := l.setStep(p, "timed-out", "deadline passed for "+action+"; "+p.Timeout.Cancel+"; director "+p.Timeout.Director); err != nil {
		return "", err
	}
	return "settled: cancel failed, director " + p.Timeout.Director, nil
}

// AckTimeout records that the director or duty owns a step timeout, with
// the next action and a response deadline. Same ack again is a no-op; a
// different ack while one is in force is refused. It never resumes or
// closes the package.
// The caller holds the ledger lock and opened l under it (timeout-ack does).
func (l *Loop) AckTimeout(qid, action, by, next string, within time.Duration) (*StepAck, error) {
	return l.ackTimeout(qid, action, by, next, within)
}

func (l *Loop) ackTimeout(qid, action, by, next string, within time.Duration) (*StepAck, error) {
	p := l.Pkg(qid)
	if p == nil {
		return nil, fmt.Errorf("no package %s", qid)
	}
	if p.Step != "timed-out" || p.Timeout == nil || p.Timeout.Action != action {
		return nil, fmt.Errorf("%s has no open step timeout for %s (step %s)", qid, action, p.Step)
	}
	role := map[string]string{l.Cfg.Director: "director", l.Cfg.Duty: "duty"}[by]
	if role == "" {
		return nil, fmt.Errorf("%s is neither the director (%s) nor duty (%s)", by, l.Cfg.Director, l.Cfg.Duty)
	}
	if _, err := l.authority(p, role); err != nil {
		return nil, err
	}
	if err := l.Cfg.VerifySeats(by); err != nil {
		return nil, err
	}
	if strings.TrimSpace(next) == "" {
		return nil, fmt.Errorf("--next must name the next action")
	}
	if within <= 0 || within > MaxAckWithin {
		return nil, fmt.Errorf("--within must be between 1s and %s", MaxAckWithin)
	}
	now := l.now()
	if a := p.Timeout.Ack; a != nil {
		dl, ok := py.Instant(a.Deadline)
		inForce := ok && now.Before(dl)
		if inForce && a.By == by && a.NextAction == next {
			return a, nil // replay
		}
		if inForce {
			return nil, fmt.Errorf("%s is already acknowledged by %s until %s (%s)", p.Timeout.ID, a.By, a.Deadline, a.NextAction)
		}
	}
	p.Timeout.Ack = &StepAck{By: by, NextAction: next, Deadline: py.ISO(now.Add(within)), At: py.ISO(now)}
	p.Timeout.AckExpiredAt = ""
	p.Notes = append(p.Notes, py.ISO(now)+" timeout "+p.Timeout.ID+" acknowledged by "+by+": "+next)
	return p.Timeout.Ack, l.save(p)
}

// LedgerLock serializes every writer of one project's ledger across
// processes: run passes, deadline callbacks, the outside check's timeout
// escalation, timeout-ack, decide, dispatch and claim. The holder opens the
// ledger only AFTER taking the lock, so it reads fresh core and package state,
// and keeps the lock for the whole operation (core transition, package record
// and effects), so no writer acts on a stale view. There is no nesting (each
// process takes it once per operation). Waits are bounded: a timeout is the
// owned fault E_LEDGER_BUSY, never a silent skip.
type LedgerLock struct {
	f   *os.File
	cfg *Config
	run host.Runner
}

// HoldBudget bounds every ledger-lock hold; MinIO is the least time left in
// which a subprocess is still started; UnitReserve is the least time left in
// which a new unit of work (one package step, one due marker) is started.
var (
	HoldBudget  = 10 * time.Second
	MinIO       = 1500 * time.Millisecond
	UnitReserve = 6 * time.Second
)

// OutOfBudget reports that the current hold cannot start another unit.
func (l *Loop) OutOfBudget() bool { return budgetShort(l.Cfg) }

// BudgetShort reports that the current hold has too little budget left for
// another unit of work (the holder should release and queue again).
func BudgetShort(cfg *Config) bool { return budgetShort(cfg) }

func budgetShort(cfg *Config) bool {
	return !cfg.HoldDeadline.IsZero() && time.Until(cfg.HoldDeadline) < UnitReserve
}

func LockLedger(cfg *Config, wait time.Duration) (*LedgerLock, error) {
	f, err := os.OpenFile(cfg.DB+".lock", os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return nil, err
	}
	q, class := newQueue(cfg), lockClass()
	deadline := time.Now().Add(wait)
	ent, admitted, refused := "", false, 0
	defer func() {
		if ent != "" {
			q.remove(ent)
		}
	}()
	for {
		isHead, exists := false, false
		if ent != "" {
			q.touch(ent)
			if isHead, exists = q.head(ent); !exists {
				lockLog("queue-lost-place") // reaped (stale): back to the end of the queue
				ent = ""
			}
		}
		if ent == "" {
			switch name, err := q.admit(class); {
			case err == errQueueFull:
				if refused == 0 {
					lockLog("queue-refused")
				}
				refused++
			case err != nil:
				f.Close()
				return nil, err
			default:
				if !admitted && wait >= AdmittedWait() {
					// Bounded progress: an admitted writer is granted within
					// AdmittedWait of its admission; time spent refused
					// before admission does not count against it.
					deadline = time.Now().Add(AdmittedWait())
				}
				ent, admitted = name, true
				lockLog("queue-admitted")
				isHead, _ = q.head(ent)
			}
		}
		if isHead {
			err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB)
			if err == nil {
				// The deferred removal drops this entry: a holder that wants the
				// lock again queues at the back.
				q.granted(class)
				k := &LedgerLock{f: f, cfg: cfg, run: cfg.Run}
				dl := time.Now().Add(HoldBudget)
				inner := cfg.Run
				if inner == nil {
					inner = host.ExecRunner
				}
				cfg.HoldDeadline = dl
				lockLog("acquire")
				cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
					rem := time.Until(dl)
					if rem < MinIO {
						return host.Proc{}, host.ErrBudget
					}
					if timeout > rem {
						timeout = rem
					}
					return inner(argv, env, timeout)
				}
				return k, nil
			}
			if err != syscall.EWOULDBLOCK {
				f.Close()
				return nil, err
			}
		}
		if time.Now().After(deadline) {
			f.Close()
			if !admitted {
				return nil, &host.Fault{Code: "E_LEDGER_SATURATED", Detail: fmt.Sprintf("ledger %s: the %s admission queue (cap %d) stayed full for %s; not admitted", cfg.DB, class, QueueCap[class], wait), Owner: "cairn"}
			}
			return nil, &host.Fault{Code: "E_LEDGER_BUSY", Detail: fmt.Sprintf("ledger %s held by another writer for more than %s", cfg.DB, wait), Owner: "cairn"}
		}
		time.Sleep(queuePoll)
	}
}

// lockLog appends "<unix-nanos> <pid> <event> <cmd>" to $AGENT_LOOP_LOCK_LOG
// when set: measurement for contention tests, off in production.
func lockLog(ev string) {
	path := os.Getenv("AGENT_LOOP_LOCK_LOG")
	if path == "" {
		return
	}
	cmd := ""
	if len(os.Args) > 1 {
		cmd = os.Args[1]
	}
	if f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644); err == nil {
		fmt.Fprintf(f, "%d %d %s %s\n", time.Now().UnixNano(), os.Getpid(), ev, cmd)
		f.Close()
	}
}

// Unlock releases the lock (process exit releases it too).
func (k *LedgerLock) Unlock() {
	lockLog("release")
	k.cfg.Run, k.cfg.HoldDeadline = k.run, time.Time{}
	syscall.Flock(int(k.f.Fd()), syscall.LOCK_UN)
	k.f.Close()
}

// withTimeouts takes the ledger lock (bounded CheckLockWait, so the check
// service's TimeoutStartSec holds), opens the ledger fresh and runs fn: the
// outside check's entry point.
func withTimeouts(cfg *Config, clock core.DriverClock, fn func(f *Loop) error) error {
	k, err := LockLedger(cfg, CheckLockWait)
	if err != nil {
		return err
	}
	defer k.Unlock()
	due := ProcessDue(cfg) // due deadlines before ordinary work
	f, err := Open(cfg, clock)
	if err != nil {
		return err
	}
	err = fn(f)
	f.Close()
	ProcessDue(cfg) // and again before the lock is released
	_ = due
	return err
}

// EscalateTimeouts runs the never-acked and expired-ack escalations under
// the timeout lock. run calls it after every pass; the outside liveness
// check calls it on every check, also while run is stopped.
func EscalateTimeouts(cfg *Config, clock core.DriverClock) ([]string, error) {
	var out []string
	err := withTimeouts(cfg, clock, func(f *Loop) error {
		out = append(append(f.unacked(), f.expiredAcks()...), f.decisionLadder()...)
		return nil
	})
	return out, err
}

// unacked escalates timeouts nobody acknowledged: duty at NoAckAfter, the
// director at 2*NoAckAfter or as soon as duty cannot be reached. Bound to the
// same incident (T-<action>), action and recorded principals.
func (l *Loop) unacked() []string {
	var out []string
	pk := l.Pkgs()
	sort.Slice(pk, func(i, j int) bool { return pk[i].QID < pk[j].QID })
	now := l.now()
	for _, p := range pk {
		t := p.Timeout
		if p.Step != "timed-out" || t == nil || t.Ack != nil {
			continue
		}
		at, ok := py.Instant(t.At)
		if !ok || now.Sub(at) < NoAckAfter {
			continue
		}
		text := func(to string) string {
			return fmt.Sprintf("[agent-loop] %s: timeout %s (step %s) has had NO acknowledgement for %s (settled %s; cancel %s). You are %s. Acknowledge ownership with: %s",
				p.QID, t.ID, t.Action, now.Sub(at).Round(time.Second), t.At, t.Cancel, to, l.AckCommand(p.QID, t.Action))
		}
		send := func(role, seat string) string {
			if _, err := l.authority(p, role); err != nil {
				return "failed " + py.ISO(now) + ": " + err.Error()
			}
			if err := l.sendSeat("noack|"+p.QID+"|"+role+"|"+t.ID+"|"+t.At, seat, text(role), "escalation", p.QID); err != nil {
				return "failed " + py.ISO(now) + ": " + err.Error()
			}
			return "sent " + py.ISO(now)
		}
		changed := false
		if !strings.HasPrefix(t.NoAckDuty, "sent") {
			t.NoAckDuty, changed = send("duty", l.Cfg.Duty), true
			out = append(out, p.QID+": no ack, duty "+t.NoAckDuty)
		}
		if !strings.HasPrefix(t.NoAckDirector, "sent") && (now.Sub(at) >= 2*NoAckAfter || strings.HasPrefix(t.NoAckDuty, "failed")) {
			t.NoAckDirector, changed = send("director", l.Cfg.Director), true
			out = append(out, p.QID+": no ack, director "+t.NoAckDirector)
		}
		if changed {
			if err := l.save(p); err != nil {
				out = append(out, p.QID+": no-ack record not saved: "+err.Error())
			}
		}
	}
	return out
}

// expiredAcks escalates, once, every timeout whose acknowledged response
// deadline passed while the package is still timed out.
func (l *Loop) expiredAcks() []string {
	var out []string
	pk := l.Pkgs()
	sort.Slice(pk, func(i, j int) bool { return pk[i].QID < pk[j].QID })
	for _, p := range pk {
		t := p.Timeout
		if p.Step != "timed-out" || t == nil || t.Ack == nil || t.AckExpiredAt != "" {
			continue
		}
		dl, ok := py.Instant(t.Ack.Deadline)
		if !ok || l.now().Before(dl) {
			continue
		}
		msg := fmt.Sprintf("[agent-loop] %s: the acknowledgement of %s by %s expired at %s (next action was: %s). Re-acknowledge with: %s",
			p.QID, t.ID, t.Ack.By, t.Ack.Deadline, t.Ack.NextAction, l.AckCommand(p.QID, t.Action))
		if err := l.sendSeat("ackexpiry|"+p.QID+"|"+t.ID+"|"+t.Ack.Deadline, l.Cfg.Director, msg, "escalation", p.QID); err != nil {
			out = append(out, p.QID+": ack expiry escalation failed: "+err.Error())
			continue
		}
		t.AckExpiredAt = py.ISO(l.now())
		if err := l.save(p); err == nil {
			out = append(out, p.QID+": acknowledgement expired; director told")
		}
	}
	return out
}
