package core

import (
	"database/sql"
	"os"
	"sort"
	"time"

	"agent-loop/internal/py"
)

// Event-driven driver: authoritative deadline events plus durable recovery.
// No subprocess, socket, signal, network or model calls exist here. External
// state is simulated by FakeWorld, an object held independently of any
// Driver so that crash-boundary behaviour across reopen is genuine.

// FakeClock is the injected test clock with coherent wall + monotonic time.
type FakeClock struct {
	now  string
	Mono float64
}

func NewFakeClock(start any) *FakeClock {
	s, ok := start.(string)
	if !ok {
		s = "2026-09-21T12:00:00Z"
	}
	return &FakeClock{now: s, Mono: 1000.0}
}

func (c *FakeClock) Now() string        { return c.now }
func (c *FakeClock) UtcNow() string     { return c.now }
func (c *FakeClock) Monotonic() float64 { return c.Mono }

// SetNow assigns the wall clock; the monotonic counter moves by the same
// delta, so ordinary time travel never looks like a discontinuity.
func (c *FakeClock) SetNow(v string) {
	old, ok1 := py.Instant(c.now)
	nw, ok2 := py.Instant(v)
	if ok1 && ok2 {
		c.Mono += nw.Sub(old).Seconds()
	}
	c.now = v
}

func (c *FakeClock) shift(seconds float64) string {
	cur, _ := py.Instant(c.now)
	c.now = py.ISO(cur.Add(time.Duration(seconds * float64(time.Second))))
	return c.now
}

func (c *FakeClock) Advance(seconds float64) string {
	c.shift(seconds)
	c.Mono += seconds
	return c.now
}
func (c *FakeClock) AdvanceWallOnly(seconds float64) string { return c.shift(seconds) }
func (c *FakeClock) AdvanceMonoOnly(seconds float64) string {
	c.Mono += seconds
	return c.now
}

// FakeWorld is the independent simulation of external delivery state.
type FakeWorld struct {
	Path  string
	State *py.Dict
}

func NewFakeWorld(path string) (*FakeWorld, error) {
	w := &FakeWorld{Path: path, State: py.NewDict()}
	if path != "" {
		if data, err := os.ReadFile(path); err == nil {
			v, err := py.Loads(data)
			if err != nil {
				return nil, err
			}
			w.State = py.AsDict(v)
		}
	}
	return w, nil
}

func (w *FakeWorld) save() error {
	if w.Path == "" {
		return nil
	}
	tmp := w.Path + ".tmp"
	if err := os.WriteFile(tmp, []byte(py.Dumps(w.State)), 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, w.Path)
}

func (w *FakeWorld) Record(actionID string, delivery any) error {
	w.State.Set(actionID, py.D("delivery", delivery))
	return w.save()
}

func (w *FakeWorld) Delivery(actionID string) any {
	return py.AsDict(w.State.GetOr(actionID, py.NewDict())).GetOr("delivery", "unknown")
}

type FakeExecutor struct {
	Artifacts *py.Dict
	Runs      []any
}

func (e *FakeExecutor) Run(actionID string) any {
	e.Runs = append(e.Runs, actionID)
	return e.Artifacts.GetOr(actionID, py.D("output_hash", "sha256:fake-"+actionID))
}

type FakeLaunch struct {
	World     *FakeWorld
	Artifacts *py.Dict
	Launches  []any
}

func (l *FakeLaunch) Launch(actionID string) (*py.Dict, error) {
	l.Launches = append(l.Launches, actionID)
	arts := py.AsDict(l.Artifacts.GetOr(actionID,
		py.D("output_hash", "sha256:fake-"+actionID))).Copy()
	if err := l.World.Record(actionID, "dispatched"); err != nil {
		return nil, err
	}
	// Bind the dispatch artifacts for later claim verification.
	py.AsDict(l.World.State.Get(actionID)).Set("artifacts", arts)
	return arts, l.World.save()
}

type FakeInspect struct {
	World *FakeWorld
	Calls []any
}

func (i *FakeInspect) Inspect(actionID string) *py.Dict {
	i.Calls = append(i.Calls, actionID)
	return py.D("action_id", actionID, "delivery", i.World.Delivery(actionID))
}

// FakeStopWake records stop/wake into the independent world. It sends
// nothing unless a production caller sets OnStop/OnWake, which run first;
// an error from them leaves the effect undelivered, to be retried.
type FakeStopWake struct {
	World         *FakeWorld
	Stops, Wakes  []any
	Notifications []any
	OnStop        func(actionID, reason string) error
	OnWake        func(seat, reason string) error
}

func (x *FakeStopWake) Stop(actionID, reason string) error {
	if x.OnStop != nil {
		if err := x.OnStop(actionID, reason); err != nil {
			return err
		}
	}
	x.Stops = append(x.Stops, []any{actionID, reason})
	return x.World.Record("stop:"+actionID, "delivered")
}

func (x *FakeStopWake) Wake(seat, reason string) error {
	if x.OnWake != nil {
		if err := x.OnWake(seat, reason); err != nil {
			return err
		}
	}
	x.Wakes = append(x.Wakes, []any{seat, reason})
	return x.World.Record("wake:"+seat+":"+reason, "delivered")
}

// FakeTimer: one-shot arming, in memory only. Authority lives in the ledger
// plus the durable handled-effect table.
type FakeTimer struct {
	clock   DriverClock
	Armed   *py.Dict
	Fired   map[string]bool
	Removed map[string]bool
}

func (t *FakeTimer) Arm(id string, deadline any) {
	if !t.Fired[id] {
		t.Armed.Set(id, deadline)
	}
}
func (t *FakeTimer) Remove(id string) { t.Armed.Pop(id); t.Removed[id] = true }
func (t *FakeTimer) Fire(id string)   { t.Fired[id] = true; t.Armed.Pop(id) }

const (
	CrashAfterInterrupt = "after-interrupt"
	CrashAfterStop      = "after-stop"
	CrashAfterStopAck   = "after-stop-ack"
	CrashAfterWake      = "after-wake"
	CrashAfterWakeAck   = "after-wake-ack"
)

// Actor is the authoritative role -> trusted context mapping. Worker prose
// never supplies identity.
var Actor = map[string]*py.Dict{
	"director": py.D("seat", "tern", "role", "director"),
	"duty":     py.D("seat", "cairn", "role", "duty"),
	"worker":   py.D("seat", "kiln", "role", "worker"),
	"verifier": py.D("seat", "corvid", "role", "verifier"),
	"reader":   py.D("seat", "corvid", "role", "reader"),
}

func actor(key string) *py.Dict { return Actor[key].Copy() }

type Driver struct {
	Clock       DriverClock
	World       *FakeWorld
	Store       *Store
	Launch      *FakeLaunch
	Inspect     *FakeInspect
	Ext         *FakeStopWake
	Timer       *FakeTimer
	Executor    *FakeExecutor
	Budget      *py.Dict
	KV          map[string]string
	CrashPoints map[string]bool
	Grants      *py.Dict
	Ingress     *Ingress
}

func NewDriver(dbPath string, clock DriverClock, world *FakeWorld, artifacts *py.Dict) (*Driver, error) {
	if clock == nil {
		clock = NewFakeClock(nil)
	}
	if world == nil {
		world, _ = NewFakeWorld("")
	}
	st, err := OpenStore(dbPath)
	if err != nil {
		return nil, err
	}
	if artifacts == nil {
		artifacts = py.NewDict()
	}
	d := &Driver{Clock: clock, World: world, Store: st,
		Launch:      &FakeLaunch{World: world, Artifacts: artifacts},
		Inspect:     &FakeInspect{World: world},
		Ext:         &FakeStopWake{World: world},
		Timer:       &FakeTimer{clock: clock, Armed: py.NewDict(), Fired: map[string]bool{}, Removed: map[string]bool{}},
		Executor:    &FakeExecutor{Artifacts: artifacts},
		Budget:      DefaultBudget(),
		CrashPoints: map[string]bool{},
	}
	if _, err := st.DB.Exec("CREATE TABLE IF NOT EXISTS driver_kv (key TEXT PRIMARY KEY, value TEXT)"); err != nil {
		return nil, err
	}
	if d.KV, err = loadKV(st.DB); err != nil {
		return nil, err
	}
	d.Grants = d.loadGrants()
	d.Ingress, err = NewIngress(st, clock, d.KVPut,
		func(k string) (string, bool) { v, ok := d.KV[k]; return v, ok }, "")
	if err != nil {
		return nil, err
	}
	d.ReconstructTimers()
	return d, nil
}

func loadKV(db *sql.DB) (map[string]string, error) {
	rows, err := db.Query("SELECT key, value FROM driver_kv")
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	kv := map[string]string{}
	for rows.Next() {
		var k, v string
		if err := rows.Scan(&k, &v); err != nil {
			return nil, err
		}
		kv[k] = v
	}
	return kv, nil
}

func (d *Driver) loadGrants() *py.Dict {
	if raw, ok := d.KV["ingress-grants"]; ok && raw != "" {
		if v, err := py.Loads([]byte(raw)); err == nil {
			if g := py.AsDict(v); g != nil {
				return g
			}
		}
	}
	return py.D("__allocation_cap_s__", int64(7200))
}

// PinGrant pins a director-approved absolute grant, durable across restart.
func (d *Driver) PinGrant(ref string, deadline, phase, decidedBy any) (string, error) {
	if decidedBy == nil {
		decidedBy = "tern"
	}
	d.Grants.Set(ref, py.D("absolute_deadline", deadline, "phase", phase, "decided_by", decidedBy))
	return ref, d.KVPut("ingress-grants", py.Dumps(d.Grants))
}

// DriverClock is what the driver reads time from: FakeClock in tests,
// HostClock in production.
type DriverClock interface {
	Clock
	Now() string
}

// KVPutMany writes several keys in ONE transaction. The in-memory view
// changes only after the commit, so a crash cannot leave half a
// declaration behind.
func (d *Driver) KVPutMany(pairs [][2]string) error {
	tx, err := d.Store.DB.Begin()
	if err != nil {
		return err
	}
	for _, p := range pairs {
		if _, err := tx.Exec("INSERT OR REPLACE INTO driver_kv (key, value) VALUES (?, ?)", p[0], p[1]); err != nil {
			tx.Rollback()
			return err
		}
	}
	if err := tx.Commit(); err != nil {
		return err
	}
	for _, p := range pairs {
		d.KV[p[0]] = p[1]
	}
	return nil
}

func (d *Driver) KVPut(k, v string) error {
	d.KV[k] = v
	_, err := d.Store.DB.Exec("INSERT OR REPLACE INTO driver_kv (key, value) VALUES (?, ?)", k, v)
	return err
}

func (d *Driver) Handled(effect string) bool { return d.KV["handled:"+effect] == "handled-acked" }
func (d *Driver) MarkHandled(effect string) error {
	return d.KVPut("handled:"+effect, "handled-acked")
}

func (d *Driver) maybeCrash(point string) error {
	if d.CrashPoints[point] {
		return &SimulatedCrash{point}
	}
	return nil
}

// CancelDeadline durably invalidates this action's deadline callback. The
// ledger flight and deadline stay authoritative.
func (d *Driver) CancelDeadline(actionID string, qid any, owner, reason any) (py.Tuple, error) {
	if owner == nil {
		owner = "cairn"
	}
	if reason == nil {
		reason = "owned-hold"
	}
	tid := "deadline:" + actionID
	d.Timer.Remove(tid)
	if err := d.KVPut("cancelled:"+tid, "cancelled"); err != nil {
		return nil, err
	}
	if err := d.KVPut("cancel-info:"+tid, py.Dumps(py.D("owner", owner, "reason", reason,
		"qid", qid, "at", d.Clock.Now()))); err != nil {
		return nil, err
	}
	return py.T("cancelled", true), nil
}

func (d *Driver) IsCancelled(timerID string) bool { return d.KV["cancelled:"+timerID] == "cancelled" }

// Submit binds the trusted actor context at the boundary; any actor inside
// the claim is dropped before submission.
func (d *Driver) Submit(claim *py.Dict, actorKey string, budget *py.Dict, atomic any, atomicActorKey string) (py.Tuple, error) {
	c := claim.Copy()
	c.Pop("actor")
	var aa any
	if atomicActorKey != "" {
		aa = actor(atomicActorKey)
	}
	if budget == nil {
		budget = d.Budget
	}
	return d.Ingress.Append(c, budget, atomic, d.Grants, actor(actorKey), aa)
}

func (d *Driver) ev(eid, qid any, typ, who string, body *py.Dict) *py.Dict {
	e := py.D("event_id", eid, "question_id", qid, "revision", int64(1),
		"type", typ, "actor", actor(who), "at", d.Clock.Now())
	e.Update(body)
	return e
}

func (d *Driver) AdmitAuthorize(qid string) error {
	if _, err := d.Submit(d.ev(qid+"-admit", qid, "admit", "verifier", nil), "reader", nil, nil, ""); err != nil {
		return err
	}
	_, err := d.Submit(d.ev(qid+"-authz", qid, "authorize", "director",
		py.D("contract", "P5-fixture-v1")), "director", nil, nil, "")
	return err
}

// StartDispatch records the trusted start before dispatch. The deadline is
// derived by ingress; duplicate delivery cannot create attempts.
func (d *Driver) StartDispatch(qid, actionID string, durationS, grantRef any) (py.Tuple, error) {
	if err := d.KVPut("intent:"+actionID, "intended"); err != nil {
		return nil, err
	}
	if py.Eq(d.Store.Acks.Get(actionID), "acknowledged") {
		return py.T("redelivered-same-action", true), nil
	}
	if d.Store.SeenEvents[actionID+"-start"] {
		return py.T("duplicate-ignored", true), nil
	}
	claim := py.D("event_id", actionID+"-start", "question_id", qid, "revision", int64(1),
		"type", "start", "actor", py.D("seat", "cairn", "role", "duty"),
		"action_id", actionID, "acknowledged", false)
	if durationS != nil {
		claim.Set("duration_s", durationS)
	}
	if grantRef != nil {
		claim.Set("grant_ref", grantRef)
	}
	out, err := d.Submit(claim, "duty", nil, nil, "")
	if err != nil {
		return nil, err
	}
	artifacts := d.Executor.Run(actionID)
	if _, err := d.Launch.Launch(actionID); err != nil {
		return nil, err
	}
	if err := d.Store.SetAck(actionID, "acknowledged"); err != nil {
		return nil, err
	}
	derived := py.AsDict(py.AsDict(d.Store.Revs.Get(RevKey{qid, int64(1)})).Get("flight")).Get("deadline")
	if py.Truthy(derived) && !d.IsCancelled("deadline:"+actionID) {
		d.Timer.Arm("deadline:"+actionID, derived)
	}
	return py.T(py.D("start", out[0], "artifacts", artifacts), false), nil
}

func (d *Driver) Acknowledge(actionID string) error {
	if err := d.Store.SetAck(actionID, "acknowledged"); err != nil {
		return err
	}
	return d.KVPut("intent:"+actionID, "acknowledged")
}

func (d *Driver) PublishCompletion(qid, actionID string, hashes any, verify, handoff, eid,
	verifyGrantRef, handoffGrantRef any) (py.Tuple, error) {
	body := py.D("artifact_hashes", hashes)
	if verify != nil {
		body.Set("verify", verify)
	}
	if handoff != nil {
		body.Update(py.AsDict(handoff))
	}
	if verifyGrantRef != nil {
		body.Set("verify_grant_ref", verifyGrantRef)
	}
	if handoffGrantRef != nil {
		body.Set("handoff_grant_ref", handoffGrantRef)
	}
	if !py.Truthy(hashes) {
		return nil, &PyError{"AssertionError", "immutable outputs must precede completion"}
	}
	if !py.Truthy(eid) {
		eid = actionID + "-pub"
	}
	out, err := d.Submit(d.ev(eid, qid, "publish", "worker", body), "worker", nil, nil, "")
	if err != nil {
		return nil, err
	}
	if _, err := d.CancelDeadline(actionID, qid, "cairn", "rotated-on-publish"); err != nil {
		return nil, err
	}
	rec := d.Store.Revs.Get(RevKey{qid, int64(1)})
	fl := py.AsDict(rec.Get("flight"))
	ho := py.AsDict(rec.Get("handoff"))
	if py.Truthy(fl.Get("action_id")) && py.Truthy(fl.Get("deadline")) {
		aid := fl.Get("action_id").(string)
		d.Timer.Arm("deadline:"+aid, fl.Get("deadline"))
		if err := d.KVPut("intent:"+aid, "intended"); err != nil {
			return nil, err
		}
	} else if py.Truthy(ho.Get("deadline")) {
		d.Timer.Arm("handoff:"+qid, ho.Get("deadline"))
	}
	return out, nil
}

func (d *Driver) Verify(qid, eid string, passed bool, elapsedS any, holdDeadline any, kw *py.Dict) (py.Tuple, error) {
	typ, finding := "verify_fail", "defect"
	if passed {
		typ, finding = "verify_pass", "positive"
	}
	if elapsedS == nil {
		elapsedS = int64(60)
	}
	if holdDeadline == nil {
		// From the trusted clock, never a fixed literal that expires.
		now, _ := py.Instant(d.Clock.UtcNow())
		holdDeadline = py.ISO(now.Add(time.Hour))
	}
	body := py.D("elapsed_s", elapsedS, "pass_budget_s", int64(1800),
		"finding", kw.GetOr("finding", finding))
	for _, k := range kw.Keys() {
		if k != "finding" {
			body.Set(k, kw.Get(k))
		}
	}
	return d.Submit(d.ev(eid, qid, typ, "verifier", body), "verifier", nil,
		py.D("hold", holdDeadline), "")
}

func (d *Driver) TerminalClose(qid, verdictEID, decideEID string, verdictBody *py.Dict, disposition any) (py.Tuple, error) {
	who := verdictBody.Get("who").(string)
	vb := py.AsDict(verdictBody.GetOr("body", py.NewDict()))
	v := d.ev(verdictEID, qid, verdictBody.Get("type").(string), who, vb)
	v.Pop("actor")
	dd := d.ev(decideEID, qid, "decide", "director", py.D("disposition", disposition))
	dd.Pop("actor")
	return d.Ingress.RecordTerminal(v, dd, d.Budget, d.Grants, actor(who), actor("director"))
}

func (d *Driver) currentFlight(qid any) *py.Dict {
	rec := d.Store.Revs.Get(RevKey{qid, int64(1)})
	if rec == nil || isTerminal(rec.Get("phase")) {
		return nil
	}
	fl := py.AsDict(rec.Get("flight"))
	if py.Truthy(fl.Get("action_id")) && py.Truthy(fl.Get("deadline")) {
		return py.D("kind", "flight", "action_id", fl.Get("action_id"),
			"deadline", fl.Get("deadline"), "phase", rec.Get("phase"))
	}
	ho := py.AsDict(rec.Get("handoff"))
	if py.Truthy(ho.Get("deadline")) {
		return py.D("kind", "handoff", "action_id", nil,
			"deadline", ho.Get("deadline"), "phase", rec.Get("phase"))
	}
	return nil
}

func (d *Driver) phaseOf(qid any) any {
	return py.AsDict(d.Store.Revs.Get(RevKey{qid, int64(1)})).Get("phase")
}

// OnDeadline handles one deadline event against authoritative ledger
// facts. Only a genuinely due current-action deadline interrupts.
func (d *Driver) OnDeadline(actionID, qid string) (py.Tuple, error) {
	tid := "deadline:" + actionID
	if d.IsCancelled(tid) {
		return py.T("no-op-cancelled", true), nil
	}
	effect := "deadline:" + qid + ":" + actionID
	if d.Handled(effect) {
		return py.T("already-handled", true), nil
	}
	if d.Timer.Removed[tid] || !d.Timer.Armed.Has(tid) {
		return py.T("no-op-not-armed", true), nil
	}
	cur := d.currentFlight(qid)
	if cur == nil {
		return py.T("no-op-no-current-action", true), nil
	}
	if py.Eq(cur.Get("kind"), "handoff") {
		return py.T("no-op-handoff-owned", true), nil
	}
	if !py.Eq(cur.Get("action_id"), actionID) {
		return py.T("no-op-stale-action", true), nil
	}
	now, ok1 := py.Instant(d.Clock.Now())
	dl, ok2 := py.Instant(cur.Get("deadline"))
	if !ok1 || !ok2 || now.Before(dl) {
		return py.T("no-op-early", true), nil
	}
	stopKey, wakeKey := effect+":stop", effect+":wake"
	wakeReason := "deadline-expired:" + qid
	stopDone, err := d.effectSettled(stopKey, "stop:"+actionID)
	if err != nil {
		return nil, err
	}
	wakeDone, err := d.effectSettled(wakeKey, "wake:tern:"+wakeReason)
	if err != nil {
		return nil, err
	}
	if stopDone && wakeDone {
		if err := d.MarkHandled(effect); err != nil {
			return nil, err
		}
		return py.T("already-handled", true), nil
	}
	recovered := stopDone || wakeDone
	d.Timer.Fire(tid)
	out, err := d.Submit(d.ev(actionID+"-int", qid, "interrupt", "duty",
		py.D("reason", "deadline-expired")), "duty", nil, nil, "")
	if err != nil {
		te, ok := err.(*TransitionError)
		if !ok {
			return nil, err
		}
		if te.Code == "E_BAD_TRANSITION" && py.Eq(d.phaseOf(qid), "BLOCKED") {
			recovered = true
		} else {
			return py.T("interrupt-rejected:"+te.Code, true), nil
		}
	} else if py.Truthy(out[1]) {
		recovered = true
	}
	if err := d.maybeCrash(CrashAfterInterrupt); err != nil {
		return nil, err
	}
	if !stopDone {
		if err := d.KVPut(stopKey, "intended"); err != nil {
			return nil, err
		}
		if err := d.Ext.Stop(actionID, "deadline-expired"); err != nil {
			return nil, err
		}
		if err := d.maybeCrash(CrashAfterStop); err != nil {
			return nil, err
		}
		if err := d.KVPut(stopKey, "delivered-acked"); err != nil {
			return nil, err
		}
		if err := d.maybeCrash(CrashAfterStopAck); err != nil {
			return nil, err
		}
	}
	if !wakeDone {
		if err := d.KVPut(wakeKey, "intended"); err != nil {
			return nil, err
		}
		if err := d.Ext.Wake("tern", wakeReason); err != nil {
			return nil, err
		}
		if err := d.maybeCrash(CrashAfterWake); err != nil {
			return nil, err
		}
		if err := d.KVPut(wakeKey, "delivered-acked"); err != nil {
			return nil, err
		}
		if err := d.maybeCrash(CrashAfterWakeAck); err != nil {
			return nil, err
		}
	}
	if err := d.MarkHandled(effect); err != nil {
		return nil, err
	}
	if recovered {
		return py.T("recovered", false), nil
	}
	return py.T("interrupted", false), nil
}

func (d *Driver) effectSettled(localKey, worldKey string) (bool, error) {
	if d.KV[localKey] == "delivered-acked" {
		return true, nil
	}
	if py.Eq(d.World.Delivery(worldKey), "delivered") {
		return true, d.KVPut(localKey, "delivered-acked")
	}
	return false, nil
}

// OnHandoffDeadline is the genuine due handoff-deadline path (duty-owned).
func (d *Driver) OnHandoffDeadline(qid string) (py.Tuple, error) {
	cur := d.currentFlight(qid)
	if cur == nil || !py.Eq(cur.Get("kind"), "handoff") {
		return py.T("no-op-no-handoff", true), nil
	}
	now, ok1 := py.Instant(d.Clock.Now())
	dl, ok2 := py.Instant(cur.Get("deadline"))
	if !ok1 || !ok2 || now.Before(dl) {
		return py.T("no-op-early", true), nil
	}
	effect := "handoff:" + qid
	if d.Handled(effect) {
		return py.T("already-handled", true), nil
	}
	wakeKey, reason := effect+":wake", "handoff-expired:"+qid
	done, err := d.effectSettled(wakeKey, "wake:tern:"+reason)
	if err != nil {
		return nil, err
	}
	if done {
		if err := d.MarkHandled(effect); err != nil {
			return nil, err
		}
		return py.T("already-handled", true), nil
	}
	if _, err := d.Submit(d.ev(qid+"-handoff-int", qid, "interrupt", "duty",
		py.D("reason", "handoff-expired")), "duty", nil, nil, ""); err != nil {
		te, ok := err.(*TransitionError)
		if !ok {
			return nil, err
		}
		if !(te.Code == "E_BAD_TRANSITION" && py.Eq(d.phaseOf(qid), "BLOCKED")) {
			return py.T("interrupt-rejected:"+te.Code, true), nil
		}
	}
	if err := d.KVPut(wakeKey, "intended"); err != nil {
		return nil, err
	}
	if err := d.Ext.Wake("tern", reason); err != nil {
		return nil, err
	}
	if err := d.maybeCrash(CrashAfterWake); err != nil {
		return nil, err
	}
	if err := d.KVPut(wakeKey, "delivered-acked"); err != nil {
		return nil, err
	}
	if err := d.MarkHandled(effect); err != nil {
		return nil, err
	}
	return py.T("interrupted", false), nil
}

// ReconstructTimers re-arms one-shot timers purely from ledger facts.
func (d *Driver) ReconstructTimers() {
	for _, k := range d.Store.Revs.Keys() {
		rec := d.Store.Revs.Get(k)
		if isTerminal(rec.Get("phase")) {
			continue
		}
		fl := py.AsDict(rec.Get("flight"))
		ho := py.AsDict(rec.Get("handoff"))
		if py.Truthy(fl.Get("action_id")) && py.Truthy(fl.Get("deadline")) {
			tid := "deadline:" + py.S(fl.Get("action_id"))
			if !d.IsCancelled(tid) {
				d.Timer.Arm(tid, fl.Get("deadline"))
			}
		} else if py.Truthy(ho.Get("deadline")) {
			d.Timer.Arm("handoff:"+py.S(k.Q), ho.Get("deadline"))
		}
	}
}

// ReconcileRestart is bounded owned reconciliation of intent vs world.
func (d *Driver) ReconcileRestart(qid, actionID string) *py.Dict {
	d.ReconstructTimers()
	tid := "deadline:" + actionID
	if d.IsCancelled(tid) {
		var info any
		if v, ok := d.KV["cancel-info:"+tid]; ok {
			info = v
		}
		return py.D("decision", "cancelled-owned", "cancel", info,
			"note", "explicit cancellation; owner must reconcile against the still-authoritative ledger deadline")
	}
	insp := d.Inspect.Inspect(actionID)
	ack := d.Store.Acks.Get(actionID)
	if d.Handled("deadline:" + qid + ":" + actionID) {
		return py.D("decision", "effect-already-handled", "ack", ack, "external", insp.Get("delivery"))
	}
	if py.Eq(ack, "acknowledged") && in(insp.Get("delivery"), "acknowledged", "dispatched") {
		return py.D("decision", "settled-acknowledged")
	}
	return py.D("decision", "hold-for-reconciliation", "ack", ack, "external", insp.Get("delivery"))
}

// DedupeTrigger: durable ACTION_DUE dedup across restart.
func (d *Driver) DedupeTrigger(triggerID string) (bool, error) {
	if d.KV["trigger-seen:"+triggerID] == "seen" {
		return true, nil
	}
	return false, d.KVPut("trigger-seen:"+triggerID, "seen")
}

func (d *Driver) Ledger() (*py.Dict, error) {
	pkgs := py.NewDict()
	view := d.Store.LedgerView()
	for _, q := range view.Keys() {
		revs := py.AsDict(view.Get(q))
		for _, rev := range revs.Keys() {
			pkgs.Set(q+"-r"+rev, revs.Get(rev))
		}
	}
	n, err := d.Store.LedgerRevision()
	return py.D("revision", n, "packages", pkgs), err
}

func (d *Driver) Snapshot(path string) (*py.Dict, error) {
	if path == "" {
		path = "/tmp/p4r2-snap.json"
	}
	return d.Store.PublishSnapshot(path, nil)
}

func (d *Driver) Close() error { return d.Store.Close() }

// SortedKeys is sorted(set) for the timer and crash-point sets.
func SortedKeys(m map[string]bool) []any { return py.SortedStrings(m) }

var _ = sort.Strings
