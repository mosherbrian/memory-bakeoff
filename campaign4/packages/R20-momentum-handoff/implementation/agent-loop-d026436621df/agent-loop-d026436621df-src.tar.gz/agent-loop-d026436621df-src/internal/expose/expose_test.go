package expose_test

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/expose"
	"agent-loop/internal/host"
	"agent-loop/internal/loop"
	"agent-loop/internal/py"
)

type rig struct {
	t     *testing.T
	dir   string
	cfg   *loop.Config
	clock *core.FakeClock
}

func newRig(t *testing.T) *rig {
	dir := t.TempDir()
	r := &rig{t: t, dir: dir, clock: core.NewFakeClock(py.ISO(time.Date(2026, 9, 23, 4, 0, 0, 0, time.UTC)))}
	r.cfg = &loop.Config{Project: "fx", Wake: "/x/wake", DB: filepath.Join(dir, "loop.db"),
		StreamDir: filepath.Join(dir, "stream"), ClaimsDir: filepath.Join(dir, "claims"), ArtifactsDir: filepath.Join(dir, "art"),
		Director: "fx-director", Duty: "fx-director", AgentDeck: "agent-deck", SystemdRun: "systemd-run", Systemctl: "systemctl",
		Seats: map[string]string{"fx-worker": "W", "fx-verifier": "V", "fx-director": "D"}, Bin: "/x/agent-loop",
		MaxVerifyS: 7200, DecisionS: 86400, Path: filepath.Join(dir, "loop.json")}
	os.MkdirAll(r.cfg.StreamDir, 0o755)
	os.MkdirAll(r.cfg.ArtifactsDir, 0o755)
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		switch {
		case argv[0] == "agent-deck":
			return host.Proc{RC: 0, Stdout: `[{"id": "W", "title": "fx-worker"}, {"id": "V", "title": "fx-verifier"}, {"id": "D", "title": "fx-director"}]`}, nil
		case filepath.Base(argv[0]) == "wake":
			return host.Proc{RC: 0, Stdout: "wake: " + argv[1] + " -> started"}, nil
		}
		return host.Proc{RC: 0}, nil
	}
	return r
}

func (r *rig) open() *loop.Loop {
	l, err := loop.Open(r.cfg, r.clock)
	if err != nil {
		r.t.Fatal(err)
	}
	return l
}

func (r *rig) end(key string) {
	now, _ := py.Instant(r.clock.Now())
	item := fmt.Sprintf("i%d", now.UnixMilli())
	f, _ := os.OpenFile(filepath.Join(r.cfg.StreamDir, key+".jsonl"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	fmt.Fprintf(f, "{\"t\": \"end\", \"item\": %q}\n", item)
	f.Close()
}

func (r *rig) must(err error) {
	r.t.Helper()
	if err != nil {
		r.t.Fatal(err)
	}
}

func (r *rig) req(q string, after ...string) loop.Request {
	return loop.Request{QID: q, Worker: "fx-worker", Verifier: "fx-verifier", WorkerTask: "w", VerifyTask: "v",
		DurationS: 2400, VerifyS: 1200, After: after}
}

// toDecision runs a package to its verifier verdict: worker 300 s, verifier 600 s.
func (r *rig) toDecision(l *loop.Loop, q string) {
	r.clock.Advance(300)
	os.WriteFile(filepath.Join(r.cfg.ArtifactsDir, "o-"+q), []byte("x"), 0o644)
	_, err := l.Claim(q, "worker", "completed", map[string]string{"o": "o-" + q})
	r.must(err)
	r.end("W")
	_, err = l.Tick()
	r.must(err)
	r.clock.Advance(600)
	os.WriteFile(filepath.Join(r.cfg.ArtifactsDir, "r-"+q), []byte("ok"), 0o644)
	_, err = l.Claim(q, "verify", "completed", map[string]string{"r": "r-" + q})
	r.must(err)
	r.end("V")
	_, err = l.Tick()
	r.must(err)
}

func (r *rig) view(inv string) *expose.View {
	v, err := expose.Build(expose.Options{Project: "fx", DB: r.cfg.DB, Inventory: inv, BaseDir: r.dir,
		ClaimsDir: r.cfg.ClaimsDir, Bin: r.cfg.Bin, Config: r.cfg.Path, Now: time.Date(2026, 9, 23, 4, 30, 0, 0, time.UTC)})
	if err != nil {
		r.t.Fatal(err)
	}
	return v
}

func sum(t *testing.T, paths ...string) string {
	h := sha256.New()
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err == nil {
			h.Write(b)
		}
		fmt.Fprintf(h, "|%s|%v|", p, err == nil)
	}
	return hex.EncodeToString(h.Sum(nil))
}

// rows counts ledger rows from a copy: opening the ledger itself would
// create its -wal/-shm files and spoil the byte comparison.
func rows(t *testing.T, db string) string {
	snap := t.TempDir()
	for _, suffix := range []string{"", "-wal"} {
		if b, err := os.ReadFile(db + suffix); err == nil {
			os.WriteFile(filepath.Join(snap, "l.db"+suffix), b, 0o600)
		}
	}
	c, err := sql.Open("sqlite", "file:"+filepath.Join(snap, "l.db")+"?mode=ro")
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	var e, k int
	c.QueryRow("SELECT count(*) FROM events").Scan(&e)
	c.QueryRow("SELECT count(*) FROM driver_kv").Scan(&k)
	return fmt.Sprintf("events=%d kv=%d", e, k)
}

func fileSHA(p string) string {
	b, _ := os.ReadFile(p)
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}

// Check 1: a blocked judgment appears with owner, question, dependents,
// next action and source; its resolution removes it and keeps the source.
func TestPendingJudgmentAppearsAndResolves(t *testing.T) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(r.req("A"))
	r.must(err)
	_, err = l.Dispatch(r.req("B", "A"))
	r.must(err)
	r.toDecision(l, "A")
	l.Close()
	v := r.view("")
	if len(v.Pending) != 1 {
		t.Fatalf("pending: %+v", v.Pending)
	}
	p := v.Pending[0]
	if p.ID != "A/decision" || p.Owner != "fx-director" || len(p.Dependents) != 1 || p.Dependents[0] != "B" ||
		!strings.Contains(p.NextAction, "decide --config") || !strings.Contains(p.Question, "PASS") ||
		!strings.HasSuffix(p.Source, "ex-A-v1.json") || p.Evidence != "OK" {
		t.Fatalf("pending item: %+v", p)
	}
	l = r.open()
	r.must(l.Decide("A", "question_answered", "tern-1", "ok"))
	l.Close()
	v = r.view("")
	if len(v.Pending) != 0 {
		t.Fatalf("resolved judgment still pending: %+v", v.Pending)
	}
	found := false
	for _, x := range v.Resolved {
		found = found || (x.ID == "A/decision" && strings.Contains(x.Evidence, "tern-1"))
	}
	if !found {
		t.Fatalf("resolution lost its source: %+v", v.Resolved)
	}

	// The same through an inventory pointer (a campaign decision the loop
	// ledger does not hold).
	os.WriteFile(filepath.Join(r.dir, "ruling.md"), []byte("question"), 0o644)
	inv := filepath.Join(r.dir, "inv.json")
	item := map[string]any{"id": "D-1", "kind": "decision", "title": "cutover", "status": "OPEN", "owner": "tern",
		"question": "Cut over after P9?", "dependents": []string{"P10"}, "next_action": "record a ruling",
		"source": "ruling.md", "sha256": fileSHA(filepath.Join(r.dir, "ruling.md"))}
	b, _ := json.Marshal(map[string]any{"items": []any{item}})
	os.WriteFile(inv, b, 0o644)
	v = r.view(inv)
	if len(v.Pending) != 1 || v.Pending[0].Owner != "tern" || v.Pending[0].Dependents[0] != "P10" || v.Pending[0].Source != "ruling.md" {
		t.Fatalf("inventory judgment: %+v", v.Pending)
	}
	os.WriteFile(filepath.Join(r.dir, "resolution.md"), []byte("answered"), 0o644)
	item["resolved_by"] = map[string]any{"source": "resolution.md", "sha256": fileSHA(filepath.Join(r.dir, "resolution.md"))}
	b, _ = json.Marshal(map[string]any{"items": []any{item}})
	os.WriteFile(inv, b, 0o644)
	v = r.view(inv)
	if len(v.Pending) != 0 || len(v.Resolved) < 2 || !strings.Contains(expose.Text(v), "resolved by resolution.md") {
		t.Fatalf("inventory resolution: %+v %+v", v.Pending, v.Resolved)
	}
}

// Check 2: missing, stale, conflicting and empty inputs are UNKNOWN or
// CONFLICT, never healthy; NOT READY is never green; rendering is stable
// and changes nothing, even on malformed input.
func TestNothingMissingLooksHealthy(t *testing.T) {
	r := newRig(t)
	// No ledger at all.
	v := r.view("")
	if v.Overhead != nil || !strings.HasPrefix(v.Freshness, "UNKNOWN") || len(v.Problems) == 0 {
		t.Fatalf("missing ledger: %+v", v)
	}
	// An empty ledger: no pass, no packages.
	l := r.open()
	l.Close()
	v = r.view("")
	if !strings.HasPrefix(v.Freshness, "UNKNOWN: no loop pass") {
		t.Fatalf("empty ledger looked alive: %s", v.Freshness)
	}
	// A future pass time and a stale one.
	l = r.open()
	r.clock.SetNow("2026-09-23T05:00:00Z")
	l.RecordPass(1, 0, nil)
	l.Close()
	if v = r.view(""); !strings.Contains(v.Freshness, "in the future") {
		t.Fatalf("future pass: %s", v.Freshness)
	}
	l = r.open()
	r.clock.SetNow("2026-09-23T04:20:00Z")
	l.RecordPass(2, 0, nil)
	l.Close()
	if v = r.view(""); !strings.HasPrefix(v.Freshness, "STALE") {
		t.Fatalf("stale pass: %s", v.Freshness)
	}
	// Inventory: missing source, changed source, duplicate id, qualification.
	os.WriteFile(filepath.Join(r.dir, "p8.json"), []byte(`{"state": "NOT_READY_UNATTENDED"}`), 0o644)
	os.WriteFile(filepath.Join(r.dir, "changed.md"), []byte("new"), 0o644)
	items := []map[string]any{
		{"id": "Q-P8", "kind": "qualification", "status": "NOT_READY_UNATTENDED", "source": "p8.json", "sha256": fileSHA(filepath.Join(r.dir, "p8.json"))},
		{"id": "X-1", "kind": "finding", "status": "open", "source": "gone.md", "sha256": "00"},
		{"id": "X-2", "kind": "finding", "status": "open", "source": "changed.md", "sha256": "00"},
		{"id": "X-2", "kind": "finding", "status": "open", "source": "changed.md", "sha256": fileSHA(filepath.Join(r.dir, "changed.md"))},
		{"id": "D-2", "kind": "decision", "status": "OPEN", "question": "?", "source": "changed.md", "sha256": fileSHA(filepath.Join(r.dir, "changed.md")),
			"resolved_by": map[string]any{"source": "gone.md", "sha256": "00"}},
	}
	b, _ := json.Marshal(map[string]any{"items": items})
	inv := filepath.Join(r.dir, "inv.json")
	os.WriteFile(inv, b, 0o644)
	v = r.view(inv)
	txt := expose.Text(v)
	for _, want := range []string{"X-1: UNKNOWN", "X-2: CONFLICT: changed.md no longer matches", "CONFLICT: duplicate inventory id X-2",
		"D-2: UNKNOWN: gone.md unreadable (claimed resolution not verified)", "NOT_READY_UNATTENDED", expose.Label} {
		if !strings.Contains(txt, want) {
			t.Errorf("view lacks %q", want)
		}
	}
	if !strings.Contains(txt, "D-2: UNKNOWN: pending decision lacks an owner, question or next action") {
		t.Error("an incomplete pending decision was not flagged")
	}
	if len(v.Pending) != 1 || v.Pending[0].ID != "D-2" {
		t.Errorf("an unverified resolution removed a pending judgment: %+v", v.Pending)
	}
	if strings.Contains(strings.ToLower(txt), "qualified for unattended use\n") || strings.Contains(txt, "QUALIFIED:") {
		t.Error("the view claims qualification")
	}
	// Stable except as-of, and read-only, including on malformed input.
	os.WriteFile(filepath.Join(r.dir, "bad.json"), []byte("{not json"), 0o644)
	paths := []string{r.cfg.DB, r.cfg.DB + "-wal", r.cfg.DB + "-shm", inv, filepath.Join(r.dir, "bad.json")}
	before, rowsBefore := sum(t, paths...), rows(t, r.cfg.DB)
	a := r.view(inv)
	c := r.view(inv)
	bad := r.view(filepath.Join(r.dir, "bad.json"))
	a.AsOf, c.AsOf = "", ""
	ja, _ := json.Marshal(a)
	jc, _ := json.Marshal(c)
	if string(ja) != string(jc) {
		t.Error("two renders differ beyond as-of")
	}
	if !strings.Contains(strings.Join(bad.Problems, "\n"), "UNKNOWN: inventory") {
		t.Errorf("malformed inventory not reported: %v", bad.Problems)
	}
	if sum(t, paths...) != before || rows(t, r.cfg.DB) != rowsBefore {
		t.Error("rendering changed the ledger or the inventory")
	}
	// With the ledger closed and checkpointed (no -wal/-shm on disk), a
	// render must not create them either.
	os.Remove(r.cfg.DB + "-wal")
	os.Remove(r.cfg.DB + "-shm")
	listing := func() string {
		es, _ := os.ReadDir(r.dir)
		var ns []string
		for _, e := range es {
			fi, _ := e.Info()
			ns = append(ns, fmt.Sprintf("%s:%d:%d", e.Name(), fi.Size(), fi.ModTime().UnixNano()))
		}
		return strings.Join(ns, ",")
	}
	dirBefore, dbBefore := listing(), fileSHA(r.cfg.DB)
	r.view(inv)
	r.view(filepath.Join(r.dir, "bad.json"))
	if listing() != dirBefore || fileSHA(r.cfg.DB) != dbBefore {
		t.Errorf("rendering created or changed files:\n before %s\n after  %s", dirBefore, listing())
	}
}

// Check 3: overhead counts and durations against a predeclared sequence
// with duplicate observations.
func TestOverheadMatchesTheSequence(t *testing.T) {
	r := newRig(t)
	l := r.open()
	// Sequence: A dispatched, worker 300 s, verifier 600 s, decision after 120 s.
	_, err := l.Dispatch(r.req("A"))
	r.must(err)
	r.toDecision(l, "A")
	// Duplicate observations: the same turn ends seen again, the same
	// decision retried with the same ref.
	r.end("V")
	l.Tick()
	r.clock.Advance(120)
	r.must(l.Decide("A", "question_answered", "tern-1", "ok"))
	r.must(l.Decide("A", "question_answered", "tern-1", "ok"))
	// C is interrupted for another reason: not a timeout.
	_, err = l.Dispatch(r.req("C"))
	r.must(err)
	_, err = l.D.Submit(py.D("event_id", "C-hold", "question_id", "C", "revision", int64(1), "type", "interrupt",
		"reason", "operator-hold", "at", r.clock.Now()), "duty", nil, nil, "")
	r.must(err)
	// B is dispatched with a 60 s grant and times out.
	_, err = l.Dispatch(loop.Request{QID: "B", Worker: "fx-worker", Verifier: "fx-verifier", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 600})
	r.must(err)
	l.Close()
	// The callback runs on the host clock, which is past B's fake 60 s grant.
	if out, err := loop.TimerCallback(r.cfg, "B", "B-w1", "ex-B-w1"); err != nil || py.S(out.Get("decision")) != "interrupted" {
		t.Fatalf("timer callback: %v %v", out, err)
	}
	if false {
		t.Fatal(err)
	}
	v := r.view("")
	o := v.Overhead
	if o.WorkerDispatches != 3 || o.VerifierDispatches != 1 || o.DirectorDecisions != 1 || o.Timeouts != 1 || o.Repairs != 0 {
		t.Fatalf("counts: %+v", o)
	}
	want := map[string]int64{"A/worker": 300, "A/verify": 600, "A/decision": 120}
	got := map[string]*int64{}
	for _, s := range o.Steps {
		got[s.QID+"/"+s.Step] = s.Seconds
		if s.QID == "A" && s.Step == "worker" && (s.Seat != "fx-worker" || s.Session != "W") {
			t.Errorf("worker step lacks its principal: %+v", s)
		}
	}
	for k, w := range want {
		if got[k] == nil || *got[k] != w {
			t.Errorf("%s: want %ds, got %v", k, w, got[k])
		}
	}
	if s, ok := got["B/worker"]; !ok || s != nil {
		t.Errorf("B's unfinished worker step must be open, not a number (and never its 60 s grant): %v", s)
	}
	if !strings.Contains(o.Costs, "not in this binary") {
		t.Error("costs claimed")
	}
}

// A package from before principals were recorded cannot be moved by any
// loop command; the view must not offer one.
func TestPackageWithoutPrincipalsOffersNoCommand(t *testing.T) {
	r := newRig(t)
	l := r.open()
	_, err := l.Dispatch(r.req("A"))
	r.must(err)
	r.toDecision(l, "A")
	p := l.Pkg("A")
	p.Principals = nil
	b, _ := json.Marshal(p)
	r.must(l.D.KVPut("loop-pkg:A", string(b)))
	l.Close()
	v := r.view("")
	if len(v.Pending) != 1 || v.Pending[0].Owner != "UNKNOWN" || strings.Contains(v.Pending[0].NextAction, "decide --config") ||
		!strings.Contains(strings.Join(v.Problems, "\n"), "no recorded principals") {
		t.Fatalf("pending %+v problems %v", v.Pending, v.Problems)
	}
}
