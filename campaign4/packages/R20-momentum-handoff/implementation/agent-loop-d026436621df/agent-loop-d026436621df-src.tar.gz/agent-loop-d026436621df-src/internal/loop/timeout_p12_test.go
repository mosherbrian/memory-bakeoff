package loop

import (
	"path/filepath"
	"strings"
	"testing"
	"time"

	"agent-loop/internal/host"
)

// P12: a step deadline is settled and owned whatever the /cancel finds.
// The /cancel replies below are the real wake script's shapes (wake exits
// 1 for every reply except started/queued; P11 live send log).

// cancelReply makes the rig's wake answer /cancel with rc and stdout.
func (r *rig) cancelReply(rc int, stdout, stderr string) {
	run := r.cfg.Run
	r.cfg.Run = func(argv []string, env []string, timeout time.Duration) (host.Proc, error) {
		if filepath.Base(argv[0]) == "wake" && argv[2] == "/cancel" {
			r.calls = append(r.calls, argv)
			return host.Proc{RC: rc, Stdout: stdout, Stderr: stderr}, nil
		}
		return run(argv, env, timeout)
	}
}

func (r *rig) timedOut(t *testing.T, qid string) *Loop {
	l := r.open()
	_, err := l.Dispatch(Request{QID: qid, Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 60, VerifyS: 60})
	must(t, err)
	l.Close()
	return nil
}

// settle runs the deadline callback the way `agent-loop timer-callback` does.
func (r *rig) settle(t *testing.T, qid, action, exec string) (string, error) {
	out, err := TimerCallback(r.cfg, qid, action, exec)
	l := r.open()
	defer l.Close()
	if err != nil {
		msg, serr := l.SettleTimeoutFailure(qid, action, err)
		if serr != nil {
			t.Fatalf("not settled: %v (callback: %v)", serr, err)
		}
		return msg, err
	}
	d := out.Get("decision").(string)
	if d == "interrupted" || d == "recovered" || d == "already-handled" { // as the CLI does
		must(t, l.MarkTimedOut(qid, action))
	}
	return d, nil
}

func TestTimeoutSettlesWhateverTheCancelFinds(t *testing.T) {
	for _, c := range []struct {
		name, stdout, stderr string
		rc                   int
		cancel               string // prefix of the recorded cancel outcome
		failed               bool
	}{
		{"idle worker (P11 L2/L6)", "wake: K -> nothing running\n", "", 1, "idle", false},
		{"running turn cancelled", "wake: K -> cancelled\n", "", 1, "cancelled", false},
		{"transport refused", "", "wake: could not reach K: [Errno 111] Connection refused", 1, "failed", true},
		{"receipt for another session", "wake: X -> nothing running\n", "", 1, "failed", true},
		{"reply without a receipt", "nothing running\n", "", 1, "failed", true},
		{"unknown reply", "wake: K -> busy\n", "", 1, "failed", true},
	} {
		t.Run(c.name, func(t *testing.T) {
			r := newRig(t)
			r.timedOut(t, "Q")
			r.cancelReply(c.rc, c.stdout, c.stderr)
			_, err := r.settle(t, "Q", "Q-w1", "ex-Q-w1")
			if (err != nil) != c.failed {
				t.Fatalf("callback error %v, want failed=%v", err, c.failed)
			}
			l := r.open()
			defer l.Close()
			p := l.Pkg("Q")
			if p.Step != "timed-out" || p.Timeout == nil || !strings.HasPrefix(p.Timeout.Cancel, c.cancel) || p.Timeout.Director != "told" {
				t.Fatalf("not settled and owned: step %s timeout %+v", p.Step, p.Timeout)
			}
			w := r.wakes()
			last := w[len(w)-1]
			if !strings.HasPrefix(last, "tern: [agent-loop]") {
				t.Fatalf("director not told last: %v", w)
			}
			// Every director notice carries the exact ack command.
			var dir string
			for _, call := range r.calls {
				if filepath.Base(call[0]) == "wake" && call[1] == "T" {
					dir = call[2]
				}
			}
			if !strings.Contains(dir, "timeout-ack --config "+r.cfg.Path+" --qid Q --action Q-w1") {
				t.Fatalf("no ack command in the director notice: %q", dir)
			}
			// Status is readable and durable across a reopen.
			rows := l.Status()
			if rows[0]["timeout"] == nil {
				t.Fatal("status has no timeout record")
			}
		})
	}
}

func TestSettlementIsNotRepeated(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	n := len(r.wakes())
	r.settle(t, "Q", "Q-w1", "ex-Q-w1") // the timer's replay
	if len(r.wakes()) != n {
		t.Fatalf("replay repeated effects: %v", r.wakes()[n:])
	}
	// A failed cancel settles once; the settlement is not re-sent.
	r2 := newRig(t)
	r2.timedOut(t, "Q")
	r2.cancelReply(1, "", "wake: could not reach K")
	r2.settle(t, "Q", "Q-w1", "ex-Q-w1")
	l := r2.open()
	msg, err := l.SettleTimeoutFailure("Q", "Q-w1", nil)
	l.Close()
	if err != nil || msg != "already settled" {
		t.Fatalf("second settlement: %q %v", msg, err)
	}
}

func TestSettlementRefusesAPackageTheCoreDidNotInterrupt(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	l := r.open()
	defer l.Close()
	if _, err := l.SettleTimeoutFailure("Q", "Q-w1", nil); err == nil {
		t.Fatal("settled a running step without a core interrupt")
	}
	if _, err := l.SettleTimeoutFailure("Q", "Q-v1", nil); err == nil {
		t.Fatal("settled the wrong action")
	}
}

func TestTimeoutAcknowledgement(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	l := r.open()
	// Delivery is not acknowledgement: before an ack there is none.
	if l.Pkg("Q").Timeout.Ack != nil {
		t.Fatal("an ack exists before anyone acknowledged")
	}
	for _, c := range []struct {
		name, action, by, next string
		within                 time.Duration
	}{
		{"wrong actor", "Q-w1", "kiln", "look", 10 * time.Minute},
		{"unknown actor", "Q-w1", "mallory", "look", 10 * time.Minute},
		{"wrong action", "Q-v1", "tern", "look", 10 * time.Minute},
		{"no next action", "Q-w1", "tern", " ", 10 * time.Minute},
		{"zero deadline", "Q-w1", "tern", "look", 0},
		{"past deadline", "Q-w1", "tern", "look", -time.Minute},
		{"unbounded deadline", "Q-w1", "tern", "look", 25 * time.Hour},
	} {
		if _, err := l.AckTimeout("Q", c.action, c.by, c.next, c.within); err == nil {
			t.Errorf("%s: accepted", c.name)
		}
	}
	a, err := l.AckTimeout("Q", "Q-w1", "tern", "re-dispatch after reading the log", 10*time.Minute)
	must(t, err)
	r.clock.Advance(5)
	b, err := l.AckTimeout("Q", "Q-w1", "tern", "re-dispatch after reading the log", 10*time.Minute)
	if err != nil || b.At != a.At || b.Deadline != a.Deadline {
		t.Fatalf("replay changed the ack: %+v %+v %v", a, b, err)
	}
	if _, err := l.AckTimeout("Q", "Q-w1", "tern", "something else", 10*time.Minute); err == nil {
		t.Fatal("a conflicting ack replaced one in force")
	}
	l.Close()
	// Durable across a restart; not a resume or a close.
	l = r.open()
	p := l.Pkg("Q")
	if p.Timeout.Ack == nil || p.Timeout.Ack.By != "tern" || p.Step != "timed-out" {
		t.Fatalf("after reopen: step %s ack %+v", p.Step, p.Timeout.Ack)
	}
	// An expired response is escalated once, then a fresh ack is allowed.
	n := len(r.wakes())
	r.clock.Advance(11 * 60)
	r.tick(l)
	r.tick(l)
	if got := r.wakes()[n:]; len(got) != 1 || !strings.HasPrefix(got[0], "tern: [agent-loop] Q: the acknowledgement") {
		t.Fatalf("expiry escalation: %v", got)
	}
	if _, err := l.AckTimeout("Q", "Q-w1", "tern", "second look", 10*time.Minute); err != nil {
		t.Fatalf("re-ack after expiry: %v", err)
	}
	l.Close()
}

func TestTimeoutAckRejectsAChangedPrincipal(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	// The config now binds the director seat to another session: forged.
	r.cfg.Seats["tern"] = "T2"
	r.registry = `[{"id": "K", "title": "kiln"}, {"id": "C", "title": "corvid - reviewer"}, {"id": "T2", "title": "tern"}]`
	l := r.open()
	defer l.Close()
	if _, err := l.AckTimeout("Q", "Q-w1", "tern", "look", 10*time.Minute); err == nil {
		t.Fatal("an ack from a changed principal was accepted")
	}
}

func TestStepTimersAreArmedAtAnExplicitUTCInstant(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	for _, c := range r.calls {
		if c[0] == "systemd-run" {
			if c[3] != "--timer-property=AccuracySec=1s" || !strings.HasPrefix(c[4], "--on-calendar=") || !strings.HasSuffix(c[4], " UTC") {
				t.Fatalf("timer argv %v", c)
			}
			return
		}
	}
	t.Fatal("no timer armed")
}

// The callback crashes after the core's effects, before the loop record:
// the timer's replay (core: already-handled) completes the record.
func TestAReplayCompletesACrashedSettlement(t *testing.T) {
	r := newRig(t)
	r.timedOut(t, "Q")
	r.cancelReply(1, "wake: K -> nothing running\n", "")
	_, err := TimerCallback(r.cfg, "Q", "Q-w1", "ex-Q-w1") // crash here: no MarkTimedOut
	must(t, err)
	n := len(r.wakes())
	d, err := r.settle(t, "Q", "Q-w1", "ex-Q-w1")
	must(t, err)
	l := r.open()
	defer l.Close()
	if d != "already-handled" || l.Pkg("Q").Step != "timed-out" || len(r.wakes()) != n {
		t.Fatalf("replay: %s step %s wakes %v", d, l.Pkg("Q").Step, r.wakes()[n:])
	}
	// A deadline the core did not act on is never recorded as timed out.
	r2 := newRig(t)
	r2.timedOut(t, "Q")
	l2 := r2.open()
	defer l2.Close()
	must(t, l2.MarkTimedOut("Q", "Q-w1"))
	if l2.Pkg("Q").Step != "worker" {
		t.Fatal("marked timed out without a core interrupt")
	}
}
