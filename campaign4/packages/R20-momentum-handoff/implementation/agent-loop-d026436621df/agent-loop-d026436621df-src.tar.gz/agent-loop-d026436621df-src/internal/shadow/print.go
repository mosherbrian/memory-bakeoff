package shadow

import (
	"fmt"
	"io"
	"sort"
	"strings"
)

func joinInts(xs []int) string {
	parts := make([]string, len(xs))
	for i, x := range xs {
		parts[i] = fmt.Sprint(x)
	}
	return strings.Join(parts, ",")
}

// Print writes the report for a person: findings first, gaps last.
func Print(w io.Writer, r *Report) {
	fmt.Fprintf(w, "shadow: %d ledger rows -> %d core events, %d rejected by the core\n",
		r.Rows, r.Events, r.Rejected)
	fmt.Fprintln(w, "Leads, not verdicts. Certainty: exact = rows of one dispatch only;")
	fmt.Fprintln(w, "name-/order-linked = rests on a verifier link; synthesized = rests on an event the shadow made up.")
	fmt.Fprintln(w)
	section := func(title string, fs []Finding) {
		fmt.Fprintf(w, "%s (%d)\n", title, len(fs))
		for _, f := range fs {
			fmt.Fprintf(w, "  line %-4d %-26s %-12s %s: %s  [lines %s]\n", f.Line, f.Kind, f.Certainty, f.QID, f.Detail, joinInts(f.Sources))
		}
		fmt.Fprintln(w)
	}
	section("FINDINGS the core's rules would raise", r.Findings)
	sort.SliceStable(r.Rejections, func(i, j int) bool { return r.Rejections[i].Kind < r.Rejections[j].Kind })
	section("REJECTIONS by the core, by rule", r.Rejections)
	if r.FollowOn > 0 {
		fmt.Fprintf(w, "(%d more rejections only followed one of these on the same question)\n\n", r.FollowOn)
	}
	fmt.Fprintf(w, "DECIDED IN FILES, not in the ledger (%d)\n", len(r.FileDecisions))
	for _, o := range r.FileDecisions {
		fmt.Fprintln(w, "  "+o)
	}
	fmt.Fprintln(w)
	fmt.Fprintf(w, "OPEN now (%d)\n", len(r.Open))
	for _, o := range r.Open {
		fmt.Fprintln(w, "  "+o)
	}
	fmt.Fprintln(w)
	fmt.Fprintf(w, "Not modelled: %d review dispatch(es) with no worker product\n", len(r.Reviews))
	var verbs []string
	for v := range r.NotModelled {
		verbs = append(verbs, v)
	}
	sort.Slice(verbs, func(i, j int) bool {
		if r.NotModelled[verbs[i]] != r.NotModelled[verbs[j]] {
			return r.NotModelled[verbs[i]] > r.NotModelled[verbs[j]]
		}
		return verbs[i] < verbs[j]
	})
	fmt.Fprint(w, "Not modelled: verbs with no core meaning:")
	for _, v := range verbs {
		fmt.Fprintf(w, " %s=%d", v, r.NotModelled[v])
	}
	fmt.Fprintln(w)
	for _, g := range r.Guesses {
		fmt.Fprintln(w, "Guessed link: "+g)
	}
	for _, g := range r.Gaps {
		fmt.Fprintln(w, "Unreadable: "+g)
	}
}
