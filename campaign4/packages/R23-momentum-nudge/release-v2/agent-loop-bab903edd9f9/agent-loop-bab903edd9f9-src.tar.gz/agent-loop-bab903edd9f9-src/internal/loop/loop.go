// Package loop is the agent-loop product: it dispatches one package's work
// to a worker seat, sees the worker's turn end, checks the completion
// claim, dispatches the verifier, and records the verdict for the
// director's decision. Every state change goes through the ported core
// (internal/core) and the host blocks (internal/host).
//
// One package runs one worker step and one verifier step:
//
//	dispatch -> worker turn ends with a claim -> verifier dispatched
//	         -> verifier turn ends with a claim -> verdict recorded
//	         -> director decides (or a pre-authorized disposition closes it)
//
// Deadlines are systemd one-shot timers whose callback is this binary; a
// due deadline interrupts the step, cancels the seat's turn and wakes the
// director. Nothing here reads model prose: only turn ends, claim files and
// artifact hashes.
package loop

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"agent-loop/internal/core"
	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// Config is one project's loop configuration (a JSON file).
type Config struct {
	Project      string            `json:"project"`
	Profile      string            `json:"profile"`       // AGENTDECK_PROFILE for the wake script
	Wake         string            `json:"wake"`          // the wake script
	DB           string            `json:"db"`            // the loop's SQLite ledger
	StreamDir    string            `json:"stream_dir"`    // the runtime's per-session turn streams
	ClaimsDir    string            `json:"claims_dir"`    // completion claims, one per execution
	ArtifactsDir string            `json:"artifacts_dir"` // claim artifact paths are relative to this
	Director     string            `json:"director"`      // the seat that decides
	Duty         string            `json:"duty"`          // the seat that owns operations: deadlines, liveness alarms
	Unit         string            `json:"unit"`          // the systemd user unit running "agent-loop run" (liveness)
	Seats        map[string]string `json:"seats"`         // seat name -> session id (director included)
	AgentDeck    string            `json:"agent_deck"`    // registry that must confirm every seat's id
	Bin          string            `json:"bin"`           // this binary, for timer callbacks
	SystemdRun   string            `json:"systemd_run"`
	Systemctl    string            `json:"systemctl"`
	MaxVerifyS   int64             `json:"max_verify_s"`      // per-pass verifier ceiling
	DecisionS    int64             `json:"decision_window_s"` // how long a verdict waits for the director
	// P13: the director's decision obligation (mechanism here; the ladder and
	// responders are fleet policy, in the config).
	DecisionDeadlineS  int64    `json:"decision_deadline_s"` // default 1800, max 86400
	DecisionLadder     []Rung   `json:"decision_ladder"`     // default: director at the deadline, duty +300 s
	DecisionResponders []string `json:"decision_responders"` // who may acknowledge an overdue decision (once, <= 15 min)
	DecisionPolicy     string   `json:"decision_policy"`     // "required": a campaign; the full three-rung policy must be configured

	Path string      `json:"-"`
	Run  host.Runner `json:"-"` // tests inject; nil = real subprocesses
	// HoldDeadline is the current ledger-lock hold's budget end (zero when
	// not holding): every subprocess is capped to it, and work units that
	// cannot fit are not started (P12-lock-budget-1).
	HoldDeadline time.Time `json:"-"`
}

func expand(p string) string {
	if strings.HasPrefix(p, "~/") {
		h, _ := os.UserHomeDir()
		return filepath.Join(h, p[2:])
	}
	return p
}

// LoadConfig reads and checks a config file.
func LoadConfig(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	c := &Config{}
	if err := json.Unmarshal(b, c); err != nil {
		return nil, fmt.Errorf("%s: %v", path, err)
	}
	c.Path, _ = filepath.Abs(path)
	for _, p := range []*string{&c.Wake, &c.DB, &c.StreamDir, &c.ClaimsDir, &c.ArtifactsDir, &c.Bin} {
		*p = expand(*p)
	}
	if c.Director == "" {
		c.Director = "tern"
	}
	if c.AgentDeck == "" {
		c.AgentDeck = "agent-deck"
	}
	if c.SystemdRun == "" {
		c.SystemdRun = "systemd-run"
	}
	if c.Systemctl == "" {
		c.Systemctl = "systemctl"
	}
	if c.MaxVerifyS == 0 {
		c.MaxVerifyS = 7200
	}
	if c.DecisionS == 0 {
		c.DecisionS = 86400
	}
	if c.Bin == "" {
		c.Bin, _ = os.Executable()
	}
	var missing []string
	for name, v := range map[string]string{"project": c.Project, "wake": c.Wake, "db": c.DB,
		"stream_dir": c.StreamDir, "claims_dir": c.ClaimsDir, "artifacts_dir": c.ArtifactsDir} {
		if v == "" {
			missing = append(missing, name)
		}
	}
	if len(c.Seats) == 0 {
		missing = append(missing, "seats")
	} else if c.Seats[c.Director] == "" {
		missing = append(missing, "seats."+c.Director+" (the director's session)")
	}
	if c.Duty == "" {
		missing = append(missing, "duty")
	} else if c.Seats[c.Duty] == "" {
		missing = append(missing, "seats."+c.Duty+" (the duty seat's session)")
	}
	missing = append(missing, c.validateDecision()...)
	if missing != nil {
		sort.Strings(missing)
		return nil, fmt.Errorf("%s: missing %s", path, strings.Join(missing, ", "))
	}
	return c, nil
}

// Pkg is the loop's record of one package.
type Pkg struct {
	QID          string               `json:"qid"`
	Worker       string               `json:"worker"`
	Verifier     string               `json:"verifier"`
	WorkerTask   string               `json:"worker_task"`
	VerifyTask   string               `json:"verify_task"`
	WorkAction   string               `json:"work_action"`
	WorkExec     string               `json:"work_exec"`
	VerifyAction string               `json:"verify_action"`
	VerifyExec   string               `json:"verify_exec"`
	DurationS    int64                `json:"duration_s"`
	VerifyS      int64                `json:"verify_window_s"`
	OnPass       *OnPass              `json:"on_pass,omitempty"`
	Inputs       map[string]string    `json:"inputs,omitempty"`     // declared input path -> sha256 at registration
	After        []string             `json:"after,omitempty"`      // packages whose eligible decision this one waits for
	Principals   map[string]Principal `json:"principals,omitempty"` // core role -> real seat and session, fixed at dispatch
	Step         string               `json:"step"`                 // held, worker, verify, decision, closed, recovery, blocked, timed-out
	StepAt       string               `json:"step_at"`
	Verdict      string               `json:"verdict,omitempty"`
	Notes        []string             `json:"notes,omitempty"`
	Timeout      *StepTimeout         `json:"timeout,omitempty"`  // set when a step deadline passed
	Decision     *DecisionDue         `json:"decision,omitempty"` // P13: set on entry into the decision step
}

// OnPass is a director-authorized disposition that closes the package
// when the verifier passes it, without a separate decision.
type OnPass struct {
	Kind        string `json:"kind"`
	DecisionRef string `json:"decision_ref"`
	Reason      string `json:"reason"`
}

// Loop is one open ledger with its adapter.
type Loop struct {
	Cfg     *Config
	Adapter *host.Adapter
	D       *core.Driver
	watcher *host.TurnWatcher
	cursors *py.Dict
	Yielded bool // this pass stopped early at the lock budget; run continues at once
}

// Open opens the ledger. clock nil = host clock.
func Open(cfg *Config, clock core.DriverClock) (*Loop, error) {
	if clock == nil {
		clock = core.HostClock{}
	}
	if err := os.MkdirAll(filepath.Dir(cfg.DB), 0o755); err != nil {
		return nil, err
	}
	d, err := core.NewDriver(cfg.DB, clock, nil, nil)
	if err != nil {
		return nil, err
	}
	// The director sets verifier windows; the per-pass ceiling follows the
	// configured maximum instead of the core's 30-minute default.
	d.Budget.Set("passes", py.D("verify", py.D("max_s", cfg.MaxVerifyS),
		"controller_recovery", py.D("max_s", int64(core.HardRecoveryMaxS))))
	tr := newTransport(cfg, d)
	tm := host.NewTimers(host.DriverKV(d))
	tm.Host, tm.Enabled, tm.Run, tm.SystemdRun, tm.Systemctl = true, true, cfg.Run, cfg.SystemdRun, cfg.Systemctl
	var units []string
	json.Unmarshal([]byte(d.KV["loop-units"]), &units)
	tm.Allowlist = units
	a, err := host.NewAdapter(d, tr, tm, true)
	if err != nil {
		d.Close()
		return nil, err
	}
	a.Director = cfg.Seats[cfg.Director]
	l := &Loop{Cfg: cfg, Adapter: a, D: d, watcher: host.NewTurnWatcher(cfg.StreamDir), cursors: py.NewDict()}
	l.wire()
	return l, nil
}

// newTransport sends to session ids, the same identities the loop watches
// in the stream directory: a name can resolve to a different session than
// the one observed (Tern, P8-CANDIDATE-READINESS item 4).
func newTransport(cfg *Config, d *core.Driver) *host.WakeTransport {
	var ids []string
	for _, id := range cfg.Seats {
		ids = append(ids, id)
	}
	return &host.WakeTransport{WakePath: cfg.Wake, Allowlist: ids, Enabled: true, Profile: cfg.Profile,
		KV: host.DriverKV(d), Run: cfg.Run}
}

var titleHead = regexp.MustCompile(`\s+[·|:\-—]\s+`)

// VerifySeats checks, against the agent-deck registry, that every named
// seat's configured session id exists under that name, and that the
// sessions are distinct. Nothing is dispatched on an unconfirmed binding.
func (l *Loop) VerifySeats(names ...string) error { return l.Cfg.VerifySeats(names...) }

// VerifySeats is Loop.VerifySeats without opening a ledger.
func (c *Config) VerifySeats(names ...string) error {
	l := struct{ Cfg *Config }{c}
	run := l.Cfg.Run
	if run == nil {
		run = host.ExecRunner
	}
	proc, err := run([]string{l.Cfg.AgentDeck, "list", "--json"}, []string{"AGENTDECK_PROFILE=" + l.Cfg.Profile}, 30*time.Second)
	if err != nil || proc.RC != 0 {
		if errors.Is(err, host.ErrBudget) {
			// Not a binding fault: the lock hold's budget is spent; retry in a later hold.
			return &host.Fault{Code: "E_BUDGET_EXHAUSTED", Detail: "the agent-deck registry was not read: the ledger-lock hold's budget is spent", Owner: "cairn"}
		}
		return &host.Fault{Code: "E_SEAT_BINDING", Detail: fmt.Sprintf("cannot read the agent-deck registry: %v %s", err, proc.Stderr), Owner: "cairn"}
	}
	var rows []struct{ ID, Title string }
	if err := json.Unmarshal([]byte(proc.Stdout), &rows); err != nil {
		var wrapped struct{ Sessions []struct{ ID, Title string } }
		if json.Unmarshal([]byte(proc.Stdout), &wrapped) != nil {
			return &host.Fault{Code: "E_SEAT_BINDING", Detail: "agent-deck registry is not JSON", Owner: "cairn"}
		}
		rows = wrapped.Sessions
	}
	title := map[string]string{}
	for _, r := range rows {
		title[r.ID] = titleHead.Split(r.Title, 2)[0]
	}
	// One session has one title, so two seat names can never both match it.
	for _, n := range names {
		id := l.Cfg.Seats[n]
		if id == "" {
			return &host.Fault{Code: "E_SEAT_BINDING", Detail: "seat " + n + " has no session id in the config", Owner: "cairn"}
		}
		t, ok := title[id]
		if !ok {
			return &host.Fault{Code: "E_SEAT_BINDING", Detail: "session " + id + " (" + n + ") is not in profile " + l.Cfg.Profile, Owner: "cairn"}
		}
		if t != n {
			return &host.Fault{Code: "E_SEAT_BINDING", Detail: "session " + id + " is " + t + ", not " + n, Owner: "cairn"}
		}
	}
	return nil
}

// wire makes a due deadline cancel the seat's running turn and tell the
// director. A send that did not arrive leaves the effect undelivered, so
// the next callback retries it.
func (l *Loop) wire() {
	l.D.Ext.OnStop = func(action, reason string) error {
		id, err := l.Adapter.RouteFor(action)
		if err != nil {
			return err
		}
		return l.sendIncident("stop|"+action, id, "/cancel", "stop", action)
	}
	l.D.Ext.OnWake = func(seat, reason string) error {
		// The core wakes its director by role name.
		text := "[agent-loop] " + reason + ". See: agent-loop status --config " + l.Cfg.Path
		incident := "wake|" + reason
		if qid, ok := strings.CutPrefix(reason, "deadline-expired:"); ok {
			if p := l.Pkg(qid); p != nil {
				if a := map[string]string{"worker": p.WorkAction, "verify": p.VerifyAction}[p.Step]; a != "" {
					text += ". Acknowledge ownership with: " + l.AckCommand(qid, a)
					incident += "|" + a
				}
			}
		}
		return l.sendSeat(incident, l.Cfg.Director, text, "wake", "")
	}
}

// SetWatcher shares one turn watcher across reopened ledgers.
func (l *Loop) SetWatcher(w *host.TurnWatcher, cursors *py.Dict) { l.watcher, l.cursors = w, cursors }

// Cursors are the watcher's byte cursors after the last Tick.
func (l *Loop) Cursors() *py.Dict { return l.cursors }

// Close closes the ledger.
func (l *Loop) Close() error { return l.D.Close() }

func (l *Loop) now() time.Time {
	t, _ := py.Instant(l.D.Clock.UtcNow())
	return t
}

// send delivers to a named seat's session.
func (l *Loop) send(seat, text, kind, action string) error {
	return l.sendID(l.Cfg.Seats[seat], text, kind, action)
}

func (l *Loop) sendID(id, text, kind, action string) error {
	return l.sendIncident("text|"+action+"|"+text, id, text, kind, action)
}

// sendSeat sends one incident's notice to a named seat.
func (l *Loop) sendSeat(incident, seat, text, kind, action string) error {
	return l.sendIncident(incident, l.Cfg.Seats[seat], text, kind, action)
}

// Pkgs returns every package record, sorted.
func (l *Loop) Pkgs() []*Pkg {
	var out []*Pkg
	for k, v := range l.D.KV {
		if strings.HasPrefix(k, "loop-pkg:") {
			p := &Pkg{}
			if json.Unmarshal([]byte(v), p) == nil {
				out = append(out, p)
			}
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].QID < out[j].QID })
	return out
}

// Pkg returns one package record, or nil.
func (l *Loop) Pkg(qid string) *Pkg {
	p := &Pkg{}
	if json.Unmarshal([]byte(l.D.KV["loop-pkg:"+qid]), p) != nil || p.QID == "" {
		return nil
	}
	return p
}

func (l *Loop) save(p *Pkg) error {
	b, _ := json.Marshal(p)
	return l.D.KVPut("loop-pkg:"+p.QID, string(b))
}

func (l *Loop) setStep(p *Pkg, step, note string) error {
	p.Step, p.StepAt = step, py.ISO(l.now())
	if note != "" {
		p.Notes = append(p.Notes, p.StepAt+" "+note)
	}
	return l.save(p)
}

var unitSafe = regexp.MustCompile(`[^A-Za-z0-9_.-]`)

func (l *Loop) unit(action string) string {
	return unitSafe.ReplaceAllString("agent-loop-"+l.Cfg.Project+"-"+action, "_")
}

// arm creates the host deadline timer for an action, before anything is
// sent: no timer, no dispatch.
func (l *Loop) arm(qid, action, execution string, deadline any) error {
	dl, ok := py.Instant(deadline)
	if !ok {
		return fmt.Errorf("deadline %v is not a UTC instant", deadline)
	}
	remaining := dl.Sub(l.now()).Seconds()
	if remaining <= 0 {
		return fmt.Errorf("deadline %v has passed", deadline)
	}
	unit := l.unit(action)
	tm := l.Adapter.Timers
	tm.Allowlist = append(tm.Allowlist, unit)
	b, _ := json.Marshal(tm.Allowlist)
	if err := l.D.KVPut("loop-units", string(b)); err != nil {
		return err
	}
	cb := []string{l.Cfg.Bin, "timer-callback", "--config", l.Cfg.Path, "--qid", qid,
		"--action", action, "--execution", execution}
	_, err := tm.CreateHost(unit, deadline, remaining, cb)
	return err
}

// disarm stops a finished step's host timer. A failure is only noted:
// the callback checks the ledger and refuses a finished step anyway.
func (l *Loop) disarm(action string) {
	if _, err := l.Adapter.Timers.CancelHost(l.unit(action)); err != nil {
		fmt.Fprintf(os.Stderr, "agent-loop: timer for %s not cancelled: %v\n", action, err)
	}
}

func flightDeadline(d *core.Driver, qid string) any {
	rec := d.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if rec == nil {
		return nil
	}
	return py.AsDict(rec.GetOr("flight", py.NewDict())).Get("deadline")
}

// ClaimCommand is the exact command a seat runs to file its claim.
func (l *Loop) ClaimCommand(qid, step string) string {
	return fmt.Sprintf("%s claim --config %s --qid %s --step %s --outcome completed|failed --artifact NAME=PATH [--artifact ...]",
		l.Cfg.Bin, l.Cfg.Path, qid, step)
}

// Nudge is appended to every worker, verifier and director message (R23):
// a prompt, not a check. Nothing reads or validates the answers.
const Nudge = "\n\nBefore you end your turn, answer briefly in your reply: (1) What did this move forward? " +
	"(2) What happens next? If it is yours, do it now; if not, who has it, and do they know? (3) What might I have dropped - anything left undone, " +
	"skipped because of a rule, or handed to someone who does not know?"

func (l *Loop) instructions(p *Pkg, step string) string {
	return Nudge + fmt.Sprintf("\n\n---\nagent-loop package %s, %s step.\nWhen you are done, file your claim with this exact command "+
		"(PATH is relative to %s; list every file you produced or reviewed):\n  %s\n"+
		"Then end your turn. The loop sees the end of your turn and the claim; do not wake anyone.",
		p.QID, step, l.Cfg.ArtifactsDir, l.ClaimCommand(p.QID, step))
}

// Request is one package to dispatch.
type Request struct {
	QID, Worker, Verifier  string
	WorkerTask, VerifyTask string
	DurationS, VerifyS     int64
	OnPass                 *OnPass
	Inputs                 []string // files the work depends on; a change blocks the next dispatch
	After                  []string // packages that must close with an eligible decision first
}

// EligibleKinds are the decisions that release a dependent package.
var EligibleKinds = map[string]bool{"question_answered": true, "successor_opened": true}

func (l *Loop) inputPath(p string) string {
	if filepath.IsAbs(p) {
		return p
	}
	return filepath.Join(l.Cfg.ArtifactsDir, p)
}

func fileHash(path string) (string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// inputsChanged names the first declared input that is missing or no
// longer has its registered hash.
func (l *Loop) inputsChanged(p *Pkg) string {
	paths := make([]string, 0, len(p.Inputs))
	for k := range p.Inputs {
		paths = append(paths, k)
	}
	sort.Strings(paths)
	for _, path := range paths {
		h, err := fileHash(l.inputPath(path))
		if err != nil {
			return "E_INPUT_MISSING: " + path
		}
		if h != p.Inputs[path] {
			return "E_INPUT_CHANGED: " + path
		}
	}
	return ""
}

// depState is "eligible", "pending" or "ineligible: <why>", read from the
// ledger's recorded disposition, never from the loop's own notes.
func (l *Loop) depState(qid string) string {
	rec := l.D.Store.Revs.Get(core.RevKey{Q: qid, Rev: int64(1)})
	if rec == nil {
		return "ineligible: " + qid + " has no ledger record"
	}
	disp := py.AsDict(rec.Get("disposition"))
	if disp == nil {
		return "pending"
	}
	if k := py.S(disp.Get("kind")); !EligibleKinds[k] {
		return "ineligible: " + qid + " closed " + k
	}
	return "eligible"
}

// Dispatch registers a package. Running it is the director's
// authorization. The worker is sent its task at once, or, with After set,
// when every prerequisite has closed with an eligible decision.
func (l *Loop) Dispatch(r Request) (*Pkg, error) {
	qid := r.QID
	if l.Pkg(qid) != nil {
		return nil, fmt.Errorf("package %s already exists", qid)
	}
	for _, s := range []string{r.Worker, r.Verifier} {
		if _, ok := l.Cfg.Seats[s]; !ok {
			return nil, fmt.Errorf("seat %s is not in the config", s)
		}
	}
	if r.Worker == r.Verifier || r.Worker == l.Cfg.Director || r.Verifier == l.Cfg.Director {
		return nil, errors.New("worker, verifier and director must be three different seats")
	}
	if l.Cfg.Duty == r.Worker || l.Cfg.Duty == r.Verifier {
		return nil, errors.New("the duty seat cannot be the package's worker or verifier")
	}
	if err := l.VerifySeats(r.Worker, r.Verifier, l.Cfg.Director, l.Cfg.Duty); err != nil {
		return nil, err
	}
	if r.VerifyS > l.Cfg.MaxVerifyS {
		return nil, fmt.Errorf("verify window %ds exceeds max_verify_s %d", r.VerifyS, l.Cfg.MaxVerifyS)
	}
	for _, dep := range r.After {
		// A package can wait only for packages registered before it, and its
		// prerequisites never change, so no cycle can form (waiting for
		// itself is refused here too: it is not registered yet).
		if l.Pkg(dep) == nil {
			return nil, fmt.Errorf("unknown prerequisite %s", dep)
		}
	}
	inputs := map[string]string{}
	for _, in := range r.Inputs {
		h, err := fileHash(l.inputPath(in))
		if err != nil {
			return nil, &host.Fault{Code: "E_INPUT_MISSING", Detail: in + ": " + err.Error(), Owner: "cairn"}
		}
		inputs[in] = h
	}
	p := &Pkg{QID: qid, Worker: r.Worker, Verifier: r.Verifier, WorkerTask: r.WorkerTask, VerifyTask: r.VerifyTask,
		WorkAction: qid + "-w1", WorkExec: "ex-" + qid + "-w1", VerifyAction: qid + "-v1", VerifyExec: "ex-" + qid + "-v1",
		DurationS: r.DurationS, VerifyS: r.VerifyS, OnPass: r.OnPass, Inputs: inputs, After: r.After}
	l.bindPrincipals(p)
	if err := l.authorities(p, "verifier", "director"); err != nil { // admit is the reader (verifier) role
		return nil, err
	}
	if err := l.D.AdmitAuthorize(qid); err != nil {
		return nil, err
	}
	if len(r.After) > 0 {
		if err := l.setStep(p, "held", "waiting for "+strings.Join(r.After, ", ")); err != nil {
			return nil, err
		}
		_, err := l.releaseIfReady(p)
		return l.Pkg(qid), err
	}
	return p, l.release(p)
}

// releaseIfReady releases a held package once every prerequisite has an
// eligible recorded decision; an ineligible one blocks it.
func (l *Loop) releaseIfReady(p *Pkg) (string, error) {
	for _, dep := range p.After {
		switch st := l.depState(dep); {
		case st == "pending":
			return "", nil
		case st != "eligible":
			return l.blocked(p, &host.Fault{Code: "E_DEPENDENCY_UNMET", Detail: strings.TrimPrefix(st, "ineligible: "), Owner: "cairn"})
		}
	}
	if err := l.release(p); err != nil {
		if _, ok := host.IsFault(err); ok {
			return l.Pkg(p.QID).Step + ": " + err.Error(), nil
		}
		return "", err
	}
	if s := l.Pkg(p.QID).Step; s != "worker" {
		return s, nil
	}
	return "released to " + p.Worker, nil
}

// release starts the worker step: inputs rechecked, deadline timer armed
// (no timer, nothing sent), then the task sent.
func (l *Loop) release(p *Pkg) error {
	if why := l.inputsChanged(p); why != "" {
		code, detail, _ := strings.Cut(why, ": ")
		_, err := l.blocked(p, &host.Fault{Code: code, Detail: detail + " changed since registration; nothing sent", Owner: "cairn"})
		if err != nil {
			return err
		}
		return &host.Fault{Code: code, Detail: detail, Owner: "cairn"}
	}
	qid := p.QID
	if err := l.authorities(p, "duty", "worker"); err != nil {
		return err
	}
	if _, err := l.D.StartDispatch(qid, p.WorkAction, p.DurationS, nil); err != nil {
		return err
	}
	deadline := flightDeadline(l.D, qid)
	a := l.Adapter
	if _, err := a.RegisterExecution(p.WorkAction, p.WorkExec, "director-dispatch", deadline); err != nil {
		return err
	}
	if _, err := a.BindRoute(p.WorkAction, l.Cfg.Seats[p.Worker]); err != nil {
		return err
	}
	if _, err := a.BindRoute(p.VerifyAction, l.Cfg.Seats[p.Verifier]); err != nil {
		return err
	}
	if err := l.setStep(p, "worker", "dispatched to "+p.Worker); err != nil {
		return err
	}
	if err := l.arm(qid, p.WorkAction, p.WorkExec, deadline); err != nil {
		l.setStep(p, "blocked", "no deadline timer, nothing sent: "+err.Error())
		return err
	}
	payload := py.D("kind", "dispatch", "package", qid, "action", p.WorkAction, "execution", p.WorkExec,
		"text", p.WorkerTask+l.instructions(p, "worker"))
	_, err := a.OutboxSend(p.WorkAction, payload, p.WorkExec)
	return err
}

func itemTime(item any) (time.Time, bool) {
	s, ok := item.(string)
	if !ok || !strings.HasPrefix(s, "i") {
		return time.Time{}, false
	}
	ms, err := strconv.ParseInt(s[1:], 10, 64)
	if err != nil {
		return time.Time{}, false
	}
	return time.UnixMilli(ms).UTC(), true
}

// Tick reads new turn ends and advances every package that has one and
// a claim. It returns what it did, one line per action.
func (l *Loop) Tick() ([]string, error) {
	var done []string
	active := map[string][]*Pkg{} // stream key -> packages waiting on it
	yield := func() ([]string, error) {
		l.Yielded = true
		return append(done, "yield: ledger-lock budget spent; the rest continues in the next pass"), nil
	}
	for _, p := range l.Pkgs() {
		if p.Step == "held" {
			if l.OutOfBudget() {
				return yield()
			}
			msg, err := l.releaseIfReady(p)
			if err != nil {
				return done, err
			}
			if msg != "" {
				done = append(done, p.QID+": "+msg)
			}
			continue
		}
	}
	for _, p := range l.Pkgs() {
		seat := ""
		switch p.Step {
		case "worker":
			seat = p.Worker
		case "verify":
			seat = p.Verifier
		default:
			continue
		}
		// Watch the session recorded at dispatch: a later rebinding in the
		// config must surface as a refusal, not silently move the watch.
		key := l.Cfg.Seats[seat]
		if pr, ok := p.Principals[map[string]string{"worker": "worker", "verify": "verifier"}[p.Step]]; ok {
			key = pr.Session
		}
		active[key] = append(active[key], p)
	}
	var keys []string
	for k := range active {
		if k != "" {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	if len(keys) > 0 {
		evs, cur, _, _, err := l.watcher.Poll(keys, l.cursors,
			func(t string) error { return l.D.KVPut("sidecar-seen:"+t, "1") },
			func(t string) bool { return l.D.KV["sidecar-seen:"+t] == "1" })
		if err != nil {
			return done, err
		}
		l.cursors = cur
		for _, ev := range evs {
			if !py.Eq(ev.Get("kind"), "end") {
				continue
			}
			key := py.S(ev.Get("stream_key"))
			for _, p := range active[key] {
				at, _ := py.Instant(p.StepAt)
				if it, ok := itemTime(ev.Get("item")); ok && it.Before(at.Add(-2*time.Second)) {
					continue // a turn that started before this step was sent
				}
				if err := l.D.KVPut("loop-end:"+p.QID+":"+p.Step, py.Dumps(ev)); err != nil {
					return done, err
				}
			}
		}
	}
	for _, ps := range active {
		for _, p := range ps {
			if l.OutOfBudget() {
				return yield()
			}
			msg, err := l.advance(p)
			if err != nil {
				return done, err
			}
			if msg != "" {
				done = append(done, p.QID+": "+msg)
			}
		}
	}
	if l.OutOfBudget() {
		return yield()
	}
	if _, err := l.Adapter.DrainOutboxSettled(""); err != nil {
		return done, err
	}
	if l.OutOfBudget() {
		return yield()
	}
	// run holds the ledger lock for the whole pass: this view is fresh.
	done = append(done, l.unacked()...)
	done = append(done, l.decisionLadder()...) // P13: run walks the decision ladder after every pass
	return append(done, l.expiredAcks()...), nil
}

func (l *Loop) lastEnd(p *Pkg) *py.Dict {
	raw := l.D.KV["loop-end:"+p.QID+":"+p.Step]
	if raw == "" {
		return nil
	}
	v, err := py.Loads([]byte(raw))
	if err != nil {
		return nil
	}
	return py.AsDict(v)
}

func (l *Loop) launch(p *Pkg, verify bool) *py.Dict {
	action, exec, step := p.WorkAction, p.WorkExec, "worker-run"
	if verify {
		action, exec, step = p.VerifyAction, p.VerifyExec, "verify-run"
	}
	esc := py.ISO(l.now().Add(time.Hour))
	return py.D("package", p.QID, "attempt", "a1", "action", action, "execution", exec, "contract_step", step,
		"escalation_deadline_utc", esc, "artifact_base_dir", l.Cfg.ArtifactsDir, "stream_dir", l.Cfg.StreamDir,
		"defer_verifier_send", true)
}

// advance moves one package if its step's turn has ended with a claim.
func (l *Loop) advance(p *Pkg) (string, error) {
	end := l.lastEnd(p)
	if end == nil {
		return "", nil
	}
	verify := p.Step == "verify"
	exec := p.WorkExec
	if verify {
		exec = p.VerifyExec
	}
	if _, err := os.Stat(host.ClaimPathFor(l.Cfg.ClaimsDir, exec)); err != nil {
		return "", nil // no claim yet: the deadline timer owns a claim that never comes
	}
	role := "worker"
	if verify {
		role = "verifier"
	}
	if err := l.authorities(p, role); err != nil {
		return l.blocked(p, err)
	}
	key := py.S(end.Get("stream_key"))
	launch := l.launch(p, verify)
	if err := l.Adapter.BindTurn(key, end.Get("item"), py.S(launch.Get("execution")),
		py.S(launch.Get("action")), py.S(launch.Get("contract_step"))); err != nil {
		return "", err
	}
	if !verify {
		return l.finishWorker(p, end, launch)
	}
	return l.finishVerify(p, end, launch)
}

func (l *Loop) blocked(p *Pkg, err error) (string, error) {
	f, ok := host.IsFault(err)
	if !ok {
		var ce *host.ClaimError
		if !errors.As(err, &ce) {
			return "", err
		}
	}
	note := err.Error()
	if f != nil {
		note = f.Code + ": " + f.Detail
	}
	if err := l.setStep(p, "blocked", note); err != nil {
		return "", err
	}
	l.send(l.Cfg.Director, fmt.Sprintf("[agent-loop] %s is BLOCKED: %s. See: agent-loop status --config %s",
		p.QID, note, l.Cfg.Path), "escalation", p.QID)
	return "blocked: " + note, nil
}

func (l *Loop) finishWorker(p *Pkg, end, launch *py.Dict) (string, error) {
	if why := l.inputsChanged(p); why != "" {
		code, detail, _ := strings.Cut(why, ": ")
		return l.blocked(p, &host.Fault{Code: code, Detail: detail + " changed during the work; verifier not dispatched", Owner: "cairn"})
	}
	vdeadline := py.ISO(l.now().Add(time.Duration(p.VerifyS) * time.Second))
	spec := py.D("action_id", p.VerifyAction, "deadline_utc", vdeadline, "execution_id", p.VerifyExec)
	out, err := host.RunHandoff(l.Adapter, p.QID, end, l.Cfg.ClaimsDir, launch, spec)
	if err != nil {
		return l.blocked(p, err)
	}
	switch py.S(out.Get("decision")) {
	case "transition-committed":
	case "owned-recovery":
		return "recovery: " + py.S(out.Get("reason")), l.setStep(p, "recovery", "worker: "+py.S(out.Get("reason")))
	default:
		return "", nil
	}
	a := l.Adapter
	l.disarm(p.WorkAction)
	if _, err := a.RegisterExecution(p.VerifyAction, p.VerifyExec, "director-dispatch", vdeadline); err != nil {
		return "", err
	}
	if err := l.setStep(p, "verify", "worker claim verified; dispatched to "+p.Verifier); err != nil {
		return "", err
	}
	if err := l.arm(p.QID, p.VerifyAction, p.VerifyExec, vdeadline); err != nil {
		return l.blocked(p, &host.Fault{Code: "E_NO_TIMER", Detail: err.Error(), Owner: "cairn"})
	}
	text := p.VerifyTask + fmt.Sprintf("\n\nThe worker's claim is %s; its artifacts are under %s.",
		host.ClaimPathFor(l.Cfg.ClaimsDir, p.WorkExec), l.Cfg.ArtifactsDir) + l.instructions(p, "verify")
	payload := py.D("kind", "dispatch", "package", p.QID, "action", p.VerifyAction, "execution", p.VerifyExec, "text", text)
	if _, err := a.OutboxSend(p.VerifyAction, payload, p.VerifyExec); err != nil {
		return "", err
	}
	return "verifier dispatched to " + p.Verifier, nil
}

func readJSON(path string) *py.Dict {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	v, err := py.Loads(b)
	if err != nil {
		return nil
	}
	return py.AsDict(v)
}

func (l *Loop) finishVerify(p *Pkg, end, launch *py.Dict) (string, error) {
	claim := readJSON(host.ClaimPathFor(l.Cfg.ClaimsDir, p.VerifyExec))
	if claim == nil {
		return l.blocked(p, &host.Fault{Code: "E_CLAIM_MALFORMED", Detail: "verifier claim is not a JSON object", Owner: "cairn"})
	}
	outcome := claim.Get("outcome")
	if py.Eq(outcome, "completed") && p.OnPass != nil {
		if err := l.authorities(p, "director"); err != nil {
			return l.blocked(p, err)
		}
		launch.Set("authorized_dispositions", []any{py.D("kind", p.OnPass.Kind,
			"decision_ref", p.OnPass.DecisionRef, "reason", p.OnPass.Reason)})
		out, err := host.RunHandoff(l.Adapter, p.QID, end, l.Cfg.ClaimsDir, launch, nil)
		if err != nil {
			return l.blocked(p, err)
		}
		if py.Eq(out.Get("decision"), "terminal-rest") {
			l.disarm(p.VerifyAction)
			p.Verdict = "PASS"
			return "PASS; closed by the pre-authorized disposition", l.setStep(p, "closed", "closed "+p.OnPass.Kind)
		}
		return "", nil
	}
	// Record the verdict and leave the decision to the director.
	if err := host.ValidateClaim(claim, launch); err != nil {
		return l.blocked(p, err)
	}
	passed := py.Eq(outcome, "completed")
	if _, err := host.RecomputeArtifacts(claim, l.Cfg.ArtifactsDir); err != nil {
		return l.blocked(p, err)
	}
	if !passed && !py.Eq(outcome, "failed") {
		return l.blocked(p, &host.Fault{Code: "E_CLAIM_OUTCOME", Detail: "verifier outcome " + py.S(outcome), Owner: "cairn"})
	}
	at, _ := py.Instant(p.StepAt)
	elapsed := int64(l.now().Sub(at).Seconds())
	if elapsed < 0 {
		elapsed = 0
	}
	hold := py.ISO(l.now().Add(time.Duration(l.Cfg.DecisionS) * time.Second))
	if _, err := l.D.Verify(p.QID, p.VerifyAction+"-verdict", passed, elapsed, hold,
		py.D("pass_budget_s", p.VerifyS)); err != nil {
		return l.blocked(p, &host.Fault{Code: "E_VERDICT_REFUSED", Detail: err.Error(), Owner: "cairn"})
	}
	l.disarm(p.VerifyAction)
	p.Verdict = "FAIL"
	if passed {
		p.Verdict = "PASS"
	}
	l.D.KVPut("turn-seen:"+py.S(end.Get("stream_key"))+":"+py.S(end.Get("item"))+":"+p.VerifyExec, `{"outcome": "`+py.S(outcome)+`"}`)
	if err := l.setStep(p, "decision", "verifier "+p.Verdict+"; waiting for the director"); err != nil {
		return "", err
	}
	if err := l.openDecision(l.Pkg(p.QID), l.now()); err != nil { // P13: deadline + timer; a failed arm is recovered by the checks
		fmt.Fprintln(os.Stderr, "agent-loop: decision timer for", p.QID, "not armed:", err)
	}
	l.send(l.Cfg.Director, fmt.Sprintf("[agent-loop] %s: verifier %s. Claim: %s. Decide with: %s decide --config %s --qid %s --kind successor_opened|question_answered|budget_spent|blocked --ref REF --reason TEXT%s",
		p.QID, p.Verdict, host.ClaimPathFor(l.Cfg.ClaimsDir, p.VerifyExec), l.Cfg.Bin, l.Cfg.Path, p.QID, Nudge), "decision", p.QID)
	return "verifier " + p.Verdict + "; decision requested from " + l.Cfg.Director, nil
}

// Decide records the director's disposition.
func (l *Loop) Decide(qid, kind, ref, reason string) error {
	p := l.Pkg(qid)
	if p == nil {
		return fmt.Errorf("no package %s", qid)
	}
	// The ref is part of the event id: a retry of the same decision is a
	// duplicate, a different decision reaches the core and is refused.
	ev := py.D("event_id", qid+"-decide-"+ref, "question_id", qid, "revision", int64(1), "type", "decide",
		"disposition", py.D("kind", kind, "decision_ref", ref, "reason", reason))
	director, err := l.authority(p, "director")
	if err != nil {
		return err
	}
	if _, err := l.D.Ingress.Append(ev, l.D.Budget, nil, l.D.Grants, director, nil); err != nil {
		return err
	}
	if err := l.setStep(p, "closed", "decided "+kind+" ("+ref+")"); err != nil {
		return err
	}
	if p = l.Pkg(qid); p.Decision != nil && p.Decision.Resolved == "" { // P13: an actual decision resolves the incident
		l.Adapter.Timers.CancelHost(l.unit(decisionUnit(p)))
		l.resolveDecision(p, l.now())
	}
	return nil
}

// Claim writes a seat's completion claim with hashes computed from disk.
func (l *Loop) Claim(qid, step, outcome string, artifacts map[string]string) (string, error) {
	p := l.Pkg(qid)
	if p == nil {
		return "", fmt.Errorf("no package %s", qid)
	}
	action, exec, cstep := p.WorkAction, p.WorkExec, "worker-run"
	if step == "verify" {
		action, exec, cstep = p.VerifyAction, p.VerifyExec, "verify-run"
	} else if step != "worker" {
		return "", fmt.Errorf("step must be worker or verify, not %q", step)
	}
	if outcome != "completed" && outcome != "failed" {
		return "", fmt.Errorf("outcome must be completed or failed, not %q", outcome)
	}
	if len(artifacts) == 0 {
		return "", errors.New("name at least one artifact")
	}
	arts := py.NewDict()
	names := make([]string, 0, len(artifacts))
	for n := range artifacts {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		rel := artifacts[n]
		b, err := os.ReadFile(filepath.Join(l.Cfg.ArtifactsDir, rel))
		if err != nil {
			return "", fmt.Errorf("artifact %s: %v", n, err)
		}
		h := sha256.Sum256(b)
		arts.Set(n, py.D("path", rel, "sha256", hex.EncodeToString(h[:])))
	}
	return host.WriteClaim(l.Cfg.ClaimsDir, exec, py.D("package", qid, "attempt", "a1", "action", action,
		"execution", exec, "contract_step", cstep, "outcome", outcome, "artifacts", arts))
}

// Status is the one view: every package, its step, phase, deadline,
// verdict, and what is waiting on whom.
func (l *Loop) Status() []map[string]any {
	var out []map[string]any
	for _, p := range l.Pkgs() {
		rec := l.D.Store.Revs.Get(core.RevKey{Q: p.QID, Rev: int64(1)})
		phase, deadline := "", ""
		if rec != nil {
			phase = py.S(rec.Get("phase"))
			if dl := py.AsDict(rec.GetOr("flight", py.NewDict())).Get("deadline"); dl != nil && (p.Step == "worker" || p.Step == "verify") {
				deadline = py.S(dl)
			}
		}
		waiting := map[string]string{"held": strings.Join(p.After, ", "), "worker": p.Worker, "verify": p.Verifier, "decision": l.Cfg.Director,
			"blocked": l.Cfg.Director, "recovery": l.Cfg.Director, "timed-out": l.Cfg.Director}[p.Step]
		last := ""
		if len(p.Notes) > 0 {
			last = p.Notes[len(p.Notes)-1]
		}
		out = append(out, map[string]any{"qid": p.QID, "step": p.Step, "since": p.StepAt, "phase": phase,
			"deadline": deadline, "waiting_on": waiting, "verdict": p.Verdict, "last": last, "principals": p.Principals, "timeout": p.Timeout, "decision": p.Decision})
	}
	return out
}

// PendingOutbox counts intents not yet proven delivered.
func (l *Loop) PendingOutbox() int {
	n := 0
	for k, v := range l.D.KV {
		if strings.HasPrefix(k, "outbox-pending:") && v != "" && l.D.KV["outbox-acked:"+strings.TrimPrefix(k, "outbox-pending:")] == "" {
			n++
		}
	}
	return n
}

// TimerCallback runs a deadline through ledger authority, with real
// stop and wake effects.
func TimerCallback(cfg *Config, qid, action, execution string) (*py.Dict, error) {
	l, err := Open(cfg, nil)
	if err != nil {
		return nil, err
	}
	p := l.Pkg(qid)
	if p == nil {
		l.Close()
		return nil, &host.Fault{Code: "E_UNKNOWN_PACKAGE", Detail: "no loop record for " + qid, Owner: "cairn"}
	}
	err = l.authorities(p, "duty")
	l.Close()
	if err != nil {
		return nil, err
	}
	return host.TimerCallback(cfg.DB, "deadline:"+action, qid, action, execution, core.HostClock{},
		func(d *core.Driver) {
			a, err := host.NewAdapter(d, newTransport(cfg, d), nil, true)
			if err == nil {
				(&Loop{Cfg: cfg, Adapter: a, D: d}).wire()
			}
		})
}
