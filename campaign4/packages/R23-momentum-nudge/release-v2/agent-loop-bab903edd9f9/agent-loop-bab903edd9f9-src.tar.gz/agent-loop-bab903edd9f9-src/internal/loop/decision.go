package loop

import (
	"crypto/md5"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"agent-loop/internal/host"
	"agent-loop/internal/py"
)

// P13: director decision ownership.
//
// MECHANISM (here, in the loop) versus POLICY (in the config). The loop owns
// only the obligation: when a package enters the decision step it persists a
// trusted deadline and incident identity, arms a real absolute UTC calendar
// timer, and walks a ladder of rungs, each at most once per incident, each
// persisted before delivery, with durable per-incident notice records (D3).
// WHO is told at which offset is the config's decision_ladder: a rung names a
// seat (a wake to that seat) or an external command (an adapter, e.g. the
// fleet's notify-claude, fed the text on stdin). The loop knows nothing about
// Claude, Signal or the fleet's pager: those are fleet policy, reached only
// through a configured command and, beyond it, the fleet's own
// escalation-watch.
//
// Responses: a configured responder may acknowledge ONCE per incident with an
// owner, a next action and a response deadline of at most MaxDecisionAckWithin.
// An acknowledgement is not a decision. If the response deadline passes while
// the package still waits (or, after the external rung, no acknowledgement
// comes within MaxDecisionAckWithin) the external rung is RE-RAISED once with
// the SAME text, so a ledger keyed on the text sees the same key again after
// its ack (the fleet's recurrence path). Only an actual decision resolves the
// incident: every later rung is then skipped, a stale timer callback is
// harmless, and resolution commands (e.g. acking the ledger records of that key)
// run so an unacked record cannot page after the fact.
const (
	DefaultDecisionS     = 1800
	MaxDecisionS         = 86400
	MaxDecisionAckWithin = 15 * time.Minute
	// A rung (or the re-raise) gets at most MaxRungAttempts transport attempts,
	// counted durably before each effect, RungRetryAfter apart; then it is
	// "unresolved", shown in status and owned by the director (one notice).
	MaxRungAttempts = 2
	RungRetryAfter  = 30 * time.Second
)

// Rung is one step of the decision ladder (config).
type Rung struct {
	AfterS int64    `json:"after_s"`        // seconds after the decision deadline
	Seat   string   `json:"seat,omitempty"` // a configured seat to wake
	Exec   []string `json:"exec,omitempty"` // or an external command; the text arrives on stdin
	// External rungs only: the JSONL ledger the command writes (durable
	// registration is verified by the key md5(kind + "\n" + text)), and the
	// command that acknowledges a ledger record id on resolution.
	Ledger     string   `json:"ledger,omitempty"`
	LedgerKind string   `json:"ledger_kind,omitempty"`
	ResolveCmd []string `json:"resolve_cmd,omitempty"` // + ID + "--note" + reason
}

// DecisionDue is a package's decision obligation (persisted in the package).
type DecisionDue struct {
	Incident string            `json:"incident"`
	Deadline string            `json:"deadline"`
	Rungs    map[string]string `json:"rungs,omitempty"` // rung index -> "sent <t>" | "failed <t>: why" | "intended <t>"
	Ack      *DecisionAck      `json:"ack,omitempty"`
	Reraised string            `json:"reraised,omitempty"`
	Resolved string            `json:"resolved,omitempty"`
	Resolve  []string          `json:"resolve_actions,omitempty"`
	Attempts map[string]int    `json:"attempts,omitempty"` // rung index|"reraise" -> transport attempts started
	Caps     map[string]Cap    `json:"caps,omitempty"`     // responder -> current capability (digest only)
}

// Cap is an incident-scoped acknowledgement capability: 256 random bits in a
// mode-0600 file under <db>.caps (0700), named in the notice by path only.
// The loop keeps only its sha256. It is re-issued (rotated) on every external
// send, so an older secret is stale. Trust boundary: any process of the same
// Unix user can read the file; this guards against guessing, mistakes and
// cross-incident replay, not against a hostile same-user process.
type Cap struct {
	Digest string `json:"sha256"`
	Exp    string `json:"expires"`
}

// DecisionAck is a responder's bounded acknowledgement (not a decision).
type DecisionAck struct {
	By       string `json:"by"`
	Next     string `json:"next_action"`
	Deadline string `json:"response_deadline"`
	At       string `json:"at"`
	Cap      string `json:"cap_sha256"`
}

func (c *Config) decisionWindow() time.Duration {
	s := c.DecisionDeadlineS
	if s <= 0 {
		s = DefaultDecisionS
	}
	if s > MaxDecisionS {
		s = MaxDecisionS
	}
	return time.Duration(s) * time.Second
}

// ladder is the configured ladder, or the default: director at the deadline,
// duty 300 s later. External rungs exist only when configured.
func (c *Config) ladder() []Rung {
	if len(c.DecisionLadder) > 0 {
		return c.DecisionLadder
	}
	return []Rung{{AfterS: 0, Seat: c.Director}, {AfterS: 300, Seat: c.Duty}}
}

// validateDecision checks the decision policy. With decision_policy
// "required" (a campaign) the full three-rung policy must be present:
// director at the deadline, duty +300 s, an external rung +600 s with an
// absolute command, ledger, ledger kind and resolution command, and responders.
func (c *Config) validateDecision() []string {
	var bad []string
	if c.DecisionDeadlineS < 0 || c.DecisionDeadlineS > MaxDecisionS {
		bad = append(bad, fmt.Sprintf("decision_deadline_s must be 0 (default %d) .. %d", DefaultDecisionS, MaxDecisionS))
	}
	last := int64(-1)
	ext := false
	for i, r := range c.DecisionLadder {
		switch {
		case (r.Seat == "") == (len(r.Exec) == 0):
			bad = append(bad, fmt.Sprintf("decision_ladder[%d] must name exactly one of seat or exec", i))
		case r.Seat != "" && c.Seats[r.Seat] == "":
			bad = append(bad, fmt.Sprintf("decision_ladder[%d].seat %q is not a configured seat", i, r.Seat))
		case len(r.Exec) > 0 && !filepath.IsAbs(r.Exec[0]):
			bad = append(bad, fmt.Sprintf("decision_ladder[%d].exec[0] must be an absolute path", i))
		}
		if r.AfterS < last {
			bad = append(bad, fmt.Sprintf("decision_ladder[%d].after_s must be >= 0 and not before the previous rung", i))
		}
		last = r.AfterS
		if len(r.Exec) > 0 {
			ext = true
			if r.Ledger != "" && (!filepath.IsAbs(r.Ledger) || r.LedgerKind == "") {
				bad = append(bad, fmt.Sprintf("decision_ladder[%d].ledger must be absolute with a ledger_kind", i))
			}
			if len(r.ResolveCmd) > 0 && !filepath.IsAbs(r.ResolveCmd[0]) {
				bad = append(bad, fmt.Sprintf("decision_ladder[%d].resolve_cmd[0] must be an absolute path", i))
			}
		}
	}
	if ext && len(c.DecisionResponders) == 0 {
		bad = append(bad, "decision_responders must be set when the ladder has an external rung")
	}
	switch c.DecisionPolicy {
	case "":
	case "required":
		l := c.DecisionLadder
		if len(l) != 3 || l[0].AfterS != 0 || l[0].Seat != c.Director || l[1].AfterS != 300 || l[1].Seat != c.Duty ||
			l[2].AfterS != 600 || len(l[2].Exec) == 0 || l[2].Ledger == "" || len(l[2].ResolveCmd) == 0 || len(c.DecisionResponders) == 0 {
			bad = append(bad, "decision_policy required: decision_ladder must be exactly director +0 s, duty +300 s, an external rung +600 s with ledger and resolve_cmd, and decision_responders")
		}
	default:
		bad = append(bad, fmt.Sprintf("decision_policy %q: want \"\" or \"required\"", c.DecisionPolicy))
	}
	return bad
}

func decisionUnit(p *Pkg) string { return p.VerifyAction + "-decision" }

// openDecision persists the obligation and arms its calendar timer. The
// deadline is taken from `from` (entry into the decision step); reopening a
// package that already has one never moves it.
func (l *Loop) openDecision(p *Pkg, from time.Time) error {
	if p.Decision == nil {
		p.Decision = &DecisionDue{Incident: "D-" + p.QID + "-" + p.VerifyAction,
			Deadline: py.ISO(from.Add(l.Cfg.decisionWindow())), Rungs: map[string]string{}}
		if err := l.save(p); err != nil {
			return err
		}
	}
	return l.armDecision(p)
}

// armDecision (re)arms the deadline timer at the ORIGINAL instant; a missing
// timer is recovered by the next check, never by moving the deadline.
func (l *Loop) armDecision(p *Pkg) error {
	dl, ok := py.Instant(p.Decision.Deadline)
	if !ok {
		return fmt.Errorf("decision deadline %q unreadable", p.Decision.Deadline)
	}
	rem := dl.Sub(l.now()).Seconds()
	if rem <= 0 {
		return nil // already due: the checks own it
	}
	unit := l.unit(decisionUnit(p))
	tm := l.Adapter.Timers
	tm.Allowlist = append(tm.Allowlist, unit)
	b, _ := json.Marshal(tm.Allowlist)
	if err := l.D.KVPut("loop-units", string(b)); err != nil {
		return err
	}
	_, err := tm.CreateHost(unit, p.Decision.Deadline, rem, []string{l.Cfg.Bin, "decision-check", "--config", l.Cfg.Path})
	return err
}

func (l *Loop) decisionText(p *Pkg, i int) string {
	// Stable per incident (no clock values): an external ledger keyed on the
	// text sees the same key on a re-raise.
	return fmt.Sprintf("[agent-loop] DECISION OVERDUE %s: package %s (verifier %s) has waited for the director (%s) since its decision deadline %s. Decide: %s decide --config %s --qid %s --kind ... --ref ... --reason ... ; or acknowledge once (owner, next action, <= %s): %s decision-ack --config %s --qid %s --by RESPONDER --next 'NEXT ACTION' --within 15m",
		p.Decision.Incident, p.QID, p.Verdict, l.Cfg.Director, p.Decision.Deadline, l.Cfg.Bin, l.Cfg.Path, p.QID,
		MaxDecisionAckWithin, l.Cfg.Bin, l.Cfg.Path, p.QID) + l.capNote(p, i)
}

func (l *Loop) capDir() string { return l.Cfg.DB + ".caps" }

func (l *Loop) capPath(p *Pkg, by string) string {
	return filepath.Join(l.capDir(), p.Decision.Incident+"."+by)
}

// capNote names (by path only, stable per incident) each responder's
// capability file on an external rung's text.
func (l *Loop) capNote(p *Pkg, i int) string {
	lad := l.Cfg.ladder()
	if i >= len(lad) || len(lad[i].Exec) == 0 {
		return ""
	}
	var b strings.Builder
	for _, by := range l.Cfg.DecisionResponders {
		fmt.Fprintf(&b, " Acknowledgement capability for %s: --cap-file %s", by, l.capPath(p, by))
	}
	return b.String()
}

// issueCaps writes a fresh capability per responder (rotating any older one).
func (l *Loop) issueCaps(p *Pkg, now time.Time) error {
	if err := os.MkdirAll(l.capDir(), 0o700); err != nil {
		return err
	}
	if err := os.Chmod(l.capDir(), 0o700); err != nil {
		return err
	}
	if p.Decision.Caps == nil {
		p.Decision.Caps = map[string]Cap{}
	}
	for _, by := range l.Cfg.DecisionResponders {
		var raw [32]byte
		if _, err := rand.Read(raw[:]); err != nil {
			return err
		}
		sec := hex.EncodeToString(raw[:])
		f := l.capPath(p, by)
		tmp := f + ".tmp"
		if err := os.WriteFile(tmp, []byte(sec+"\n"), 0o600); err != nil {
			return err
		}
		if err := os.Rename(tmp, f); err != nil {
			return err
		}
		d := sha256.Sum256([]byte(sec))
		p.Decision.Caps[by] = Cap{Digest: hex.EncodeToString(d[:]), Exp: py.ISO(now.Add(MaxDecisionAckWithin))}
	}
	return l.save(p)
}

// decisionLadder walks every waiting decision (run after each pass, the
// outside check every 30 s and the deadline timer's callback). The caller
// holds the ledger lock.
func (l *Loop) decisionLadder() []string {
	var out []string
	now := l.now()
	for _, p := range l.Pkgs() {
		if p.Step != "decision" {
			if p.Decision != nil && p.Decision.Resolved == "" && p.Step == "closed" {
				out = append(out, l.resolveDecision(p, now)...)
			}
			continue
		}
		if p.Decision == nil { // migration: a package that entered decision before P13
			at, ok := py.Instant(p.StepAt)
			if !ok {
				at = now
			}
			if err := l.openDecision(p, at); err != nil {
				out = append(out, p.QID+": decision deadline not armed: "+err.Error())
			}
			p = l.Pkg(p.QID)
		}
		dl, ok := py.Instant(p.Decision.Deadline)
		if !ok || now.Before(dl) {
			continue
		}
		for i, r := range l.Cfg.ladder() {
			k := fmt.Sprint(i)
			if st := p.Decision.Rungs[k]; strings.HasPrefix(st, "sent") || strings.HasPrefix(st, "unresolved") || now.Before(dl.Add(time.Duration(r.AfterS)*time.Second)) {
				continue
			}
			out = append(out, l.fireRung(p, i, r, "rung", now)...)
		}
		out = append(out, l.reraise(p, now)...)
	}
	return out
}

// fireRung persists the intent, delivers once (D3 incident key), records the outcome.
func (l *Loop) fireRung(p *Pkg, i int, r Rung, what string, now time.Time) []string {
	k := fmt.Sprint(i)
	if what != "rung" {
		k = what
	}
	if p.Decision.Rungs == nil { // omitempty: an empty map reloads as nil
		p.Decision.Rungs = map[string]string{}
	}
	if p.Decision.Attempts == nil {
		p.Decision.Attempts = map[string]int{}
	}
	prev := p.Decision.Rungs[k]
	text := l.decisionText(p, i)
	if st := strings.SplitN(prev, " ", 3); len(st) >= 2 && (st[0] == "intended" || st[0] == "failed") {
		if at, ok := py.Instant(strings.TrimSuffix(st[1], ":")); ok {
			// An uncertain earlier attempt (a crash after "intended"): a durable
			// ledger record since then is its receipt, so it is not sent again.
			if st[0] == "intended" && len(r.Exec) > 0 && r.Ledger != "" && len(ledgerIDs(r, text, at.Add(-5*time.Second), false)) > 0 {
				p.Decision.Rungs[k] = "sent " + py.ISO(now) + " (receipt of the uncertain attempt of " + st[1] + ")"
				l.save(p)
				return []string{fmt.Sprintf("%s: decision %s %s: %s", p.QID, what, k, p.Decision.Rungs[k])}
			}
			if st[0] == "failed" && now.Before(at.Add(RungRetryAfter)) {
				return nil
			}
		}
	}
	if p.Decision.Attempts[k] >= MaxRungAttempts {
		p.Decision.Rungs[k] = "unresolved " + py.ISO(now) + " after " + fmt.Sprint(p.Decision.Attempts[k]) + " attempts; last: " + prev
		l.save(p)
		err := l.sendSeat("decision|"+p.Decision.Incident+"|"+k+"|unresolved", l.Cfg.Director,
			fmt.Sprintf("[agent-loop] DECISION NOTICE UNDELIVERED %s: %s %s failed %d times (%s). You own it: decide %s, or repair the adapter.",
				p.Decision.Incident, what, k, p.Decision.Attempts[k], prev, p.QID), "escalation", p.QID)
		return []string{fmt.Sprintf("%s: decision %s %s: %s (director told: %v)", p.QID, what, k, p.Decision.Rungs[k], err)}
	}
	p.Decision.Attempts[k]++
	p.Decision.Rungs[k] = "intended " + py.ISO(now)
	if err := l.save(p); err != nil {
		return []string{p.QID + ": decision rung not persisted: " + err.Error()}
	}
	var err error
	if len(r.Exec) > 0 && len(l.Cfg.DecisionResponders) > 0 {
		err = l.issueCaps(p, now)
	}
	switch {
	case err != nil:
		err = fmt.Errorf("capability not issued: %v", err)
	case r.Seat != "":
		err = l.sendSeat("decision|"+p.Decision.Incident+"|"+k, r.Seat, text, "escalation", p.QID)
	case len(r.Exec) > 0:
		err = l.execRung(p.Decision.Incident+"|"+k, r, text, now)
	default:
		err = fmt.Errorf("rung %d names neither a seat nor a command", i)
	}
	if err != nil {
		p.Decision.Rungs[k] = "failed " + py.ISO(now) + ": " + err.Error()
	} else {
		p.Decision.Rungs[k] = "sent " + py.ISO(now)
	}
	l.save(p)
	return []string{fmt.Sprintf("%s: decision %s %s: %s", p.QID, what, k, p.Decision.Rungs[k])}
}

// execRung runs an external rung: the text on stdin, bounded, rc 0 required,
// and (with a ledger) durable registration verified by key.
func (l *Loop) execRung(incident string, r Rung, text string, now time.Time) error {
	run := l.Cfg.Run
	if run == nil {
		run = host.ExecRunner
	}
	argv := append([]string{"/bin/sh", "-c", `m=$1; shift; printf '%s\n' "$m" | "$@"`, "sh", text}, r.Exec...)
	p, err := run(argv, nil, 10*time.Second)
	if err != nil {
		return err
	}
	if r.Ledger != "" {
		// The ledger is the durable path; the command's rc reports only its fast
		// path (notify-claude exits 1 when no chat listener is up, after writing
		// the ledger). Delivered = a record with this incident's key since now-5s.
		ids := ledgerIDs(r, text, now.Add(-5*time.Second), false)
		if len(ids) == 0 {
			return fmt.Errorf("rc %d and no durable ledger record with this key in %s: %s", p.RC, r.Ledger, strings.TrimSpace(p.Stderr))
		}
		return nil
	}
	if p.RC != 0 {
		return fmt.Errorf("rc %d: %s", p.RC, strings.TrimSpace(p.Stderr))
	}
	return nil
}

func ledgerKey(r Rung, text string) string {
	h := md5.Sum([]byte(r.LedgerKind + "\n" + strings.TrimSpace(text)))
	return hex.EncodeToString(h[:])[:12]
}

// ledgerIDs lists the ledger record ids whose key is md5(kind + "\n" + text),
// written at/after since (unacked only when requested).
func ledgerIDs(r Rung, text string, since time.Time, unackedOnly bool) []string {
	key := ledgerKey(r, text)
	b, err := os.ReadFile(expand(r.Ledger))
	if err != nil {
		return nil
	}
	acked := map[string]bool{}
	var recs []map[string]any
	for _, ln := range strings.Split(string(b), "\n") {
		var m map[string]any
		if json.Unmarshal([]byte(ln), &m) != nil {
			continue
		}
		if a, ok := m["ack"].(string); ok {
			acked[a] = true
		}
		recs = append(recs, m)
	}
	var ids []string
	for _, m := range recs {
		id, _ := m["id"].(string)
		t, _ := m["t"].(float64)
		if id == "" || m["key"] != key || int64(t) < since.Unix() || (unackedOnly && acked[id]) {
			continue
		}
		ids = append(ids, id)
	}
	return ids
}

// reraise re-sends the external rung once, with the same text, when the
// responder's acknowledgement expired or never came within the bound.
func (l *Loop) reraise(p *Pkg, now time.Time) []string {
	if st := p.Decision.Reraised; strings.HasPrefix(st, "sent") || strings.HasPrefix(st, "unresolved") {
		return nil
	}
	for i, r := range l.Cfg.ladder() {
		if len(r.Exec) == 0 {
			continue
		}
		sent := strings.TrimPrefix(p.Decision.Rungs[fmt.Sprint(i)], "sent ")
		at, ok := py.Instant(sent)
		if !ok {
			continue
		}
		due := at.Add(MaxDecisionAckWithin)
		if a := p.Decision.Ack; a != nil {
			if d, ok := py.Instant(a.Deadline); ok {
				due = d
			}
		}
		if now.Before(due) {
			continue
		}
		out := l.fireRung(p, i, r, "reraise", now)
		p.Decision.Reraised = p.Decision.Rungs["reraise"]
		l.save(p)
		return out
	}
	return nil
}

// resolveDecision marks the incident resolved by the actual decision and runs
// the external rungs' resolution commands for records of this incident's key.
func (l *Loop) resolveDecision(p *Pkg, now time.Time) []string {
	p.Decision.Resolved = py.ISO(now)
	var out []string
	for i, r := range l.Cfg.ladder() {
		if len(r.ResolveCmd) == 0 || r.Ledger == "" {
			continue
		}
		run := l.Cfg.Run
		if run == nil {
			run = host.ExecRunner
		}
		// One append-only resolution record keyed to this incident's ledger key
		// (the private watcher does not page a key resolved after its record).
		key := ledgerKey(r, l.decisionText(p, i))
		argv := append(append([]string{}, r.ResolveCmd...), key, p.Decision.Incident, "resolved: "+p.QID+" decided ("+p.Decision.Incident+")")
		res, err := run(argv, nil, 10*time.Second)
		st := "ok"
		if err != nil || res.RC != 0 {
			st = fmt.Sprintf("failed rc %d %v", res.RC, err)
		}
		p.Decision.Resolve = append(p.Decision.Resolve, key+" "+st)
	}
	l.save(p)
	return append(out, p.QID+": decision incident "+p.Decision.Incident+" resolved by the decision")
}

// DecisionAck records a responder's single bounded acknowledgement. The
// responder proves itself with the incident's current capability secret
// (read from its file by the CLI, never passed in argv).
func (l *Loop) DecisionAck(qid, by, secret, next string, within time.Duration) (*DecisionAck, error) {
	p := l.Pkg(qid)
	if p == nil || p.Step != "decision" || p.Decision == nil {
		return nil, fmt.Errorf("%s has no open decision obligation", qid)
	}
	ok := false
	for _, r := range l.Cfg.DecisionResponders {
		ok = ok || r == by
	}
	if !ok {
		return nil, fmt.Errorf("%s is not a configured decision responder %v", by, l.Cfg.DecisionResponders)
	}
	c, have := p.Decision.Caps[by]
	d := sha256.Sum256([]byte(strings.TrimSpace(secret)))
	dig := hex.EncodeToString(d[:])
	if !have || secret == "" || subtle.ConstantTimeCompare([]byte(dig), []byte(c.Digest)) != 1 {
		return nil, fmt.Errorf("%s: no valid acknowledgement capability for %s (missing, wrong, stale or another incident's)", p.Decision.Incident, by)
	}
	now := l.now()
	if exp, ok := py.Instant(c.Exp); !ok || now.After(exp) {
		return nil, fmt.Errorf("%s: the capability for %s expired at %s", p.Decision.Incident, by, c.Exp)
	}
	if strings.TrimSpace(next) == "" {
		return nil, fmt.Errorf("--next must name the next action")
	}
	if within <= 0 || within > MaxDecisionAckWithin {
		return nil, fmt.Errorf("--within must be between 1s and %s", MaxDecisionAckWithin)
	}
	if a := p.Decision.Ack; a != nil {
		if a.By == by && a.Next == next && a.Cap == dig {
			return a, nil // replay
		}
		return nil, fmt.Errorf("%s was already acknowledged once by %s (%s); an acknowledgement is not renewed", p.Decision.Incident, a.By, a.Next)
	}
	p.Decision.Ack = &DecisionAck{By: by, Next: next, Deadline: py.ISO(now.Add(within)), At: py.ISO(now), Cap: dig}
	return p.Decision.Ack, l.save(p)
}
