package loop

import (
	"path/filepath"
	"strings"
	"testing"
)

// R23: the three questions reach the worker, the verifier and the director.
func TestNudgeReachesWorkerVerifierAndDirector(t *testing.T) {
	r := newRig(t)
	l := r.open()
	defer l.Close()
	_, err := l.Dispatch(Request{QID: "P1", Worker: "kiln", Verifier: "corvid", WorkerTask: "w", VerifyTask: "v", DurationS: 2400, VerifyS: 1200})
	must(t, err)
	r.clock.Advance(60)
	r.artifact("o", "x")
	_, err = l.Claim("P1", "worker", "completed", map[string]string{"o": "o"})
	must(t, err)
	r.turnEnd("K")
	r.tick(l)
	r.clock.Advance(60)
	r.artifact("r", "ok")
	_, err = l.Claim("P1", "verify", "completed", map[string]string{"r": "r"})
	must(t, err)
	r.turnEnd("C")
	r.tick(l)
	want := "What happens next, who does it, and by when?"
	seen := map[string]bool{}
	for _, c := range r.calls {
		if filepath.Base(c[0]) == "wake" && strings.Contains(c[2], want) {
			seen[c[1]] = true
		}
	}
	for _, id := range []string{"K", "C", "T"} {
		if !seen[id] {
			t.Fatalf("nudge missing for %s: %v", id, seen)
		}
	}
}
